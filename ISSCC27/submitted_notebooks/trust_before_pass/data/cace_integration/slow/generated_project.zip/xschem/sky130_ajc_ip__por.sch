v {xschem version=3.4.4 file_version=1.2}
G {}
K {}
V {}
S {}
E {}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 0 0 0 {name=p0 lab=avdd}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 30 0 0 {name=p1 lab=porb_h}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 60 0 0 {name=p2 lab=porb}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 90 0 0 {name=p3 lab=avss}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 120 0 0 {name=p4 lab=dvdd}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 150 0 0 {name=p5 lab=por}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 180 0 0 {name=p6 lab=dvss}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 210 0 0 {name=p7 lab=osc_ck}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 240 0 0 {name=p8 lab=vbg_1v2}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 270 0 0 {name=p9 lab=dcomp}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 300 0 0 {name=p10 lab=otrip[2]}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 330 0 0 {name=p11 lab=otrip[1]}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 360 0 0 {name=p12 lab=otrip[0]}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 390 0 0 {name=p13 lab=itest}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 420 0 0 {name=p14 lab=force_pdn}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 450 0 0 {name=p15 lab=pwup_filt}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 480 0 0 {name=p16 lab=vin}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 510 0 0 {name=p17 lab=force_ena_rc_osc}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 540 0 0 {name=p18 lab=force_dis_rc_osc}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 570 0 0 {name=p19 lab=startup_timed_out}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 600 0 0 {name=p20 lab=por_timed_out}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 630 0 0 {name=p21 lab=force_short_oneshot}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 660 0 0 {name=p22 lab=isrc_sel}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/iopin.sym} 0 690 0 0 {name=p23 lab=ibg_200n}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/code_shown.sym} 500 0 0 0 {name=body only_toplevel=false value=".include \"C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/cr/074008993577/xschem/dut_body.spice\""}
C {C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/xschem_runtime/xschem-3.4.4-win64/xschem_library/devices/code_shown.sym} 500 300 0 0 {name=dependencies only_toplevel=false place=end value=".include \"C:/Users/QuRYous/Documents/Codex/2026-10-13/open-source-analog-verification-opportunity-audit/work/cr/074008993577/xschem/dependencies.spice\""}
