#!/usr/bin/env python3
"""Export a real pretrained BERT layer on a machine with Hugging Face access.

Install in a Python 3.11 environment:
  python -m pip install "torch>=2.6" "transformers>=4.45,<5" "datasets>=3,<5" numpy safetensors
Run:
  python prepare_bert_layer.py

The resulting ZIP contains layer_npz inputs for the MXFP4 project. Exporting
does not run MXFP4 experiments or claim any accuracy or hardware result.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile


MODEL_ID = "google/bert_uncased_L-2_H-128_A-2"
DATASET_ID = "Salesforce/wikitext"
DATASET_CONFIG = "wikitext-2-raw-v1"
LAYER_NAME = "encoder.layer.0.intermediate.dense"


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def capture_vectors(model, tokenizer, layer, rows, split, target, seed,
                    max_length, tokens_per_sequence, excluded_hashes=()):
    import numpy as np
    import torch

    rng = np.random.default_rng(seed)
    captured = {}
    chunks = {k: [] for k in (
        "x", "source_row", "token_position", "token_id", "source_text_sha256"
    )}
    used_hashes = set()
    excluded_hashes = set(excluded_hashes)
    count = 0

    def hook(_module, inputs):
        captured["x"] = inputs[0].detach().cpu().numpy().copy()

    handle = layer.register_forward_pre_hook(hook)
    try:
        with torch.inference_mode():
            for row_index in rng.permutation(len(rows)):
                row_index = int(row_index)
                text = rows[row_index]["text"].strip()
                if not text or text.startswith("="):
                    continue
                text_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
                if text_hash in used_hashes or text_hash in excluded_hashes:
                    continue
                encoded = tokenizer(
                    text, truncation=True, max_length=max_length,
                    return_tensors="pt", return_special_tokens_mask=True,
                )
                special = encoded.pop("special_tokens_mask")[0].bool()
                valid = encoded["attention_mask"][0].bool() & ~special
                positions = valid.nonzero(as_tuple=True)[0].cpu().numpy()
                take = min(len(positions), tokens_per_sequence, target - count)
                if not take:
                    continue
                positions = np.sort(rng.choice(positions, take, replace=False))
                captured.clear()
                model(**encoded)
                if "x" not in captured:
                    raise RuntimeError(f"Input hook did not run for {LAYER_NAME}")
                x = captured["x"]
                if x.ndim != 3 or x.shape[0] != 1 or x.shape[2] != 128:
                    raise RuntimeError(f"Unexpected layer input shape: {x.shape}")
                chunks["x"].append(x[0, positions].astype(np.float32))
                chunks["source_row"].append(np.full(take, row_index, np.int64))
                chunks["token_position"].append(positions.astype(np.int64))
                chunks["token_id"].append(
                    encoded["input_ids"][0].cpu().numpy()[positions].astype(np.int64)
                )
                chunks["source_text_sha256"].append(np.full(take, text_hash, dtype="U64"))
                used_hashes.add(text_hash)
                count += take
                if count == target:
                    break
    finally:
        handle.remove()
    if count != target:
        raise RuntimeError(f"{split}: requested {target} vectors, collected {count}")
    arrays = {key: np.concatenate(value, axis=0) for key, value in chunks.items()}
    return arrays, {
        "split": split, "vectors": count, "source_sequence_count": len(used_hashes),
        "sampling_seed": seed, "maximum_tokens_per_sequence": tokens_per_sequence,
        "sampling_unit_note": "Multiple token vectors may come from the same source sequence; they are not independent observations.",
    }, used_hashes


def write_bundle(out, calibration, test, weights, bias, metadata):
    import numpy as np

    out = Path(out)
    archive = out.parent / (out.name + ".zip")
    if out.exists() or archive.exists():
        raise FileExistsError(f"Output already exists. Choose another --out: {out}")
    if weights.shape != (512, 128) or bias.shape != (512,):
        raise ValueError("Expected a 128 -> 512 dense layer")
    for split in (calibration, test):
        if split["x"].ndim != 2 or split["x"].shape[1] != 128:
            raise ValueError("Layer inputs must have shape [N, 128]")
        if split["x"].dtype != np.float32 or weights.dtype != np.float32:
            raise ValueError("X and W must be float32")
        if not np.isfinite(split["x"]).all():
            raise ValueError("Layer inputs contain nonfinite values")
    if not np.isfinite(weights).all() or not np.isfinite(bias).all():
        raise ValueError("Weights or bias contain nonfinite values")
    if set(calibration["source_text_sha256"]) & set(test["source_text_sha256"]):
        raise ValueError("Calibration and test contain identical source texts")
    out.mkdir(parents=True)
    for name, arrays in (("calibration", calibration), ("test", test)):
        # Existing mxacc consumes x and w. Bias is saved separately and is not
        # part of the dot-product accumulator or its accumulation-error budget.
        np.savez_compressed(out / f"{name}.npz", **arrays, w=weights, bias=bias)
    shutil.copyfile(Path(__file__), out / "prepare_bert_layer.py")
    metadata = dict(metadata)
    metadata["files"] = {
        p.name: {"sha256": sha256_file(p), "bytes": p.stat().st_size}
        for p in sorted(out.iterdir()) if p.is_file()
    }
    (out / "manifest.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.iterdir()):
            z.write(p, arcname=f"{out.name}/{p.name}")
    return archive


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--out", type=Path, default=Path("bert_tiny_ffn_k128"))
    parser.add_argument("--n-cal", type=int, default=512)
    parser.add_argument("--n-test", type=int, default=2048)
    parser.add_argument("--max-length", type=int, default=128)
    parser.add_argument("--tokens-per-sequence", type=int, default=16)
    parser.add_argument("--seed", type=int, default=20261018)
    parser.add_argument("--model-revision", default="main")
    parser.add_argument("--dataset-revision", default="main")
    args = parser.parse_args()
    if min(args.n_cal, args.n_test, args.tokens_per_sequence) <= 0 or not 3 <= args.max_length <= 512:
        parser.error("Counts must be positive; --max-length must be in [3, 512]")
    if args.out.exists() or (args.out.parent / (args.out.name + ".zip")).exists():
        parser.error("Output exists; choose another --out directory")
    try:
        import numpy as np
        import torch
        from datasets import load_dataset
        from huggingface_hub import HfApi
        from transformers import AutoModel, AutoTokenizer
    except ImportError as exc:
        raise SystemExit(
            f"Missing dependency: {exc}\nInstall with:\n"
            'python -m pip install "torch>=2.6" "transformers>=4.45,<5" "datasets>=3,<5" numpy safetensors'
        ) from exc

    torch.manual_seed(args.seed)
    torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))
    api = HfApi()
    print("Resolving exact model and dataset revisions ...", flush=True)
    model_revision = api.model_info(MODEL_ID, revision=args.model_revision).sha
    dataset_revision = api.dataset_info(DATASET_ID, revision=args.dataset_revision).sha
    if not model_revision or not dataset_revision:
        raise RuntimeError("Cannot establish source revisions")
    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_ID, revision=model_revision, use_fast=True, do_lower_case=True,
    )
    model = AutoModel.from_pretrained(
        MODEL_ID, revision=model_revision, use_safetensors=True,
        attn_implementation="eager",
    ).to("cpu").float().eval()
    layer = model.get_submodule(LAYER_NAME)
    weights = layer.weight.detach().cpu().numpy().astype(np.float32).copy()
    bias = layer.bias.detach().cpu().numpy().astype(np.float32).copy()
    if weights.shape != (512, 128):
        raise RuntimeError(f"Unexpected dense weight shape: {weights.shape}")
    dataset = load_dataset(DATASET_ID, DATASET_CONFIG, revision=dataset_revision)
    print("Capturing validation vectors for calibration ...", flush=True)
    cal, cal_info, cal_hashes = capture_vectors(
        model, tokenizer, layer, dataset["validation"], "validation", args.n_cal,
        args.seed, args.max_length, args.tokens_per_sequence,
    )
    print("Capturing held-out test vectors ...", flush=True)
    test, test_info, _ = capture_vectors(
        model, tokenizer, layer, dataset["test"], "test", args.n_test,
        args.seed + 1, args.max_length, args.tokens_per_sequence, cal_hashes,
    )
    metadata = {
        "id": args.out.name, "kind": "pretrained_transformer_layer", "k": 128,
        "outputs": 512,
        "description": "Real pretrained BERT first FFN dense layer; WikiText-2 text; CPU FP32 extraction.",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "model": {"id": MODEL_ID, "revision": model_revision, "layer": LAYER_NAME,
                  "mode": "eval", "device": "cpu", "dtype": "float32",
                  "attention_implementation": "eager", "license": "apache-2.0",
                  "url": f"https://huggingface.co/{MODEL_ID}"},
        "dataset": {"id": DATASET_ID, "config": DATASET_CONFIG, "revision": dataset_revision,
                    "url": f"https://huggingface.co/datasets/{DATASET_ID}"},
        "preprocessing": {"max_length": args.max_length, "truncation": True,
                          "exclude_padding_and_special_tokens": True,
                          "skip_blank_and_heading_rows": True,
                          "deduplicate_identical_source_texts_across_splits": True},
        "calibration": cal_info, "test": test_info,
        "contract": {"equation": "Y = X @ W.T", "x_shape": "[N,128]",
                     "w_shape": [512, 128], "bias": "saved separately; excluded from dot-product comparison",
                     "source_row": "row index in the pinned official split",
                     "token_position": "position in the truncated tokenizer output, including special-token offsets"},
        "scope": "Exports layer inputs and pretrained weights only. No fine-tuning, MXFP4 results, task-accuracy result or hardware qualification is claimed.",
        "python": sys.version,
        "packages": {name: version(name) for name in (
            "torch", "transformers", "datasets", "numpy", "huggingface_hub", "safetensors"
        )},
        "reproduce": {"seed": args.seed, "command": (
            f"python prepare_bert_layer.py --out bert_tiny_ffn_k128_reproduced "
            f"--n-cal {args.n_cal} --n-test {args.n_test} --max-length {args.max_length} "
            f"--tokens-per-sequence {args.tokens_per_sequence} --seed {args.seed} "
            f"--model-revision {model_revision} --dataset-revision {dataset_revision}"
        )},
    }
    archive = write_bundle(args.out, cal, test, weights, bias, metadata)
    print(f"Done: {archive.resolve()} ({archive.stat().st_size / 1024**2:.2f} MiB)")
    print(f"Calibration X: {cal['x'].shape}; test X: {test['x'].shape}; W: {weights.shape}")
    print("Upload this ZIP to the restricted environment and extract it.")
    print(f'In the MXFP4 notebook, set WORKLOAD = "/absolute/path/to/{args.out.name}"')
    print("The v0.3 notebook must also receive the previously identified workload-to-hardware data-flow fix.")


if __name__ == "__main__":
    main()
