"""Timing-driven selection experiment: implement candidates at a tighter clock.

Runs the same pinned flow and settings as scripts/run_flow.py, but at a clock
period different from the qualified comparison, under flow/timing_sweep/, and
writes results/timing_sweep/summary.json with post-route STA metrics only.
These runs are a labelled experiment for the selector's "no candidate meets
the clock" answer; they are never imported as cost candidates.
"""
from pathlib import Path
import argparse, json, os, re, subprocess, sys
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
from run_flow import physical_config, driver_command
from mxacc.implementation import sha256
from mxacc.physical import parse_metrics


def worst_path_summary(run_dir):
    """Return start/end points and a short cell chain of the worst SS-corner path."""
    sta = sorted(p for p in run_dir.iterdir() if p.is_dir() and p.name.endswith('-openroad-stapostpnr'))
    if not sta: return None
    rpt = sta[-1] / 'max_ss_125C_4v50' / 'max.rpt'
    if not rpt.exists(): return None
    text = rpt.read_text()
    start = re.search(r'Startpoint: (\S+)', text); end = re.search(r'Endpoint: (\S+)', text)
    cells = re.findall(r'\(gf180mcu_fd_sc_mcu7t5v0__(\w+)\)', text.split('data arrival time')[0])
    return {'startpoint': start[1] if start else None, 'endpoint': end[1] if end else None,
            'cells_on_path': len(cells), 'cell_types': cells[:60]}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--f', type=int, nargs='+', required=True)
    ap.add_argument('--clock-ns', type=float, required=True); ap.add_argument('--pdk-root', default=os.environ.get('PDK_ROOT'))
    ap.add_argument('--run-tag', default='sweep'); a = ap.parse_args()
    environment = json.loads((ROOT / 'flow/environment.json').read_text())
    out = ROOT / 'results/timing_sweep'; out.mkdir(parents=True, exist_ok=True)
    summary_path = out / 'summary.json'
    summary = json.loads(summary_path.read_text()) if summary_path.exists() else {'runs': []}
    for f in a.f:
        folder = ROOT / 'flow/timing_sweep' / f'f{f}_{a.clock_ns:g}ns'
        config_path = physical_config(f, a.clock_ns, folder)
        run_dir = folder / 'runs' / a.run_tag
        if run_dir.exists(): raise ValueError(f'{run_dir} exists; use a new --run-tag')
        command, env = driver_command(config_path, a.pdk_root, a.run_tag, environment)
        cp = subprocess.run(command, cwd=ROOT, env=env)
        metrics_path = run_dir / 'final/metrics.json'
        if not metrics_path.exists():
            summary['runs'].append({'f': f, 'clock_period_ns': a.clock_ns, 'verdict': 'flow_failed', 'exit_code': cp.returncode}); continue
        m = json.loads(metrics_path.read_text()); row = parse_metrics(m)
        resolved = json.loads((run_dir / 'resolved.json').read_text())
        verdict = ('meets clock at all corners' if row['setup_wns_ns'] is not None and row['setup_wns_ns'] >= 0 and row['hold_wns_ns'] >= 0
                   and row['max_slew_violations'] == 0 and row['max_cap_violations'] == 0 else 'fails')
        summary['runs'] = [r for r in summary['runs'] if not (r['f'] == f and r['clock_period_ns'] == a.clock_ns)]
        summary['runs'].append({'f': f, 'clock_period_ns': float(resolved['CLOCK_PERIOD']), 'stage': 'post_route_sta_experiment',
                                'cell_area_um2': row['cell_area_um2'], 'setup_ws_ns': row['setup_wns_ns'], 'hold_ws_ns': row['hold_wns_ns'],
                                'max_slew_violations': row['max_slew_violations'], 'max_cap_violations': row['max_cap_violations'],
                                'drc_errors': row['drc_errors'], 'lvs_errors': row['lvs_errors'],
                                'setup_ws_by_corner': {k.split(':')[1]: v for k, v in m.items() if k.startswith('timing__setup__ws__corner')},
                                'worst_path_max_ss': worst_path_summary(run_dir), 'verdict': verdict,
                                'rtl_sha256': sha256(ROOT / 'rtl/dot_top.sv'), 'run_dir': str(run_dir.relative_to(ROOT)),
                                'flow_exit_code': cp.returncode})
        print(json.dumps(summary['runs'][-1]), flush=True)
    summary['runs'].sort(key=lambda r: (r['clock_period_ns'], r['f']))
    summary['scope'] = ('Same RTL, PDK, die, I/O constraints and flow settings as the qualified 50 ns comparison, at a different clock. '
                        'Post-route STA experiment only: not a cost candidate, not imported into results/physical.')
    summary['conclusion'] = summary.get('conclusion', '')
    summary_path.write_text(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
