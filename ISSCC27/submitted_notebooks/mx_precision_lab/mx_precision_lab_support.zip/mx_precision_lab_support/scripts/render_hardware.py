"""Rebuild circuit views, layout views or the HTML evidence report of one configuration from the real artefacts.

  python scripts/render_hardware.py schematic evidence/generic_core/MXFP4_E2M1_W18_K128_P4     # Yosys + Graphviz (generic core job)
  python scripts/render_hardware.py schematic evidence/mxfp4_core/K128_F2                        # the MXFP4 core at F2 (flattened rtl/dot_top.sv)
  python scripts/render_hardware.py layout evidence/mxfp4_core/K128_F2 | <generic job with raw/layout.gds>
  python scripts/render_hardware.py report <job> --output hardware_evidence.html
"""
from pathlib import Path
import argparse, re, sys
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
from mxlab import visuals
from mxlab.backends import BACKENDS, join
from mxlab.numerics import load_layer
p = argparse.ArgumentParser(); p.add_argument('kind', choices=['schematic', 'layout', 'report']); p.add_argument('job', type=Path)
p.add_argument('--liberty', type=Path); p.add_argument('--output', type=Path); p.add_argument('--full', action='store_true'); p.add_argument('--k', type=int, default=128)
a = p.parse_args(); job = a.job.resolve()
mx = re.match(r'K(\d+)_F(\d+)$', job.name)
if a.kind == 'schematic':
    print(visuals.render_mxfp4_schematics(ROOT, int(mx[2]), int(mx[1])) if mx else visuals.render_generic_schematics(job, liberty=a.liberty, full=a.full))
elif a.kind == 'layout':
    print(visuals.render_mxfp4_layout(ROOT, int(mx[2]), int(mx[1])) if mx else visuals.render_generic_layout(job))
else:
    layer = load_layer(ROOT / 'data/mnist_fc2_subset')
    if mx:
        b = BACKENDS['mxfp4_core']; k, f = int(mx[1]), int(mx[2]); W = 14 + (k // 32 - 1).bit_length() + f; fmt = 'MXFP4_E2M1'; lanes = 4
        gds = ROOT / f'results/physical/f{f}/final/gds/dot_k{k}_f{f}.gds'; sha = b.rtl_sha256(ROOT)
    else:
        import json; b = BACKENDS['generic_core']; c = json.loads((job / 'contract.json').read_text()); k, W, fmt, lanes = c['k'], c['accumulator_bits'], c['format_x'], c['lanes']
        gds = job / 'raw/layout.gds'; sha = c['rtl_sha256']
    row = b.evaluate(layer, fmt, W, lanes=lanes) if layer.k == k else b.contract(fmt, k, lanes, W)
    row.setdefault('numerically_eligible', None); row = join([row], b.records(ROOT))[0]
    print(visuals.export_visual_report(ROOT, b, job, row, a.output or ROOT / 'hardware_evidence.html', sha, gds if gds.exists() else None))
