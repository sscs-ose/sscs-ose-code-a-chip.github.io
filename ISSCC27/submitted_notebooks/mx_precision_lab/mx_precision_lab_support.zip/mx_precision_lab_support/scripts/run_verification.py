from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from mxacc.hardware import verify
from mxacc.arithmetic import CANDIDATES
ap=argparse.ArgumentParser();ap.add_argument('--f',type=int,nargs='+',default=list(CANDIDATES));ap.add_argument('--random',type=int,default=1000);ap.add_argument('--output-dir',default='rtl')
a=ap.parse_args();rows=[]
for f in a.f:
    row=verify(ROOT,f,n=a.random,result_dir=a.output_dir);rows.append(row);print(json.dumps(row),flush=True)
bounded=ROOT/'results'/a.output_dir/'k128_f8_bounded/summary.json'
if not bounded.exists():verify(ROOT,8,n=a.random,e_bound=-5,result_dir=a.output_dir)
rows=[json.loads(p.read_text()) for p in sorted((ROOT/'results'/a.output_dir).glob('*/summary.json'))]
(ROOT/'results'/f'{a.output_dir}_summary.json').write_text(json.dumps(rows,indent=2))
