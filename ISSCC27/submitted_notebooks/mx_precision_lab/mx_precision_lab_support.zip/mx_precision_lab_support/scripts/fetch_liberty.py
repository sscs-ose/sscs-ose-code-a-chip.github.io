"""Build a reproducible 1x-drive GF180 Liberty subset for exploratory synthesis."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,urllib.request,time
ROOT=Path(__file__).resolve().parents[1]
REPO='google/globalfoundries-pdk-libs-gf180mcu_fd_sc_mcu7t5v0'
REV='43beb45e4d323a76239de436db2df6732e9a689b'
BASE=f'https://raw.githubusercontent.com/{REPO}/{REV}/'

def get(path):
    for attempt in range(3):
        try:
            with urllib.request.urlopen(BASE+path,timeout=40) as r:return r.read()
        except Exception:
            if attempt==2:raise
            time.sleep(1)

def main():
    target=ROOT/'tech';target.mkdir(exist_ok=True)
    api=f'https://api.github.com/repos/{REPO}/git/trees/{REV}?recursive=1'
    with urllib.request.urlopen(api,timeout=40) as r:tree=json.load(r)
    paths=sorted(v['path'] for v in tree['tree'] if v['path'].startswith('cells/') and v['path'].endswith('_1__tt_025C_5v00.lib'))
    header=get('liberty/gf180mcu_fd_sc_mcu7t5v0__tt_025C_5v00.lib').decode()
    assert header.rstrip().endswith('}')
    with ThreadPoolExecutor(max_workers=8) as ex:raw=list(ex.map(get,paths))
    combined=header.rstrip()[:-1]+'\n'+'\n'.join(r.decode() for r in raw)+'\n}\n'
    p=target/'gf180_1x_tt_5v00.lib';p.write_text(combined)
    (target/'LICENSE.gf180').write_bytes(get('LICENSE'))
    manifest={'repository':f'https://github.com/{REPO}','revision':REV,'corner':'tt_025C_5v00',
              'subset':'only drive-strength-1 cell variants; exploratory mapping, not the full PDK',
              'files':{n:hashlib.sha256(r).hexdigest() for n,r in zip(paths,raw)},
              'merged_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
    (target/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({'cells':len(paths),'bytes':p.stat().st_size,'file':str(p)}))

if __name__=='__main__':main()
