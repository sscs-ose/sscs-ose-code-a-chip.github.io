"""Burstiness study with the validated C++ performance model (v0.4, plan step 4).

  python scripts/run_perf_study.py [--backend cpp] [--quick]

Question: is the average recompute rate enough to choose the queue depth and the number of cores
sharing the exact unit, or does the burstiness of real requests change the answer?

For every workload (BERT F2, MNIST ReLU F2, MNIST GELU/LN F2 as real layers; outlier F4 as a stress
family) the same calibration transactions are issued in three orders - original activation/channel
order, a per-core seeded shuffle, and an artificial burst order (all flagged transactions of a core
contiguous) - over N in {4,8,16,32} x Q in {1,2,4,8,16}, with saturated inputs and no external
stalls (base curves) and once more with fixed input/return back-pressure masks (robustness). Every
number is a measured C++ result; the analytic load rho0 = N*p*S0/II0 is a screen only. Configurations
outside the RTL-validated set are labelled 'architecture exploration prediction'.

Outputs: results/perf/study.json, study_table.md, perf_fig1..4 (png/svg); stimulus files are
written under build/perf_study/ (regenerable, hashes recorded) and not kept in the release.
"""
from pathlib import Path
import argparse, hashlib, json, shutil, sys, time
import numpy as np
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
from mxacc.perf_stimulus import real_case, threshold, build_masks, masks_to_lines, DEV_CONFIGS, HELDOUT_CONFIGS
from mxacc.perf_backend import run_generated, find_binary, binary_info
from mxacc.system import simulate as legacy_simulate

WORKLOADS = [('bert_tiny_ffn_k128', 2, 'real layer'), ('mnist_relu_fc2', 2, 'real layer'), ('mnist_gelu_ln_fc2', 2, 'real layer'), ('syn_outlier_k128', 4, 'stress family')]
ORDERINGS = ('original', 'shuffled', 'burst')
NS = (4, 8, 16, 32); QS = (1, 2, 4, 8, 16)
VALIDATED = set(DEV_CONFIGS) | set(HELDOUT_CONFIGS)
SATURATED = {k: threshold(1.0) for k in ('ret', 'start', 'meta', 'data', 'out')}
ROBUST = {'ret': threshold(0.7), 'start': threshold(0.9), 'meta': threshold(0.9), 'data': threshold(0.9), 'out': threshold(0.9)}
ROBUST_SEED = 20261018


def stimulus(scratch, wl, f, n, ordering, split='calibration', tx_per_core=None):
    """Light stimulus (no payload) for the C++ model; returns (dir, manifest)."""
    from mxacc.workloads import load_workload
    w = load_workload(ROOT, wl); x = w['x_cal'] if split == 'calibration' else w['x_test']
    total = len(x) * w['outputs']
    per_core = tx_per_core or total // n
    name = f'S_{wl}_f{f}_{split}_{ordering}_n{n}'
    d = scratch / name
    if (d / 'manifest.json').exists():
        return d, json.loads((d / 'manifest.json').read_text())
    man, _ = real_case(ROOT, d, wl, n, 1, f, tx_per_core=per_core, split=split, ordering=ordering, name=name, light=True)
    return d, man


TWINS = {}


def no_flag_twin(scratch, out_dir, exe, wl, f, n, masks, split, p, window, max_cycles):
    """Same transactions, same masks, every flag forced to 0: the throughput reference for 'loss due to recompute'."""
    key = (wl, f, n, split, 'sat' if masks is SATURATED else 'robust')
    if key in TWINS: return TWINS[key]
    src = scratch / f'S_{wl}_f{f}_{split}_original_n{n}'; d = scratch / f'S_{wl}_f{f}_{split}_noflags_n{n}'
    if not (d / 'manifest.json').exists():
        d.mkdir(parents=True, exist_ok=True)
        for c in range(n):
            rows = []
            for l in (src / f'tx_c{c}.txt').read_text().splitlines():
                parts = l.split()
                if parts: parts[3] = '0'; parts[4] = '0'; rows.append(' '.join(parts))
            (d / f'tx_c{c}.txt').write_text('\n'.join(rows) + '\n')
        (d / 'manifest.json').write_text(json.dumps({'twin_of': src.name, 'note': 'inexact and ooc columns forced to 0'}))
    pp = dict(p); pp['q'] = 1
    s = run_generated(ROOT, d, out_dir / f"{wl}_f{f}_{split}_noflags_n{n}_{key[4]}", pp, ROBUST_SEED, masks, max_cycles, window=window, exe=exe)
    TWINS[key] = s['window']['useful_throughput_per_cycle']; return TWINS[key]


def run_point(scratch, out_dir, exe, wl, f, n, q, ordering, masks, split='calibration'):
    d, man = stimulus(scratch, wl, f, n, ordering, split)
    p = dict(man['params']); p['q'] = q
    per_core = max(man['stats']['per_core']); ii0 = p['ii0']
    p_in = min(1 - masks[k] / 65536 for k in ('start', 'meta', 'data', 'out'))
    t_nom = per_core * ii0 / max(p_in, 0.05)
    window = (1000, int(0.9 * t_nom))
    max_cycles = int(t_nom * 1.5 + n * per_core * p['s0'] / max(1 - masks['ret'] / 65536, 0.1) + 5000)
    tag = f"{wl}_f{f}_{split}_{ordering}_n{n}_q{q}_{'sat' if masks is SATURATED else 'robust'}"
    s = run_generated(ROOT, d, out_dir / tag, p, ROBUST_SEED, masks, max_cycles, window=window, exe=exe)
    ideal = n / ii0
    ref = no_flag_twin(scratch, out_dir, exe, wl, f, n, masks, split, p, window, max_cycles)
    win = s['window']; lat = win['recompute_latency']
    flagged = man['stats']['flagged']; total = man['stats']['transactions']; pflag = flagged / total if total else 0
    row = {'workload': wl, 'f': f, 'split': split, 'ordering': ordering, 'n': n, 'q': q, 'masks': 'saturated' if masks is SATURATED else 'robust',
           'validated_config': (n, q) in VALIDATED, 'scope': 'RTL-validated (N,Q)' if (n, q) in VALIDATED else 'architecture exploration prediction',
           'transactions': total, 'flagged': flagged, 'flagged_fraction': pflag, 'per_core_flagged': man['workload']['per_core_flagged'],
           'rho0': n * pflag * p['s0'] / ii0, 'status': s['status'], 'cycles': s['cycles'], 'makespan': s['batch']['makespan_cycles'],
           'window': [win['start'], win['end']], 'window_completed': win['completed_in_window'], 'window_useful': win['useful_completed_in_window'],
           'throughput_fraction': win['useful_throughput_per_cycle'] / ideal, 'throughput_loss_vs_ideal_pct': 100 * (1 - win['useful_throughput_per_cycle'] / ideal),
           'no_flag_throughput_fraction': ref / ideal, 'throughput_loss_pct': max(0.0, 100 * (1 - win['useful_throughput_per_cycle'] / ref)) if ref > 0 else None,
           'batch_throughput_fraction': s['batch']['useful_throughput_per_cycle'] / ideal,
           'cohort': win['cohort'], 'rc_count': lat['count'], 'rc_p50': lat['p50'], 'rc_p90': lat['p90'], 'rc_p99': lat['p99'], 'rc_max': lat['max'], 'rc_mean': lat['mean'],
           'rc_sample_ok': (lat['count'] or 0) >= 1000, 'queue_wait_p99': win['queue_wait']['p99'], 'queue_wait_count': win['queue_wait']['count'],
           'e2e_p99': win['e2e_latency']['p99'], 'queue_peak': s['queue']['peak'], 'occupancy_cycles': s['queue']['occupancy_cycles'],
           'merge_busy_fraction': s['merge']['compute_busy_fraction'], 'merge_blocked_fraction': s['merge']['output_blocked_fraction'],
           'multi_request_cycles': s['arbiter']['multi_request_cycles'], 'max_simultaneous_requests': s['arbiter']['max_simultaneous_requests'],
           'stalls': s['stalls'], 'traffic_bits': s['traffic_bits'], 'multiset_sha256': man['multiset_sha256'], 'stimulus_files': man['files'],
           'binary_sha256': s['provenance']['binary']['sha256'][:16]}
    return row


def legacy_comparison(scratch, rows):
    """The v0.3.3 Python cycle model on the same flag sequences (no stalls): what its simplifications cost."""
    out = []
    for r in rows:
        if r['masks'] != 'saturated' or r['ordering'] != 'original' or r['split'] != 'calibration' or (r['n'], r['q']) not in ((4, 2), (16, 2), (16, 4)) or r['workload'] not in ('bert_tiny_ffn_k128', 'syn_outlier_k128'): continue
        d = scratch / f"S_{r['workload']}_f{r['f']}_calibration_original_n{r['n']}"
        flags = []
        for c in range(r['n']):
            flags.append([int(l.split()[3]) for l in (d / f'tx_c{c}.txt').read_text().splitlines() if l.strip()])
        t0 = time.time(); leg = legacy_simulate(flags, q=r['q']); t_leg = time.time() - t0
        out.append({'workload': r['workload'], 'n': r['n'], 'q': r['q'], 'legacy': {'throughput_loss_pct': leg['throughput_loss_pct'], 'latency_p99': leg['latency_p99'], 'queue_peak': leg['queue_peak'], 'runtime_s': round(t_leg, 2)},
                    'cpp': {'throughput_loss_pct': r['throughput_loss_pct'], 'rc_p99': r['rc_p99'], 'queue_peak': r['queue_peak']},
                    'note': 'legacy: whole transaction = II cycles, result taken the cycle it completes, percentile = numpy linear interpolation, latency = completion->return; C++: validated handshakes, nearest-rank P99 of return_handshake - record_first_valid over the window cohort'})
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--backend', default='cpp', choices=['cpp']); ap.add_argument('--quick', action='store_true'); ap.add_argument('--out', default='results/perf')
    ap.add_argument('--scratch', default='build/perf_study'); a = ap.parse_args()
    out = ROOT / a.out; out.mkdir(parents=True, exist_ok=True); scratch = ROOT / a.scratch; scratch.mkdir(parents=True, exist_ok=True)
    runs = out / 'study_runs'; runs.mkdir(exist_ok=True)
    exe = find_binary(ROOT); info = binary_info(exe); print('== C++ model:', info['version_line'], info['sha256'][:16], flush=True)
    ns = (4, 16) if a.quick else NS; qs = (1, 2, 4) if a.quick else QS
    rows = []; t0 = time.time()
    for wl, f, kind in WORKLOADS:
        for ordering in ORDERINGS:
            for n in ns:
                # multiset check across orderings: same transactions per core
                for q in qs:
                    for masks in (SATURATED, ROBUST):
                        if masks is ROBUST and q not in (1, 2, 4): continue
                        r = run_point(scratch, runs, exe, wl, f, n, q, ordering, masks); r['kind'] = kind; rows.append(r)
                        print(f"   {wl} F{f} {ordering:8s} N={n:2d} Q={q:2d} {r['masks']:9s} loss={r['throughput_loss_pct']:6.2f}% P99={r['rc_p99']} (n={r['rc_count']}) peak={r['queue_peak']} rho0={r['rho0']:.3f}", flush=True)
    # multiset assertion: for each workload and N, the three orderings carry the same per-core transaction multiset
    multiset_ok = True
    for wl, f, kind in WORKLOADS:
        for n in ns:
            hs = {r['ordering']: r['multiset_sha256'] for r in rows if r['workload'] == wl and r['n'] == n and r['q'] == qs[0] and r['masks'] == 'saturated'}
            if len(set(hs.values())) != 1: multiset_ok = False; print('!! multiset differs', wl, n, hs)
    legacy = legacy_comparison(scratch, rows)
    from mxacc.provenance import source_hashes, STUDY_SOURCES
    study = {'version': '0.4.2', 'source_sha256': source_hashes(ROOT, STUDY_SOURCES), 'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'cpp_binary': info, 'contract': 'docs/perf_contract.md',
             'contract_sha256': hashlib.sha256((ROOT / 'docs/perf_contract.md').read_bytes()).hexdigest(), 'quick': a.quick,
             'validated_configs': sorted(VALIDATED), 'ns': list(ns), 'qs': list(qs), 'orderings': list(ORDERINGS), 'masks': {'saturated': SATURATED, 'robust': ROBUST, 'robust_seed': ROBUST_SEED},
             'loss_rule': 'throughput loss = 1 - useful window throughput / useful window throughput of the no-flag twin (same transactions, same masks, every flag forced to 0); loss vs the ideal N/II0 is reported separately',
             'window_rule': 'start = 1000 cycles; end = 0.9 x (per-core transactions x II0 / min input offer probability); cohort = transactions whose start is inside; throughput = useful completions inside / window length',
             'percentile_rule': 'nearest rank: the ceil(p*n)-th sorted value; null when count = 0; rc_sample_ok marks >= 1000 recompute completions',
             'multiset_identical_across_orderings': multiset_ok, 'rows': rows, 'legacy_python_model': legacy, 'wall_s': round(time.time() - t0, 1)}
    (out / 'study.json').write_text(json.dumps(study, indent=1))
    (out / 'study_table.md').write_text(study_table(study))
    figures(study, out)
    print(f"== study done: {len(rows)} runs, multiset identical: {multiset_ok}, {study['wall_s']} s")


def study_table(st):
    rows = st['rows']
    lines = ['| workload | F | order | N | Q | masks | scope | flagged % | rho0 | thr. loss vs no-flag twin % | P50 | P99 | n(rc) | queue peak | merge busy % | multi-req cycles |', '|' + '---|' * 16]
    for r in rows:
        if r['q'] not in (1, 2, 4, 16) or r['n'] not in (4, 16, 32): continue
        p99 = 'N/A' if r['rc_p99'] is None else str(r['rc_p99']) + ('' if r['rc_sample_ok'] else '*')
        lines.append(f"| {r['workload']} | {r['f']} | {r['ordering']} | {r['n']} | {r['q']} | {r['masks']} | {'validated' if r['validated_config'] else 'exploration'} | {100 * r['flagged_fraction']:.2f} | {r['rho0']:.3f} | {r['throughput_loss_pct']:.2f} | {r['rc_p50'] if r['rc_p50'] is not None else 'N/A'} | {p99} | {r['rc_count']} | {r['queue_peak']} | {100 * r['merge_busy_fraction']:.1f} | {r['multi_request_cycles']} |")
    lines.append(''); lines.append('* fewer than 1,000 recompute completions in the window cohort: tail estimate from a small sample (count shown).')
    lines.append(''); lines.append('Legacy v0.3.3 Python cycle model on the same flag sequences (no stalls):'); lines.append('')
    lines.append('| workload | N | Q | legacy loss % | C++ loss % | legacy P99 | C++ P99 (window cohort) | legacy peak | C++ peak |'); lines.append('|---|---|---|---|---|---|---|---|---|')
    for l in st['legacy_python_model']:
        lines.append(f"| {l['workload']} | {l['n']} | {l['q']} | {l['legacy']['throughput_loss_pct']:.2f} | {l['cpp']['throughput_loss_pct']:.2f} | {l['legacy']['latency_p99']:.1f} | {l['cpp']['rc_p99']} | {l['legacy']['queue_peak']} | {l['cpp']['queue_peak']} |")
    return '\n'.join(lines) + '\n'


# ------------------------------------------------------------------ figures
C_ORDER = {'original': '#2a78d6', 'shuffled': '#1baf7a', 'burst': '#eb6834'}   # validated categorical slots 1, 3, 2 (dataviz palette)
SEQ = ['#cde2fb', '#9ec5f4', '#6da7ec', '#3987e5', '#256abf', '#184f95', '#0d366b']


def figures(st, out):
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import LinearSegmentedColormap, LogNorm
    plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True, 'grid.color': '#e6e6e3', 'grid.linewidth': 0.6, 'axes.edgecolor': '#9a9a96'})
    rows = [r for r in st['rows'] if r['masks'] == 'saturated']
    wls = [(w, f) for w, f, _ in WORKLOADS]
    # ---- Fig 1: cycle match (representative trace window + per-case summary)
    fig1_cycle_match(out, plt)
    # ---- Fig 2: same rate, different order (N = 16, Q = 2 reference point; three metrics)
    n0, q0 = 16, 2
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.4))
    metrics = [('rc_p99', 'P99 recompute latency (cycles)'), ('queue_peak', 'queue peak (records)'), ('throughput_loss_pct', 'throughput loss vs ideal (%)')]
    labels = ['BERT F2', 'ReLU F2', 'GELU/LN F2', 'outlier F4']
    for ax, (key, title) in zip(axes, metrics):
        for j, ordering in enumerate(ORDERINGS):
            vals = []; notes = []
            for w, f in wls:
                r = next((r for r in rows if r['workload'] == w and r['f'] == f and r['ordering'] == ordering and r['n'] == n0 and r['q'] == q0), None)
                v = None if r is None else r[key]; vals.append(np.nan if v is None else v); notes.append('' if r is None or key != 'rc_p99' else ('' if r['rc_sample_ok'] else f"n={r['rc_count']}"))
            x = np.arange(len(wls)) + (j - 1) * 0.27
            ax.bar(x, vals, width=0.25, color=C_ORDER[ordering], label=ordering, linewidth=0)
            for xi, v, nt in zip(x, vals, notes):
                if nt: ax.text(xi, (0 if np.isnan(v) else v), nt, ha='center', va='bottom', fontsize=6.5, color='#52514e', rotation=90)
        ax.set_xticks(range(len(wls))); ax.set_xticklabels(labels, fontsize=8); ax.set_title(title, fontsize=9); ax.set_axisbelow(True)
        if key == 'rc_p99': ax.set_yscale('log')
    axes[0].legend(frameon=False, fontsize=8, title=f'issue order (N={n0}, Q={q0})', title_fontsize=8)
    fig.suptitle('Same transactions, same recompute rate, three issue orders: what the average rate misses', fontsize=10)
    fig.tight_layout(); fig.savefig(out / 'perf_fig2_ordering.png', dpi=160); fig.savefig(out / 'perf_fig2_ordering.svg'); plt.close(fig)
    # ---- Fig 3: N x Q heatmaps of P99 recompute latency, original vs burst, two workloads
    cmap = LinearSegmentedColormap.from_list('seqblue', SEQ)
    pairs = [('bert_tiny_ffn_k128', 2, 'BERT F2'), ('syn_outlier_k128', 4, 'outlier F4')]
    fig, axes = plt.subplots(2, 2, figsize=(9.2, 7.6))
    fig.subplots_adjust(hspace=0.42, wspace=0.3, top=0.88, right=0.86)
    ns, qs = st['ns'], st['qs']
    vmax = max((r['rc_p99'] or 1) for r in rows if r['workload'] in [p[0] for p in pairs])
    for i, (w, f, lab) in enumerate(pairs):
        for j, ordering in enumerate(('original', 'burst')):
            ax = axes[i][j]; grid = np.full((len(ns), len(qs)), np.nan); sat = np.zeros_like(grid, dtype=bool)
            for a_, n in enumerate(ns):
                for b_, q in enumerate(qs):
                    r = next((r for r in rows if r['workload'] == w and r['f'] == f and r['ordering'] == ordering and r['n'] == n and r['q'] == q), None)
                    if r and r['rc_p99'] is not None: grid[a_, b_] = r['rc_p99']; sat[a_, b_] = r['throughput_loss_pct'] > 5
            im = ax.imshow(grid, cmap=cmap, norm=LogNorm(vmin=5, vmax=vmax), aspect='auto')
            ax.set_xticks(range(len(qs))); ax.set_xticklabels(qs); ax.set_yticks(range(len(ns))); ax.set_yticklabels(ns); ax.grid(False)
            ax.set_xlabel('queue depth Q'); ax.set_ylabel('cores N'); ax.set_title(f'{lab}, {ordering} order', fontsize=9)
            for a_, n in enumerate(ns):
                for b_, q in enumerate(qs):
                    v = grid[a_, b_]
                    if not np.isnan(v): ax.text(b_, a_, f'{int(v)}' + ('!' if sat[a_, b_] else ''), ha='center', va='center', fontsize=7, color='#0b0b0b' if v < vmax ** 0.6 else '#f0efec')
                    if (n, q) in VALIDATED: ax.add_patch(plt.Rectangle((b_ - 0.5, a_ - 0.5), 1, 1, fill=False, edgecolor='#0b0b0b', linewidth=1.4))
    cax = fig.add_axes([0.89, 0.15, 0.02, 0.6]); cb = fig.colorbar(im, cax=cax); cb.set_label('P99 recompute latency (cycles, log)')
    fig.suptitle('N x Q boundary: P99 recompute latency (window cohort). Outlined cells: RTL-validated (N,Q); others: architecture exploration.\n"!" = > 5 % throughput loss vs the no-flag twin (shared unit saturating)', fontsize=9)
    fig.savefig(out / 'perf_fig3_nq_heatmap.png', dpi=160, bbox_inches='tight'); fig.savefig(out / 'perf_fig3_nq_heatmap.svg', bbox_inches='tight'); plt.close(fig)
    # ---- Fig 4: logical payload traffic per useful dot (by component) and the measured full-cost area per core
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.8))
    ax = axes[0]; n0 = 16; q0 = 2
    comps = [('core_record_write', 'core record write (every transaction)', SEQ[5]), ('core_to_queue', 'core -> queue (flagged only)', SEQ[3]), ('queue_to_merge', 'queue -> merge (flagged only)', SEQ[1])]
    for j, (key, lab, col) in enumerate(comps):
        vals = []
        for w, f in wls:
            r = next((r for r in rows if r['workload'] == w and r['f'] == f and r['ordering'] == 'original' and r['n'] == n0 and r['q'] == q0), None)
            vals.append(np.nan if r is None else max(r['traffic_bits']['per_useful_dot'][key], 1e-3))
        x = np.arange(len(wls)) + (j - 1) * 0.27
        ax.bar(x, vals, width=0.25, color=col, label=lab, linewidth=0)
        for xi, v in zip(x, vals):
            if not np.isnan(v): ax.text(xi, v, f'{v:.3g}', ha='center', va='bottom', fontsize=6.5, color='#52514e')
    ax.set_yscale('log'); ax.set_xticks(range(len(wls))); ax.set_xticklabels(labels, fontsize=8); ax.set_ylabel('logical payload bits per useful dot product (log)')
    rec_w = next(r for r in rows if r['n'] == n0)['traffic_bits']['record_width']
    ax.set_title(f'Logical payload traffic, N={n0}, Q={q0} (record = {rec_w} bits; configured queue = Q x {rec_w} bits). Not DRAM, switching or power.', fontsize=8.5)
    ax.legend(frameon=False, fontsize=7.5, loc='upper right')
    ax = axes[1]
    try:
        sysst = json.loads((ROOT / 'results/system/study.json').read_text()); pc = sysst['per_core_cost']['post_route']; f6 = sysst['components']['fixed']['f6']['post_route']
        meas = [(int(k), v['per_core_total']) for k, v in pc.items() if 'measured' in v['source']]; est = [(int(k), v['per_core_total']) for k, v in pc.items() if 'measured' not in v['source']]
        if meas: ax.scatter([m[0] for m in meas], [m[1] for m in meas], marker='s', s=42, color='#2a78d6', label='measured full top (post-route)', zorder=3)
        if est: ax.scatter([m[0] for m in est], [m[1] for m in est], marker='^', s=42, facecolors='none', edgecolors='#2a78d6', label='component-scaled estimate', zorder=3)
        ax.axhline(f6, color='#eb6834', lw=1.6, label='fixed F6 core (routed, no recompute)')
        ax.set_xscale('log', base=2); ax.set_xticks(ns); ax.set_xticklabels(ns); ax.set_xlabel('cores N sharing one exact unit'); ax.set_ylabel('area per core (um^2)')
        ax.set_title('Cost side (v0.3.3 measurements): per-core area of the recompute system', fontsize=9); ax.legend(frameon=False, fontsize=8)
    except Exception as e:
        ax.text(0.5, 0.5, f'area data unavailable: {e}', ha='center', va='center', transform=ax.transAxes)
    fig.tight_layout(); fig.savefig(out / 'perf_fig4_traffic_cost.png', dpi=160); fig.savefig(out / 'perf_fig4_traffic_cost.svg'); plt.close(fig)


def fig1_cycle_match(out, plt):
    """RTL vs C++ queue occupancy and handshakes on a congested window of a kept representative trace + the per-case verdicts."""
    from mxacc.perf_trace import Trace
    val = ROOT / 'results/perf/validation'; summ = ROOT / 'results/perf/validation_summary.json'
    case = 'B_all_flagged_n4_q2_k128_f2'
    fig, axes = plt.subplots(2, 1, figsize=(10, 5.2), gridspec_kw={'height_ratios': [3, 2]})
    ax = axes[0]
    if (val / case / 'cycles_rtl.csv').exists() and (val / case / 'cycles_cpp.csv').exists():
        tr = Trace(val / case / 'cycles_rtl.csv'); tc = Trace(val / case / 'cycles_cpp.csv')
        lo, hi = 30, 230
        t = tr.g['cycle'][lo:hi]
        ax.step(t, tr.g['qcount'][lo:hi], where='post', color='#2a78d6', lw=2.0, label='RTL (Icarus) queue occupancy')
        ax.step(t, tc.g['qcount'][lo:hi], where='post', color='#eb6834', lw=1.2, ls='--', label='C++ model queue occupancy')
        g = np.nonzero(tr.g['enq'][lo:hi])[0] + lo; p = np.nonzero(tr.g['pop'][lo:hi])[0] + lo; rh = np.nonzero(tr.g['ret_hs'][lo:hi])[0] + lo
        ax.scatter(g, np.full(len(g), -0.35), marker='|', s=60, color='#2a78d6', label='RTL enqueue'); ax.scatter(p, np.full(len(p), -0.6), marker='|', s=60, color='#1baf7a', label='RTL merge accept')
        ax.scatter(rh, np.full(len(rh), -0.85), marker='|', s=60, color='#eda100', label='RTL return handshake')
        gc = np.nonzero(tc.g['enq'][lo:hi])[0] + lo; pc = np.nonzero(tc.g['pop'][lo:hi])[0] + lo; rc = np.nonzero(tc.g['ret_hs'][lo:hi])[0] + lo
        ax.scatter(gc, np.full(len(gc), -0.35), marker='_', s=40, color='#eb6834'); ax.scatter(pc, np.full(len(pc), -0.6), marker='_', s=40, color='#eb6834'); ax.scatter(rc, np.full(len(rc), -0.85), marker='_', s=40, color='#eb6834')
        ax.set_ylim(-1.1, 2.4); ax.set_yticks([0, 1, 2]); ax.set_xlabel('cycle'); ax.set_ylabel('queue occupancy'); ax.legend(frameon=False, fontsize=7.5, ncol=5, loc='lower center', bbox_to_anchor=(0.5, 1.0))
        ax.text(0.0, 1.14, f'{case}: N=4, Q=2, every transaction flagged, return port stalled at random - cycles {lo}-{hi}', fontsize=9, transform=ax.transAxes)
    else:
        ax.text(0.5, 0.5, 'representative trace not kept', ha='center', va='center', transform=ax.transAxes)
    ax = axes[1]
    if summ.exists():
        s = json.loads(summ.read_text()); cases = [c for c in s['cases'] if c.get('events')]
        xs = np.arange(len(cases)); ev = [c['events']['rtl_vs_cpp']['compared'] for c in cases]; dl = [c['events']['rtl_vs_cpp']['max_abs_cycle_delta'] for c in cases]
        cols = ['#2a78d6' if c['config_role'] == 'development' else '#1baf7a' for c in cases]
        ax.bar(xs, ev, color=cols, linewidth=0, width=0.8); ax.set_yscale('log'); ax.set_ylabel('events compared (log)'); ax.set_xlabel(f'validation case ({len(cases)} cases: blue = development configs, aqua = held-out configs)')
        ax.set_xticks([]); ax.set_title(f"max |cycle delta| over all cases = {max(dl)}; per-cycle traces identical in {sum(c['cycle_trace_identical'] for c in cases)}/{len(cases)} cases; {sum(ev):,} events", fontsize=9)
    fig.tight_layout(); fig.savefig(out / 'perf_fig1_cycle_match.png', dpi=160); fig.savefig(out / 'perf_fig1_cycle_match.svg'); plt.close(fig)


if __name__ == '__main__':
    main()
