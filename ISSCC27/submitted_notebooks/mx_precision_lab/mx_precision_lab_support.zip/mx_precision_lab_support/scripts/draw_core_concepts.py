"""Rebuild Figures 3 and 4 as vector artwork and notebook PNGs.

These are conceptual views checked against rtl/dot_top.sv and
src/mxlab/hardware.py. Actual synthesized netlists are shown by Section 6.
Run from any directory: python scripts/draw_core_concepts.py
"""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle

ROOT = Path(__file__).resolve().parents[1]
INK = '#203449'
MUTED = '#566777'
BLUE = '#356787'
BLUE_BG = '#EFF5FA'
GREEN = '#247B69'
GREEN_BG = '#EDF7F3'
ORANGE = '#B86A27'
ORANGE_BG = '#FFF6EA'
GREY = '#CBD4DD'

plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 10,
    'mathtext.fontset': 'dejavusans', 'text.color': INK,
    'svg.fonttype': 'none', 'pdf.fonttype': 42,
    'axes.unicode_minus': True,
})


def text(ax, x, y, value, size=10, color=INK, weight='normal', ha='center', **kw):
    return ax.text(x, y, value, fontsize=size, color=color, weight=weight,
                   ha=ha, va='center', **kw)


def box(ax, x, y, w, h, title, detail, color=BLUE, fill=BLUE_BG, dashed=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h,
        boxstyle='round,pad=0.02,rounding_size=0.09',
        linewidth=1.35, edgecolor=color, facecolor=fill,
        linestyle=(0, (4, 3)) if dashed else 'solid'))
    text(ax, x + w/2, y + h - .29, title, 10.5, weight='bold')
    text(ax, x + w/2, y + h/2 - .16, detail, 9.5, color=MUTED,
         linespacing=1.65)


def arrow(ax, points, color=INK, dashed=False, width=1.35, head=True):
    for j in range(len(points)-1):
        last = j == len(points)-2
        ax.add_patch(FancyArrowPatch(points[j], points[j+1],
            arrowstyle='-|>' if last and head else '-',
            mutation_scale=11, linewidth=width, color=color,
            linestyle=(0, (4, 3)) if dashed else 'solid',
            shrinkA=0, shrinkB=0, capstyle='round', joinstyle='miter'))


def register_mark(ax, x, y, w, h, color):
    ax.plot([x+w-.15, x+w-.15], [y+.11, y+h-.11], color=color, lw=1)


def legend(ax):
    entries = [(0.25, BLUE, BLUE_BG, 'Exact block arithmetic'),
               (3.65, GREEN, GREEN_BG, 'Precision-dependent logic'),
               (7.75, ORANGE, ORANGE_BG, 'Loss / inexact flag')]
    for x, color, bg, label in entries:
        ax.add_patch(FancyBboxPatch((x, .13), .20, .16,
            boxstyle='round,pad=0.01,rounding_size=0.02',
            facecolor=bg, edgecolor=color, linewidth=1.1))
        text(ax, x+.31, .21, label, 8.3, MUTED, ha='left')
    text(ax, 14.35, .21, 'Conceptual datapath', 8.3, MUTED, ha='right')


def build(generic=False):
    fig = plt.figure(figsize=(14.6, 6.1), facecolor='white')
    ax = fig.add_axes([.015, .025, .97, .95])
    ax.set(xlim=(0, 14.6), ylim=(0, 6.0)); ax.axis('off')
    title = 'Generic MX core' if generic else 'MXFP4 core'
    subtitle = ('Six encodings  /  configurable P lanes and W-bit accumulation'
                if generic else 'K = 128  /  P = 4 lanes  /  four exact dot32 blocks')
    text(ax, .25, 5.73, title, 17, weight='bold', ha='left')
    text(ax, .25, 5.39, subtitle, 10.2, MUTED, ha='left')
    ax.plot([.25, 14.35], [5.13, 5.13], color=GREY, lw=.85)

    # Metadata is a separate input stream, collected before the data phase.
    text(ax, .25, 4.58, 'E8M0 scales', 10, weight='bold', ha='left')
    text(ax, .25, 4.28, r'$s_{x,g},\ s_{w,g}$', 12, ha='left')
    box(ax, 2.25, 4.05, 3.7, .84, 'Scale decode + exponent state',
        r'$E_g$ bank     |     $E_{\max}=\max_g E_g$', color=BLUE, fill=BLUE_BG)
    arrow(ax, [(1.62, 4.46), (2.22, 4.46)], BLUE)
    arrow(ax, [(5.98, 4.46), (8.65, 4.46), (8.65, 3.54)], BLUE)
    text(ax, 7.28, 4.67, r'$d_g=F+E_g-E_{\max}$', 11, color=BLUE)
    text(ax, 10.0, 4.62, 'Metadata first; data follow', 9, MUTED, ha='left')
    text(ax, 10.0, 4.27,
         r'$F=W-S_B-\lceil\log_2 B\rceil$' if generic else r'$W=16+F$',
         12, color=GREEN, ha='left')

    # Common placement, typography and signal semantics in both figures.
    y, h = 2.20, 1.30
    xs = [1.75, 4.13, 7.48, 10.24]
    ws = [1.95, 2.18, 2.30, 2.05]
    text(ax, .25, 3.05, 'MX codes', 10, weight='bold', ha='left')
    text(ax, .25, 2.71, r'$x,\ w$', 12, ha='left')
    text(ax, .25, 2.37, '4 / 6 / 8 bits' if generic else '4 bits / value', 8.8, MUTED, ha='left')
    box(ax, xs[0], y, ws[0], h,
        'Integer lift × P' if generic else 'Decode × 4',
        'Encoding-specific\nsigned integers' if generic else 'Signed 5-bit values\n10-bit products')
    box(ax, xs[1], y, ws[1], h, 'Exact dot32',
        (r'$P$ products / beat'+'\n'+r'$S_g$: $S_B$ bits') if generic
        else (r'$\Sigma_4$: 12 bits / beat'+'\n'+r'$S_g$: 14-bit block sum'))
    register_mark(ax, xs[1], y, ws[1], h, BLUE)
    box(ax, xs[2], y, ws[2], h, 'Align + RNE control',
        (r'$T_g=\mathrm{RNE}(S_g\,2^{d_g})$'+'\nGuard, sticky and tie bit') if generic
        else (r'$v_g$: aligned word'+'\n'+r'$r_g$: RNE correction bit'),
        GREEN, GREEN_BG)
    if not generic: register_mark(ax, xs[2], y, ws[2], h, GREEN)
    box(ax, xs[3], y, ws[3], h, 'W-bit accumulator',
        (r'$A\leftarrow A+T_g$' if generic else r'$A\leftarrow A+v_g+r_g$')+'\nRegistered running sum',
        GREEN, GREEN_BG)
    register_mark(ax, xs[3], y, ws[3], h, GREEN)
    arrow(ax, [(1.12, 2.85), (xs[0]-.03, 2.85)], BLUE)
    arrow(ax, [(xs[0]+ws[0]+.03, 2.85), (xs[1]-.03, 2.85)], BLUE)
    arrow(ax, [(xs[1]+ws[1]+.03, 2.85), (xs[2]-.03, 2.85)], BLUE)
    text(ax, 6.89, 3.08, r'$S_g$', 11, color=BLUE)
    arrow(ax, [(xs[2]+ws[2]+.03, 2.85), (xs[3]-.03, 2.85)], GREEN)
    arrow(ax, [(12.32, 2.85), (12.8, 2.85)], GREEN)
    text(ax, 13.55, 3.11, 'Result', 10, weight='bold')
    text(ax, 13.55, 2.76, r'$\hat y=A\,2^{E_{\max}-F}$', 11)
    text(ax, 13.55, 2.38, 'valid / ready', 8.8, MUTED)

    # The register feedback is explicit, rather than buried in a label.
    arrow(ax, [(11.78, 3.52), (11.78, 3.87), (10.53, 3.87), (10.53, 3.52)], GREEN)
    text(ax, 11.15, 4.02, 'feedback', 8.2, GREEN)
    text(ax, 5.23, 1.95, r'$32/P$ accepted beats / block' if generic else '8 accepted beats / block', 8.8, MUTED)

    # The optional / mandatory flag boundary is unmistakable.
    box(ax, 7.48, .81, 2.85, .87,
        'Inexact flag · built in' if generic else 'Inexact flag · optional',
        'OR of discarded non-zero bits', ORANGE, ORANGE_BG, dashed=not generic)
    arrow(ax, [(8.65, 2.18), (8.65, 1.71)], ORANGE, dashed=not generic)
    text(ax, 10.62, 1.46,
         'Included in every mapped core.' if generic else 'Excluded from all baseline PPA.',
         9, MUTED, ha='left')
    text(ax, 10.62, 1.13,
         'No routed layout measured yet.' if generic else 'Separate variant: +0.42% area at F2.',
         8.8, MUTED, ha='left')

    text(ax, .25, 1.47, 'NO-STALL SCHEDULE', 8, BLUE, weight='bold', ha='left')
    text(ax, .25, 1.13,
         r'$\mathrm{II}=2+B(2+32/P)$' if generic else r'$\mathrm{II}=9B+4$',
         11, ha='left')
    text(ax, .25, .79,
         'K128 / P4: 42 cycles per dot product' if generic else 'K128 / P4: 40 cycles per dot product',
         8.8, MUTED, ha='left')
    text(ax, 4.15, 1.47, 'EVIDENCE', 8, BLUE, weight='bold', ha='left')
    text(ax, 4.15, 1.13, 'RTL + mapped synthesis' if generic else 'RTL + routed GF180MCU', 10, ha='left')
    text(ax, 4.15, .79, 'Area includes the inexact flag' if generic else 'Nine-corner STA · DRC · LVS', 8.8, MUTED, ha='left')
    ax.plot([.25, 14.35], [.48, .48], color=GREY, lw=.85)
    legend(ax)
    target = ROOT / 'assets' / ('concept_generic_core' if generic else 'concept_mxfp4_core')
    target.parent.mkdir(parents=True, exist_ok=True)
    for suffix in ('png', 'svg', 'pdf'):
        fig.savefig(target.with_suffix('.'+suffix), dpi=220, facecolor='white')
    plt.close(fig)
    print(target)


if __name__ == '__main__':
    build(False)
    build(True)
