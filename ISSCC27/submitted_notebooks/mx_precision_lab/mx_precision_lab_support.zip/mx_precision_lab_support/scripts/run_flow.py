"""Generate GF180 physical configs or run honest, separately labelled synthesis."""
from pathlib import Path
import argparse,json,re,shutil,subprocess,sys,hashlib,os
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from mxacc.hardware import generate,VARIANTS
from mxacc.implementation import sha256,json_hash,conditions
from mxacc.physical import import_run

def synth(f,variant=None,out_root=None):
    wrapper,name=generate(ROOT,f,variant=variant);lib=ROOT/'tech/gf180_1x_tt_5v00.lib';core=VARIANTS[variant]['file']
    if not lib.exists():raise RuntimeError('Run python scripts/fetch_liberty.py first')
    exe=shutil.which('yosys') or shutil.which('yowasp-yosys')
    if not exe:raise RuntimeError('Install yosys or yowasp-yosys')
    out=(ROOT/'results/synthesis' if out_root is None else Path(out_root))/f'f{f}';out.mkdir(parents=True,exist_ok=True)
    # All paths are relative to the project: usable with native Yosys and YoWASP.
    rel=lib.relative_to(ROOT);rp=out.relative_to(ROOT)
    script=f'''read_verilog -sv {core} {wrapper.relative_to(ROOT)}
hierarchy -check -top {name}
synth -top {name} -flatten -noabc
dffunmap
dfflibmap -liberty {rel}
abc -liberty {rel}
clean
delete t:$scopeinfo
read_liberty -lib -ignore_miss_func {rel}
check -assert
stat -liberty {rel}
write_json {rp}/netlist.json
write_verilog -noattr {rp}/netlist.v
'''
    (out/'synth.ys').write_text(script)
    cp=subprocess.run([exe,'-l',str(rp/'yosys.log'),str(rp/'synth.ys')],cwd=ROOT,text=True,capture_output=True,timeout=600)
    (out/'console.log').write_text(cp.stdout+cp.stderr)
    if cp.returncode:raise RuntimeError(f'Yosys exit code {cp.returncode}: '+(cp.stdout+cp.stderr)[-3000:])
    text=(out/'yosys.log').read_text()
    values=re.findall(r'Chip area for (?:top )?module[^:]*:\s*([0-9.]+)',text)
    if not values:raise RuntimeError('No mapped cell area found; inspect synthesis log')
    # Refuse partial mapping when any internal Yosys cell remains.
    net=json.loads((out/'netlist.json').read_text());cells=net['modules'][name]['cells']
    # $scopeinfo cells are hierarchy metadata emitted by Yosys >= 0.4x after flattening, not logic.
    unmapped=[v['type'] for v in cells.values() if v['type'].startswith('$') and v['type']!='$scopeinfo']
    if unmapped:raise RuntimeError('Unmapped internal cells: '+str(set(unmapped)))
    row={'f':f,'k':128,'lanes':4,'stage':'post_synthesis','cell_area_um2':float(values[-1]),'mapped_cells':len(cells),
         'library_subset':'GF180 1x drive cells, tt_025C_5v00; exploratory mapping',
         'liberty_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),
         'rtl_sha256':hashlib.sha256((ROOT/core).read_bytes()).hexdigest(),'rtl_file':core,'variant':variant,
         'yosys_version':subprocess.run([exe,'-V'],capture_output=True,text=True).stdout.strip(),
         'clock_period_ns':50.0,'setup_wns_ns':None,'hold_wns_ns':None,'timing_status':'not_evaluated'}
    (out/'summary.json').write_text(json.dumps(row,indent=2));return row


# implementation settings common to every candidate (see flow/README.md):
#  - delay cells and the weakest buffers are excluded from PnR (the resizer used
#    dlyb_1/buf_1 as fanout buffers; their SS-corner slews broke signoff),
#  - design repair and timing repair are rerun on global-routing parasitics,
#  - the clock tree gets a buffer on every H-tree level so the root buffer does
#    not exceed the PDK's max fanout / max capacitance,
#  - repair margins leave headroom for extracted (RCX) parasitics at signoff.
FLOW_SETTINGS=json.loads((ROOT/'flow/flow_settings.json').read_text()) if (ROOT/'flow/flow_settings.json').exists() else {}


def physical_config(f,clock_ns=50.,folder=None,variant=None):
    wrapper,name=generate(ROOT,f,variant=variant);folder=Path(folder) if folder else ROOT/'flow'/f'f{f}';folder.mkdir(parents=True,exist_ok=True)
    rel=os.path.relpath(ROOT,folder);core=VARIANTS[variant]['file']
    c={'DESIGN_NAME':name,'VERILOG_FILES':[f'dir::{rel}/{core}',f'dir::{rel}/rtl/{wrapper.name}'],
       'CLOCK_PORT':'clk','CLOCK_PERIOD':clock_ns,'FP_SIZING':'absolute','DIE_AREA':[0,0,500,500],
       'DRT_THREADS':2,'STA_THREADS':2,'IO_DELAY_CONSTRAINT':10.0}
    for k,v in FLOW_SETTINGS.items():
        c[k]=v.replace('@ROOT@',rel) if isinstance(v,str) else v
    (folder/'config.json').write_text(json.dumps(c,indent=2));return folder/'config.json'


def driver_command(config_path,pdk_root,tag,environment):
    """LibreLane runs in its own interpreter (the pinned tool bundle's Python).

    MXACC_LIBRELANE_PYTHON / MXACC_LIBRELANE_PYTHONPATH select it; by default the
    current interpreter is used. Yosys' embedded Python derives its prefix from
    the first python3 on PATH, so the tool bundle's bin directory must be first.
    """
    driver=ROOT/environment['host_adapter']
    if sha256(driver)!=environment['host_adapter_sha256']:raise RuntimeError('Host adapter changed')
    python=os.environ.get('MXACC_LIBRELANE_PYTHON',sys.executable)
    env=dict(os.environ)
    if os.environ.get('MXACC_LIBRELANE_PYTHONPATH'):env['PYTHONPATH']=os.environ['MXACC_LIBRELANE_PYTHONPATH']
    command=[python,str(driver),'--manual-pdk','--jobs','2','--pdk-root',str(Path(pdk_root).resolve()),'--pdk',environment['pdk'],
             '--scl',environment['scl'],'--run-tag',tag,str(config_path)]
    return command,env


def route(f,clock_ns,pdk_root,tag):
    existing=ROOT/'flow'/f'f{f}'/'runs'/tag
    if existing.exists():raise ValueError('Use a new --run-tag; refusing to mix existing run evidence')
    config_path=physical_config(f,clock_ns)
    exe=shutil.which('librelane')
    if not exe:raise RuntimeError('Install the pinned LibreLane tool environment first')
    environment=json.loads((ROOT/'flow/environment.json').read_text())
    actual_version=subprocess.check_output([exe,'--version'],text=True).splitlines()[0]
    if environment['librelane_version'] not in actual_version:raise RuntimeError('LibreLane version mismatch: '+actual_version)
    if not pdk_root:raise ValueError('Set PDK_ROOT or supply --pdk-root')
    # Ciel's enabled symlink resolves through the immutable PDK revision folder.
    enabled=Path(pdk_root)/environment['pdk']
    if environment['pdk_revision'] not in str(enabled.resolve()):
        raise RuntimeError('Enabled PDK does not match flow/environment.json')
    wrapper,top=generate(ROOT,f)
    config=json.loads(config_path.read_text());common=conditions(config,environment)
    plan={'schema_version':'0.2','f':f,'k':128,'lanes':4,'top':top,
          'created_utc':datetime.now(timezone.utc).isoformat(),
          'source_hashes':{str(p.relative_to(ROOT)):sha256(p) for p in [ROOT/'rtl/dot_top.sv',wrapper]},
          'conditions':common,'comparison_signature':json_hash(common)}
    plan_path=config_path.parent/'mxacc_input.json';plan_path.write_text(json.dumps(plan,indent=2))
    run_dir=config_path.parent/'runs'/tag
    if run_dir.exists():raise ValueError('Use a new --run-tag; refusing to mix existing run evidence')
    command,env=driver_command(config_path,pdk_root,tag,environment)
    cp=subprocess.run(command,cwd=ROOT,env=env)
    if run_dir.exists():shutil.copy2(plan_path,run_dir/'mxacc_input.json')
    try:row=import_run(ROOT,run_dir,f);print(json.dumps(row),flush=True)
    except (OSError,ValueError,KeyError) as exc:
        failure={'f':f,'exit_code':cp.returncode,'run_dir':str(run_dir),'import_error':str(exc)}
        (config_path.parent/'last_attempt.json').write_text(json.dumps(failure,indent=2))
        raise RuntimeError('Implementation incomplete; see '+str(config_path.parent/'last_attempt.json')) from exc
    return cp.returncode


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['configs','synth','route'],default='configs')
    ap.add_argument('--f',type=int,nargs='+',default=[2,4,24]);ap.add_argument('--clock-ns',type=float,default=50.)
    ap.add_argument('--pdk-root',default=os.environ.get('PDK_ROOT'));ap.add_argument('--run-tag',default='mxacc_v02')
    a=ap.parse_args();failures=[]
    for f in a.f:
        try:
            if a.stage=='synth':print(json.dumps(synth(f)),flush=True)
            elif a.stage=='route':
                code=route(f,a.clock_ns,a.pdk_root,a.run_tag)
                if code:
                    failures.append({'f':f,'error':'LibreLane returned nonzero; imported failed checks remain visible','exit_code':code})
            else:print(physical_config(f,a.clock_ns).relative_to(ROOT))
        except Exception as exc:
            failures.append({'f':f,'error':str(exc)});print(json.dumps(failures[-1]),flush=True)
    if a.stage=='route':
        from make_report import make_report
        make_report(ROOT,json.loads((ROOT/'configs/default.json').read_text()))
    if failures:raise SystemExit(1)
if __name__=='__main__':main()
