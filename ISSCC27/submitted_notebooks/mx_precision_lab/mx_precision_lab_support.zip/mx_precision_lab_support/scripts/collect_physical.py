"""Import a real run; clock and provenance come from the run, not CLI assertions."""
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from mxacc.physical import import_run
from make_report import make_report

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run-dir',type=Path,required=True);ap.add_argument('--f',type=int,required=True)
    a=ap.parse_args();row=import_run(ROOT,a.run_dir,a.f)
    print(json.dumps(row,indent=2));print(json.dumps(make_report(ROOT,json.loads((ROOT/'configs/default.json').read_text()))))

if __name__=='__main__':main()
