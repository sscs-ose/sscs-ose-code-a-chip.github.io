"""RTL vs C++ cycle validation of the selective-recompute system (v0.4, plan step 3).

  python scripts/run_perf_validation.py --suite smoke     # 3 small cases, < 1 min
  python scripts/run_perf_validation.py --suite dev       # development configs (1,1) (4,2) (16,4) x scenarios A-F + real vectors
  python scripts/run_perf_validation.py --suite full      # dev + held-out configs, real vectors on (4,2)/(16,2), K512/K32, comparator self-test

For every case: the shared stimulus is exported, the C++ model and the Icarus trace testbench run
on the same files, the per-cycle traces are compared column by column, the per-transaction events
are derived from both traces with one reconstruction and compared (all cycle deltas must be 0),
the C++ internal event list is checked against its own trace, and every summary counter is
recomputed from the traces. Results: results/perf/validation/<case>/ and
results/perf/validation_summary.json (+ validation_table.md). Traces are kept only for the
representative cases and for failures (the +-16 cycle window around the first divergence).
"""
from pathlib import Path
import argparse, json, shutil, sys, time, hashlib
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
from mxacc.perf_stimulus import synthetic_case, real_case, SCENARIOS, DEV_CONFIGS, HELDOUT_CONFIGS
from mxacc.perf_rtl import run_rtl
from mxacc.perf_backend import run_case, find_binary, binary_info
from mxacc.perf_trace import (Trace, compare_cycles, derive_events, events_table, read_events_csv, compare_events, counts_from_trace,
                              latencies_from_events, coverage_from_trace, mutate_trace)

REPRESENTATIVE = ('hand_n1_q1', 'B_all_flagged_n4_q2_k128_f2', 'R_bert_tiny_ffn_k128_f2_original_n4_q2_smoke')


def case_list(suite):
    cases = []   # (kind, args)
    cases.append(('hand', {}))
    if suite == 'smoke':
        cases.append(('syn', dict(scenario='B_all_flagged', n=4, q=2)))
        cases.append(('real', dict(workload='bert_tiny_ffn_k128', n=4, q=2, f=2, tx_per_core=64, name='R_bert_tiny_ffn_k128_f2_original_n4_q2_smoke')))
        return cases
    configs = list(DEV_CONFIGS) + (list(HELDOUT_CONFIGS) if suite == 'full' else [])
    for n, q in configs:
        for sc in SCENARIOS: cases.append(('syn', dict(scenario=sc, n=n, q=q)))
    reals = [('bert_tiny_ffn_k128', 2), ('mnist_gelu_ln_fc2', 2), ('syn_outlier_k128', 4)]
    real_cfgs = [(4, 2)] + ([(16, 2)] if suite == 'full' else [])
    for n, q in real_cfgs:
        for wl, f in reals: cases.append(('real', dict(workload=wl, n=n, q=q, f=f, tx_per_core=1024 if n == 4 else 512)))
    if suite == 'full':
        cases.append(('real', dict(workload='mnist_relu_fc2_k512', n=4, q=2, f=2, tx_per_core=256)))
        cases.append(('syn', dict(scenario='A_no_flags', n=4, q=2, k=32)))
        cases.append(('syn', dict(scenario='B_all_flagged', n=4, q=2, k=512, tx_per_core=24)))
    return cases


def hand_case(out_dir):
    import numpy as np
    from mxacc.perf_stimulus import case_params, gen_exact, gen_flagged, gen_contract_edge, tx_row, threshold, build_masks, write_case, INITIAL_RESET
    rng = np.random.default_rng(1); k = 128; f = 2; dmax = 24
    p = case_params(1, k, f, 1, dmax)
    txs = gen_exact(rng, k, f, 1) + gen_flagged(rng, k, f, dmax, 1) + [gen_contract_edge(k, f, dmax, dmax + 1)]
    lines = [[tx_row(o, 0, *t, f, dmax, k)[0] for o, t in enumerate(txs)]]
    thr = {i: threshold(1.0) for i in ('ret', 'start', 'meta', 'data', 'out')}
    bits = build_masks(5, 1, 600, thr)
    meta = {'case': 'hand_n1_q1', 'scenario': 'hand', 'kind': 'synthetic', 'seed': 5, 'mask_thresholds': thr, 'mask_segments': [], 'rtl_consumable': True,
            'expected_events': {'first start': 3, 'first result handshake': 42, 'second start': 43, 'record enqueue of the flagged transaction': 82, 'merge accept': 83, 'return': 89},
            'provenance': {'generator': 'scripts/run_perf_validation.py:hand_case'}}
    return write_case(out_dir, p, lines, bits, [INITIAL_RESET], None, meta, root=ROOT), 'hand_n1_q1'


def run_one(kind, args, cases_dir, val_dir, exe, keep):
    t0 = time.time()
    tmp = cases_dir / 'tmp'
    if tmp.exists(): shutil.rmtree(tmp)
    if kind == 'hand': man, name = hand_case(tmp)
    elif kind == 'syn': man, name = synthetic_case(ROOT, tmp, **args)
    else: man, name = real_case(ROOT, tmp, **args)
    case_dir = cases_dir / name
    if case_dir.exists(): shutil.rmtree(case_dir)      # always a fresh export (a passing run strips its rows; regenerate)
    shutil.move(str(tmp), str(case_dir))
    out = val_dir / name
    if out.exists(): shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    man = json.loads((case_dir / 'manifest.json').read_text()); p = man['params']
    res = {'case': name, 'kind': kind, 'scenario': man.get('scenario'), 'config': {'n': p['n'], 'q': p['q'], 'k': p['k'], 'f': p['f'], 'dmax': p['dmax']},
           'config_role': 'development' if (p['n'], p['q']) in DEV_CONFIGS else 'held_out', 'transactions': man['stats']['transactions'], 'flagged': man['stats']['flagged'],
           'out_of_contract': man['stats']['out_of_contract'], 'seed': man.get('seed'), 'input_sha256': man['files'], 'rtl_sha256': man.get('rtl_sha256'),
           'workload': man.get('workload'), 'status': 'pass', 'failures': []}
    t_gen = time.time() - t0
    # ---- C++
    t1 = time.time(); cpp = run_case(ROOT, case_dir, out, trace=True, exe=exe); t_cpp = time.time() - t1
    # ---- RTL
    t1 = time.time(); rtl = run_rtl(ROOT, case_dir, out); t_rtl = time.time() - t1
    res['cycles'] = {'cpp': cpp['cycles'], 'rtl': rtl['cycles']}; res['rtl_value_errors'] = rtl['value_errors']
    if rtl['value_errors']: res['failures'].append(f"RTL value errors: {rtl['value_errors']}")
    if cpp['status'] != 'finished': res['failures'].append('C++ run incomplete: ' + str(cpp.get('error')))
    # ---- per-cycle comparison
    t1 = time.time()
    tr_c = Trace(out / 'cycles_cpp.csv'); tr_r = Trace(out / 'cycles_rtl.csv')
    diff = compare_cycles(tr_r, tr_c)
    res['cycle_trace_identical'] = diff is None
    if diff is not None:
        res['failures'].append(f"per-cycle trace differs first at cycle {diff['cycle']} column {diff['column']} core {diff['core']}: rtl={diff['a']} cpp={diff['b']}")
        (out / 'first_divergence.json').write_text(json.dumps(diff, indent=1))
    # ---- events: RTL-derived vs C++-derived vs C++ internal
    ev_r, chk_r = derive_events(tr_r, p['b']); ev_c, chk_c = derive_events(tr_c, p['b'])
    tab_r, tab_c = events_table(ev_r), events_table(ev_c); tab_i = read_events_csv(out / 'events_cpp.csv')
    cmp_rc = compare_events(tab_r, tab_c, 'rtl', 'cpp'); cmp_ci = compare_events(tab_c, tab_i, 'cpp_trace', 'cpp_internal')
    res['events'] = {'rtl_vs_cpp': {k: v for k, v in cmp_rc.items() if not isinstance(v, list)}, 'cpp_trace_vs_internal': {k: v for k, v in cmp_ci.items() if not isinstance(v, list)},
                     'n_events_rtl': len(tab_r), 'n_events_cpp': len(tab_c), 'reconstruction_checks_rtl': chk_r[:20], 'reconstruction_checks_cpp': chk_c[:20]}
    if not cmp_rc['identical']: res['failures'].append(f"events differ: {cmp_rc['n_cycle_deltas']} cycle deltas (max |d| = {cmp_rc['max_abs_cycle_delta']}), missing rtl {cmp_rc['n_missing_in_rtl']} / cpp {cmp_rc['n_missing_in_cpp']}, id mismatches {cmp_rc['n_hw_id_mismatches']}")
    if not cmp_ci['identical']: res['failures'].append('C++ internal events differ from its own trace')
    if chk_r: res['failures'].append(f'RTL trace reconstruction checks failed: {chk_r[0]}')
    if chk_c: res['failures'].append(f'C++ trace reconstruction checks failed: {chk_c[0]}')
    (out / 'event_diff.json').write_text(json.dumps({'rtl_vs_cpp': cmp_rc, 'cpp_trace_vs_internal': cmp_ci}, indent=1))
    # ---- summary counters recomputed from the traces
    cnt_r = counts_from_trace(tr_r, ev_r); cnt_c = counts_from_trace(tr_c, ev_c)
    cc = cpp['counts']
    checks = {'rtl_summary_vs_rtl_trace': {k: (rtl[k], cnt_r[k]) for k in ('cycles', 'starts', 'completed', 'returns', 'ooc_returns', 'enqueues', 'pops', 'aborted', 'resets', 'queue_peak')},
              'cpp_summary_vs_cpp_trace': {'cycles': (cpp['cycles'], cnt_c['cycles']), 'starts': (cc['starts'], cnt_c['starts']), 'completed': (cc['completed'], cnt_c['completed']),
                                           'returns': (cc['returns'], cnt_c['returns']), 'ooc_returns': (cc['ooc_returns'], cnt_c['ooc_returns']), 'enqueues': (cc['enqueues'], cnt_c['enqueues']),
                                           'pops': (cc['pops'], cnt_c['pops']), 'aborted': (cc['aborted'], cnt_c['aborted']), 'resets': (cpp['resets'], cnt_c['resets']), 'queue_peak': (cpp['queue']['peak'], cnt_c['queue_peak']),
                                           'occupancy_cycles': (cpp['queue']['occupancy_cycles'], cnt_c['occupancy_cycles'] + [0] * (len(cpp['queue']['occupancy_cycles']) - len(cnt_c['occupancy_cycles']))),
                                           'stall_union': (cpp['stalls']['union_core_cycles'], cnt_c['stall_union']), 'stalls': (cpp['stalls']['per_reason_core_cycles'], cnt_c['stalls']),
                                           'merge_compute_busy': (cpp['merge']['compute_busy_cycles'], cnt_c['merge_compute_busy']), 'merge_output_blocked': (cpp['merge']['output_blocked_cycles'], cnt_c['merge_output_blocked'])},
              'rtl_trace_vs_cpp_trace': {k: (cnt_r[k], cnt_c[k]) for k in ('cycles', 'starts', 'completed', 'returns', 'ooc_returns', 'enqueues', 'pops', 'aborted', 'resets', 'queue_peak', 'stall_union', 'merge_compute_busy', 'merge_output_blocked')}}
    lat_c = latencies_from_events(ev_c); lat_r = latencies_from_events(ev_r)
    checks['cpp_latency_vs_trace'] = {k: ({'count': cpp['all'][k]['count'], 'p50': cpp['all'][k]['p50'], 'p99': cpp['all'][k]['p99'], 'max': cpp['all'][k]['max']}, lat_c[k]) for k in ('e2e_latency', 'recompute_latency', 'queue_wait')}
    checks['rtl_latency_vs_cpp_latency'] = {k: (lat_r[k], lat_c[k]) for k in ('e2e_latency', 'recompute_latency', 'queue_wait')}
    bad = [(grp, k) for grp, d in checks.items() for k, (x, y) in d.items() if x != y]
    res['summary_checks'] = {'all_consistent': not bad, 'inconsistent': [f'{g}:{k}' for g, k in bad]}
    if bad: res['failures'].append('summary counters inconsistent: ' + ', '.join(f'{g}:{k}' for g, k in bad[:6]))
    (out / 'summary_checks.json').write_text(json.dumps(checks, indent=1, default=str))
    res['coverage'] = coverage_from_trace(tr_r, ev_r, p['q'])
    res['metrics_rtl'] = {'counts': {k: cnt_r[k] for k in ('starts', 'completed', 'returns', 'ooc_returns', 'enqueues', 'aborted', 'queue_peak')}, 'latency': lat_r}
    res['metrics_cpp'] = {'counts': cc, 'queue_peak': cpp['queue']['peak'], 'latency_all': cpp['all'], 'stalls': cpp['stalls'], 'merge': cpp['merge'], 'traffic_bits': cpp['traffic_bits']}
    res['timing_s'] = {'stimulus': round(t_gen, 2), 'cpp': round(t_cpp, 2), 'rtl': round(t_rtl, 2), 'compare': round(time.time() - t1, 2)}
    res['status'] = 'pass' if not res['failures'] else 'fail'
    # ---- retention
    keep_all = keep or name in REPRESENTATIVE or res['status'] == 'fail'
    if not keep_all:
        for f in ('cycles_cpp.csv', 'cycles_rtl.csv', 'events_cpp.csv', 'sim.vvp'): (out / f).unlink(missing_ok=True)
        for f in ('masks.txt',): (case_dir / f).unlink(missing_ok=True)
        for c in range(p['n']): (case_dir / f'tx_c{c}.txt').unlink(missing_ok=True)
        (case_dir / 'NOTE.txt').write_text('transaction rows and masks removed after a passing run (regenerate with scripts/export_perf_stimulus.py --case ' + name + '); hashes in manifest.json\n')
    else:
        (out / 'sim.vvp').unlink(missing_ok=True)
    if res['status'] == 'fail' and diff is not None:
        lo, hi = max(0, diff['cycle'] - 16), diff['cycle'] + 17
        for src, dst in (('cycles_cpp.csv', 'window_cpp.csv'), ('cycles_rtl.csv', 'window_rtl.csv')):
            lines = (out / src).read_text().splitlines(); (out / dst).write_text('\n'.join([lines[0]] + lines[1 + lo:1 + hi]) + '\n')
    (out / 'result.json').write_text(json.dumps(res, indent=1))
    return res


def comparator_self_test(val_dir, case='B_all_flagged_n4_q2_k128_f2'):
    """The comparator must flag deliberately corrupted traces (mutation check)."""
    out = val_dir / case
    if not (out / 'cycles_cpp.csv').exists(): return {'status': 'skipped', 'reason': f'no trace kept for {case}'}
    p = json.loads((out / 'result.json').read_text())['config']; b = p['k'] // 32
    ref = Trace(out / 'cycles_cpp.csv'); ev_ref, _ = derive_events(ref, b); tab_ref = events_table(ev_ref)
    results = {}
    for kind in ('plus_one_cycle', 'drop_return', 'swap_id', 'occupancy'):
        mpath = out / f'mutated_{kind}.csv'; mutate_trace(out / 'cycles_cpp.csv', mpath, kind)
        mt = Trace(mpath); d = compare_cycles(ref, mt); ev_m, chk_m = derive_events(mt, b); ce = compare_events(tab_ref, events_table(ev_m), 'ref', 'mutated')
        caught = {'per_cycle_diff': d is not None, 'event_diff': not ce['identical'], 'reconstruction_check': bool(chk_m)}
        # timing mutations must show up as event deltas; identity/occupancy mutations as reconstruction failures; all as per-cycle diffs
        needs = {'plus_one_cycle': caught['event_diff'], 'drop_return': caught['event_diff'], 'swap_id': caught['reconstruction_check'], 'occupancy': caught['reconstruction_check']}[kind]
        results[kind] = {'caught': caught, 'detected': caught['per_cycle_diff'] and needs,
                         'first_cycle_diff': None if d is None else {'cycle': d['cycle'], 'column': d['column']},
                         'event_summary': {k: ce[k] for k in ('n_cycle_deltas', 'max_abs_cycle_delta', 'n_missing_in_mutated', 'n_hw_id_mismatches')}, 'reconstruction_checks': chk_m[:3]}
        mpath.unlink()
    results['status'] = 'pass' if all(v['detected'] for k, v in results.items() if k != 'status') else 'fail'
    return results


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--suite', default='smoke', choices=['smoke', 'dev', 'full']); ap.add_argument('--out', default='results/perf')
    ap.add_argument('--keep-traces', action='store_true'); ap.add_argument('--only', default=None, help='substring filter on case names'); a = ap.parse_args()
    base = ROOT / a.out; cases_dir = base / 'cases'; val_dir = base / 'validation'; cases_dir.mkdir(parents=True, exist_ok=True); val_dir.mkdir(parents=True, exist_ok=True)
    exe = find_binary(ROOT); info = binary_info(exe); print('== C++ model:', info['version_line'], info['sha256'][:16])
    results = []; t0 = time.time()
    for kind, args in case_list(a.suite):
        label = args.get('name') or args.get('scenario', kind) + ('' if kind == 'hand' else f"_n{args.get('n')}_q{args.get('q')}") + (f"_{args['workload']}_f{args['f']}" if kind == 'real' else '')
        if a.only and a.only not in label: continue
        print(f'== {label}', flush=True)
        try:
            r = run_one(kind, args, cases_dir, val_dir, exe, a.keep_traces)
        except Exception as e:
            r = {'case': label, 'kind': kind, 'status': 'error', 'failures': [str(e)[-1500:]]}
        results.append(r); print(f"   {r['status']}" + ('' if r['status'] == 'pass' else ': ' + '; '.join(r['failures'])[:300]), flush=True)
    self_test = comparator_self_test(val_dir) if a.suite != 'smoke' or True else None
    print('== comparator self-test:', self_test.get('status'))
    from mxacc.provenance import source_hashes, VALIDATION_SOURCES
    summary = {'suite': a.suite, 'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'cpp_binary': info, 'contract': 'docs/perf_contract.md',
               'source_sha256': source_hashes(ROOT, VALIDATION_SOURCES),
               'contract_sha256': hashlib.sha256((ROOT / 'docs/perf_contract.md').read_bytes()).hexdigest(),
               'cases': results, 'n_cases': len(results), 'n_pass': sum(r['status'] == 'pass' for r in results),
               'total_events_compared': sum(r.get('events', {}).get('rtl_vs_cpp', {}).get('compared', 0) for r in results),
               'total_transactions': sum(r.get('transactions', 0) for r in results), 'total_cycles_rtl': sum(r.get('cycles', {}).get('rtl', 0) for r in results),
               'max_abs_cycle_delta': max((r.get('events', {}).get('rtl_vs_cpp', {}).get('max_abs_cycle_delta', 0) for r in results), default=0),
               'all_cycle_traces_identical': all(r.get('cycle_trace_identical', False) for r in results), 'comparator_self_test': self_test,
               'status': 'pass' if all(r['status'] == 'pass' for r in results) and self_test.get('status') == 'pass' else 'fail', 'wall_s': round(time.time() - t0, 1)}
    prev = base / 'validation_summary.json'
    if prev.exists() and a.suite != 'full':   # keep the full-suite record; store partial suites under their own name
        (base / f'validation_summary_{a.suite}.json').write_text(json.dumps(summary, indent=1))
    else:
        prev.write_text(json.dumps(summary, indent=1))
    (base / f'validation_table_{a.suite}.md').write_text(table(summary))
    print(f"== {summary['status']}: {summary['n_pass']}/{summary['n_cases']} cases, {summary['total_events_compared']} events compared, max |delta| = {summary['max_abs_cycle_delta']}, {summary['wall_s']} s")


def table(summary):
    rows = ['| case | N,Q | role | tx | flagged | cycles (RTL) | events compared | max abs cycle delta | per-cycle trace | coverage | status |', '|---|---|---|---|---|---|---|---|---|---|---|']
    for r in summary['cases']:
        if r['status'] == 'error': rows.append(f"| {r['case']} | | | | | | | | | | error: {r['failures'][0][:80]} |"); continue
        cov = r['coverage']; flags = []
        if cov['queue_full_cycles']: flags.append('full')
        if cov['same_cycle_enqueue_dequeue']: flags.append('enq+deq')
        if cov['handshake_order']['result_before_record'] and cov['handshake_order']['record_before_result']: flags.append('both orders')
        if cov['reset_with_queue_nonempty']: flags.append('reset@busy')
        if cov['id_wrap_observed']: flags.append('id wrap')
        if cov['out_of_contract_returns']: flags.append('ooc')
        if cov['cycles_with_multiple_requests']: flags.append('multi-req')
        if cov['return_blocked_cycles']: flags.append('ret bp')
        if cov['result_blocked_core_cycles']: flags.append('out bp')
        if cov['input_mask_stall_core_cycles']: flags.append('in stall')
        ev = r['events']['rtl_vs_cpp']
        rows.append(f"| {r['case']} | {r['config']['n']},{r['config']['q']} | {r['config_role']} | {r['transactions']} | {r['flagged']} | {r['cycles']['rtl']} | {ev['compared']} | {ev['max_abs_cycle_delta']} | {'identical' if r['cycle_trace_identical'] else 'DIFFERS'} | {', '.join(flags)} | {r['status']} |")
    st = summary['comparator_self_test'] or {}
    rows.append(''); rows.append(f"Comparator self-test: {st.get('status')} (" + ', '.join(f"{k}: {'caught' if v.get('detected') else 'MISSED'}" for k, v in st.items() if k != 'status') + ')')
    rows.append(f"C++ model {summary['cpp_binary']['version_line']} ({summary['cpp_binary']['sha256'][:16]}); contract {summary['contract_sha256'][:16]}; {summary['total_events_compared']} events compared; max |delta| {summary['max_abs_cycle_delta']}; status {summary['status']}.")
    return '\n'.join(rows) + '\n'


if __name__ == '__main__':
    main()
