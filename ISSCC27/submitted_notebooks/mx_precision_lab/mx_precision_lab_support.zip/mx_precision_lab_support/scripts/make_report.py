"""Generate the report from current numerics and validated implementation records."""
from pathlib import Path
import argparse,csv,json,sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from mxacc.experiment import numeric_experiment,choose_hardware,comparison_table
from mxacc.implementation import load_implementations


def make_report(root,config,tolerance=None,workload=None):
    root=Path(root)
    if config['lanes']!=4 or config['candidates']!=[0,2,4,6,8,12,16,24]:
        raise ValueError('The report covers the fixed P4 candidate set only')
    workload=config.get('workload','mnist_relu_fc2') if workload is None else workload
    tolerance=config['max_calib_nrmse'] if tolerance is None else tolerance
    period,rate=config['clock_period_ns'],config['min_dot_products_per_s']
    out=root/'results/quick';n=numeric_experiment(root,tolerance,workload=workload,out=out)
    implementation=load_implementations(root)
    selection=choose_hardware(n,implementation['costs'],period,rate)
    (out/'hardware_selection.json').write_text(json.dumps(selection,indent=2))
    policy=comparison_table(n,selection)
    (out/'policy_comparison.json').write_text(json.dumps(policy,indent=2))
    (out/'implementation_records.json').write_text(json.dumps(implementation,indent=2))
    by_f={r['f']:r for r in selection['costs']}
    synth={r['f']:r for r in implementation['all_records'] if r['stage']=='post_synthesis'}
    fields=['f','w','nrmse','max_abs','max_bound','synthesis_area_um2','post_route_area_um2',
            'preferred_stage','setup_wns_ns','hold_wns_ns','unconstrained_paths','drc_errors','lvs_errors',
            'max_slew_violations','max_cap_violations','unannotated_signal_nets','ii_no_stall','dot_products_per_s','rtl_pass','provenance_pass','timing_pass',
            'electrical_checks_pass','physical_checks_pass','eligible','qualification_reasons']
    with (out/'comparison.csv').open('w',newline='') as fp:
        writer=csv.DictWriter(fp,fieldnames=fields);writer.writeheader()
        for r in n['calibration']:
            c=by_f.get(r['f'],{})
            row={**{k:r[k] for k in fields if k in r},**{k:c[k] for k in fields if k in c},
                 'synthesis_area_um2':synth.get(r['f'],{}).get('cell_area_um2'),
                 'post_route_area_um2':c.get('cell_area_um2') if c.get('stage')=='post_route' else None,
                 'preferred_stage':c.get('stage','not_evaluated'),
                 'qualification_reasons':'; '.join(c.get('qualification_reasons',['not evaluated']))}
            writer.writerow(row)
    fig,axs=plt.subplots(1,2,figsize=(11.5,4.3),layout='constrained')
    rr=n['calibration'];errors={r['f']:r['nrmse'] for r in rr}
    axs[0].plot([r['f'] for r in rr],[r['nrmse'] for r in rr],'o-',color='#3253dc')
    axs[0].set(xlabel='Alignment precision F (bits)',ylabel='Calibration NRMSE',title=f"{n['workload']} (K{n['k']}): identical MXFP4 inputs")
    labels=set()
    for c in implementation['all_records']:
        if c.get('cell_area_um2') is None or (c.get('k'),c.get('lanes'))!=(n['k'],n['lanes']):continue
        routed=c['stage']=='post_route';qualified=by_f.get(c['f'],{}).get('eligible',False)
        color=('#008569' if qualified else '#b84040') if routed else '#3253dc'
        label=('Post-route: qualified' if qualified else 'Post-route: not qualified') if routed else 'Synthesis: timing unknown'
        axs[1].scatter(c['cell_area_um2'],errors[c['f']],marker='s' if routed else 'o',
                       facecolors='none' if routed and not qualified else color,edgecolors=color,
                       label=label if label not in labels else None)
        labels.add(label)
        axs[1].annotate(f"F{c['f']}",(c['cell_area_um2'],errors[c['f']]),xytext=(4,7),textcoords='offset points',fontsize=8)
    routed_present=any(c['stage']=='post_route' and (c.get('k'),c.get('lanes'))==(n['k'],n['lanes']) for c in implementation['all_records'])
    title=(f"No K{n['k']}/P{n['lanes']} implementation record: not_evaluated" if selection['status']=='no_implementation_evaluated_for_architecture' else
           'No routed candidate meets all constraints' if routed_present and selection['selected_f'] is None else 'Measured stages shown separately')
    axs[1].set(xlabel='Non-filler standard-cell area (um²)',ylabel='Calibration NRMSE',title=title)
    for ax in axs:
        ax.axhline(tolerance,color='#b84040',ls='--',label='Calibration budget')
        ax.set_yscale('symlog',linthresh=1e-7)
        ax.set_ylim(-1e-8,max(tolerance,max(errors.values()))*3)
        ax.grid(alpha=.2);ax.legend(fontsize=7);ax.margins(x=.14)
    fig.savefig(out/'comparison.png',dpi=180);fig.savefig(out/'comparison.svg');plt.close(fig)
    def fmt(v):return 'unknown' if v is None else f'{v:,.5g}' if isinstance(v,(int,float)) else str(v)
    def fmtn(h):return 'none' if h is None else '%.8g'%h['nrmse']
    rows=['| F | W | Cal. NRMSE | Synthesis area (um²) | Routed area (um²) | Setup / hold (ns) | DRC / LVS | Slew / cap violations | Eligible |',
          '|---:|---:|---:|---:|---:|---|---|---|---|']
    for r in rr:
        c=by_f.get(r['f'],{});routed=c.get('stage')=='post_route'
        rows.append(f"| {r['f']} | {r['w']} | {r['nrmse']:.7g} | {fmt(synth.get(r['f'],{}).get('cell_area_um2'))} | "
                    f"{fmt(c.get('cell_area_um2') if routed else None)} | {fmt(c.get('setup_wns_ns'))} / {fmt(c.get('hold_wns_ns'))} | "
                    f"{fmt(c.get('drc_errors'))} / {fmt(c.get('lvs_errors'))} | {fmt(c.get('max_slew_violations'))} / {fmt(c.get('max_cap_violations'))} | {c.get('eligible',False)} |")
    full=json.loads((root/'results/mnist_full_test.json').read_text())
    ft=selection.get('final_test')
    hardware_line=(f"Selected hardware: **F{selection['selected_f']}**, minimum area among qualified, comparable evaluated K{selection['k']}/P{selection['lanes']} candidates for workload `{selection['workload']}` at budget {selection['budget']:g}. Independent test of this frozen hardware choice: NRMSE {ft['test_nrmse']:.6g} -> {'pass' if ft['pass'] else 'FAIL (reported, not re-picked)'}."
                   if selection['selected_f'] is not None else
                   (f"**Hardware selection remains unset: no implementation record exists for K{selection['k']}/P{selection['lanes']} (not_evaluated).**" if selection['status']=='no_implementation_evaluated_for_architecture' else
                    '**Hardware selection remains unset.** No supplied candidate passes every required implementation check under matching conditions.'))
    if selection['selected_f'] is not None and selection['selected_f']!=n['numeric_recommendation_f']:
        hardware_line+=f" The numeric minimum is F{n['numeric_recommendation_f']}; the smallest *qualified routed* candidate is F{selection['selected_f']} (minimum bits and minimum area differ)."
    pol_rows=['| Policy | F | W | Cal. NRMSE | Test NRMSE | Budget | Routed area (um²) | vs fixed F4 | Qualified |','|---|---:|---:|---:|---:|---|---:|---:|---|']
    for r in policy['rows']:
        pol_rows.append('| %s | %s | %s | %s | %s | %s | %s | %s | %s |'%(r['policy'],'none' if r['f'] is None else 'F%d'%r['f'],r['w'] or '-',
            '-' if r['cal_nrmse'] is None else '%.3g'%r['cal_nrmse'],'-' if r['test_nrmse'] is None else '%.3g'%r['test_nrmse'],
            '-' if r['meets_budget_cal'] is None else ('pass' if r['meets_budget_cal'] and r['meets_budget_test'] else 'FAIL'),
            'not_evaluated' if r['post_route_area_um2'] is None else '%s'%format(r['post_route_area_um2'],',.1f'),
            '-' if r['area_vs_fixed_f4_pct'] is None else '%+.2f %%'%r['area_vs_fixed_f4_pct'],
            'yes' if r['qualified'] else 'no ('+'; '.join(r['qualification_reasons'][:2])+')'))
    policy_table='\n'.join(pol_rows)
    reasons='\n'.join(f"- F{c['f']} ({c['stage']}): "+('; '.join(c['qualification_reasons']) or 'qualified') for c in selection['costs'])
    savings=''
    routed={r['f']:r for r in implementation['all_records'] if r['stage']=='post_route' and r.get('cell_area_um2')}
    if all(f in synth for f in [0,2,4,24]):
        a=lambda f:synth[f]['cell_area_um2']
        savings=f'''Exploratory synthesis (same Yosys/Liberty for all eight F): F0, F2, F4 and F24 map to {a(0):,.0f}, {a(2):,.0f}, {a(4):,.0f} and {a(24):,.0f} um2, i.e. F0/F2/F4 are {100*(1-a(0)/a(24)):.1f} / {100*(1-a(2)/a(24)):.1f} / {100*(1-a(4)/a(24)):.1f} % smaller than the F24 baseline.'''
    if all(f in routed for f in [2,4,24]):
        r=lambda f:routed[f]['cell_area_um2']
        savings+=f''' Post-route (same die, clock, constraints, flow settings): F2 is {100*(1-r(2)/r(24)):.2f} % smaller than F24 and {100*(1-r(2)/r(4)):.2f} % smaller than F4'''+(f'''; F0 is {100*(1-r(0)/r(24)):.2f} % smaller than F24.''' if 0 in routed else '.')
    workload_table=(root/'results/workloads/selection_table.md').read_text() if (root/'results/workloads/selection_table.md').exists() else '(workload study not run)'
    sweep=json.loads((root/'results/timing_sweep/summary.json').read_text()) if (root/'results/timing_sweep/summary.json').exists() else None
    sweep_rows=''
    if sweep:
        def num(v,spec):return '-' if v is None else format(v,spec)
        sweep_rows='| Clock (ns) | F | Setup WS (ns) | Hold WS (ns) | Slew / cap | Area (um2) | Verdict |\n|---:|---:|---:|---:|---|---:|---|\n'+'\n'.join(
            '| %g | %s | %s | %s | %s / %s | %s | %s |'%(r['clock_period_ns'],r['f'],num(r.get('setup_ws_ns'),'.3f'),num(r.get('hold_ws_ns'),'.3f'),
                                                     r.get('max_slew_violations','-'),r.get('max_cap_violations','-'),num(r.get('cell_area_um2'),',.1f'),r['verdict'])
            for r in sweep['runs'])+'\n\n'+sweep.get('conclusion','')
    report=f'''# MXFP4 accumulator: execution report

Measured evidence only; a missing check stays unknown. The engineering log with every decision and experiment is `../../EXPERIMENT_LOG.md`.

## Result in one line

The accumulator precision a workload needs is set by its block-exponent spread `max_g(E_max - E_g)` and its cancellation, not by the 4-bit inputs: `F >= spread` is sufficient for exactness, below it the error grows with cancellation. The selected F spans F0 to F24 across the 13 bundled workloads; post-route, the qualified F2 of the default MNIST layer is 7.15 % smaller than the equally qualified F4, the F0->F24 span is 16.95 % post-route (F24 not qualified: one max-cap violation) and 22.2 % in synthesis. That is why F is measured per workload instead of fixed.

## Numerical selection

- Current run: workload `{n['workload']}` ({n['workload_source']}, {n['workload_kind']}), K{n['k']} / P{n['lanes']}; {n['calibration_samples']} calibration vectors and {n['test_samples']} disjoint test vectors; data sha256 `{n['data_sha256'][:16]}`.
- FP4 quantization error (exact MXFP4 vs FP32, independent of F): calibration NRMSE {n['quantization_cal']['nrmse_vs_fp32']:.4g}, test NRMSE {n['quantization_test']['nrmse_vs_fp32']:.4g}. The budget below applies to the accumulation error only.
- Block-exponent spread {n['spread_bits']} bits -> first candidate satisfying the sufficient condition F >= spread: F{n['sufficient_exact_candidate_f']}; smallest measured zero-error candidate: F{n['smallest_zero_error_candidate_f']}.
- Minimum numerically feasible F: **{n['numeric_recommendation_f']}**, calibration NRMSE <= {tolerance:g}.
- Independent test NRMSE of that numeric minimum: {fmtn(n['heldout'])}; budget pass: {n['heldout_budget_pass']}.
- Bounded demo: E_bound=0, abs_tol=0.01, feasible F={n['bounded']['feasible_f']}.
- E_bound=0 / abs_tol=1e-12 gives no candidate under this conservative-bound rule, not proof every actual input fails.

## Implementation selection

{hardware_line}

The report and notebook both call `mxacc.implementation.load_implementations`. Post-route records replace synthesis records for qualification, including failed timing. A missing metric never becomes a pass. RTL, input/configuration hashes, archived metrics, PDK/toolchain, matching clock, setup, hold, unconstrained paths, throughput, slew/cap/parasitic coverage, DRC and LVS must qualify. Only comparable implementation conditions can compete on area.

{chr(10).join(rows)}

{savings}

![Area and error comparison](comparison.png)

Synthesis area uses a pinned GF180 1x-drive Liberty subset, TT / 25C / 5V, Yosys 0.62 (exploratory mapping of all eight F). Post-route area comes from the full-PDK LibreLane implementation: `design__instance__area__stdcell`, i.e. non-filler standard cells including clock/repair buffers and tap/endcap cells. Total instance and filler area are kept in the raw JSON; a fixed die filled with filler is not the objective. Never compute a saving across the two stages. Magic performs the full DRC and KLayout the GDS XOR; KLayout DRC has no runset for gf180mcu in LibreLane 3.0.16 (the step is skipped by the tool) and stays not_evaluated. Power has not been measured.

### Same-platform comparison of selection policies

Identical conditions for every row: K{selection['k']}/P{selection['lanes']} core, {period:g} ns clock, same LibreLane/GF180 flow, same calibration/test split, budget {tolerance:g}; FP4 quantization NRMSE vs FP32 is {n['quantization_cal']['nrmse_vs_fp32']:.3g} (cal) / {n['quantization_test']['nrmse_vs_fp32']:.3g} (test) for every row. Area only from records matching (K, lanes, F).

{policy_table}

### Qualification details

{reasons}

Provenance diagnostics: `{json.dumps(implementation['diagnostics'],ensure_ascii=False)}`.

The required period is {period:g} ns and the minimum rate is {rate:g} complete dot products/s. Rate is computed from the implemented clock and verified no-stall II only when post-route timing qualifies. It describes the core interface, not whole-model throughput.

## Workload study (results/workloads)

{workload_table}

`*`/`(test FAIL)` marks a frozen calibration choice that does not meet the budget on the disjoint test split; it is reported, never re-picked. Figures: `../workloads/nrmse_vs_f.png`, `../workloads/spread_vs_exact_f.png`. Task accuracy for the three MNIST models (official 10,000 test images, F-bit layer plugged into the network) is in `../workloads/study.json` and is flat across F for this single-layer replacement.

## Timing-driven experiment (results/timing_sweep)

{sweep_rows if sweep_rows else 'not_evaluated'}

## Saved full-model test (cached_result)

The training/evaluation run froze F={full['numeric_recommendation_f']} before evaluating {full['samples']} official test images. Model/data provenance: `examples/mnist/manifest.json`. Changing this quick-run budget does not regenerate that experiment.

- Original FP32 accuracy: {full['fp32_accuracy']:.4%}.
- Only fc2 MXFP4 with exact accumulation: {full['mxfp4_exact_task']['accuracy']:.4%}.
- Full results: `../mnist_full_test.json`; remaining layers and bias execute in software.

## Reproduce

`python scripts/run_quick.py --rtl` regenerates quick numerical results and current RTL checks.

`python scripts/run_flow.py --stage route --f 0 2 4 8 12 24` runs the fixed physical comparison in the pinned LibreLane/GF180 environment (settings in `flow/flow_settings.json`, rationale in `flow/README.md`); `python scripts/timing_sweep.py --f 2 24 --clock-ns 35` reproduces the timing-driven experiment. Successful runs are imported automatically. An existing completed run can be re-imported with `python scripts/collect_physical.py --run-dir PATH --f F` and then `python scripts/make_report.py`.

Notebook cell-source execution is checked separately. The Colab run of 2026-10-18 (public GitHub clone, 18 cells, Icarus RTL check included) is recorded in `../notebook_validation.json` with the executed copy in `../colab/`.
'''
    (out/'REPORT.md').write_text(report)
    return {'workload':n['workload'],'k':n['k'],'numeric_f':n['numeric_recommendation_f'],'hardware_f':selection['selected_f'],'status':selection['status'],'report':str(out/'REPORT.md')}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--tolerance',type=float);ap.add_argument('--config',type=Path,default=ROOT/'configs/default.json')
    ap.add_argument('--workload',default=None,help='catalogue id or layer_npz directory (default: configs/default.json workload or mnist_relu_fc2)');a=ap.parse_args()
    print(json.dumps(make_report(ROOT,json.loads(a.config.read_text()),a.tolerance,a.workload)))

if __name__=='__main__':main()
