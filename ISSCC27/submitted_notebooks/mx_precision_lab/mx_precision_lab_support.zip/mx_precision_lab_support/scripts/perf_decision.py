"""Requirements -> qualified selection (v0.4, plan step 5.1): Table 2 of the performance study.

  python scripts/perf_decision.py [--max-p99 200] [--budget 1e-3] [--ooc-policy reject]

For every workload of the burstiness study: the single-core selection (mxacc.experiment, qualified
routed cores), the strict system selection over N x fixed-F tops and (F2, N, Q) recompute systems
(qualification first, then performance, then area), the exploration ranking with area-source and
validation-scope labels, and the frozen-test check of the reference configuration (N=16, Q=2) and
of the best exploratory configuration chosen on calibration (reported, never used to re-select).
Selection inputs: calibration split + declared contract + physical records only (mxacc.qualify);
the test split (its spread, its NRMSE, its C++ runs) is read only after the choice is frozen.
Writes results/perf/decision.json and decision_table.md.
"""
from pathlib import Path
import argparse, json, sys, tempfile, time
import numpy as np
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
from mxacc.experiment import numeric_experiment, choose_hardware
from mxacc.implementation import load_implementations
from mxacc.qualify import system_candidates, choose_system, frozen_test_check, block_spread_max
from mxacc.perf_backend import find_binary, binary_info, run_generated
from mxacc.perf_stimulus import real_case, threshold
from mxacc.workloads import load_workload
from mxacc.arithmetic import quantize, groups

WORKLOADS = [('bert_tiny_ffn_k128', 2), ('mnist_relu_fc2', 2), ('mnist_gelu_ln_fc2', 2), ('syn_outlier_k128', 4)]


def spreads(wl):
    """(calibration spread, test spread): the first feeds the contract check, the second only the frozen-test report."""
    w = load_workload(ROOT, wl)
    return block_spread_max(w['x_cal'], w['w']), block_spread_max(w['x_test'], w['w'])


def test_split_run(scratch, runs, exe, wl, f, n, q):
    """C++ run on the frozen test split, original order, saturated input; same window rule as the study."""
    d = scratch / f'T_{wl}_f{f}_test_original_n{n}'
    if not (d / 'manifest.json').exists():
        w = load_workload(ROOT, wl); total = len(w['x_test']) * w['outputs']
        real_case(ROOT, d, wl, n, 1, f, tx_per_core=total // n, split='test', ordering='original', name=d.name, light=True)
    man = json.loads((d / 'manifest.json').read_text()); p = dict(man['params']); p['q'] = q
    per_core = max(man['stats']['per_core']); ii0 = p['ii0']; t_nom = per_core * ii0; window = (1000, int(0.9 * t_nom))
    sat = {k: threshold(1.0) for k in ('ret', 'start', 'meta', 'data', 'out')}
    s = run_generated(ROOT, d, runs / f'{wl}_f{f}_test_n{n}_q{q}', p, 20261018, sat, int(t_nom * 1.5 + n * per_core * p['s0'] + 5000), window=window, exe=exe)
    lat = s['window']['recompute_latency']; ideal = n / ii0
    return {'split': 'test', 'transactions': man['stats']['transactions'], 'flagged': man['stats']['flagged'], 'flagged_fraction': man['stats']['flagged'] / max(1, man['stats']['transactions']),
            'rc_p50': lat['p50'], 'rc_p99': lat['p99'], 'rc_count': lat['count'], 'queue_peak': s['queue']['peak'],
            'throughput_loss_vs_ideal_pct': 100 * (1 - s['window']['useful_throughput_per_cycle'] / ideal), 'ooc_returns': s['counts']['ooc_returns']}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--max-p99', type=float, default=200.); ap.add_argument('--budgets', type=float, nargs='*', default=[1e-3, 1e-6]); ap.add_argument('--ooc-policy', default='reject')
    ap.add_argument('--out', default='results/perf'); ap.add_argument('--scratch', default='build/perf_study'); ap.add_argument('--no-test-split', action='store_true'); a = ap.parse_args()
    out = ROOT / a.out; scratch = ROOT / a.scratch; scratch.mkdir(parents=True, exist_ok=True); runs = out / 'study_runs'; runs.mkdir(parents=True, exist_ok=True)
    study = json.loads((out / 'study.json').read_text()); sysst = json.loads((ROOT / 'results/system/study.json').read_text())
    rc = json.loads((ROOT / 'results/recompute/study.json').read_text())['workloads']; impl = load_implementations(ROOT)
    val = json.loads((out / 'validation_summary.json').read_text()) if (out / 'validation_summary.json').exists() else {}
    exe = find_binary(ROOT); info = binary_info(exe)
    req = {'clock_period_ns': 50., 'min_dot_products_per_s': 1e5, 'max_p99_latency_cycles': a.max_p99, 'ooc_policy': a.ooc_policy, 'ii0': 40}
    decisions = []; test_cache = {}
    with tempfile.TemporaryDirectory() as tmp:
      for budget in a.budgets:
        for wl, f in WORKLOADS:
            t0 = time.time()
            num = numeric_experiment(ROOT, budget, workload=wl, out=Path(tmp) / f'{wl}_{budget:g}'); hw = choose_hardware(num, impl['costs'], 50., 1e5)
            sp_cal, sp_test = spreads(wl)
            cands = system_candidates(wl, f, sysst, study['rows'], hw, rc[wl], num, rtl_hashes=val.get('cases', [{}])[0].get('rtl_sha256') if val else None, model_version=info['version_line'])
            d = choose_system(cands, budget, req, calibration_spread_max=sp_cal)
            d['workload'] = wl; d['f_low'] = f; d['hardware_status'] = hw['status']
            d['frozen_test'] = frozen_test_check(d, sp_test, budget)        # after the choice; never fed back
            # frozen-test check: reference (16, 2) and the best exploratory configuration chosen on calibration
            best = next((e for e in d['exploration_ranking'] if e['performance_feasible']), None)
            d['calibration_choice'] = None if best is None else {'n': best['n'], 'q': best['q'], 'p99_cycles': best['p99_cycles'], 'throughput_loss_pct': best['throughput_loss_pct']}
            d['test_split'] = {}
            if not a.no_test_split:
                for n, q in sorted({(16, 2)} | ({(best['n'], best['q'])} if best else set())):
                    key = (wl, f, n, q)
                    if key not in test_cache: test_cache[key] = test_split_run(scratch, runs, exe, wl, f, n, q)
                    d['test_split'][f'N{n}_Q{q}'] = test_cache[key]
            d['wall_s'] = round(time.time() - t0, 1)
            decisions.append(d)
            print(f"{wl:22s} budget {budget:<6g} single core: {d['single_core_selection']['id'] if d['single_core_selection'] else 'none'} | strict system: {d['strict_system_status']} | best exploratory: "
                  f"{(best['id'] + ' (' + best['area_source'] + ', ' + best['qualification'] + ')') if best else 'none'} | test: " +
                  ', '.join(f"{k}: P99 {v['rc_p99']} (n={v['rc_count']}), loss vs ideal {v['throughput_loss_vs_ideal_pct']:.2f}%" for k, v in d['test_split'].items()), flush=True)
    from mxacc.provenance import source_hashes, DECISION_SOURCES
    result = {'version': '0.4.2', 'source_sha256': source_hashes(ROOT, DECISION_SOURCES), 'selection_inputs': 'calibration split + declared contract + physical records; test split read only after the choice (frozen_test, test_split)', 'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'requirements': req, 'budgets': a.budgets, 'cpp_binary': info, 'decisions': decisions,
              'note': 'strict system selection requires a fully qualified routed top of the exact (N, Q); the two routed 4-core tops carry electrical violations (slew/cap), so the strict answer is none / not_qualified and the single-core qualified selection stands. The exploration ranking is a prediction with its area-source and validation-scope labels. Test-split numbers are reported after the calibration choice and never used to re-select.'}
    (out / 'decision.json').write_text(json.dumps(result, indent=1))
    (out / 'decision_table.md').write_text(table(result))
    print('== decision written')


def table(res):
    L = ['| workload | budget | single-core selection (qualified; calibration NRMSE) | strict system selection | best exploratory (calibration) | its P99 / loss (cal) | area per core, source, qualification | frozen test (reported after the choice) | why not selected |', '|' + '---|' * 9]
    for d in res['decisions']:
        sc = d['single_core_selection']; best = next((e for e in d['exploration_ranking'] if e['performance_feasible']), None)
        bid = '-' if best is None else f"N={best['n']}, Q={best['q']}"
        perf = '-' if best is None else f"{best['p99_cycles']} cyc / {best['throughput_loss_pct']:.2f} %"
        area = '-' if best is None else f"{best['area_per_core_um2']:,.0f} um2 ({best['area_source']}, {best['qualification']}; {best['vs_single_core_pct']:+.1f} % vs single core)"
        ts = ', '.join(f"{k}: {v['rc_p99']} cyc (n={v['rc_count']}) / {v['throughput_loss_vs_ideal_pct']:.2f} %" for k, v in d['test_split'].items()) or 'not run'
        ft = d.get('frozen_test', {}).get('exploration_choice')
        if ft: ts += f"; test spread {ft['test_spread_max']} (D_MAX 24: {'within' if ft['within_contract'] else 'OUT OF'} contract), test NRMSE after recompute {ft['test_nrmse_after_recompute']:.2g}" 
        why = '-'
        if best:
            c = next(r for r in d['candidates'] if r['id'] == best['id']); why = '; '.join(c['eliminated_by'][:3])
        L.append(f"| {d['workload']} | {d['budget']:g} | {sc['id'] if sc else 'none'} ({sc['area_um2']:,.0f} um2, {sc['qualification']}; {sc['cal_nrmse']:.2g}) | {d['strict_system_status']} | {bid} | {perf} | {area} | {ts} | {why} |")
    L.append(''); L.append(res['note'])
    return '\n'.join(L) + '\n'


if __name__ == '__main__':
    main()
