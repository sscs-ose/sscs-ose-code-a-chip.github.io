from pathlib import Path
import argparse,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from mxlab.evidence import collect_layout
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--job',required=True);p.add_argument('--run',required=True)
    a=p.parse_args();r=collect_layout(a.job,a.run)
    print('area',r['cell_area_um2'],'um2; qualified',r['qualified'])
    for reason in r['qualification_reasons']:print(reason)
