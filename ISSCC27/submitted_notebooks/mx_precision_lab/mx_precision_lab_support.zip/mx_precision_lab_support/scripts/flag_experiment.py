"""Hardware cost of the `inexact` flag (labelled experiment): synthesis of every F and a
post-route run of chosen F at the qualified clock, using exactly the pinned flow and
settings of the fixed physical comparison, but on rtl/dot_top_inexact.sv. Results go to
results/recompute/{synthesis,physical}/ and results/recompute/hardware.json next to the
baseline numbers; they are a labelled experiment, never imported as cost candidates.
"""
from pathlib import Path
import argparse, json, os, subprocess, sys
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
from run_flow import synth, physical_config, driver_command
from timing_sweep import worst_path_summary
from mxacc.implementation import sha256
from mxacc.physical import parse_metrics, constraint_coverage


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--stage', choices=['synth', 'route'], required=True)
    ap.add_argument('--f', type=int, nargs='+', default=[0, 2, 4, 6, 8, 12, 16, 24]); ap.add_argument('--clock-ns', type=float, default=50.)
    ap.add_argument('--pdk-root', default=os.environ.get('PDK_ROOT')); ap.add_argument('--run-tag', default='flag'); a = ap.parse_args()
    out = ROOT / 'results/recompute'; out.mkdir(parents=True, exist_ok=True)
    hw_path = out / 'hardware.json'
    hw = json.loads(hw_path.read_text()) if hw_path.exists() else {'variant': 'inexact', 'rtl_file': 'rtl/dot_top_inexact.sv', 'synthesis': {}, 'post_route': {}}
    hw['rtl_sha256'] = sha256(ROOT / 'rtl/dot_top_inexact.sv'); hw['baseline_rtl_sha256'] = sha256(ROOT / 'rtl/dot_top.sv')
    if a.stage == 'synth':
        for f in a.f:
            row = synth(f, variant='inexact', out_root=out / 'synthesis')
            base_path = ROOT / 'results/synthesis' / f'f{f}' / 'summary.json'
            base = json.loads(base_path.read_text()) if base_path.exists() else None
            hw['synthesis'][str(f)] = {'variant_cell_area_um2': row['cell_area_um2'], 'variant_mapped_cells': row['mapped_cells'],
                                       'baseline_cell_area_um2': None if base is None else base['cell_area_um2'],
                                       'baseline_mapped_cells': None if base is None else base['mapped_cells'],
                                       'delta_area_um2': None if base is None else row['cell_area_um2'] - base['cell_area_um2'],
                                       'delta_area_pct': None if base is None else 100 * (row['cell_area_um2'] / base['cell_area_um2'] - 1)}
            print(f"F{f}: variant {row['cell_area_um2']:,.1f} um2 vs baseline {None if base is None else format(base['cell_area_um2'], ',.1f')} -> {hw['synthesis'][str(f)]['delta_area_pct']}", flush=True)
    else:
        environment = json.loads((ROOT / 'flow/environment.json').read_text())
        for f in a.f:
            folder = ROOT / 'flow/inexact' / f'f{f}_{a.clock_ns:g}ns'
            config_path = physical_config(f, a.clock_ns, folder, variant='inexact')
            run_dir = folder / 'runs' / a.run_tag
            metrics_path = run_dir / 'final/metrics.json'
            if run_dir.exists() and not metrics_path.exists(): raise ValueError(f'{run_dir} exists without final metrics; use a new --run-tag')
            if metrics_path.exists():
                print(f'F{f}: reusing completed run {run_dir}', flush=True); cp = type('cp', (), {'returncode': 0})()
            else:
                command, env = driver_command(config_path, a.pdk_root, a.run_tag, environment)
                cp = subprocess.run(command, cwd=ROOT, env=env)
            base_path = ROOT / 'results/physical' / f'f{f}.json'
            base = json.loads(base_path.read_text()) if base_path.exists() else None
            if not metrics_path.exists():
                hw['post_route'][str(f)] = {'verdict': 'flow_failed', 'exit_code': cp.returncode}; continue
            m = json.loads(metrics_path.read_text()); row = parse_metrics(m); row['xor_differences'] = m.get('design__xor_difference__count')
            # unconstrained endpoints: same evidence as mxacc.physical.import_run (post-route STA check reports, one per corner)
            sta = sorted(p for p in run_dir.iterdir() if p.is_dir() and p.name.endswith('-openroad-stapostpnr'))
            if row.get('unconstrained_paths') is None and sta:
                checks = sorted(sta[-1].rglob('checks.rpt')); corners = json.loads((run_dir / 'resolved.json').read_text()).get('STA_CORNERS', [])
                row['unconstrained_paths'] = constraint_coverage([p.read_text() for p in checks]) if corners and len(checks) == len(corners) else None
            resolved = json.loads((run_dir / 'resolved.json').read_text())
            verdict = ('meets every check at all corners' if row['setup_wns_ns'] is not None and row['setup_wns_ns'] >= 0 and row['hold_wns_ns'] >= 0
                       and row['unconstrained_paths'] == 0 and row['max_slew_violations'] == 0 and row['max_cap_violations'] == 0
                       and row['drc_errors'] == 0 and row['lvs_errors'] == 0 else 'fails')
            entry = {'clock_period_ns': float(resolved['CLOCK_PERIOD']), 'stage': 'post_route_experiment', 'verdict': verdict,
                     'variant': {k: row.get(k) for k in ['cell_area_um2', 'setup_wns_ns', 'hold_wns_ns', 'unconstrained_paths', 'max_slew_violations',
                                                         'max_cap_violations', 'unannotated_signal_nets', 'drc_errors', 'lvs_errors', 'xor_differences']},
                     'baseline': None if base is None else {k: base.get(k) for k in ['cell_area_um2', 'setup_wns_ns', 'hold_wns_ns', 'max_slew_violations', 'max_cap_violations', 'drc_errors', 'lvs_errors']},
                     'delta_area_um2': None if base is None else row['cell_area_um2'] - base['cell_area_um2'],
                     'delta_area_pct': None if base is None else 100 * (row['cell_area_um2'] / base['cell_area_um2'] - 1),
                     'setup_ws_by_corner': {k.split(':')[1]: v for k, v in m.items() if k.startswith('timing__setup__ws__corner')},
                     'worst_path_max_ss': worst_path_summary(run_dir), 'run_dir': str(run_dir.relative_to(ROOT)), 'flow_exit_code': cp.returncode,
                     'same_conditions_as_baseline': 'same flow_settings.json, die, clock, corners, PDK and LibreLane version as results/physical/f%d.json' % f}
            hw['post_route'][str(f)] = entry
            print(json.dumps({k: entry[k] for k in ['verdict', 'delta_area_um2', 'delta_area_pct']}), flush=True)
    hw_path.write_text(json.dumps(hw, indent=2)); print('wrote', hw_path.relative_to(ROOT))


if __name__ == '__main__':
    main()
