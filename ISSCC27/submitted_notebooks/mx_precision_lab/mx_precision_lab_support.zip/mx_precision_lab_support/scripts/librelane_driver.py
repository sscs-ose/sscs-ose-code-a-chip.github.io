"""Host adapter for LibreLane 3.0.16's subprocess-resource tracker.

Only the optional CPU/memory sampler is replaced with waiting for child exit.
The EDA commands, constraints, metrics, DRC and LVS checkers remain upstream.
CPU/memory usage reports from this adapter must not be interpreted as measured.
"""
import os,sys,runpy
if os.environ.get('MXACC_LIBRELANE_PATH'):
    sys.path.insert(0,os.environ['MXACC_LIBRELANE_PATH'])
from librelane.__version__ import __version__
if __version__!='3.0.16':raise RuntimeError('This adapter requires LibreLane 3.0.16')
from librelane.steps.step import ProcessStatsThread

def wait_for_exit(self):
    self.process.wait()

ProcessStatsThread.run=wait_for_exit
runpy.run_module('librelane',run_name='__main__')
