"""A small GDSII reader (pure NumPy) and a GF180 layer renderer.

Draws the real polygons of a final GDS: BOUNDARY, BOX and PATH elements of the
top cell and every placed cell (SREF/AREF with mirror, rotation and magnification).
It is a picture of the geometry only; connectivity, DRC, LVS and timing are
established by their own reports, never by an image.
"""
from pathlib import Path
from collections import defaultdict
import hashlib
import math
import struct
import numpy as np

GF180_LAYERS = {21: ('Nwell', '#b7bfcb'), 22: ('COMP', '#6f9974'), 30: ('Poly2', '#c36b65'), 33: ('Contact', '#6a6c74'),
                34: ('Metal1', '#5b92b3'), 35: ('Via1', '#7e7474'), 36: ('Metal2', '#cf9b4f'), 38: ('Via2', '#89818f'),
                42: ('Metal3', '#9879b7'), 40: ('Via3', '#a8908f'), 46: ('Metal4', '#60a397'), 41: ('Via4', '#8a8e8b'), 81: ('Metal5', '#b77d95')}
LAYER_SETS = {'overview': [34, 36, 42, 46, 81], 'routing_zoom': [34, 35, 36, 38, 42, 40, 46, 41, 81], 'devices_zoom': [21, 22, 30, 33, 34]}

# GDSII record types
HEADER, BGNLIB, LIBNAME, UNITS, ENDLIB, BGNSTR, STRNAME, ENDSTR, BOUNDARY, PATH, SREF, AREF, TEXT, LAYER, DATATYPE, WIDTH, XY, ENDEL, SNAME, COLROW, STRANS, MAG, ANGLE, BOX, BOXTYPE, PATHTYPE = \
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x1A, 0x1B, 0x1C, 0x2D, 0x2E, 0x21


def _real8(b):
    """GDSII 8-byte excess-64 real."""
    sign = -1.0 if b[0] & 0x80 else 1.0
    exponent = (b[0] & 0x7F) - 64
    mantissa = int.from_bytes(b[1:8], 'big') / float(1 << 56)
    return sign * mantissa * 16.0 ** exponent


def read_gds(path):
    """Return (unit_in_metres, {cell: {'polys': [(layer, datatype, ndarray[N,2])], 'refs': [...]}})."""
    data = Path(path).read_bytes(); pos = 0; n = len(data)
    cells = {}; cell = None; element = None; unit = 1e-6
    while pos + 4 <= n:
        length, rtype, dtype = struct.unpack('>HBB', data[pos:pos + 4])
        if length < 4: break
        body = data[pos + 4:pos + length]; pos += length
        if rtype == UNITS:
            unit = _real8(body[8:16])              # database unit in metres
        elif rtype == BGNSTR:
            cell = {'polys': [], 'refs': []}
        elif rtype == STRNAME:
            cells[body.rstrip(b'\x00').decode('ascii', 'replace')] = cell
        elif rtype == ENDSTR:
            cell = None
        elif rtype in (BOUNDARY, BOX, PATH, SREF, AREF, TEXT):
            element = {'type': rtype, 'layer': 0, 'datatype': 0, 'width': 0, 'strans': 0, 'mag': 1.0, 'angle': 0.0, 'colrow': (1, 1)}
        elif element is None:
            continue
        elif rtype == LAYER: element['layer'] = struct.unpack('>h', body[:2])[0]
        elif rtype in (DATATYPE, BOXTYPE): element['datatype'] = struct.unpack('>h', body[:2])[0]
        elif rtype == WIDTH: element['width'] = struct.unpack('>i', body[:4])[0]
        elif rtype == SNAME: element['sname'] = body.rstrip(b'\x00').decode('ascii', 'replace')
        elif rtype == STRANS: element['strans'] = struct.unpack('>H', body[:2])[0]
        elif rtype == MAG: element['mag'] = _real8(body[:8])
        elif rtype == ANGLE: element['angle'] = _real8(body[:8])
        elif rtype == COLROW: element['colrow'] = struct.unpack('>hh', body[:4])
        elif rtype == XY:
            element['xy'] = np.frombuffer(body, dtype='>i4').reshape(-1, 2).astype(np.float64)
        elif rtype == ENDEL:
            t = element['type']
            if cell is not None:
                if t in (BOUNDARY, BOX):
                    cell['polys'].append((element['layer'], element['datatype'], element['xy']))
                elif t == PATH and element.get('width', 0) > 0 and len(element['xy']) >= 2:
                    cell['polys'].extend((element['layer'], element['datatype'], p) for p in _path_polygons(element['xy'], element['width']))
                elif t in (SREF, AREF):
                    cell['refs'].append(element)
            element = None
    return unit, cells


def _path_polygons(points, width):
    """Axis-aligned path segments as rectangles (routing in these layouts is Manhattan)."""
    half = width / 2.0; out = []
    for a, b in zip(points[:-1], points[1:]):
        (x0, y0), (x1, y1) = a, b
        if abs(x1 - x0) >= abs(y1 - y0):
            lo, hi = min(x0, x1), max(x0, x1); out.append(np.array([[lo, y0 - half], [hi, y0 - half], [hi, y0 + half], [lo, y0 + half]]))
        else:
            lo, hi = min(y0, y1), max(y0, y1); out.append(np.array([[x0 - half, lo], [x0 + half, lo], [x0 + half, hi], [x0 - half, hi]]))
    return out


def _transform(points, ref, origin):
    p = points
    if ref['mag'] != 1.0: p = p * ref['mag']
    if ref['strans'] & 0x8000: p = p * np.array([1.0, -1.0])
    if ref['angle']:
        a = math.radians(ref['angle']); c, s = math.cos(a), math.sin(a)
        p = p @ np.array([[c, s], [-s, c]])
    return p + origin


def flatten(cells, top, layers=None, box=None, scale=1.0):
    """Polygons of `top` and its placements in user units (database units * scale); clipped by bounding box when given."""
    chosen = None if layers is None else set(layers)
    groups = defaultdict(list)
    def keep(poly):
        if box is None: return True
        return not (poly[:, 0].max() < box[0] or poly[:, 0].min() > box[2] or poly[:, 1].max() < box[1] or poly[:, 1].min() > box[3])
    def visit(name, refs_chain):
        cell = cells[name]
        for layer, dt, xy in cell['polys']:
            if dt != 0 or (chosen is not None and layer not in chosen): continue
            p = xy
            for ref, origin in reversed(refs_chain): p = _transform(p, ref, origin)
            p = p * scale
            if keep(p): groups[layer].append(p)
        for ref in cell['refs']:
            if ref['sname'] not in cells: continue
            xy = ref['xy']
            if ref['type'] == SREF:
                visit(ref['sname'], refs_chain + [(ref, xy[0])])
            else:
                cols, rows = ref['colrow']; o = xy[0]
                dc = (xy[1] - o) / max(cols, 1); dr = (xy[2] - o) / max(rows, 1)
                for r in range(rows):
                    for c in range(cols):
                        visit(ref['sname'], refs_chain + [(ref, o + c * dc + r * dr)])
    visit(top, [])
    return groups


def top_cells(cells):
    referenced = {ref['sname'] for c in cells.values() for ref in c['refs']}
    return [name for name in cells if name not in referenced]


def bounding_box(cells, top, scale=1.0):
    groups = flatten(cells, top, scale=scale)
    allp = np.concatenate([p for ps in groups.values() for p in ps]) if groups else np.zeros((1, 2))
    return (float(allp[:, 0].min()), float(allp[:, 1].min()), float(allp[:, 0].max()), float(allp[:, 1].max()))


def render_gds(path, output, layers=None, box=None, top_name=None, title=None):
    """Draw real flattened GDS geometry into a PNG; returns a manifest with hashes."""
    import matplotlib.pyplot as plt
    from matplotlib.collections import PolyCollection
    from matplotlib.patches import Patch
    unit, cells = read_gds(path)
    tops = top_cells(cells)
    top = top_name or (tops[0] if len(tops) == 1 else None)
    if top is None or top not in cells: raise ValueError(f'specify one top cell; candidates: {tops}')
    scale = unit * 1e6                                              # database units -> micrometres
    full = bounding_box(cells, top, scale)
    box = tuple(box) if box is not None else full
    groups = flatten(cells, top, layers if layers is not None else list(GF180_LAYERS), box, scale)
    fig, ax = plt.subplots(figsize=(7.2, 6.6), layout='constrained'); ax.set_facecolor('#f8fafb')
    handles = []
    for layer in GF180_LAYERS:
        if layer not in groups: continue
        name, color = GF180_LAYERS[layer]
        ax.add_collection(PolyCollection(groups[layer], facecolors=color, edgecolors='none', alpha=.78 if layer >= 33 else .55, rasterized=True))
        handles.append(Patch(facecolor=color, label=name))
    ax.set(xlim=(box[0], box[2]), ylim=(box[1], box[3]), xlabel='x (µm)', ylabel='y (µm)', title=title or top)
    ax.set_aspect('equal'); ax.legend(handles=handles, loc='upper left', bbox_to_anchor=(1.01, 1), fontsize=8, frameon=False)
    output = Path(output); output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=180, bbox_inches='tight', pad_inches=.08); plt.close(fig)
    return dict(gds_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(), top=top, unit_m=unit, box_um=list(box),
                layers=sorted(groups), polygons_rendered=int(sum(map(len, groups.values()))),
                image_sha256=hashlib.sha256(output.read_bytes()).hexdigest(), source='actual GDS polygons; no inferred connectivity or signoff claim')


def render_views(gds, out_dir, prefix='layout', title=None, zoom_um=35.0):
    """The three standard views: metal overview, routing + vias zoom, devices + Metal1 zoom at the die centre."""
    unit, cells = read_gds(gds); tops = top_cells(cells); top = tops[0] if len(tops) == 1 else None
    if top is None: raise ValueError('the GDS must have one top cell')
    scale = unit * 1e6; x0, y0, x1, y1 = bounding_box(cells, top, scale)
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2; size = min(x1 - x0, y1 - y0, zoom_um) / 2
    zoom = (cx - size, cy - size, cx + size, cy + size)
    out = {}
    for name, layers in LAYER_SETS.items():
        out[name] = render_gds(gds, Path(out_dir) / f'{prefix}_{name}.png', layers, None if name == 'overview' else zoom, top, title)
    return out
