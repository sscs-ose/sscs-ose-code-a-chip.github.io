"""Notebook panels for MX Precision Lab.

One ``Session`` holds the configuration every panel shares (backend, layer, budgets, candidate widths, the design
point being inspected, the last comparison, the frozen choice). Changing any input bumps ``session.version``; a
panel whose result belongs to an older version shows a "needs recomputing" banner instead of a result that no
longer applies. Expensive work runs only behind buttons; sliders update when released.

Every panel first displays its controls, then the result of the current configuration as ordinary cell output
(so the saved notebook shows figures and tables without a running kernel); later interactive runs appear in the
panel's own output area above the saved result.
"""
from pathlib import Path
import csv
import html
import io
import json
import math
import shutil
import time
import traceback
import zipfile
import numpy as np
import matplotlib.pyplot as plt
from .formats import FORMATS, get_format
from .numerics import load_layer, prepare, accumulate, rne_shift, DEFAULT_WIDTHS, EXTENDED_WIDTHS
from .backends import BACKENDS, join, select, matching_records, CLOCK_NS
from . import hardware, visuals
from .figures import show as show_figure

COLORS = {'MXFP4_E2M1': '#245c7c', 'MXFP6_E2M3': '#317c79', 'MXFP6_E3M2': '#9a6b35', 'MXFP8_E4M3': '#665b91', 'MXFP8_E5M2': '#a44d42', 'MXINT8': '#5d6d37'}
LABELS = {k: k.replace('_', ' / ') for k in FORMATS}
DEFAULTS = dict(backend='mxfp4_core', layer='mnist_relu_fc2', total_budget=.12, acc_budget=.001, clock_ns=CLOCK_NS, min_rate=100_000.0, lanes=4,
                point_format='MXFP4_E2M1', point_width=18, extended_widths=False)
BIG_LAYER_DOTS = 300_000      # above this many calibration dot products the "Inspect" panel waits for its button


# ------------------------------------------------------------------------------------------------ display helpers
PANEL_FALLBACK = '[interactive panel: open this notebook in Jupyter or Colab to use the controls; the saved result follows below]'


def _display(*items):
    from IPython.display import display
    for item in items:
        bundle = None
        if hasattr(item, 'model_id') and hasattr(item, '_repr_mimebundle_'):     # ipywidgets 8: keep the widget view, replace the long repr shown by static viewers
            try:
                bundle = item._repr_mimebundle_()
                bundle = dict(bundle[0] if isinstance(bundle, tuple) else bundle); bundle['text/plain'] = PANEL_FALLBACK
            except Exception: bundle = None
        if bundle and 'application/vnd.jupyter.widget-view+json' in bundle: display(bundle, raw=True)
        else: display(item)


def _html(text):
    from IPython.display import HTML
    return HTML(text)


def esc(v):
    return html.escape(str(v))


def pct(v, digits=4):
    if v is None: return 'n/a'
    return '0 %' if v == 0 else f'{100 * v:.{digits}g} %'


def area_text(v):
    return 'Not measured' if v is None else f'{v:,.0f} µm²'


def cards(items):
    body = ''.join(f'<div style="flex:1;min-width:160px;border:1px solid #d1d8de;border-radius:6px;padding:10px 14px;background:#fbfcfd">'
                   f'<div style="font-size:12px;color:#61707c">{esc(label)}</div><div style="font-size:21px;color:{color};margin:4px 0">{esc(value)}</div>'
                   f'<div style="font-size:12px;color:#61707c">{esc(note)}</div></div>' for label, value, note, *rest in [(*c, '#245c7c')[:4] if len(c) == 3 else c for c in items] for color in [rest[0] if rest else '#245c7c'])
    return _html(f'<div style="display:flex;gap:10px;flex-wrap:wrap;margin:12px 0">{body}</div>')


def table(headers, rows, note=None):
    head = ''.join(f'<th style="padding:7px;text-align:left;border-bottom:2px solid #8a969f;white-space:nowrap">{esc(v)}</th>' for v in headers)
    body = ''.join('<tr>' + ''.join(f'<td style="padding:6px 7px;border-bottom:1px solid #d7dde2;vertical-align:top">{v if isinstance(v, Raw) else esc(v)}</td>' for v in r) + '</tr>' for r in rows)
    foot = f'<p style="font-size:12px;color:#61707c;margin:4px 0">{note}</p>' if note else ''
    return _html(f'<div style="overflow:auto"><table style="border-collapse:collapse;width:100%;font-size:13px"><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>{foot}')


class Raw(str):
    """Pre-escaped HTML in a table cell."""


def banner(text, kind='warn'):
    colors = {'warn': ('#fff6e5', '#916129'), 'ok': ('#eef7f1', '#2d6b4a'), 'error': ('#fdecec', '#9c3a3a'), 'info': ('#eef3f8', '#245c7c')}[kind]
    return f'<div style="background:{colors[0]};color:{colors[1]};border-radius:6px;padding:8px 12px;margin:8px 0;font-size:13px">{text}</div>'


def guide(purpose, do, look):
    return _html(f'<div style="border-left:4px solid #245c7c;padding:6px 12px;margin:6px 0 10px 0;font-size:14px"><b>{esc(purpose)}</b><br>'
                 f'<span style="color:#2d4a5c"><b>Now you can:</b> {do}</span><br><span style="color:#2d4a5c"><b>Look at:</b> {look}</span></div>')


def _json_safe(value):
    if isinstance(value, dict): return {k: _json_safe(v) for k, v in value.items() if k not in ('record', 'routed_record', 'synthesis_record')}
    if isinstance(value, (list, tuple)): return [_json_safe(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value): return str(value)
    if isinstance(value, (np.integer,)): return int(value)
    if isinstance(value, (np.floating,)): return float(value)
    if isinstance(value, np.ndarray): return value.tolist()
    return value


def _accordion(w, child, title):
    """A collapsed accordion whose title is set in the way both ipywidgets 7 and 8 accept."""
    acc = w.Accordion(children=[child], selected_index=None)
    try: acc.set_title(0, title)
    except Exception: acc.titles = (title,)
    return acc


def tool_status():
    found = {n: bool(shutil.which(n)) for n in ('iverilog', 'vvp', 'yosys', 'dot')}
    try:
        import importlib.util; found['librelane'] = importlib.util.find_spec('librelane') is not None
    except Exception: found['librelane'] = False
    return found


# ------------------------------------------------------------------------------------------------ layer catalogue
def catalogue(root):
    """Bundled layers: the small MNIST fc2 subset first, then the full catalogue of the project."""
    root = Path(root); out = []
    sub = root / 'data/mnist_fc2_subset'
    if (sub / 'calibration.npz').exists():
        m = json.loads((sub / 'manifest.json').read_text())
        out.append(dict(id='mnist_fc2_subset', path=sub, name='MNIST fc2 subset (48 cal / 96 test rows, K128), fast demo', k=m.get('k', 128), test_role='demonstration',
                        description='First 48 calibration rows and first 96 rows of the official-test export of the MNIST fc2 layer. The test rows were inspected during development: a demonstration split, not an untouched test set.'))
    wl = root / 'data/workloads'
    order = ['mnist_relu_fc2', 'mnist_gelu_ln_fc2', 'bert_tiny_ffn_k128', 'mnist_relu_fc2_k512']
    names = [p.name for p in sorted(wl.iterdir()) if (p / 'calibration.npz').exists()] if wl.exists() else []
    for name in order + sorted(n for n in names if n not in order):
        if name not in names: continue
        p = wl / name; m = json.loads((p / 'manifest.json').read_text()) if (p / 'manifest.json').exists() else {}
        from mxacc.embedded import recorded_test
        spec = None if (p / 'test.npz').exists() else recorded_test(root, name)
        if not (p / 'test.npz').exists() and spec is None: continue
        with np.load(p / 'calibration.npz', allow_pickle=False) as c:
            nc, k = c['x'].shape; outs = c['w'].shape[0]
        if spec is None:
            with np.load(p / 'test.npz', allow_pickle=False) as t: nt = t['x'].shape[0]
        else: nt = spec['n_test']
        role = 'independent' if spec is None else 'recorded'; note = ''
        if name.startswith('mnist'): note = ' Test split = the official 10,000 MNIST test images; Sections 8 and 9 report the frozen choice on it.'
        elif name.startswith('bert'): note = ' Test split = 2,048 WikiText-2 test token vectors; reported in Section 11.'
        elif name.startswith('syn'): note = ' Synthetic stress family (documented generator); its test split is a second draw.'
        pretty = {'mnist_relu_fc2': 'MNIST fc2, ReLU model (512 cal / 10,000 test, K128)', 'mnist_gelu_ln_fc2': 'MNIST fc2, GELU + LayerNorm model (512 / 10,000, K128)',
                  'bert_tiny_ffn_k128': 'BERT-Tiny FFN dense layer (512 / 2,048 tokens, K128, 512 outputs)', 'mnist_relu_fc2_k512': 'MNIST fc2 with K = 512 (512 / 10,000)'}.get(name, name)
        if spec is not None:
            pretty += ', test split recorded'
            note += f' The support package holds the calibration split only. The {nt:,}-row test split is not included, and its frozen-choice results are the recorded ones (Section 11).'
        out.append(dict(id=name, path=p, name=pretty, k=int(k), test_role=role, description=(m.get('description', '') + note).strip(), rows=(int(nc), int(nt)), outputs=int(outs)))
    return out


# ------------------------------------------------------------------------------------------------ session
class Session:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.catalogue = catalogue(self.root)
        self.version = 0; self.listeners = []
        self._cache = {}; self._records = {}
        self.test_history = []
        self.reset()

    # ---- configuration
    def reset(self):
        self.backend_id = DEFAULTS['backend']; self.total_budget = DEFAULTS['total_budget']; self.acc_budget = DEFAULTS['acc_budget']
        self.clock_ns = DEFAULTS['clock_ns']; self.min_rate = DEFAULTS['min_rate']; self.lanes = DEFAULTS['lanes']; self.extended_widths = DEFAULTS['extended_widths']
        self.format_scope = None            # None = every format the backend supports
        self.point_format = DEFAULTS['point_format']; self.point_width = DEFAULTS['point_width']
        self.layer_id = DEFAULTS['layer']; self.layer = self.load_bundled(self.layer_id)
        self.rows = []; self.decision = None; self.rows_version = -1; self.frozen = None; self.test_result = None; self.frozen_version = -1
        self.changed('reset')

    def load_bundled(self, layer_id):
        entry = next((c for c in self.catalogue if c['id'] == layer_id), None)
        if entry is None: raise ValueError(f'unknown bundled layer {layer_id}')
        layer = load_layer(entry['path']); layer.test_role = entry['test_role']; layer.description = entry['description']; layer.name = entry['name']
        return layer

    @property
    def backend(self):
        return BACKENDS[self.backend_id]

    def set(self, **kw):
        changed = False
        for k, v in kw.items():
            if getattr(self, k) != v: setattr(self, k, v); changed = True
        if changed: self.changed('config')
        return changed

    def set_layer(self, layer, layer_id):
        self.layer = layer; self.layer_id = layer_id
        if not self.backend.supports(self.point_format, layer.k, self.lanes): self.point_format = self.backend.formats[0]
        if self.point_width not in self.widths(): self.point_width = min(self.widths(), key=lambda w: abs(w - self.point_width))
        self.changed('layer')

    def changed(self, what):
        if what not in ('point', 'point_silent'): self.version += 1      # inspecting another design point invalidates nothing
        for fn in list(self.listeners):
            try: fn(what)
            except Exception: pass

    def widths(self):
        ws = tuple(self.backend.widths(self.layer.k))
        if self.backend_id == 'generic_core' and self.extended_widths: ws = tuple(sorted(set(ws) | set(EXTENDED_WIDTHS)))
        return ws

    def formats(self):
        fs = self.backend.formats
        return tuple(f for f in fs if (self.format_scope is None or f in self.format_scope)) or fs

    def records(self, refresh=False):
        if refresh or self.backend_id not in self._records: self._records[self.backend_id] = self.backend.records(self.root)
        return self._records[self.backend_id]

    def refresh_records(self):
        self._records.clear(); return self.records()

    # ---- computations
    def evaluate(self, fmt, width, split='calibration'):
        row = self.backend.evaluate(self.layer, fmt, int(width), split=split, lanes=self.lanes, cache=self._cache)
        row['numerically_eligible'] = row['total_nrmse'] <= self.total_budget and row['acc_nrmse'] <= self.acc_budget
        row['clock_period_ns'] = self.clock_ns; row['layer'] = self.layer.name; row['layer_id'] = self.layer_id
        return row

    def compare(self):
        rows = [self.evaluate(fmt, w) for fmt in self.formats() for w in self.widths()]
        self.rows = join(rows, self.records(), self.clock_ns, self.min_rate); self.decision = select(self.rows); self.rows_version = self.version
        if self.frozen is not None and self.frozen_version != self.version: self.frozen_version = -1
        return self.rows

    def rows_current(self):
        return bool(self.rows) and self.rows_version == self.version

    def point(self, fmt=None, width=None):
        if fmt is not None: self.point_format = fmt
        if width is not None: self.point_width = int(width)
        row = self.evaluate(self.point_format, self.point_width)
        return join([row], self.records(), self.clock_ns, self.min_rate)[0]

    def point_record(self):
        c = self.backend.contract(self.point_format, self.layer.k, self.lanes, self.point_width)
        routed, synth = matching_records(self.records(), {**c, 'backend': self.backend_id}, self.clock_ns)
        return c, routed, synth

    def evidence_dir(self):
        return self.backend.evidence_dir(self.root, self.point_format, self.layer.k, self.lanes, self.point_width)

    def rtl_sha256_now(self):
        if self.backend_id == 'mxfp4_core': return self.backend.rtl_sha256(self.root)
        job = self.evidence_dir()
        if (job / 'mx_dot.sv').exists(): return hardware.sha_file(job / 'mx_dot.sv')
        from .evidence import expected_hash
        return expected_hash(self.point_format, self.point_format, self.layer.k, self.lanes, self.point_width)

    def freeze(self, row):
        if row.get('data_sha256') != self.layer.sha256 or row.get('backend') != self.backend_id or row.get('lanes') != self.lanes:
            raise ValueError('This candidate belongs to a different layer, backend or configuration; press Compare candidates and choose again.')
        if not row.get('numerically_eligible'): raise ValueError('This candidate fails the current calibration budgets; it cannot be frozen.')
        if self.layer.x_test is None: raise ValueError('The test split of this layer is not in the support package. Its recorded frozen-choice results are in Section 11.')
        test = self.backend.evaluate(self.layer, row['format_x'], row['accumulator_bits'], split='test', lanes=self.lanes, cache=self._cache)
        test['test_pass'] = test['total_nrmse'] <= self.total_budget and test['acc_nrmse'] <= self.acc_budget
        test['frozen_choice'] = {k: row[k] for k in ('backend', 'format_x', 'format_w', 'accumulator_bits', 'k', 'lanes')}
        test['test_role'] = self.layer.test_role
        self.frozen = dict(row); self.test_result = test; self.frozen_version = self.version
        self.test_history.append(dict(candidate=test['frozen_choice'], layer=self.layer_id, data_sha256=self.layer.sha256, total_budget=self.total_budget, acc_budget=self.acc_budget,
                                      test_pass=test['test_pass'], test_total_nrmse=test['total_nrmse'], test_acc_nrmse=test['acc_nrmse'], utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
        return test

    def frozen_current(self):
        return self.frozen is not None and self.frozen_version == self.version


# ------------------------------------------------------------------------------------------------ renderers (pure display of session state)
def render_comparison(s):
    rows, d = s.rows, s.decision
    if not rows:
        _display(_html(banner('No comparison has been run for this configuration yet. Press <b>Compare candidates</b>.', 'warn'))); return
    b = s.backend
    chosen = d['choice']; short = d['shortlist']
    if chosen: rec_text, rec_note, rec_color = f"{LABELS[chosen['format_x']]} · W{chosen['accumulator_bits']}", f"smallest routed, fully qualified candidate: {area_text(chosen['area_um2'])}", '#2d6b4a'
    elif short: rec_text, rec_note, rec_color = f"{LABELS[short['format_x']]} · W{short['accumulator_bits']} (to implement)", f"smallest mapped area among eligible candidates: {area_text(short['synthesis_area_um2'])}; no routed, qualified record yet", '#916129'
    else: rec_text, rec_note, rec_color = 'none', d['reason'], '#9c3a3a'
    _display(cards([('Layer', s.layer.name.split(' (')[0], f"{len(s.layer.x_cal)} calibration rows · K{s.layer.k} · {s.layer.outputs} outputs"),
                    ('Backend', b.short, f"{len(s.formats())} format(s) × {len(s.widths())} widths = {len(rows)} candidates"),
                    ('Numerically eligible', f"{d['numeric_count']} / {len(rows)}", f"calibration only: total ≤ {pct(s.total_budget, 3)}, accumulation ≤ {pct(s.acc_budget, 3)}"),
                    ('Recommendation', rec_text, rec_note, rec_color)]))
    if not chosen: _display(_html(banner(f"<b>No qualified routed candidate.</b> Reason: {esc(d['reason'])}. " + _why_none(rows), 'warn')))
    # per-format summary
    body = []
    for fmt in s.formats():
        sub = [r for r in rows if r['format_x'] == fmt]; elig = [r for r in sub if r['numerically_eligible']]
        r = min(elig, key=lambda r: r['accumulator_bits']) if elig else None
        q = [r2 for r2 in elig if r2['physically_eligible']]; rq = min(q, key=lambda r: r['area_um2']) if q else None
        body.append([LABELS[fmt], f"W{r['accumulator_bits']} (F = {r['f']})" if r else 'none meets the budgets', pct(r['total_nrmse']) if r else 'n/a', pct(r['acc_nrmse']) if r else 'n/a',
                     (f"{area_text(r['area_um2'])} · {r['area_source'].replace('_', '-')}" if r and r['area_um2'] is not None else ('no implementation record' if r else 'n/a')),
                     (f"W{rq['accumulator_bits']} · {area_text(rq['area_um2'])}" if rq else ('none qualified' if elig else 'n/a'))])
    _display(table(['Format', 'Narrowest eligible W', 'total NRMSE (cal)', 'accumulation NRMSE (cal)', 'Area of that W · source', 'Smallest qualified routed'], body,
                   'NRMSE is the relative RMS error of this layer\'s outputs, not a change in model accuracy. "Narrowest eligible" answers the numerical question only; "qualified routed" also needs a placed-and-routed record that passes timing, electrical, DRC and LVS checks at the target clock.'))
    # plots
    fig, axes = plt.subplots(1, 2, figsize=(12, 3.6), layout='constrained')
    for fmt in s.formats():
        rs = sorted([r for r in rows if r['format_x'] == fmt], key=lambda r: r['accumulator_bits'])
        for ax, metric in zip(axes, ['total_nrmse', 'acc_nrmse']):
            ax.plot([r['accumulator_bits'] for r in rs], [100 * r[metric] for r in rs], marker='o', ms=3.5, color=COLORS[fmt], label=LABELS[fmt])
    top = max(100 * r['total_nrmse'] for r in rows)
    for ax, budget, title, ylab in zip(axes, [s.total_budget, s.acc_budget], ['Layer output error vs accumulator width (format sets the floor)', 'Additional accumulation error vs accumulator width (W controls this)'], ['total NRMSE (%)', 'accumulation NRMSE (%)']):
        ax.axhline(100 * budget, color='#20262d', ls='--', lw=1, label='budget')
        ax.set(xlabel='Accumulator width W (bits)', ylabel=ylab, title=title); ax.grid(alpha=.18); ax.spines[['top', 'right']].set_visible(False)
    acc_top = max([100 * r['acc_nrmse'] for r in rows] + [100 * s.acc_budget]) * 4
    axes[0].set_ylim(0, max(top, 100 * s.total_budget) * 1.15); axes[1].set_yscale('symlog', linthresh=1e-6); axes[1].set_ylim(0, acc_top)
    axes[0].legend(fontsize=8, loc='best'); show_figure(fig, 'fig04a_error_vs_width')
    measured = [r for r in rows if r['area_um2'] is not None]
    tools = sorted({(r['synthesis_record'] or {}).get('source', '') for r in measured if r.get('synthesis_record')})
    if len(tools) > 1: _display(_html(banner('Mapped-area records of these candidates come from different tool versions (' + '; '.join(esc(x) for x in tools) + '). Live runs under experiments/ supersede the shipped records of the same configuration; compare areas across tool versions with care.', 'info')))
    if measured: qualification_chart(s, rows, d)
    else: _display(_html(banner('No implementation record matches these candidates, so no cost chart is drawn (nothing is estimated).', 'info')))


# Qualification colours: the scheme of the MXFP4 core study plots (selected routed / other eligible routed / ineligible routed /
# synthesis only), re-stepped so green, blue and red stay apart under colour-vision deficiency (validated); every bar
# also carries its status in text, and a physical failure is cross-hatched, a synthesis-only record diagonal-hatched.
Q_GREEN, Q_BLUE, Q_RED, Q_GRAY, INK, MUTED = '#4DA83A', '#1E58A6', '#9C2E2E', '#7C8790', '#20262d', '#61707c'


def qualification_status(row, decision):
    """(colour, hatch, short status text) of one joined candidate row."""
    ch = decision.get('choice') if decision else None
    routed, synth = row.get('routed_record'), row.get('synthesis_record')
    if ch and ch['format_x'] == row['format_x'] and ch['accumulator_bits'] == row['accumulator_bits']: return Q_GREEN, None, 'recommended'
    if routed is not None and row.get('qualified') and row.get('rate_ok', True): return Q_BLUE, None, 'qualified, routed'
    if routed is not None:
        bits = []
        if (routed.get('max_cap_violations') or 0) > 0: bits.append(f"{routed['max_cap_violations']} max-cap violation" + ('s' if routed['max_cap_violations'] > 1 else ''))
        if (routed.get('max_slew_violations') or 0) > 0: bits.append(f"{routed['max_slew_violations']} max-slew violation" + ('s' if routed['max_slew_violations'] > 1 else ''))
        if (routed.get('setup_slack_ns') or 0) < 0: bits.append('setup fails')
        if (routed.get('hold_slack_ns') or 0) < 0: bits.append('hold fails')
        if (routed.get('drc_errors') or 0) > 0 or (routed.get('lvs_errors') or 0) > 0: bits.append('DRC/LVS errors')
        if not row.get('rate_ok', True): bits.append('below the required rate')
        return Q_RED, 'xx', 'not qualified: ' + (', '.join(bits) or '; '.join(row.get('qualification_reasons', []))[:48])
    sl = decision.get('shortlist') if decision else None
    if synth is not None and sl and sl['format_x'] == row['format_x'] and sl['accumulator_bits'] == row['accumulator_bits']:
        return Q_GRAY, '///', 'synthesis only · shortlist: implement next'
    if synth is not None: return Q_GRAY, '///', 'synthesis only (mapped area)'
    return None, None, 'no record'


def qualification_chart(s, rows, decision):
    """One row per candidate that has an implementation record: area with its qualification, then its two errors."""
    from matplotlib.patches import Patch
    from matplotlib.lines import Line2D
    order = {f: i for i, f in enumerate(FORMATS)}
    drawn = sorted([r for r in rows if r['area_um2'] is not None], key=lambda r: (order[r['format_x']], r['accumulator_bits']))
    n = len(drawn); multi = len({r['format_x'] for r in drawn}) > 1
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 0.42 * n + 1.9), sharey=True, gridspec_kw={'width_ratios': [2.8, 1, 1], 'wspace': .06})
    fig.subplots_adjust(left=.13 if multi else .09, right=.985, top=1 - 1.05 / (0.42 * n + 1.9), bottom=.75 / (0.42 * n + 1.9))
    y = list(range(n))[::-1]; statuses = set(); any_fail = False
    top = max(r['area_um2'] for r in drawn) / 1000
    longest = max(len(f"{r['area_um2']:,.0f} µm² · " + qualification_status(r, decision)[2] + (' · fails the error budget' if not r['numerically_eligible'] else '')) for r in drawn)
    for yi, r in zip(y, drawn):
        color, hatch, label = qualification_status(r, decision)
        fails = not r['numerically_eligible']
        hollow = fails or hatch is not None
        axes[0].barh(yi, r['area_um2'] / 1000, height=.56, color='white' if hollow else color, edgecolor=color, linewidth=1.4, hatch=hatch, zorder=2)
        text = f"{r['area_um2']:,.0f} µm² · {label}" + (' · fails the error budget' if fails else '')
        axes[0].text(r['area_um2'] / 1000 + top * .015, yi, text, va='center', fontsize=8.6, color=INK, fontweight='bold' if label == 'recommended' or 'shortlist' in label else 'normal', clip_on=False)
        statuses.add((color, hatch, label.split(' ·')[0].split(':')[0])); any_fail |= fails
        for ax, metric, budget, scale in ((axes[1], 'acc_nrmse', s.acc_budget, 1), (axes[2], 'total_nrmse', s.total_budget, 1)):
            v = 100 * r[metric]; over = r[metric] > budget
            ax.plot(v, yi, marker='X' if over else 'o', ms=8, color=color, mec='white', mew=1.2, ls='none', zorder=3)
    axes[0].set_xlim(0, top * (1.12 + 0.0175 * longest)); axes[0].set_xlabel('Standard-cell area (10³ µm²)')
    try:   # widen the area axis until the longest status text ends inside it (measured, not estimated)
        for _ in range(4):
            fig.canvas.draw(); r = fig.canvas.get_renderer(); inv = axes[0].transData.inverted()
            right = max(inv.transform((tx.get_window_extent(r).x1, 0))[0] for tx in axes[0].texts)
            lo, hi = axes[0].get_xlim()
            if right <= hi * .99: break
            axes[0].set_xlim(0, right * 1.04)
    except Exception: pass
    axes[0].set_yticks(y, [(f"{LABELS[r['format_x']]} · " if multi else '') + f"W{r['accumulator_bits']}" + (f" (F{r['f']})" if s.backend_id == 'mxfp4_core' else '') for r in drawn])
    acc_vals = [100 * r['acc_nrmse'] for r in drawn] + [100 * s.acc_budget]
    axes[1].axvline(100 * s.acc_budget, color=INK, ls='--', lw=1); axes[1].set_xscale('symlog', linthresh=1e-6); axes[1].set_xlim(0, max(acc_vals) * 6)
    hi1 = max(acc_vals) * 6; axes[1].set_xticks([0] + [10.0 ** k for k in range(-6, 3, 2) if 10.0 ** k <= hi1], ['0'] + [f'$10^{{{k}}}$' for k in range(-6, 3, 2) if 10.0 ** k <= hi1])
    axes[1].set_xlabel('accumulation NRMSE (%)')
    tot_vals = [100 * r['total_nrmse'] for r in drawn] + [100 * s.total_budget]
    axes[2].axvline(100 * s.total_budget, color=INK, ls='--', lw=1); axes[2].set_xlim(0, max(tot_vals) * 1.15); axes[2].set_xlabel('total NRMSE (%)')
    for ax in axes:
        ax.grid(axis='x', color='#e3e8ec', lw=.8); ax.set_axisbelow(True); ax.spines[['top', 'right']].set_visible(False); ax.tick_params(length=0)
        ax.set_ylim(-.7, n - .3)
    axes[1].set_title('dashed = budget · ✕ over budget', fontsize=8.5, color=MUTED, loc='left')
    n_routed = sum(1 for r in drawn if r['routed_record']); n_synth = n - n_routed
    kinds = ', '.join(x for x in (f'{n_routed} routed' if n_routed else '', f'{n_synth} synthesis only' if n_synth else '') if x)
    if not n_routed: kinds = 'all synthesis only' if n > 1 else 'synthesis only'
    rest = f"{n} of {len(rows)} candidates have a record, {kinds}; the other {len(rows) - n} have none and are not drawn" if n < len(rows) else f"{n} candidates with a record: {kinds}"
    fig.suptitle(f"{s.backend.short} · cost and qualification ({rest})", x=.01, ha='left', fontsize=10.5, fontweight='bold', color=INK)
    present = {c for c, h, l in statuses}
    handles = [h for c, h in ((Q_GREEN, Patch(facecolor=Q_GREEN, edgecolor=Q_GREEN, label='recommended')), (Q_BLUE, Patch(facecolor=Q_BLUE, edgecolor=Q_BLUE, label='qualified, routed')),
                              (Q_RED, Patch(facecolor='white', edgecolor=Q_RED, hatch='xx', label='routed, physical check fails')), (Q_GRAY, Patch(facecolor='white', edgecolor=Q_GRAY, hatch='///', label='synthesis only (cannot qualify)'))) if c in present]
    if any_fail: handles.append(Patch(facecolor='white', edgecolor=MUTED, label='hollow: fails the error budget'))
    fig.legend(handles=handles, ncol=len(handles), loc='upper left', bbox_to_anchor=(.01, 1 - .5 / (0.42 * n + 1.9)), frameon=False, fontsize=8.6, handlelength=1.6)
    show_figure(fig, 'fig04b_cost_and_qualification')

def _why_none(rows):
    numeric = [r for r in rows if r['numerically_eligible']]
    if not numeric:
        best = min(rows, key=lambda r: r['total_nrmse']); return f"The smallest total error is {pct(best['total_nrmse'])} ({LABELS[best['format_x']]}, W{best['accumulator_bits']}); loosen the budget or change the format."
    reasons = {}
    for r in numeric:
        for x in r.get('qualification_reasons', []): reasons[x] = reasons.get(x, 0) + 1
    top = sorted(reasons.items(), key=lambda kv: -kv[1])[:3]
    return 'Why the eligible candidates are not qualified: ' + '; '.join(f'{esc(k)} ({v})' for k, v in top) + '.'


def render_point(s, row):
    c = row; budget_ok = row['numerically_eligible']
    _display(cards([('Input quantization error', pct(row['quant_nrmse']), 'exact MX dot vs the original FP32 layer; W cannot change it'),
                    ('Additional accumulation error', pct(row['acc_nrmse']), 'finite W vs exact accumulation of the same MX inputs; W controls this'),
                    ('Total output error', pct(row['total_nrmse']), 'finite-W result vs the original FP32 layer'),
                    ('Numerical requirement', 'meets' if budget_ok else 'fails', f"total ≤ {pct(s.total_budget, 3)}, accumulation ≤ {pct(s.acc_budget, 3)}", '#2d6b4a' if budget_ok else '#9c3a3a')]))
    rec = row.get('record')
    _display(table(['Item', 'Value', 'Meaning'], [
        ['Backend · format · W', f"{s.backend.short} · {LABELS[row['format_x']]} · W{row['accumulator_bits']}", s.backend.numerics],
        ['Exact block sum', f"{row['block_sum_bits']} bits", 'every 32-element block is summed exactly before any rounding'],
        ['Derived F (fractional alignment bits)', str(row['f']), 'F = W − block-sum bits − log2(blocks); the MXFP4 core calls its candidates by F'],
        ['Blocks · lanes', f"{row['blocks']} × 32 elements · P = {row['lanes']}", f"K = {row['k']}"],
        ['Schedule', f"II = {row['ii_no_stall']} cycles, latency {row.get('latency_cycles', row['ii_no_stall'] - 1)} cycles", 'no-stall interface; cycles, not time'],
        ['Inexact dot products', pct(row['inexact_fraction']), 'fraction of calibration dot products that discarded a non-zero bit: '
         + ('what the OPTIONAL flag variant would report. The baseline core and its records have no flag' if s.backend_id == 'mxfp4_core' else 'reported by the generated core\'s built-in out_inexact port (included in its mapped area)')],
        ['Area', f"{area_text(row['area_um2'])} ({row['area_source'].replace('_', '-')})" if row['area_um2'] is not None else 'Not measured', 'from the record that matches this backend, format, K, P, W and RTL hash'],
        ['Post-route setup / hold slack', (f"{row['setup_slack_ns']:+.3f} ns / {row['hold_slack_ns']:+.3f} ns" if row.get('setup_slack_ns') is not None else 'Not measured'), f'worst corner at the {s.clock_ns:g} ns target; a target is not an achieved fmax'],
        ['Qualification', 'qualified' if row['physically_eligible'] else 'not qualified', '; '.join(row['qualification_reasons']) or 'every physical check passed'],
    ]))
    g = s._cache.get((s.backend_id, s.layer.sha256, row['format_x'], 'calibration'))
    n = min(160, s.layer.outputs * min(4, len(s.layer.x_cal)))
    if s.backend_id == 'generic_core' and g is not None:
        r = accumulate(g, row['accumulator_bits'], row['format_x'], lanes=s.lanes); exact, finite = g.reference.ravel()[:n], r['values'].ravel()[:n]
    else:
        from mxacc.arithmetic import accumulate as macc, as_float
        gg, gold, ref, original = g; t, eo = macc(gg, row['f']); exact, finite = ref.ravel()[:n], as_float(t, eo).ravel()[:n]
    fig, axes = plt.subplots(2, 1, figsize=(9.5, 4.2), layout='constrained', sharex=True, height_ratios=[2, 1])
    axes[0].plot(exact, color='#245c7c', lw=1.4, label='exact MX accumulation'); axes[0].plot(finite, color='#b8692b', lw=1, ls='--', label=f"W{row['accumulator_bits']} (F{row['f']})")
    axes[0].set(ylabel='output value', title='Same MX inputs: exact accumulation vs the selected W, first calibration outputs'); axes[0].legend(fontsize=8, loc='upper right')
    err = finite - exact
    axes[1].bar(range(len(err)), err, color=['#b8692b' if e else '#c9d2d9' for e in err], width=1.0)
    axes[1].set(xlabel='calibration output index', ylabel='W-bit − exact', title=f"accumulation error per output: {int((err != 0).sum())} of {len(err)} shown outputs differ; max |error| {abs(err).max():.3g}" if len(err) else '')
    for ax in axes: ax.spines[['top', 'right']].set_visible(False)
    show_figure(fig, 'fig05a_exact_vs_finite_width')


def bits_view(s, fmt, width, sample, output):
    """Per-block alignment of one real calibration dot product (generic numerics; identical for the MXFP4 core at the same F)."""
    key = ('generic_core', s.layer.sha256, fmt, 'calibration')
    g = s._cache.get(key)
    if g is None: g = prepare(s.layer.x_cal, s.layer.w, fmt); s._cache[key] = g
    c = BACKENDS['generic_core'].contract(fmt, s.layer.k, s.lanes, width)
    if not (0 <= sample < len(s.layer.x_cal) and 0 <= output < s.layer.outputs): raise ValueError('sample/output index out of range')
    idx = (sample, output); anchor = int(g.exponents[idx].max()); rows = []; loss = []
    for i, (sg, e) in enumerate(zip(g.sums[idx], g.exponents[idx])):
        sh = int(e - anchor) + c['f']; value, lost = rne_shift(sg, sh); d = max(0, -sh)
        if d:
            q, r = divmod(int(sg), 1 << d); bits = f'{r:0{d}b}'
            if len(bits) > 28: bits = bits[:10] + '…' + bits[-14:] + f' ({d} bits)'
            retained, step = str(q), f'right {d}'
        else: bits, retained, step = 'none', str(int(sg) << sh), f'left {sh}'
        rows.append([i, int(sg), int(e), step, retained, bits, value, 'non-zero bits lost' if lost else 'exact']); loss.append(lost)
    result = accumulate(g, width, fmt, lanes=s.lanes)
    _display(_html(f"<p><b>{LABELS[fmt]} · W{width} (F = {c['f']}) · calibration row {sample} × output channel {output}</b><br>Each row is one 32-element block of this dot product. A right shift discards bits; an inexact flag (built into the generic core, an optional variant of the MXFP4 core) lights only when a discarded bit is non-zero.</p>"))
    _display(table(['block', 'exact block sum Sg', 'Eg', 'shift', 'retained (floor)', 'discarded bits', 'after RNE', 'status'], rows))
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.0), layout='constrained')
    contribution = [math.ldexp(float(sg), int(e)) for sg, e in zip(g.sums[idx], g.exponents[idx])]
    axes[0].bar(range(len(rows)), contribution, color=['#b8692b' if v else '#245c7c' for v in loss]); axes[0].set(xlabel='block index', ylabel='exact contribution', title='Orange: this block discarded non-zero bits'); axes[0].set_xticks(range(len(rows)))
    outputs = [float(g.reference[idx]), float(result['values'][idx])]
    bars = axes[1].bar(['exact MX', f'W{width}'], outputs, color=['#245c7c', '#b8692b']); axes[1].bar_label(bars, labels=[f'{v:.7g}' for v in outputs], padding=4, fontsize=9); axes[1].margins(y=.15)
    axes[1].set(ylabel='output value', title=f"absolute accumulation error = {abs(float(result['error'][idx])):.6g}")
    for ax in axes: ax.spines[['top', 'right']].set_visible(False)
    show_figure(fig, 'fig05b_bits_of_one_dot_product')
    _display(_html('<p style="font-size:13px;color:#61707c">Errors of different blocks can cancel, so flag = 1 does not prove the result is wrong; flag = 0 proves this transaction has zero accumulation error. The table shows real data from the selected layer, not a fixed illustration.</p>'))
    return dict(rows=rows, error=float(result['error'][idx]), inexact=bool(result['inexact'][idx]))


def render_hardware(s, view='rtl_multiply.svg', layout_view='overview'):
    """Circuit view, layout view and PPA table of the current design point (static)."""
    row = s.point(); folder = s.evidence_dir(); sha = s.rtl_sha256_now()
    c, routed, synth = s.point_record()
    head = f"<p><b>Current design: {s.backend.short} · {LABELS[s.point_format]} · W{s.point_width} (F = {c['f']}) · K{s.layer.k} · P{s.lanes}</b> · evidence folder <code>{esc(folder.relative_to(s.root)) if str(folder).startswith(str(s.root)) else esc(folder)}</code> · RTL hash <code>{sha[:16]}…</code></p>"
    _display(_html(head + '<h4 style="margin:10px 0 2px 0">Circuit view (actual netlist)</h4>'))
    _display(_html(visuals.schematic_html(folder, view, sha)))
    _display(_html('<h4 style="margin:10px 0 2px 0">Layout (actual GDS)</h4>'))
    lay = visuals.layout_html(folder, layout_view, sha, _gds_path(s, routed))
    _display(_html(lay if lay else banner('<b>Not measured:</b> this configuration has no placed-and-routed layout. ' + ('Run or import a LibreLane result (Run hardware tab), then draw it.' if s.backend_id == 'generic_core' else 'Only the routed F candidates of the MXFP4 core have layouts.'), 'info')))
    _display(_html('<h4 style="margin:10px 0 2px 0">PPA evidence</h4>' + visuals.ppa_html(row)))
    return row


def _gds_path(s, routed):
    if routed is None: return None
    if s.backend_id == 'mxfp4_core': return s.root / f"results/physical/f{routed['f']}/final/gds/dot_k{routed['k']}_f{routed['f']}.gds"
    return Path(routed['evidence_dir']) / 'raw/layout.gds' if routed.get('evidence_dir') else None


def render_freeze(s):
    if s.frozen is None:
        _display(_html(banner('No configuration has been frozen yet.', 'info'))); return
    t = s.test_result; stale = not s.frozen_current()
    if stale: _display(_html(banner('<b>Stale:</b> the layer, backend or budgets changed after this result was produced. It no longer describes the current configuration: compare and freeze again.', 'warn')))
    role = ('demonstration split: its rows were inspected during development; keep a separate untouched test set before claiming final generalisation' if t['test_role'] == 'demonstration'
            else 'independent split (not used for the calibration choice above)')
    _display(cards([('Frozen configuration', f"{LABELS[t['format_x']]} · W{t['accumulator_bits']}", f"{s.backend.short}; the test never re-selects"),
                    ('Test total NRMSE', pct(t['total_nrmse']), f"{t['vectors']:,} test rows · {role.split(':')[0]}"),
                    ('Test accumulation NRMSE', pct(t['acc_nrmse']), 'vs exact accumulation of the same MX inputs'),
                    ('Numerical acceptance', 'PASS' if t['test_pass'] else 'FAIL, kept, not reselected', f"same budgets as calibration; hardware qualification is checked separately", '#2d6b4a' if t['test_pass'] else '#9c3a3a')]))
    _display(_html(f'<p style="font-size:13px;color:#61707c">Test split role: {esc(role)}. Layer-level NRMSE is reported here; task accuracy (for the MNIST models) is a separate measurement in Section 9.</p>'))
    opened = [h for h in s.test_history if h['data_sha256'] == s.layer.sha256]
    if len(opened) > 1: _display(_html(banner(f'The test split of this layer has been opened {len(opened)} times in this session. If you changed settings after looking at a test result, that split is no longer an untouched test set.', 'warn')))


def cases_html(s):
    """The two worked decisions, recomputed from the records and the numerics now (with the expected figures checked)."""
    out = []
    # Case A: the MXFP4 core on the full MNIST fc2 layer (512 calibration rows, official 10,000-image test) at 12 % / 0.1 %
    cache = {}; mx = BACKENDS['mxfp4_core']; layer = s.load_bundled('mnist_relu_fc2'); recs = mx.records(s.root)
    rows = []
    for W in mx.widths(128):
        r = mx.evaluate(layer, 'MXFP4_E2M1', W, cache=cache); r['numerically_eligible'] = r['total_nrmse'] <= .12 and r['acc_nrmse'] <= .001; rows.append(r)
    rows = join(rows, recs); d = select(rows); by = {r['accumulator_bits']: r for r in rows}
    f2, f4 = by[18], by[20]; saving = 100 * (1 - f2['routed_area_um2'] / f4['routed_area_um2'])
    ta = mx.evaluate(layer, 'MXFP4_E2M1', 18, split='test', cache=cache); ta_ok = ta['total_nrmse'] <= .12 and ta['acc_nrmse'] <= .001
    out.append(f"<p style='color:{MUTED}'>Fixed worked decisions at the default settings, independent of the panels.</p>"
               f"<h4>Case A · MXFP4 core: is F2 enough, or do we need F4?</h4>"
               f"<p><b>Setting:</b> MNIST fc2 layer (512 calibration rows, official 10,000-image test split), total NRMSE ≤ 12 %, accumulation NRMSE ≤ 0.1 %, 50 ns, GF180 routed evidence.<br>"
               f"<b>The tool excluded:</b> W16 (F0), accumulation NRMSE {pct(by[16]['acc_nrmse'])} exceeds 0.1 %; W40 (F24), routed but one max-cap violation, not qualified; W32 (F16), synthesis only.<br>"
               f"<b>It selected:</b> <b>W18 (F2)</b>, {area_text(f2['routed_area_um2'])} routed standard-cell area, setup slack {f2['setup_slack_ns']:+.2f} ns at 50 ns, DRC/LVS clean: the smallest qualified routed candidate "
               f"({'selection reproduced' if d['choice'] and d['choice']['accumulator_bits'] == 18 else 'NOTE: current selection differs'}).<br>"
               f"<b>Cost of the alternative:</b> W20 (F4), the next candidate up, is also qualified at {area_text(f4['routed_area_um2'])}; F2 is <b>{saving:.2f} % smaller</b> in routed standard-cell area.<br>"
               f"<b>Frozen check:</b> W18 once on the independent 10,000-image test split: total NRMSE {pct(ta['total_nrmse'])}, accumulation NRMSE {pct(ta['acc_nrmse'])}: {'within' if ta_ok else 'outside'} the same budgets.<br>"
               f"<b>Limits:</b> one routed implementation per candidate (placement noise is not characterised); layer-level error of one linear layer, not task accuracy; power is a vectorless flow estimate, not a workload measurement.</p>")
    # Case B: the generic core W16 / W18 / W20 on the same layer
    gc = BACKENDS['generic_core']; recs2 = gc.records(s.root); rows2 = []
    for W in (16, 18, 20):
        r = gc.evaluate(layer, 'MXFP4_E2M1', W, cache=cache); r['numerically_eligible'] = r['total_nrmse'] <= .12 and r['acc_nrmse'] <= .001; rows2.append(r)
    rows2 = join(rows2, recs2); b16, b18, b20 = rows2; saving2 = 100 * (1 - b18['synthesis_area_um2'] / b20['synthesis_area_um2'])
    tb = gc.evaluate(layer, 'MXFP4_E2M1', 18, split='test', cache=cache); tb_ok = tb['total_nrmse'] <= .12 and tb['acc_nrmse'] <= .001
    out.append(f"<h4>Case B · Generic MX core, MXFP4 example: W16 vs W18 vs W20 on the same layer</h4>"
               f"<p><b>Setting:</b> the same layer and budgets, MXFP4 inputs; backend = generic core (synthesis evidence only). The generic core also supports five other MX encodings; this case covers the MXFP4 example only.<br>"
               f"<b>The tool excluded:</b> W16, accumulation NRMSE {pct(b16['acc_nrmse'])} exceeds 0.1 % on calibration.<br>"
               f"<b>It shortlisted:</b> <b>W18</b> ({area_text(b18['synthesis_area_um2'])} technology-mapped) over the conservative W20 ({area_text(b20['synthesis_area_um2'])}): <b>{saving2:.2f} % less mapped area</b>; both have II = 42 cycles. "
               f"Calibration: W18 total NRMSE {pct(b18['total_nrmse'])}, accumulation {pct(b18['acc_nrmse'])}. Frozen check on the independent 10,000-image test split: total {pct(tb['total_nrmse'])}, accumulation {pct(tb['acc_nrmse'])}, {'within' if tb_ok else 'outside'} the budgets. "
               f"The MXFP4 core gives the identical numbers at W18 (same alignment rule; checked by a unit test).<br>"
               f"<b>Limits:</b> this is a synthesis-stage, layer-level result for MXFP4 inputs: no placement, routing, timing closure, DRC/LVS or power exists for the generic core yet, so nothing here is a qualified implementation or a full PPA improvement.</p>")
    return ''.join(out), dict(case_a_saving_pct=saving, case_b_saving_pct=saving2, f2_area=f2['routed_area_um2'], f4_area=f4['routed_area_um2'], w18_area=b18['synthesis_area_um2'], w20_area=b20['synthesis_area_um2'])


# ------------------------------------------------------------------------------------------------ the panels
class Lab:
    """Builds the notebook panels around one Session."""

    def __init__(self, root):
        self.s = Session(root); self.root = self.s.root
        self._panels = {}

    def _w(self):
        try: import ipywidgets as w
        except ImportError: raise RuntimeError('ipywidgets is required for the panels; the Session API works without it')
        return w

    # ---- status + log helpers
    def _status(self, widget, text, kind='info'):
        widget.value = banner(text, kind)

    def _run(self, status, out, log, fn, label):
        """Run fn() with a status line, exceptions explained, and the traceback in the log accordion."""
        t0 = time.time(); self._status(status, f'Running: {esc(label)} …', 'info')
        with out:
            out.clear_output(wait=True)
            try:
                result = fn(); self._status(status, f'Done: {esc(label)} ({time.time() - t0:.1f} s)', 'ok'); return result
            except Exception as e:
                self._status(status, f'<b>Failed:</b> {esc(type(e).__name__)}: {esc(e)}<br><b>Next step:</b> {esc(self._advice(e))}', 'error')
                if log is not None: log.value = '<pre style="font-size:11px;white-space:pre-wrap">' + esc(traceback.format_exc()) + '</pre>'
                return None

    @staticmethod
    def _advice(e):
        m = str(e)
        if isinstance(e, FileNotFoundError) and 'not installed' in m: return 'install the named tool (Colab: the Install tools button; Mac: brew install icarus-verilog yosys graphviz) or use the cached evidence.'
        if 'budget' in m: return 'loosen the budget in the Layer & budget panel, or choose another format/width.'
        if 'different layer' in m or 'changed' in m: return 'press Compare candidates to refresh the candidate list for the current configuration.'
        if 'calibration.npz' in m or 'test.npz' in m: return 'export the layer as calibration.npz {x, w} and test.npz {x} (see Bring your own layer).'
        return 'read the full log below; the inputs that were used are listed in the panel.'

    # ---------------------------------------------------------------- Step 1: layer, backend, budget
    def layer_panel(self):
        """Step 3: layer, backend and budgets (controls only; the comparison lives in compare_panel)."""
        w = self._w(); s = self.s; out = w.Output(); status = w.HTML(); log = w.HTML()
        cmp_out = w.Output(); cmp_status = w.HTML(); cmp_log = w.HTML()
        layers = w.Dropdown(options=[(c['name'], c['id']) for c in s.catalogue] + [('Your own layer export (see Reproducibility)', 'custom')], value=s.layer_id, description='Layer', layout=w.Layout(width='760px'), style={'description_width': '140px'})
        layer_note = w.HTML()
        upload = w.FileUpload(accept='.npz', multiple=True, description='Upload 2 files'); folder = w.Text(placeholder='or a folder with the two exported files', layout=w.Layout(width='520px'))
        load = w.Button(description='Load layer'); custom = w.VBox([w.HBox([upload, folder, load])]); custom.layout.display = 'none'
        backend = w.Dropdown(options=[(b.title, b.id) for b in BACKENDS.values()], value=s.backend_id, description='Backend', layout=w.Layout(width='760px'), style={'description_width': '140px'})
        backend_note = w.HTML()
        total = w.BoundedFloatText(value=100 * s.total_budget, min=0, max=100, step=.1, description='Total NRMSE ≤ (%)', style={'description_width': '140px'}, layout=w.Layout(width='300px'))
        acc = w.BoundedFloatText(value=100 * s.acc_budget, min=0, max=100, step=.01, description='Accumulation NRMSE ≤ (%)', style={'description_width': '180px'}, layout=w.Layout(width='340px'))
        units = w.HTML('<span style="font-size:12px;color:#61707c">Total: output error of this layer vs the original FP32 layer, including input quantization (typical MXFP4: 5 to 15 %). '
                       'Accumulation: the extra error the finite accumulator adds on top of exact MX arithmetic (typical budget 0.01 to 1 %). Neither is an accuracy drop in percentage points.</span>')
        formats = w.SelectMultiple(options=[(LABELS[f], f) for f in FORMATS], value=tuple(FORMATS), rows=6, description='Formats', style={'description_width': '140px'})
        lanes = w.Dropdown(options=[1, 2, 4, 8, 16, 32], value=s.lanes, description='Lanes P', style={'description_width': '140px'})
        clock = w.FloatText(value=s.clock_ns, description='Clock period (ns)', style={'description_width': '140px'})
        rate = w.FloatText(value=s.min_rate, description='Min dot products/s', style={'description_width': '140px'})
        extended = w.Checkbox(value=s.extended_widths, description='also sweep W = 64 and 96 (generic core; slower)', indent=False)
        advanced = _accordion(w, w.VBox([w.HTML('<span style="font-size:12px;color:#61707c">Process, Liberty and tool paths are fixed by the records (GF180MCU, 50 ns). K comes from the layer. The MXFP4 core is P = 4 only.</span>'), formats, lanes, clock, rate, extended]), 'Advanced settings (formats, lanes, clock, rate, extra widths)')
        run = w.Button(description='Compare candidates', button_style='primary', icon='play'); reset = w.Button(description='Reset to defaults', icon='refresh')

        def describe():
            entry = next((c for c in s.catalogue if c['id'] == layers.value), None)
            layer_note.value = f'<span style="font-size:12px;color:#61707c">{esc(entry["description"]) if entry else "Your own export: finite FP32 tensors; x: [N, K], w: [M, K]; weights identical in both files."}</span>'
            b = BACKENDS[backend.value]; backend_note.value = f'<span style="font-size:12px;color:#61707c">{esc(b.summary)}</span>'
            formats.disabled = backend.value == 'mxfp4_core'; lanes.disabled = backend.value == 'mxfp4_core'; extended.disabled = backend.value == 'mxfp4_core'
        describe()

        quiet = [False]                      # True while Reset writes the widgets, so observers do not push stale values back

        def changed(_=None):
            if quiet[0]: return
            try:
                s.set(backend_id=backend.value, total_budget=total.value / 100, acc_budget=acc.value / 100, lanes=lanes.value if backend.value == 'generic_core' else 4,
                      clock_ns=float(clock.value), min_rate=float(rate.value), extended_widths=bool(extended.value),
                      format_scope=None if backend.value == 'mxfp4_core' or set(formats.value) == set(FORMATS) else tuple(formats.value))
                if not s.backend.supports(s.point_format, s.layer.k, s.lanes): s.point_format = s.backend.formats[0]
                if s.point_width not in s.widths(): s.point_width = min(s.widths(), key=lambda x: abs(x - s.point_width)); s.changed('point')
                describe(); self._status(status, 'Settings changed: press <b>Compare candidates</b> (next step) to recompute. Panels below mark their results as stale until then.', 'warn')
                self._status(cmp_status, 'Configuration changed: the result below is stale; press <b>Compare candidates</b>.', 'warn')
            except Exception as e: self._status(status, f'Invalid setting: {esc(e)}', 'error')
        for widget in (backend, total, acc, formats, lanes, clock, rate, extended): widget.observe(changed, names='value')

        def choose_layer(_=None):
            if quiet[0]: return
            custom.layout.display = 'flex' if layers.value == 'custom' else 'none'
            if layers.value != 'custom':
                def go():
                    layer = s.load_bundled(layers.value); s.set_layer(layer, layers.value); describe()
                    print(f'Loaded {layer.name}: K{layer.k}, {len(layer.x_cal)} calibration rows, test split {layer.test_role}, {layer.outputs} outputs.')
                    if len(layer.x_cal) * layer.outputs > BIG_LAYER_DOTS: print('Large layer: the comparison may take up to a minute; the Inspect panel waits for its button.')
                self._run(status, out, log, go, 'load layer'); run.disabled = False; self._status(cmp_status, 'Layer changed: the result below is stale; press <b>Compare candidates</b>.', 'warn')
            else:
                run.disabled = True; self._status(status, 'Upload calibration.npz and test.npz (or give a folder), then press Load layer.', 'info')
        layers.observe(choose_layer, names='value')

        def load_custom(_):
            def go():
                if folder.value.strip(): path = Path(folder.value.strip()).expanduser()
                else:
                    files = list(upload.value) if not isinstance(upload.value, dict) else [dict(v, name=k) for k, v in upload.value.items()]
                    names = {f.get('name', f.get('metadata', {}).get('name', '')) for f in files}
                    if names != {'calibration.npz', 'test.npz'}: raise ValueError('upload exactly calibration.npz and test.npz together (so an old split cannot be reused by mistake)')
                    path = self.root / 'data/user_layer'; path.mkdir(parents=True, exist_ok=True)
                    for f in files: (path / f.get('name', f.get('metadata', {}).get('name'))).write_bytes(bytes(f['content']))
                layer = load_layer(path); layer.test_role = 'independent'; s.set_layer(layer, 'custom:' + path.name)
                print(f'Loaded {layer.name}: K{layer.k}, {len(layer.x_cal)} calibration / {len(layer.x_test)} test rows, {layer.outputs} outputs.')
                if not s.backend.supports_k(layer.k): print(f'Note: the MXFP4 core supports K in (32, 128, 512); this layer has K = {layer.k}. Switch to the generic core.')
            self._run(status, out, log, go, 'load your layer'); run.disabled = False; self._status(cmp_status, 'Layer changed: press <b>Compare candidates</b>.', 'warn')
        load.on_click(load_custom)

        def compare(_=None):
            def go():
                if s.clock_ns <= 0 or s.min_rate < 0: raise ValueError('clock period must be positive and the rate non-negative')
                if not s.backend.supports_k(s.layer.k): raise ValueError(f'the {s.backend.short} does not support K = {s.layer.k}; choose the generic core')
                s.compare(); render_comparison(s)
            run.disabled = True
            try: self._run(cmp_status, cmp_out, cmp_log, go, 'compare candidates')
            finally: run.disabled = False

        def do_reset(_=None):
            quiet[0] = True
            try:
                s.reset(); backend.value = s.backend_id; layers.value = s.layer_id; custom.layout.display = 'none'; total.value = 100 * s.total_budget; acc.value = 100 * s.acc_budget
                lanes.value = s.lanes; clock.value = s.clock_ns; rate.value = s.min_rate; extended.value = False; formats.value = tuple(FORMATS)
            finally: quiet[0] = False
            describe(); compare()
        run.on_click(compare); reset.on_click(do_reset)
        panel = w.VBox([layers, layer_note, custom, backend, backend_note, w.HBox([total, acc]), units, advanced, reset, status,
                        _accordion(w, log, 'Full log'), out])
        self._panels['layer'] = dict(panel=panel, run=compare, reset=do_reset, out=out, status=status, compare_widgets=(run, cmp_status, cmp_log, cmp_out))
        _display(panel)


    def compare_panel(self, auto_run=True):
        """Step 4: the Compare candidates button with its result (shares the configuration of layer_panel)."""
        w = self._w(); s = self.s
        if 'layer' not in self._panels: self.layer_panel()
        run, status, log, out = self._panels['layer']['compare_widgets']
        self._status(status, 'Press <b>Compare candidates</b> after changing the configuration above. Results below belong to the saved default until then.', 'info')
        panel = w.VBox([run, status, _accordion(w, log, 'Full log'), out])
        self._panels['compare'] = dict(panel=panel, run=self._panels['layer']['run'])
        _display(panel)
        if auto_run:
            s.compare(); _display(_html('<h4 style="margin:12px 0 0 0;color:#61707c">Saved result of the default configuration (visible without a running kernel)</h4>')); render_comparison(s)


    # ---------------------------------------------------------------- Step 2: inspect one design
    def inspect_panel(self, auto_run=True):
        w = self._w(); s = self.s; out = w.Output(); status = w.HTML(); log = w.HTML()
        fmt = w.Dropdown(options=[(LABELS[f], f) for f in s.backend.formats], value=s.point_format, description='Format', style={'description_width': '90px'})
        width = w.SelectionSlider(options=list(s.widths()), value=s.point_width, description='Accumulator W', continuous_update=False, layout=w.Layout(width='520px'), style={'description_width': '110px'})
        run = w.Button(description='Inspect this design', button_style='primary', icon='search'); auto = w.Checkbox(value=True, description='update when a control changes (small layers)', indent=False)
        note = w.HTML()

        def sync(_what=None):
            fmt.options = [(LABELS[f], f) for f in s.backend.formats]; fmt.value = s.point_format if s.point_format in s.backend.formats else s.backend.formats[0]
            width.options = list(s.widths()); width.value = s.point_width if s.point_width in s.widths() else width.options[0]
            big = len(s.layer.x_cal) * s.layer.outputs > BIG_LAYER_DOTS
            note.value = f'<span style="font-size:12px;color:#61707c">{esc(s.backend.short)} · widths available: {", ".join(map(str, s.widths()))} · K{s.layer.k} · P{s.lanes}' + (' · large layer: press the button to evaluate' if big else '') + '</span>'
        s.listeners.append(lambda what: sync(what) if what in ('config', 'layer', 'reset', 'point') else None); sync()

        def inspect(_=None):
            def go():
                s.point_format, s.point_width = fmt.value, int(width.value); s.changed('point_silent')
                row = s.point(); render_point(s, row)
            self._run(status, out, log, go, f'inspect {LABELS[fmt.value]} W{width.value}')
        def on_change(_):
            if auto.value and len(s.layer.x_cal) * s.layer.outputs <= BIG_LAYER_DOTS: inspect()
            else: self._status(status, 'Press <b>Inspect this design</b> to evaluate the new point.', 'warn')
        fmt.observe(on_change, names='value'); width.observe(on_change, names='value'); run.on_click(inspect)
        panel = w.VBox([w.HBox([fmt, width]), note, w.HBox([run, auto]), status, _accordion(w, log, 'Full log'), out])
        self._panels['inspect'] = dict(panel=panel, run=inspect); _display(panel)
        if auto_run:
            _display(_html('<h4 style="margin:12px 0 0 0;color:#61707c">Saved result of the default design point</h4>')); render_point(s, s.point())


    # ---------------------------------------------------------------- Step 3: where the bits are lost
    def bits_panel(self, auto_run=True):
        w = self._w(); s = self.s; out = w.Output(); status = w.HTML(); log = w.HTML()
        fmt = w.Dropdown(options=[(LABELS[f], f) for f in FORMATS], value=s.point_format, description='Format', style={'description_width': '90px'})
        width = w.IntSlider(value=s.point_width, min=8, max=64, step=1, description='Accumulator W', continuous_update=False, layout=w.Layout(width='480px'), style={'description_width': '110px'})
        sample = w.BoundedIntText(value=0, min=0, max=len(s.layer.x_cal) - 1, description='Calibration row', style={'description_width': '110px'})
        output = w.BoundedIntText(value=0, min=0, max=s.layer.outputs - 1, description='Output channel', style={'description_width': '110px'})
        first = w.Button(description='Jump to a lossy dot product'); run = w.Button(description='Show the bits', button_style='primary', icon='th')
        def sync(_what=None):
            sample.max = len(s.layer.x_cal) - 1; output.max = s.layer.outputs - 1
            if _what in ('point', 'point_silent'): fmt.value = s.point_format; width.value = max(8, min(64, s.point_width))
        s.listeners.append(sync)
        def show(_=None):
            self._run(status, out, log, lambda: bits_view(s, fmt.value, int(width.value), int(sample.value), int(output.value)), f'bits of row {sample.value} × output {output.value}')
        def jump(_):
            key = ('generic_core', s.layer.sha256, fmt.value, 'calibration'); g = s._cache.get(key)
            if g is None: g = prepare(s.layer.x_cal, s.layer.w, fmt.value); s._cache[key] = g
            loss = accumulate(g, int(width.value), fmt.value, lanes=s.lanes)['inexact']; where = np.argwhere(loss)
            if len(where): sample.value, output.value = int(where[0][0]), int(where[0][1]); show()
            else: self._status(status, f'No calibration dot product loses a bit at W{width.value} for {LABELS[fmt.value]}: every alignment is exact here. Try a narrower W.', 'ok')
        for widget in (fmt, width, sample, output): widget.observe(lambda _: show(), names='value')
        run.on_click(show); first.on_click(jump)
        panel = w.VBox([w.HBox([fmt, width]), w.HBox([sample, output, first, run]),
                        w.HTML('<span style="font-size:12px;color:#61707c">The block table uses the generic core\'s numerics; at the same F the MXFP4 core performs the identical shift-and-round (checked by a unit test).</span>'),
                        status, _accordion(w, log, 'Full log'), out])
        self._panels['bits'] = dict(panel=panel, run=show); _display(panel)
        if auto_run:
            key = ('generic_core', s.layer.sha256, s.point_format, 'calibration'); g = s._cache.get(key)
            if g is None: g = prepare(s.layer.x_cal, s.layer.w, s.point_format); s._cache[key] = g
            where = np.argwhere(accumulate(g, s.point_width, s.point_format, lanes=s.lanes)['inexact']); idx = tuple(int(v) for v in where[0]) if len(where) else (0, 0)
            sample.value, output.value = idx
            _display(_html('<h4 style="margin:12px 0 0 0;color:#61707c">Saved result for the default design point</h4>')); bits_view(s, s.point_format, s.point_width, *idx)


    # ---------------------------------------------------------------- Step 4: circuit, layout, PPA, run hardware
    def hardware_panel(self, auto_run=True):
        w = self._w(); s = self.s; out = w.Output(); status = w.HTML(); log = w.HTML(); tools = tool_status()
        view = w.Dropdown(options=[('RTL: products and sum (one beat)', 'rtl_multiply.svg'), ('RTL: alignment shift and RNE', 'rtl_round.svg'), ('RTL: accumulator register and feedback', 'rtl_accumulator.svg'), ('Gate level: GF180 cells at the output', 'mapped_output.svg')], description='Circuit view', layout=w.Layout(width='480px'), style={'description_width': '100px'})
        lview = w.Dropdown(options=[('Whole die: routed metals', 'overview'), ('Zoom: routing and vias', 'routing_zoom'), ('Zoom: devices and Metal1', 'devices_zoom')], description='Layout view', layout=w.Layout(width='400px'), style={'description_width': '100px'})
        show = w.Button(description='Show evidence for this design', button_style='primary', icon='microchip')
        gen_views = w.Button(description='Generate circuit views (Yosys + Graphviz)'); draw = w.Button(description='Draw layout from GDS'); export = w.Button(description='Export HTML report', icon='download')
        tool_line = w.HTML('<span style="font-size:12px;color:#61707c">Tools in this runtime: ' + ', '.join(f'{k} {"✓" if v else "✗"}' for k, v in tools.items()) + '. Cached evidence and numerics work without them; live RTL checks need Icarus, mapping needs Yosys, diagrams need Graphviz, layout needs LibreLane + PDK.</span>')
        # run-hardware controls (advanced)
        gen = w.Button(description='1 · Generate RTL'); verify = w.Button(description='2 · Verify RTL (Icarus)'); synth = w.Button(description='3 · Map to GF180 (Yosys)')
        expjob = w.Button(description='Export layout job (zip)'); runlane = w.Button(description='Run LibreLane (if installed)'); install = w.Button(description='Install iverilog/yosys/graphviz (Colab)')
        runpath = w.Text(placeholder='LibreLane run directory', layout=w.Layout(width='600px'), description='Run dir'); collect = w.Button(description='Import layout run')
        powerpath = w.Text(placeholder='power metadata JSON', layout=w.Layout(width='600px'), description='Power JSON'); power = w.Button(description='Import power report')
        pdk = w.Text(value='gf180mcuD', description='PDK'); scl = w.Text(value='gf180mcu_fd_sc_mcu7t5v0', description='SCL', layout=w.Layout(width='460px'))
        lib = w.Text(value='', placeholder='Liberty file (empty: the bundled GF180 TT subset)', description='Liberty', layout=w.Layout(width='600px'))
        hw_note = w.HTML('<span style="font-size:12px;color:#61707c">Live hardware steps apply to the <b>generic core</b> (its RTL is generated per configuration). The MXFP4 core\'s records are imported from the project\'s pinned flow; its RTL regressions run in Section 7 and its flow from scripts/ (Section 14).</span>')
        advanced = _accordion(w, w.VBox([hw_note, w.HBox([gen, verify, synth]), w.HBox([expjob, runlane, install]), lib, w.HBox([pdk, scl]), w.HBox([runpath, collect]), w.HBox([powerpath, power])]), 'Run hardware steps for the generic core (needs tools)')

        def current_job():
            return s.evidence_dir()

        def render(_=None):
            self._run(status, out, log, lambda: render_hardware(s, view.value, lview.value), 'show hardware evidence')

        def generate_views(_):
            def go():
                if s.backend_id == 'mxfp4_core':
                    visuals.render_mxfp4_schematics(self.root, s.backend.f_of(s.layer.k, s.point_width), s.layer.k)
                else:
                    job = current_job()
                    if not (job / 'mx_dot.sv').exists(): self._generate_job()
                    visuals.render_generic_schematics(job)
                render_hardware(s, view.value, lview.value)
            self._run(status, out, log, go, 'generate circuit views')

        def draw_layout(_):
            def go():
                if s.backend_id == 'mxfp4_core': visuals.render_mxfp4_layout(self.root, s.backend.f_of(s.layer.k, s.point_width), s.layer.k)
                else: visuals.render_generic_layout(current_job())
                s.refresh_records(); render_hardware(s, view.value, lview.value)
            self._run(status, out, log, go, 'draw layout')

        def export_report(_):
            def go():
                row = s.point(); c, routed, synth_ = s.point_record(); path = self.root / 'results' / f'hardware_evidence_{s.backend_id}_{s.backend.config_name(s.point_format, s.layer.k, s.lanes, s.point_width)}.html'
                path.parent.mkdir(exist_ok=True); visuals.export_visual_report(self.root, s.backend, current_job(), row, path, s.rtl_sha256_now(), _gds_path(s, routed)); self._download(path)
            self._run(status, out, log, go, 'export HTML report')

        def hw(which):
            def go():
                if s.backend_id != 'generic_core': raise ValueError('live hardware steps are for the generic core; switch the backend in the Layer & budget panel')
                job = self._generate_job()
                if which == 'generate':
                    c = json.loads((job / 'contract.json').read_text()); print(f"Generated {c['format_x']} W{c['accumulator_bits']} K{c['k']} P{c['lanes']} -> {job.relative_to(self.root)}/mx_dot.sv (RTL hash {c['rtl_sha256'][:16]}…). Generation implies no new measurement.")
                elif which == 'verify':
                    print('Icarus regression against the integer model (values, exponents, flags, stalls, reset, no-stall schedule)…', flush=True)
                    r = hardware.verify(job, s.layer); print(r['status'].upper(), r['transactions'], 'transactions;', r['no_stall_schedule'])
                elif which == 'synth':
                    print('Yosys/ABC technology mapping with the GF180 Liberty (about a minute)…', flush=True)
                    r = hardware.synthesize(job, lib.value.strip() or str(self.root / 'tech/gf180_1x_tt_5v00.lib')); print(f"Mapped standard-cell area {r['cell_area_um2']:,.1f} µm² ({r['mapped_cell_count']} cells). Synthesis only: no timing, routing, DRC/LVS or power.")
                elif which == 'export':
                    path = self.root / 'results' / (job.name + '_layout_job.zip'); path.parent.mkdir(exist_ok=True)
                    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, strict_timestamps=False) as z:
                        for name in ('mx_dot.sv', 'contract.json', 'config.json', 'run_layout.sh', 'rtl_validation.json'):
                            if (job / name).exists(): z.write(job / name, name)
                    self._download(path)
                elif which == 'layout':
                    print('Running the installed LibreLane flow; progress goes to layout.log (several minutes)…', flush=True)
                    r = hardware.run_layout(job, pdk.value, scl.value); print('Imported. qualified =', r['qualified'], 'area', r['cell_area_um2'], 'µm²'); [print(' -', x) for x in r['qualification_reasons']]
                elif which == 'collect':
                    from .evidence import collect_layout
                    r = collect_layout(job, runpath.value); print('Imported. qualified =', r['qualified'], 'area', r['cell_area_um2'], 'µm²; setup/hold', r['setup_slack_ns'], r['hold_slack_ns'], 'ns'); [print(' -', x) for x in r['qualification_reasons']]
                elif which == 'power':
                    from .evidence import import_power
                    r = import_power(job, powerpath.value); print(r['power_mw'], 'mW;', r['power_status'])
                s.refresh_records(); print('Records refreshed: press Compare candidates to see the new evidence in the comparison.')
            self._run(status, out, log, go, which)

        def install_tools(_):
            def go():
                import platform, os, subprocess
                if platform.system() == 'Darwin': print('On a Mac run: brew install icarus-verilog yosys graphviz'); return
                if not hasattr(os, 'geteuid') or os.geteuid() != 0: print('Install iverilog, yosys and graphviz with the system package manager, then rerun.'); return
                for cmd in (['apt-get', 'update', '-qq'], ['apt-get', 'install', '-y', '-qq', 'iverilog', 'yosys', 'graphviz']):
                    cp = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
                    if cp.returncode: raise RuntimeError(cp.stderr[-1200:])
                print('Installed. LibreLane and a PDK remain separate dependencies for layout.'); tool_line.value = tool_line.value.replace('✗', '✓')
            self._run(status, out, log, go, 'install tools')
        for b_, which in ((gen, 'generate'), (verify, 'verify'), (synth, 'synth'), (expjob, 'export'), (runlane, 'layout'), (collect, 'collect'), (power, 'power')): b_.on_click(lambda _, x=which: hw(x))
        install.on_click(install_tools); show.on_click(render); gen_views.on_click(generate_views); draw.on_click(draw_layout); export.on_click(export_report)
        view.observe(render, names='value'); lview.observe(render, names='value')
        s.listeners.append(lambda what: self._status(status, 'The design point changed: press <b>Show evidence for this design</b>.', 'warn') if what in ('point', 'point_silent', 'config', 'layer') else None)
        panel = w.VBox([w.HBox([view, lview]), w.HBox([show, gen_views, draw, export]), tool_line, advanced, status, _accordion(w, log, 'Full log'), out])
        self._panels['hardware'] = dict(panel=panel, run=render); _display(panel)
        if auto_run:
            _display(_html('<h4 style="margin:12px 0 0 0;color:#61707c">Saved evidence for the default design point</h4>')); render_hardware(s, view.value, lview.value)


    def _generate_job(self):
        s = self.s
        if s.clock_ns <= 0: raise ValueError('clock period must be positive')
        job = self.root / 'experiments' / s.backend.config_name(s.point_format, s.layer.k, s.lanes, s.point_width)
        hardware.generate(job, s.point_format, k=s.layer.k, lanes=s.lanes, acc_bits=s.point_width, clock_ns=s.clock_ns)
        return job

    # ---------------------------------------------------------------- Step 5: freeze and test
    def freeze_panel(self, auto_run=True):
        w = self._w(); s = self.s; out = w.Output(); status = w.HTML(); log = w.HTML()
        choice = w.Dropdown(options=[('press Refresh candidates', None)], description='Candidate', layout=w.Layout(width='720px'), style={'description_width': '90px'})
        refresh = w.Button(description='Refresh candidates'); run = w.Button(description='Freeze and evaluate test', button_style='primary', icon='lock')
        all_widths = w.Checkbox(value=False, description='list every eligible width (default: narrowest per format, plus the recommendation)', indent=False)
        candidates = []
        def update(_=None):
            nonlocal candidates
            if not s.rows_current(): s.compare()
            elig = [r for r in s.rows if r['numerically_eligible']]
            if all_widths.value: candidates = elig
            else:
                candidates = [min([r for r in elig if r['format_x'] == f], key=lambda r: r['accumulator_bits']) for f in s.formats() if any(r['format_x'] == f for r in elig)]
                ch = s.decision['choice'] if s.decision else None
                if ch and not any(r['format_x'] == ch['format_x'] and r['accumulator_bits'] == ch['accumulator_bits'] for r in candidates): candidates.append(ch)
            def lab(r):
                tag = 'qualified routed' if r['physically_eligible'] else ('mapped' if r['area_um2'] is not None else 'no record')
                return f"{LABELS[r['format_x']]} · W{r['accumulator_bits']} · cal total {pct(r['total_nrmse'])}, acc {pct(r['acc_nrmse'])} · {tag}"
            choice.options = [(lab(r), i) for i, r in enumerate(candidates)] or [('no candidate meets the calibration budgets', None)]
            ch = s.decision['choice'] if s.decision else None
            if ch: choice.value = next((i for i, r in enumerate(candidates) if r['format_x'] == ch['format_x'] and r['accumulator_bits'] == ch['accumulator_bits']), choice.value)
        def freeze(_=None):
            def go():
                if choice.value is None: raise ValueError('no eligible candidate: loosen the budgets or choose another format')
                s.freeze(candidates[choice.value]); render_freeze(s)
            self._run(status, out, log, go, 'freeze and evaluate test')
        def refresh_click(_):
            update(); self._status(status, f'Candidate list refreshed for the current configuration ({len(candidates)} eligible shown).', 'ok')
        refresh.on_click(refresh_click); run.on_click(freeze); all_widths.observe(update, names='value')
        s.listeners.append(lambda what: self._status(status, 'Configuration changed: the candidate list and any frozen result are stale; press Refresh candidates.', 'warn') if what in ('config', 'layer', 'reset') else None)
        role = w.HTML()
        def role_text(_=None):
            role.value = f'<span style="font-size:12px;color:#61707c">Current layer test split: <b>{esc(s.layer.test_role)}</b> ({len(s.layer.x_test) if s.layer.x_test is not None else "not included"} rows). The frozen candidate is evaluated once; a failure is kept, never silently replaced.</span>'
        s.listeners.append(role_text); role_text()
        def show():
            update(); self._run(status, out, log, lambda: render_freeze(s), 'show the frozen result')
        panel = w.VBox([choice, w.HBox([refresh, run]), all_widths, role, status, _accordion(w, log, 'Full log'), out])
        self._panels['freeze'] = dict(panel=panel, run=show)
        _display(panel); update()
        if auto_run and choice.value is not None:
            c = candidates[choice.value]
            if not (s.frozen_current() and s.frozen['format_x'] == c['format_x'] and s.frozen['accumulator_bits'] == c['accumulator_bits']): s.freeze(c)   # quick_start may have frozen it already
            _display(_html('<h4 style="margin:12px 0 0 0;color:#61707c">Saved result for the default recommendation</h4>')); render_freeze(s)


    # ---------------------------------------------------------------- Step 6: export
    def export(self, folder=None):
        s = self.s; folder = Path(folder or self.root / 'results/mx_precision_lab_export').resolve(); folder.mkdir(parents=True, exist_ok=True)
        if not s.rows_current(): s.compare()
        flat = [{k: v for k, v in r.items() if not isinstance(v, (dict, list))} for r in s.rows]
        with (folder / 'calibration_candidates.csv').open('w', newline='') as f:
            cols = list(dict.fromkeys(k for r in flat for k in r)); wr = csv.DictWriter(f, fieldnames=cols); wr.writeheader(); wr.writerows(flat)
        from mxlab import __version__
        study = dict(schema='mx-precision-lab-study-v2', version=__version__, utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                     layer=dict(id=s.layer_id, name=s.layer.name, data_sha256=s.layer.sha256, k=s.layer.k, outputs=s.layer.outputs, calibration_rows=len(s.layer.x_cal), test_rows=None if s.layer.x_test is None else len(s.layer.x_test), test_role=s.layer.test_role),
                     backend=dict(id=s.backend_id, title=s.backend.title, numerics=s.backend.numerics, rtl_sha256=s.rtl_sha256_now()),
                     requirements=dict(total_nrmse=s.total_budget, accumulation_nrmse=s.acc_budget, clock_ns=s.clock_ns, min_rate=s.min_rate, lanes=s.lanes, widths=list(s.widths()), formats=list(s.formats())),
                     calibration_rows=_json_safe(s.rows), decision=_json_safe(s.decision), frozen=_json_safe(s.frozen), independent_test=_json_safe(s.test_result), frozen_is_current=s.frozen_current(),
                     test_open_history=s.test_history, evidence=[{k: r[k] for k in ('backend', 'format_x', 'accumulator_bits', 'stage', 'cell_area_um2', 'rtl_sha256', 'rtl_current', 'qualified', 'record_path', 'evidence_dir')} for r in s.records()],
                     baseline='float64 dot of the original FP32 tensors; linear matmul only; bias, nonlinearity and task accuracy excluded',
                     note='Missing implementation or power evidence is unknown, not zero. Synthesis area is not routed area; a target clock is not an achieved frequency.')
        (folder / 'study.json').write_text(json.dumps(study, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
        (folder / 'README.md').write_text('# MX Precision Lab export\n\n`calibration_candidates.csv`: every candidate of the last comparison (calibration metrics, records). `study.json`: requirements, decision, the frozen candidate and its single test evaluation, the test-open history and the evidence index.\n')
        path = folder.with_suffix('.zip')
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, strict_timestamps=False) as z:
            for f in folder.iterdir():
                if f.is_file(): z.write(f, f.name)
        return path

    def export_panel(self):
        w = self._w(); out = w.Output(); status = w.HTML(); log = w.HTML()
        button = w.Button(description='Export results (CSV + JSON)', button_style='primary', icon='download')
        def save(_):
            def go():
                path = self.export(); self._download(path); print('Contents: calibration_candidates.csv, study.json, README.md')
            self._run(status, out, log, go, 'export results')
        button.on_click(save); panel = w.VBox([button, status, _accordion(w, log, 'Full log'), out]); self._panels['export'] = dict(panel=panel); _display(panel)

    @staticmethod
    def _download(path):
        try:
            from google.colab import files
        except ImportError:
            from IPython.display import FileLink
            _display(FileLink(str(path))); print('Saved:', path)
        else: files.download(str(path))

    # ---------------------------------------------------------------- Quick start and cases
    def quick_start(self):
        w = self._w(); s = self.s; out = w.Output(); status = w.HTML()
        demo = w.Button(description='Load default demo', button_style='primary', icon='play'); reset = w.Button(description='Reset to defaults', icon='refresh')
        def go(_):
            def run():
                layer = self._panels.get('layer')
                if layer: layer['reset']()                     # resets the session and the widgets, then compares
                else: s.reset(); s.compare()
                s.point(); s.freeze(s.decision['choice'] or next(r for r in s.rows if r['numerically_eligible']))
                self._summary(s)
                for name in ('inspect', 'freeze'):
                    p = self._panels.get(name)
                    if p and p.get('run'): p['run']()
                print('Defaults restored: MXFP4 core, MNIST fc2 layer (512 / 10,000), total NRMSE ≤ 12 %, accumulation NRMSE ≤ 0.1 %. The panels below show the default results again.')
            self._run(status, out, None, run, 'default demo')
        demo.on_click(go); reset.on_click(go)
        panel = w.VBox([w.HBox([demo, reset]), status, out]); self._panels['quick_start'] = dict(panel=panel); _display(panel)
        s.compare(); s.point(); s.freeze(s.decision['choice']); self._summary(s)


    def _summary(self, s):
        d = s.decision; ch = d['choice']; t = s.test_result
        _display(cards([('Layer', s.layer.name.split(' (')[0], f"K{s.layer.k}, {len(s.layer.x_cal)} calibration rows"),
                        ('Budgets', f"{pct(s.total_budget, 3)} / {pct(s.acc_budget, 3)}", 'total / accumulation NRMSE on calibration'),
                        ('Selected', f"{LABELS[ch['format_x']]} · W{ch['accumulator_bits']} (F{ch['f']})" if ch else 'none', (f"{area_text(ch['area_um2'])} routed, qualified" if ch else d['reason']), '#2d6b4a' if ch else '#9c3a3a'),
                        ('Frozen test', ('PASS' if t['test_pass'] else 'FAIL') if t else 'n/a', (f"test total NRMSE {pct(t['total_nrmse'])} ({s.layer.test_role} split)") if t else '', '#2d6b4a' if t and t['test_pass'] else '#9c3a3a')]))

    def cases_panel(self):
        text, self.case_numbers = cases_html(self.s); _display(_html(text))

    def panel(self, name):
        """The ipywidgets container of a panel built earlier ('layer', 'compare', 'inspect', 'freeze', ...)."""
        return self._panels[name]['panel']
