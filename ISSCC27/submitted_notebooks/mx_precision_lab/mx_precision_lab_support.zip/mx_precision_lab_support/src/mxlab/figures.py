"""Inline figures that are also kept for the submission bundle.

``save_to(folder)`` is called once by the notebook's setup cell; afterwards every ``show(fig, name)`` displays the
figure and writes ``folder/name.png``. Without a folder (tests, scripts) ``show`` only displays.
"""
from pathlib import Path
import matplotlib.pyplot as plt

FOLDER = None


def save_to(folder):
    global FOLDER
    FOLDER = Path(folder); FOLDER.mkdir(parents=True, exist_ok=True)
    return FOLDER


def show(fig=None, name=None):
    fig = fig if fig is not None else plt.gcf()
    if FOLDER is not None and name:
        fig.savefig(FOLDER / f'{name}.png', dpi=150, bbox_inches='tight', facecolor='white')
    plt.show()
