"""Exact lifted-integer block products; explicit accumulator-width experiments.

The wide integer-lift core is a reference architecture, not a claim to reproduce
a commercial FP8 accumulator. F is derived and may be negative for narrow W.

Two execution paths give identical results: a vectorised NumPy path (int64) used
whenever every intermediate is provably below 2^60, and an exact Python-integer
path used otherwise (MXFP8 E5M2 products, very wide accumulators). A unit test
checks both paths against each other.
"""
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
import hashlib
import json
import math
import numpy as np
from .formats import FORMATS, get_format, codebook, quantize

DEFAULT_WIDTHS = (12, 16, 18, 20, 22, 24, 28, 32, 40, 48)
EXTENDED_WIDTHS = (64, 96)
BACKEND = "mxlab_integer_lift_serial_v1"
FAST_LIMIT_BITS = 60          # int64 path only when |block sum| * 2^(max left shift) stays below this


def signed_width(lo, hi):
    return max(2, int(hi).bit_length()+1, (-int(lo)-1).bit_length()+1)


def contract(fmt_x, fmt_w=None, k=128, lanes=4, acc_bits=18):
    fx, fw = get_format(fmt_x), get_format(fmt_w or fmt_x)
    if k < 1 or lanes not in (1, 2, 4, 8, 16, 32) or acc_bits < 2 or acc_bits > 256:
        raise ValueError("K>=1, P in {1,2,4,8,16,32}, accumulator width 2..256 required")
    ux = codebook(fx.name)[1]; uw = codebook(fw.name)[1]
    xmin, xmax, wmin, wmax = int(ux.min()), int(ux.max()), int(uw.min()), int(uw.max())
    prods = [xmin*wmin, xmin*wmax, xmax*wmin, xmax*wmax]
    sb = signed_width(32*min(prods), 32*max(prods))
    blocks = (k+31)//32; headroom = (blocks-1).bit_length()
    ii = 1+blocks*(1+32//lanes+1)+1
    return dict(backend=BACKEND, format_x=fx.name, format_w=fw.name, k=int(k), padded_k=blocks*32,
                lanes=lanes, blocks=blocks, accumulator_bits=int(acc_bits),
                f=int(acc_bits)-sb-headroom, block_sum_bits=sb,
                decode_x_bits=signed_width(xmin, xmax), decode_w_bits=signed_width(wmin, wmax),
                product_unit_exp=fx.unit_exp+fw.unit_exp,
                # New serial core schedule; it is not the archived overlapped P4 core.
                ii_no_stall=ii, latency_cycles=ii-1,
                input_bits_per_block=(fx.bits+fw.bits)*32+16)


@dataclass
class Layer:
    name: str
    x_cal: np.ndarray
    x_test: np.ndarray
    w: np.ndarray
    source: str = "user_export"
    path: str = ""
    test_role: str = "independent"     # 'independent' or 'demonstration' (a split inspected during development)
    description: str = ""

    def __post_init__(self):
        self.x_cal=np.array(self.x_cal,dtype=np.float32,copy=True)
        self.x_test=None if self.x_test is None else np.array(self.x_test,dtype=np.float32,copy=True)   # None: test split recorded, not embedded
        self.w=np.array(self.w,dtype=np.float32,copy=True)
        arrays=[a for a in (self.x_cal,self.x_test,self.w) if a is not None]
        for a in arrays:
            if a.ndim!=2 or not len(a) or not np.all(np.isfinite(a)):
                raise ValueError("Each layer tensor must be a nonempty finite 2-D array")
        if self.x_cal.shape[1]!=self.w.shape[1] or (self.x_test is not None and self.x_test.shape[1]!=self.w.shape[1]):
            raise ValueError("x_cal/x_test/w must have matching K")
        # Export the linear matmul separately from bias/nonlinearity/task metrics.
        self.sha256=hashlib.sha256(b''.join(a.tobytes() for a in arrays)).hexdigest()
        for a in arrays:a.setflags(write=False)

    @property
    def k(self):
        return int(self.w.shape[1])

    @property
    def outputs(self):
        return int(self.w.shape[0])


def load_layer(folder, max_test_rows=None):
    p=Path(folder).expanduser().resolve()
    from mxacc.embedded import find_root, recorded_test, regenerated
    root=find_root(p); recorded=None
    if not (p/'test.npz').exists():
        recorded=recorded_test(root,p.name) if root else None
        if recorded is None: raise FileNotFoundError(f"{p}: needs calibration.npz and test.npz")
    # Never execute pickle payloads from uploaded arrays.
    with np.load(p/'calibration.npz',allow_pickle=False) as cal:
        test=None if recorded else np.load(p/'test.npz',allow_pickle=False)
        try:
            if 'w' not in cal or 'x' not in cal or (test is not None and 'x' not in test):
                raise ValueError("Need calibration.npz{x,w} and test.npz{x}; see export example")
            if test is not None and 'w' in test and not np.array_equal(test['w'],cal['w']):
                raise ValueError("Calibration/test exports must use identical frozen weights")
            manifest=json.loads((p/'manifest.json').read_text()) if (p/'manifest.json').exists() else {}
            # The project catalogue indexes each split in its own source (training ids vs official-test ids, or two generator
            # splits) and says so in the manifest; only ids from one shared space are checked for overlap.
            shared_ids=not any(k in manifest for k in ('test_ids','test_split','calibration_ids','calibration_split'))
            if test is not None and shared_ids and 'sample_ids' in cal and 'sample_ids' in test and np.intersect1d(cal['sample_ids'],test['sample_ids']).size:
                raise ValueError("Calibration and test sample IDs overlap")
            if not regenerated(p):     # a rebuilt synthetic layer is checked by its content hash when it is rebuilt (mxacc.embedded)
                for file,expected in manifest.get('files',{}).items():
                    expected=expected.get('sha256') if isinstance(expected,dict) else expected   # the project catalogue stores {sha256, bytes}
                    if expected and (p/file).exists() and hashlib.sha256((p/file).read_bytes()).hexdigest()!=expected:
                        raise ValueError(f"Workload hash mismatch: {file}")
            x_test=None if test is None else (test['x'] if max_test_rows is None else test['x'][:max_test_rows])
            return Layer(manifest.get('name',manifest.get('id',p.name)),cal['x'],x_test,cal['w'],manifest.get('kind','user_export'),str(p),
                         'recorded' if recorded else manifest.get('test_role','independent'),manifest.get('description',''))
        finally:
            if test is not None: test.close()


@dataclass
class Groups:
    sums: np.ndarray
    exponents: np.ndarray
    qa: object
    qw: object
    reference: np.ndarray
    exact_int: np.ndarray
    exact_exp: np.ndarray
    fast: bool = False


def _max_abs_block_sum(fmt_x, fmt_w):
    ux = codebook(get_format(fmt_x).name)[1]; uw = codebook(get_format(fmt_w).name)[1]
    m = max(abs(int(ux.min())), abs(int(ux.max()))) * max(abs(int(uw.min())), abs(int(uw.max())))
    return 32 * m


def prepare(x,w,fmt_x,fmt_w=None):
    fmt_w=fmt_w or fmt_x
    qa,qw=quantize(x,fmt_x),quantize(w,fmt_w)
    if qa.original_k!=qw.original_k:
        raise ValueError("Mismatched K")
    n,m,b=len(x),len(w),qa.codes.shape[1]
    fast=_max_abs_block_sum(fmt_x,fmt_w)<(1<<FAST_LIMIT_BITS)
    if fast:
        sums=np.empty((n,m,b),dtype=np.int64)
        for g in range(b):
            sums[:,:,g]=qa.integers[:,g,:].astype(np.int64) @ qw.integers[:,g,:].astype(np.int64).T
    else:
        # Python integers are essential for E5M2: int64 products can overflow. Split each integer into
        # 16-bit limbs so the three partial block sums are exact int64 matmuls; recombine exactly.
        if max(int(np.abs(qa.integers).max(initial=0)),int(np.abs(qw.integers).max(initial=0)))>=(1<<32):
            sums=np.empty((n,m,b),dtype=object)
            for g in range(b):
                sums[:,:,g]=qa.integers[:,g,:].astype(object) @ qw.integers[:,g,:].astype(object).T
        else:
            sums=np.empty((n,m,b),dtype=object)
            ax=qa.integers.astype(np.int64);wx=qw.integers.astype(np.int64)
            ahi,alo=ax>>16,ax&0xFFFF;whi,wlo=wx>>16,wx&0xFFFF      # arithmetic shift keeps the sign in the high limb
            for g in range(b):
                s2=ahi[:,g,:]@whi[:,g,:].T;s1=ahi[:,g,:]@wlo[:,g,:].T+alo[:,g,:]@whi[:,g,:].T;s0=alo[:,g,:]@wlo[:,g,:].T
                for idx in np.ndindex(n,m):
                    sums[idx+(g,)]=(int(s2[idx])<<32)+(int(s1[idx])<<16)+int(s0[idx])
    unit=get_format(fmt_x).unit_exp+get_format(fmt_w).unit_exp
    e=qa.scales.astype(np.int16)[:,None,:]+qw.scales.astype(np.int16)[None,:,:]-254+unit
    emin=e.min(axis=-1);j=np.empty((n,m),dtype=object)
    shifts=(e-emin[...,None]).astype(np.int64)
    if fast and int(shifts.max())+FAST_LIMIT_BITS<=62:
        jj=(sums.astype(np.int64)<<shifts).sum(axis=-1,dtype=np.int64)
        for idx in np.ndindex(n,m):j[idx]=int(jj[idx])
    else:
        for idx in np.ndindex(n,m):
            j[idx]=sum(int(v) << int(s) for v,s in zip(sums[idx],shifts[idx]))
    ref=np.ldexp(np.asarray(j,dtype=np.float64),emin)
    return Groups(sums,e,qa,qw,ref,j,emin,fast)


def rne_shift(value,shift):
    """Exact signed round-to-nearest-even with an unbounded integer result."""
    value,shift=int(value),int(shift)
    if shift>=0:return value<<shift,False
    d=-shift; q,r=divmod(value,1<<d); half=1<<(d-1)
    return q+int(r>half or (r==half and q&1)),bool(r)


def _rne_shift_vector(s,sh):
    """Vectorised rne_shift for int64 block sums (|s| < 2^60): returns (rounded, lost)."""
    left=sh>=0
    out=np.zeros_like(s); lost=np.zeros(s.shape,dtype=bool)
    out[left]=s[left]<<np.minimum(sh[left],62)
    d=np.minimum(-sh[~left],62).astype(np.int64); v=s[~left]
    q=v>>d                                              # floor division by 2^d (arithmetic shift)
    r=v-(q<<d); half=np.int64(1)<<(d-1)
    up=(r>half)|((r==half)&((q&1)!=0))
    out[~left]=q+up.astype(np.int64); lost[~left]=r!=0
    return out,lost


def accumulate(groups,acc_bits,fmt_x,fmt_w=None,lanes=4):
    con=contract(fmt_x,fmt_w,groups.qa.original_k,lanes,int(acc_bits));f=con['f']
    emax=groups.exponents.max(axis=-1);out_e=emax-f
    err=np.empty(emax.shape,dtype=np.float64)
    if groups.fast and acc_bits<=62:
        sh=(groups.exponents-emax[...,None]).astype(np.int64)+f
        rounded,lost=_rne_shift_vector(groups.sums,sh)
        total=rounded.sum(axis=-1,dtype=np.int64);flags=lost.any(axis=-1)
        if int(total.max())>=(1<<(acc_bits-1)) or int(total.min())<-(1<<(acc_bits-1)):
            raise OverflowError("Accumulator width contract was violated")
        t=np.empty(emax.shape,dtype=object)
        for idx in np.ndindex(emax.shape):
            tt=int(total[idx]);t[idx]=tt
            common=min(int(out_e[idx]),int(groups.exact_exp[idx]))
            d=(tt<<int(out_e[idx]-common))-(int(groups.exact_int[idx])<<int(groups.exact_exp[idx]-common))
            err[idx]=math.ldexp(float(d),common)
    else:
        t=np.empty(emax.shape,dtype=object);flags=np.zeros(emax.shape,dtype=bool)
        for idx in np.ndindex(emax.shape):
            total=0;loss=False
            for s,e in zip(groups.sums[idx],groups.exponents[idx]):
                rounded,lost=rne_shift(s,int(e-emax[idx])+f);total+=rounded;loss|=lost
            if not -(1<<(acc_bits-1))<=total<(1<<(acc_bits-1)):
                raise OverflowError("Accumulator width contract was violated")
            t[idx]=total;flags[idx]=loss
            common=min(int(out_e[idx]),int(groups.exact_exp[idx]))
            d=(total<<int(out_e[idx]-common))-(int(groups.exact_int[idx])<<int(groups.exact_exp[idx]-common))
            err[idx]=math.ldexp(float(d),common)
    y=np.ldexp(np.asarray(t,dtype=np.float64),out_e)
    return dict(integer=t,exponent=out_e,values=y,error=err,inexact=flags,contract=con)


def relative_rms(delta,reference):
    numerator=float(np.linalg.norm(delta));denominator=float(np.linalg.norm(reference))
    return numerator/denominator if denominator else (0. if numerator==0 else float('inf'))


def score(groups,point,original):
    return dict(acc_nrmse=relative_rms(point['error'],groups.reference),
                quant_nrmse=relative_rms(groups.reference-original,original),
                total_nrmse=relative_rms(point['values']-original,original),
                max_abs=float(np.max(np.abs(point['error']))),
                inexact_fraction=float(point['inexact'].mean()),
                exact_fraction=float((point['error']==0).mean()),
                bound_max=float(np.max(np.ldexp(np.full(groups.reference.shape,groups.sums.shape[-1]/2),point['exponent']))))


def evaluate_point(layer,fmt_x,acc_bits,fmt_w=None,split='calibration',lanes=4,groups=None):
    x=layer.x_cal if split=='calibration' else layer.x_test if split=='test' else None
    if x is None:raise ValueError("split must be calibration or test")
    groups=groups or prepare(x,layer.w,fmt_x,fmt_w)
    point=accumulate(groups,int(acc_bits),fmt_x,fmt_w,lanes)
    # Exact original FP32 tensors, evaluated with a float64 dot for the baseline.
    original=x.astype(np.float64) @ layer.w.astype(np.float64).T
    return {**point['contract'],**score(groups,point,original),
            'split':split,'vectors':len(x),'outputs':len(layer.w),'data_sha256':layer.sha256,
            'scale_clamps':groups.qa.clamped_scales+groups.qw.clamped_scales}


def sweep(layer,formats=None,widths=DEFAULT_WIDTHS,total_budget=.10,acc_budget=.001,lanes=4):
    """Calibration only. No test metrics participate in comparison/selection."""
    rows=[]
    for fmt in formats or FORMATS:
        groups=prepare(layer.x_cal,layer.w,fmt)
        for width in widths:
            row=evaluate_point(layer,fmt,int(width),lanes=lanes,groups=groups)
            row['numerically_eligible']=row['total_nrmse']<=total_budget and row['acc_nrmse']<=acc_budget
            rows.append(row)
    return rows


def evaluate_frozen(layer,row,total_budget=.10,acc_budget=.001):
    """Evaluate exactly the frozen candidate; do not reselect on test failure."""
    if row['data_sha256']!=layer.sha256:raise ValueError("Frozen choice belongs to different data")
    result=evaluate_point(layer,row['format_x'],row['accumulator_bits'],row['format_w'],'test',row['lanes'])
    result['test_pass']=result['total_nrmse']<=total_budget and result['acc_nrmse']<=acc_budget
    result['frozen_choice']={k:row[k] for k in ['format_x','format_w','accumulator_bits','k','lanes','backend']}
    return result
