"""MX Precision Lab: format-aware numerical experiments and auditable RTL."""
__version__ = "0.6.0"
from .formats import FORMATS, quantize, decode_elements
from .numerics import Layer, load_layer, sweep, evaluate_point, evaluate_frozen, contract
