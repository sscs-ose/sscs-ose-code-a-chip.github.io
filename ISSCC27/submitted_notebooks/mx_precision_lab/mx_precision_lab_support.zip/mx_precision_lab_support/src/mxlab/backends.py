"""Two hardware backends behind one interface.

* ``mxfp4_core``  - the MXFP4-only core of this project (``rtl/dot_top.sv``: overlapped P4 datapath,
                    II0 = 9B + 4). Its numerical model is ``mxacc.arithmetic``; its cost records are the
                    routed GF180 implementations under ``results/physical`` (and the exploratory mapping under
                    ``results/synthesis``), validated by ``mxacc.implementation.load_implementations``.
* ``generic_core`` - the six-encoding integer-lift reference core (``mxlab.hardware``: serial schedule,
                    II = 42 at K128/P4). Its numerical model is ``mxlab.numerics``; its cost records are the
                    technology-mapped synthesis results under ``evidence/generic_core`` (and any layout a user
                    imports under ``experiments/``), validated by ``mxlab.evidence.load_records``.

Every candidate row and every record carries the backend id, format, K, P, accumulator width and the RTL hash
it belongs to. A record is joined to a candidate only when all of those agree, so the MXFP4 core's routed
area, timing or layout can never be shown for the generic core and vice versa.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
from .formats import FORMATS, get_format
from . import numerics as N

CLOCK_NS = 50.0


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def relative_rms(delta, reference):
    return N.relative_rms(delta, reference)


class Backend:
    id = ''
    title = ''
    short = ''
    summary = ''
    formats = ()
    lanes_options = (4,)

    def supports(self, fmt, k, lanes):
        return fmt in self.formats and lanes in self.lanes_options and self.supports_k(k)

    def supports_k(self, k):
        return k >= 1

    def widths(self, k):
        raise NotImplementedError

    def contract(self, fmt, k, lanes, acc_bits):
        raise NotImplementedError

    def evaluate(self, layer, fmt, acc_bits, split='calibration', lanes=4, cache=None):
        raise NotImplementedError

    def records(self, root):
        raise NotImplementedError

    def evidence_dir(self, root, fmt, k, lanes, acc_bits):
        raise NotImplementedError

    def config_name(self, fmt, k, lanes, acc_bits):
        raise NotImplementedError


# --------------------------------------------------------------------------------------------- MXFP4 core
class MXFP4Core(Backend):
    id = 'mxfp4_core'
    title = 'MXFP4 core: routed GF180 evidence'
    short = 'MXFP4 core'
    summary = ('The project\'s MXFP4-only accumulator: four lanes, exact 14-bit block sums, one '
               'round-to-nearest-even per block, W = 14 + log2(B) + F accumulator. Seven F candidates are placed and '
               'routed on GF180MCU at 50 ns with nine-corner STA, DRC and LVS; F16 has synthesis only.')
    formats = ('MXFP4_E2M1',)
    lanes_options = (4,)
    numerics = 'bit-exact integer model of the MXFP4 core RTL'

    def supports_k(self, k):
        return k in (32, 128, 512)

    def widths(self, k):
        from mxacc.arithmetic import CANDIDATES, width
        return tuple(width(k, f) for f in CANDIDATES) if self.supports_k(k) else ()

    def f_of(self, k, acc_bits):
        from mxacc.arithmetic import CANDIDATES, width
        for f in CANDIDATES:
            if width(k, f) == acc_bits: return f
        raise ValueError(f'the MXFP4 core at K{k} supports accumulator widths {self.widths(k)}, not W{acc_bits}')

    def contract(self, fmt, k, lanes, acc_bits):
        if fmt not in self.formats: raise ValueError('the MXFP4 core accepts MXFP4_E2M1 only')
        if lanes != 4: raise ValueError('the MXFP4 core is a P = 4 datapath')
        f = self.f_of(k, acc_bits); b = k // 32
        return dict(backend=self.id, format_x=fmt, format_w=fmt, k=int(k), padded_k=int(k), lanes=4, blocks=b, accumulator_bits=int(acc_bits),
                    f=f, block_sum_bits=14, decode_x_bits=5, decode_w_bits=5, product_unit_exp=-2,
                    ii_no_stall=9 * b + 4, latency_cycles=9 * b + 3, input_bits_per_block=8 * 32 + 16, rtl_module=f'dot_k{k}_f{f}')

    def rtl_sha256(self, root):
        return sha256(Path(root) / 'rtl/dot_top.sv')

    def evaluate(self, layer, fmt, acc_bits, split='calibration', lanes=4, cache=None):
        from mxacc.arithmetic import quantize, groups, exact, accumulate, metrics, as_float
        from mxacc.recompute import inexact_flags
        c = self.contract(fmt, layer.k, lanes, acc_bits); f = c['f']
        x = layer.x_cal if split == 'calibration' else layer.x_test
        key = (self.id, layer.sha256, fmt, split)
        if cache is not None and key in cache:
            g, gold, ref, original = cache[key]
        else:
            xc, xs, _ = quantize(x); wc, ws, _ = quantize(layer.w); g = groups(xc, xs, wc, ws); gold = exact(g)
            ref = as_float(*gold); original = x.astype(np.float64) @ layer.w.astype(np.float64).T
            if cache is not None: cache[key] = (g, gold, ref, original)
        m = metrics(g, f, gold); t, eo = accumulate(g, f); values = as_float(t, eo); flags = inexact_flags(g, f)
        return {**c, 'acc_nrmse': m['nrmse'], 'quant_nrmse': relative_rms(ref - original, original), 'total_nrmse': relative_rms(values - original, original),
                'max_abs': m['max_abs'], 'inexact_fraction': float(flags.mean()), 'exact_fraction': float((values == ref).mean()),
                'bound_max': m['max_bound'], 'split': split, 'vectors': int(len(x)), 'outputs': layer.outputs, 'data_sha256': layer.sha256,
                'scale_clamps': 0, 'numerics': self.numerics}

    def config_name(self, fmt, k, lanes, acc_bits):
        return f'K{k}_F{self.f_of(k, acc_bits)}'

    def evidence_dir(self, root, fmt, k, lanes, acc_bits):
        return Path(root) / 'evidence/mxfp4_core' / self.config_name(fmt, k, lanes, acc_bits)

    def records(self, root):
        from mxacc.implementation import load_implementations
        from mxacc.experiment import choose_hardware
        from mxacc.arithmetic import CANDIDATES, width
        root = Path(root).resolve(); imp = load_implementations(root); current = self.rtl_sha256(root)
        # physical qualification with every F numerically admitted: the reasons are then purely physical
        hw = choose_hardware({'k': 128, 'lanes': 4, 'feasible_f': list(CANDIDATES), 'calibration': [], 'test': []}, imp['costs'], CLOCK_NS, 1.0)
        qual = {c['f']: c for c in hw['costs']}
        out = []
        for r in imp['all_records']:
            if r.get('k') != 128 or r.get('lanes') != 4: continue
            f = r['f']; stage = 'post_route' if r['stage'] == 'post_route' else 'synthesis'
            q = qual.get(f, {}) if stage == 'post_route' else {}
            reasons = [x for x in q.get('qualification_reasons', []) if not (x.startswith('calibration ') and 'error exceeds' in x)] if stage == 'post_route' else ['synthesis only: not placed, routed or signed off']
            rec = dict(backend=self.id, format_x='MXFP4_E2M1', format_w='MXFP4_E2M1', k=128, lanes=4, accumulator_bits=width(128, f), f=f, stage=stage,
                       cell_area_um2=r.get('cell_area_um2'), clock_period_ns=r.get('clock_period_ns', CLOCK_NS), setup_slack_ns=r.get('setup_wns_ns'), hold_slack_ns=r.get('hold_wns_ns'),
                       max_slew_violations=r.get('max_slew_violations'), max_cap_violations=r.get('max_cap_violations'), unconstrained_paths=r.get('unconstrained_paths'),
                       drc_errors=r.get('drc_errors'), lvs_errors=r.get('lvs_errors'), xor_differences=r.get('xor_differences'), sta_corners=r.get('sta_corners', []),
                       die_area_um2=250000.0 if stage == 'post_route' else None, pdk='gf180mcuD' if stage == 'post_route' else None, scl='gf180mcu_fd_sc_mcu7t5v0' if stage == 'post_route' else None,
                       liberty_sha256=r.get('liberty_sha256'), rtl_sha256=r.get('rtl_sha256'), rtl_current=r.get('rtl_sha256') == current, rtl_verified=bool(r.get('rtl_pass')),
                       provenance_ok=bool(r.get('provenance_pass')), qualified=bool(q.get('eligible')) if stage == 'post_route' else False, qualification_reasons=reasons,
                       ii_no_stall=36 + 4, latency_cycles=36 + 3, comparison_group=r.get('comparison_signature') if stage == 'post_route' else ('synthesis:' + str(r.get('liberty_sha256', ''))[:12]),
                       record_path=r.get('record_path'), source=('LibreLane 3.0.16 place-and-route on GF180MCU, nine-corner post-route STA, Magic DRC, Netgen LVS, KLayout XOR' if stage == 'post_route'
                                                                 else 'Yosys + ABC technology mapping with the GF180 1x TT 5 V Liberty (exploratory; not routed)'),
                       power=self._power(root, f) if stage == 'post_route' else {'status': 'not_measured', 'value_mw': None, 'note': 'no power analysis at this stage'},
                       evidence_dir=str(self.evidence_dir(root, 'MXFP4_E2M1', 128, 4, width(128, f)).relative_to(root)))
            out.append(rec)
        return out

    def _power(self, root, f):
        p = Path(root) / f'results/physical/f{f}/evidence/metrics.json'
        if not p.exists(): return {'status': 'not_measured', 'value_mw': None, 'note': 'no flow metrics'}
        m = json.loads(p.read_text()); total = m.get('power__total')
        if total is None: return {'status': 'not_measured', 'value_mw': None, 'note': 'flow reported no power'}
        return {'status': 'flow_estimate_vectorless', 'value_mw': float(total) * 1000.0, 'corner': 'nom_tt_025C_5v00', 'voltage_v': 5.0,
                'activity': 'OpenSTA default switching activity (no workload annotation)', 'method': 'LibreLane post-route power report',
                'note': 'reference only: not measured for a workload; not comparable to an activity-annotated estimate'}


# --------------------------------------------------------------------------------------------- generic core
class GenericCore(Backend):
    id = 'generic_core'
    title = 'Generic MX core: six encodings, mapped-synthesis evidence'
    short = 'Generic MX core'
    summary = ('A reference core generated for any OCP MX v1.0 encoding (MXFP4 E2M1, MXFP6 E2M3/E3M2, MXFP8 E4M3/E5M2, MXINT8): '
               'elements are lifted to exact integers, each 32-element block is summed exactly, then merged into a W-bit accumulator '
               'with one round-to-nearest-even per block. Ten configurations have Yosys/ABC technology-mapping results on the same '
               'GF180 Liberty; no configuration has been placed and routed yet.')
    formats = tuple(FORMATS)
    lanes_options = (1, 2, 4, 8, 16, 32)
    numerics = 'bit-exact integer model of the generated core'

    def widths(self, k):
        return N.DEFAULT_WIDTHS

    def contract(self, fmt, k, lanes, acc_bits):
        c = N.contract(fmt, None, k, lanes, acc_bits); c['core'] = c['backend']; c['backend'] = self.id; c['rtl_module'] = 'mx_dot'
        return c

    def evaluate(self, layer, fmt, acc_bits, split='calibration', lanes=4, cache=None):
        key = (self.id, layer.sha256, fmt, split)
        x = layer.x_cal if split == 'calibration' else layer.x_test
        if cache is not None and key in cache: g = cache[key]
        else:
            g = N.prepare(x, layer.w, fmt)
            if cache is not None: cache[key] = g
        row = N.evaluate_point(layer, fmt, acc_bits, split=split, lanes=lanes, groups=g)
        row['core'] = row['backend']; row['backend'] = self.id; row['numerics'] = self.numerics
        return row

    def config_name(self, fmt, k, lanes, acc_bits):
        return f'{fmt}_W{acc_bits}_K{k}_P{lanes}'

    def evidence_dir(self, root, fmt, k, lanes, acc_bits):
        root = Path(root); name = self.config_name(fmt, k, lanes, acc_bits)
        for top in ('experiments', 'evidence/generic_core'):
            p = root / top / name
            if any((p / n).exists() for n in ('visuals/manifest.json', 'layout_record.json', 'synthesis_record.json', 'mx_dot.sv')): return p
        return root / 'experiments' / name

    def records(self, root):
        from .evidence import load_records
        root = Path(root).resolve(); out = []
        for r in load_records(root / 'evidence/generic_core') + load_records(root / 'experiments'):
            c = r['config']; stage = r['stage']
            if stage == 'post_route':
                reasons = list(r.get('qualification_reasons', []))
            else:
                reasons = ['synthesis only: not placed, routed or signed off']
            rec = dict(backend=self.id, core=c.get('backend'), format_x=c['format_x'], format_w=c['format_w'], k=c['k'], lanes=c['lanes'], accumulator_bits=c['accumulator_bits'], f=c['f'], stage=stage,
                       cell_area_um2=r.get('cell_area_um2'), clock_period_ns=c.get('clock_period_ns', CLOCK_NS), setup_slack_ns=r.get('setup_slack_ns'), hold_slack_ns=r.get('hold_slack_ns'),
                       max_slew_violations=r.get('slew_violations'), max_cap_violations=r.get('cap_violations'), unconstrained_paths=r.get('unconstrained_paths'),
                       drc_errors=r.get('drc_errors'), lvs_errors=r.get('lvs_errors'), xor_differences=None, sta_corners=r.get('sta_corners', []),
                       die_area_um2=None, pdk=r.get('pdk'), scl=r.get('scl'), liberty_sha256=r.get('liberty_sha256'), rtl_sha256=r.get('rtl_sha256'),
                       rtl_current=bool(r.get('current_rtl')), rtl_verified=(Path(r['record_path']).parent / 'rtl_validation.json').exists(), provenance_ok=bool(r.get('current_rtl')),
                       qualified=bool(r.get('qualified')) if stage == 'post_route' else False, qualification_reasons=reasons,
                       ii_no_stall=c['ii_no_stall'], latency_cycles=c['ii_no_stall'] - 1, comparison_group=r.get('comparison_signature', 'synthesis:' + str(r.get('liberty_sha256', ''))[:12]),
                       record_path=str(Path(r['record_path']).relative_to(root)) if str(r['record_path']).startswith(str(root)) else r['record_path'],
                       source=('actual LibreLane run with post-route STA' if stage == 'post_route' else f"Yosys/ABC technology mapping with {r.get('liberty_name', 'the GF180 Liberty')} ({r.get('tool_version', '')}); not routed"),
                       power=(self._power(r) if stage == 'post_route' else {'status': 'not_measured', 'value_mw': None, 'note': 'no power analysis at this stage'}),
                       evidence_dir=str(Path(r['record_path']).parent.relative_to(root)) if str(r['record_path']).startswith(str(root)) else str(Path(r['record_path']).parent))
            out.append(rec)
        return out

    @staticmethod
    def _power(r):
        prov = r.get('power_provenance') or {}
        if r.get('power_mw') is None: return {'status': 'not_measured', 'value_mw': None, 'note': r.get('power_status', 'no activity-linked report')}
        return {'status': 'activity_linked_estimate', 'value_mw': r['power_mw'], 'corner': prov.get('corner'), 'voltage_v': prov.get('voltage_v'), 'activity': prov.get('activity'),
                'method': prov.get('method'), 'workload_sha256': prov.get('workload_sha256'), 'split': prov.get('split'), 'note': r.get('power_status')}


BACKENDS = {b.id: b for b in (MXFP4Core(), GenericCore())}
KEY = ('backend', 'format_x', 'format_w', 'k', 'lanes', 'accumulator_bits')


def key(row):
    return tuple(row.get(k) for k in KEY)


def matching_records(records, row, clock_ns=CLOCK_NS):
    """(routed, synthesis) current records of exactly this backend, format, K, P and W."""
    matching = [r for r in records if key(r) == key(row) and r.get('rtl_current')]
    routed = [r for r in matching if r['stage'] == 'post_route' and r.get('clock_period_ns') == clock_ns]
    synth = [r for r in matching if r['stage'] == 'synthesis']
    return (routed[-1] if routed else None), (synth[-1] if synth else None)


def select_record(records, row, clock_ns=CLOCK_NS):
    """The best current record for a candidate: a routed record at the requested clock first, else synthesis."""
    routed, synth = matching_records(records, row, clock_ns)
    return routed or synth


def join(rows, records, clock_ns=CLOCK_NS, min_rate=0.0):
    """Attach the matching records' cost and qualification to each candidate row (routed preferred, synthesis kept beside it)."""
    out = []
    for row in rows:
        routed, synth = matching_records(records, row, clock_ns); r = routed or synth; o = dict(row)
        rate = 1e9 / clock_ns / row['ii_no_stall']
        o.update(area_um2=None, area_source='not_measured', synthesis_area_um2=None, routed_area_um2=None, setup_slack_ns=None, hold_slack_ns=None,
                 qualified=False, physically_eligible=False, qualification_reasons=['no implementation record for this backend, format, K, P and W'],
                 power=None, record=None, routed_record=routed, synthesis_record=synth, comparison_group=None, rate_dot_s=rate, rate_ok=rate >= min_rate)
        if r:
            o.update(area_um2=r['cell_area_um2'], area_source=r['stage'], synthesis_area_um2=synth['cell_area_um2'] if synth else None,
                     routed_area_um2=routed['cell_area_um2'] if routed else None, setup_slack_ns=r.get('setup_slack_ns'), hold_slack_ns=r.get('hold_slack_ns'),
                     qualified=bool(r.get('qualified')), physically_eligible=bool(r.get('qualified')) and o['rate_ok'],
                     qualification_reasons=list(r.get('qualification_reasons', [])) + ([] if o['rate_ok'] else ['below the required dot-product rate']),
                     power=r.get('power'), record=r, comparison_group=r.get('comparison_group'))
        out.append(o)
    return out


def select(rows):
    """Selection among calibration-eligible candidates; returns the decision and, when nothing qualifies, why."""
    numeric = [r for r in rows if r.get('numerically_eligible')]
    routed = [r for r in numeric if r.get('physically_eligible')]
    mapped = [r for r in numeric if r.get('synthesis_area_um2') is not None and not r.get('physically_eligible')]
    with_area = [r for r in numeric if r.get('area_um2') is not None]
    groups = {r.get('comparison_group') for r in routed}
    choice = min(routed, key=lambda r: r['area_um2']) if routed and len(groups) == 1 else None
    # the next candidate to implement when nothing qualifies: smallest mapped area among the eligible, un-routed candidates
    shortlist = None if choice else (min(mapped, key=lambda r: r['synthesis_area_um2']) if mapped else None)
    if not rows: reason = 'no candidates were evaluated'
    elif not numeric: reason = 'numerical: no candidate meets the calibration budgets'
    elif not with_area: reason = 'evidence: the numerically eligible candidates have no implementation record for this backend'
    elif not routed: reason = 'physical: the eligible candidates with records are synthesis-only or fail a physical check'
    elif choice is None: reason = 'comparison: qualified candidates come from different implementation groups; choose one group'
    else: reason = ''
    return dict(status='selected' if choice else 'no_qualified_routed_candidate', choice=choice, shortlist=shortlist, numeric_count=len(numeric),
                candidates=len(rows), reason=reason, groups=sorted(str(g) for g in groups))
