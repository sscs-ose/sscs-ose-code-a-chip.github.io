"""Optional PyTorch bridge. Torch is not needed by the notebook's NumPy path.

This CPU integer oracle is for precision studies, not fast training/inference.
Export disjoint calibration/test batches from a frozen model. Task accuracy is
evaluated by the caller; layer NRMSE is not an accuracy estimate.
"""
from pathlib import Path
import hashlib
import json
import numpy as np


def export_linear_layers(model,calibration_batches,test_batches,folder,max_rows=96,max_batches=8,
                         calibration_source_ids=None,test_source_ids=None):
    import torch
    if calibration_source_ids is not None and test_source_ids is not None:
        if set(map(str,calibration_source_ids)) & set(map(str,test_source_ids)):
            raise ValueError('Calibration/test source IDs overlap')
    if max_rows<1 or max_batches<1:raise ValueError('Positive export limits required')
    modules={name:m for name,m in model.named_modules() if isinstance(m,torch.nn.Linear)}
    if not modules:raise ValueError('No torch.nn.Linear layers found')
    captured={split:{name:[] for name in modules} for split in ['calibration','test']}
    counts={split:{name:0 for name in modules} for split in captured}
    active=['calibration'];handles=[]
    for name,module in modules.items():
        def hook(m,args,output,key=name):
            split=active[0];need=max_rows-counts[split][key]
            if need<=0:return
            a=args[0].detach().to(device='cpu',dtype=torch.float32).reshape(-1,m.in_features).numpy()[:need].copy()
            captured[split][key].append(a);counts[split][key]+=len(a)
        handles.append(module.register_forward_hook(hook))
    was_training=model.training
    try:
        model.eval()
        with torch.no_grad():
            for split,batches in [('calibration',calibration_batches),('test',test_batches)]:
                active[0]=split
                for index,batch in enumerate(batches):
                    if index>=max_batches:break
                    if isinstance(batch,dict):model(**batch)
                    elif isinstance(batch,(tuple,list)):model(batch[0])
                    else:model(batch)
    finally:
        for handle in handles:handle.remove()
        model.train(was_training)
    root=Path(folder);root.mkdir(parents=True,exist_ok=True);exports=[]
    for name,module in modules.items():
        if not captured['calibration'][name] or not captured['test'][name]:continue
        safe=''.join(c if c.isalnum() or c in '._-' else '_' for c in (name or 'root'))
        path=root/safe;path.mkdir(exist_ok=True)
        w=module.weight.detach().to(device='cpu',dtype=torch.float32).numpy().copy()
        np.savez_compressed(path/'calibration.npz',x=np.concatenate(captured['calibration'][name]),w=w)
        np.savez_compressed(path/'test.npz',x=np.concatenate(captured['test'][name]))
        manifest=dict(name=name or 'root',kind='pytorch_linear_export',k=module.in_features,outputs=module.out_features,
                      bias_included=False,nonlinearity_included=False,
                      independence='caller source IDs disjoint' if calibration_source_ids is not None and test_source_ids is not None else 'not verified automatically; caller must use disjoint source splits',
                      files={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in path.glob('*.npz')})
        (path/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');exports.append(str(path))
    return exports


def MxLinear(linear,fmt='MXFP4_E2M1',acc_bits=18):
    """Make an inference-only nn.Module with a frozen Linear's weight and bias.

    Returned values are rounded to the original output tensor dtype only after
    the integer-accumulator result is reconstructed. Every call uses CPU NumPy;
    the returned tensor is moved back to the input device.
    """
    import torch
    from .numerics import prepare,accumulate
    if not isinstance(linear,torch.nn.Linear):raise TypeError('Expected torch.nn.Linear')
    class ReferenceMxLinear(torch.nn.Module):
        def __init__(self):
            super().__init__();self.register_buffer('weight',linear.weight.detach().clone())
            self.register_buffer('bias',None if linear.bias is None else linear.bias.detach().clone())
            self.format=fmt;self.accumulator_bits=int(acc_bits)
        def forward(self,x):
            if torch.is_grad_enabled() and x.requires_grad:
                raise RuntimeError('MxLinear is an inference oracle; use torch.no_grad()')
            arr=x.detach().to(device='cpu',dtype=torch.float32).reshape(-1,self.weight.shape[1]).numpy()
            weights=self.weight.detach().to(device='cpu',dtype=torch.float32).numpy()
            groups=prepare(arr,weights,self.format)
            out=accumulate(groups,self.accumulator_bits,self.format)['values']
            y=torch.from_numpy(out.copy()).to(device=x.device,dtype=x.dtype).reshape(*x.shape[:-1],self.weight.shape[0])
            if self.bias is not None:y=y+self.bias.to(device=x.device,dtype=x.dtype)
            return y
    return ReferenceMxLinear()
