"""Join measured implementation evidence only to the exact generated RTL.

Import actual LibreLane final metrics and post-route STA state, not screenshots
or a user-entered frequency. Missing checks remain unknown. Power is separate
unless an explicit activity-linked report with units has been supplied.
"""
from pathlib import Path
from functools import lru_cache
import hashlib
import json
import math
import shutil
import tempfile
import re
from .hardware import generate, sha_file
from .numerics import BACKEND

KEYS=('backend','format_x','format_w','k','lanes','accumulator_bits')


def key(row):
    return tuple(row.get(k) for k in KEYS)


@lru_cache(None)
def expected_hash(format_x,format_w,k,lanes,accumulator_bits):
    with tempfile.TemporaryDirectory(prefix='mxlab_hash_') as folder:
        c=generate(folder,format_x,format_w,k,lanes,accumulator_bits)
        return c['rtl_sha256']


def load_records(root):
    records=[]
    for path in sorted(Path(root).rglob('*record.json')):
        try:
            row=json.loads(path.read_text());c=row['config']
            if c.get('backend')!=BACKEND:continue
            expected=expected_hash(c['format_x'],c['format_w'],c['k'],c['lanes'],c['accumulator_bits'])
            row['current_rtl']=(expected==row.get('rtl_sha256'))
            if (path.parent/'mx_dot.sv').exists():row['current_rtl'] &= sha_file(path.parent/'mx_dot.sv')==expected
            # Re-hash archived metrics and views, rather than trusting a copied status.
            if row.get('stage')=='post_route':
                row['current_rtl'] &= all((path.parent/name).is_file() and sha_file(path.parent/name)==digest
                                         for name,digest in row.get('evidence_files',{}).items())
                row['current_rtl'] &= bool(row.get('evidence_files'))
            row['record_path']=str(path.resolve());records.append(row)
        except (ValueError,KeyError,TypeError):continue
    return records


def select_record(records,row,clock_ns=50.):
    matching=[r for r in records if key(r.get('config',{}))==key(row) and r.get('current_rtl')]
    if not matching:return None
    routes=[r for r in matching if r['stage']=='post_route' and r['config'].get('clock_period_ns')==clock_ns]
    synthesis=[r for r in matching if r['stage']=='synthesis']
    return (routes or synthesis)[-1] if (routes or synthesis) else None


def join_rows(rows,records,clock_ns=50.,min_rate=0.):
    result=[]
    for row in rows:
        out=dict(row);r=select_record(records,row,clock_ns)
        out.update(area_um2=None,area_source='not_run',power_mw=None,setup_slack_ns=None,
                   physically_eligible=False,implementation_group=None)
        if r:
            activity=r.get('power_provenance',{})
            power_matches=(activity.get('workload_sha256')==row.get('data_sha256') and activity.get('split')==row.get('split'))
            out.update(area_um2=r.get('cell_area_um2'),area_source=r['stage'],power_mw=r.get('power_mw') if power_matches else None,
                       setup_slack_ns=r.get('setup_slack_ns'),record_path=r['record_path'],
                       physically_eligible=(r['stage']=='post_route' and r.get('qualified',False)
                                            and r['config'].get('clock_period_ns')==clock_ns
                                            and 1e9/(clock_ns*row['ii_no_stall'])>=min_rate),
                       implementation_group=r.get('comparison_signature',r.get('liberty_sha256')))
        result.append(out)
    return result


def choose_routed(rows,comparison_group=None):
    feasible=[r for r in rows if r.get('numerically_eligible') and r.get('physically_eligible')]
    groups={r.get('implementation_group') for r in feasible}
    if comparison_group is None and len(groups)>1:
        return dict(status='choose_comparison_group',choice=None,groups=sorted(str(g) for g in groups))
    if comparison_group is not None:feasible=[r for r in feasible if r.get('implementation_group')==comparison_group]
    return dict(status='selected' if feasible else 'no_qualified_routed_candidate',
                choice=min(feasible,key=lambda r:r['area_um2']) if feasible else None)


def _metric(raw,prefix,how='max'):
    vals=[v for k,v in raw.items() if k==prefix or k.startswith(prefix+'__corner:')]
    try:vals=[float(v) for v in vals]
    except (TypeError,ValueError):return None
    if not vals or not all(math.isfinite(v) for v in vals):return None
    return min(vals) if how=='min' else max(vals)


def constraint_coverage(reports):
    """An explicit empty OpenSTA check_setup section is zero; no report is unknown."""
    if not reports:return None
    marker='check_setup -verbose -unconstrained_endpoints -multiple_clock -no_clock -no_input_delay -loops -generated_clocks'
    counts=[]
    for text in reports:
        if marker not in text:return None
        tail=text.split(marker,1)[1]
        if not re.match(r'\s*={20,}\s*',tail):return None
        warnings=re.findall(r'(?:Warning|Error):[^\n]*',tail,re.I);count=0
        for warning in warnings:
            if not re.search(r'unconstrained|no clock|no input delay',warning,re.I):return None
            match=re.search(r'(\d+) ',warning)
            if not match:return None
            count+=int(match[1])
        if re.search(r'Error|STA-\d+',tail) and not warnings:return None
        counts.append(count)
    return max(counts)


def collect_layout(job_folder,run_folder,output_folder=None):
    job,run=Path(job_folder).resolve(),Path(run_folder).resolve()
    c=json.loads((job/'contract.json').read_text());config=json.loads((job/'config.json').read_text())
    resolved=json.loads((run/'resolved.json').read_text())
    if sha_file(job/'mx_dot.sv')!=c['rtl_sha256']:raise ValueError('RTL changed since this job was generated')
    if resolved.get('DESIGN_NAME')!='mx_dot' or resolved.get('CLOCK_PERIOD')!=c['clock_period_ns']:
        raise ValueError('Run top/clock does not match the exported job')
    files=resolved.get('VERILOG_FILES',[])
    if isinstance(files,str):files=[files]
    if len(files)!=1 or not Path(files[0]).is_file() or sha_file(files[0])!=c['rtl_sha256']:
        raise ValueError('Resolved input RTL does not match; preserve the original source alongside the run')
    for name,value in config.items():
        if name not in ('VERILOG_FILES',) and resolved.get(name)!=value:
            raise ValueError('Resolved flow configuration differs: '+name)
    raw=json.loads((run/'final/metrics.json').read_text())
    sta=sorted(p for p in run.iterdir() if p.is_dir() and p.name.endswith('-openroad-stapostpnr'))
    if not sta or not (sta[-1]/'state_out.json').exists():raise ValueError('Post-route STA completion evidence missing')
    timed=json.loads((sta[-1]/'state_out.json').read_text())['metrics']
    gds=list((run/'final').rglob('*.gds'))
    if not gds:raise ValueError('Final GDS missing; this is not a completed layout result')
    out=Path(output_folder).resolve() if output_folder else job
    out.mkdir(parents=True,exist_ok=True)
    record=dict(stage='post_route',backend=BACKEND,config=c,rtl_sha256=c['rtl_sha256'],routed=True,
                cell_area_um2=_metric(raw,'design__instance__area__stdcell'),
                setup_slack_ns=_metric(timed,'timing__setup__ws','min'),
                hold_slack_ns=_metric(timed,'timing__hold__ws','min'),
                slew_violations=_metric(timed,'design__max_slew_violation__count'),
                cap_violations=_metric(timed,'design__max_cap_violation__count'),
                unconstrained_paths=_metric(timed,'timing__unconstrained__count'),
                unannotated_nets=_metric(timed,'timing__unannotated_net_filtered__count'),
                lvs_errors=_metric(raw,'design__lvs_error__count'),
                power_mw=None,power_status='not_evaluated: provide an activity-linked report with units',
                pdk=resolved.get('PDK'),scl=resolved.get('STD_CELL_LIBRARY'),
                sta_corners=resolved.get('STA_CORNERS',[]),source='actual LibreLane run with post-route STA',
                boundary=c['boundary'])
    drc={n:raw[n] for n in ['magic__drc_error__count','klayout__drc_error__count','design__drc_error__count','route__drc_errors'] if n in raw}
    full=any(n in drc for n in ['magic__drc_error__count','klayout__drc_error__count','design__drc_error__count'])
    record['drc_by_engine']=drc;record['drc_errors']=max(drc.values()) if drc and full else None
    checks=sorted(sta[-1].rglob('checks.rpt'))
    if record['unconstrained_paths'] is None and record['sta_corners'] and len(checks)==len(record['sta_corners']):
        record['unconstrained_paths']=constraint_coverage([path.read_text() for path in checks])
    issues=[]
    for n in ['setup_slack_ns','hold_slack_ns']:
        if record[n] is None or record[n]<0:issues.append(n+' missing/fails')
    for n in ['slew_violations','cap_violations','unconstrained_paths','unannotated_nets','lvs_errors','drc_errors']:
        if record[n] is None or record[n]!=0:issues.append(n+' missing/fails')
    if not record['sta_corners']:issues.append('STA corner coverage missing')
    if record['cell_area_um2'] is None or record['cell_area_um2']<=0:issues.append('standard-cell area missing/invalid')
    for prefix in ['timing__setup__ws','timing__hold__ws','design__max_slew_violation__count','design__max_cap_violation__count']:
        for corner in record['sta_corners']:
            if prefix+'__corner:'+corner not in timed:issues.append('corner metric missing: '+prefix+'/'+corner)
    rtl=job/'rtl_validation.json'
    passed=json.loads(rtl.read_text()) if rtl.exists() else {}
    if passed.get('status')!='pass' or passed.get('rtl_sha256')!=c['rtl_sha256']:issues.append('matching RTL validation missing')
    record['qualified']=not issues;record['qualification_reasons']=issues
    # Compare only identical process, library, clock and physical/flow settings.
    # Remove per-candidate RTL paths while retaining all resolved physical settings.
    physical={k:v for k,v in resolved.items() if k not in ['VERILOG_FILES','DESIGN_DIR','meta']}
    record['comparison_signature']=hashlib.sha256(json.dumps(physical,sort_keys=True,default=str).encode()).hexdigest()
    evidence={'metrics.json':run/'final/metrics.json','resolved.json':run/'resolved.json','sta_state_out.json':sta[-1]/'state_out.json','layout.gds':gds[0]}
    evidence.update({f'checks_{i}.rpt':path for i,path in enumerate(checks)})
    if rtl.exists():evidence['rtl_validation.json']=rtl
    record['evidence_files']={}
    for name,path in evidence.items():
        dest=out/'raw'/name;dest.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(path,dest)
        record['evidence_files']['raw/'+name]=sha_file(dest)
    (out/'layout_record.json').write_text(json.dumps(record,indent=2)+'\n')
    return record


def import_power(job_folder,metadata_path):
    """Import a total-power report with explicit units and activity provenance.

    Metadata schema is documented in docs/POWER.md. This does not invent a
    switching rate or estimate power from area. It accepts an OpenSTA-style
    Internal/Switching/Leakage/Total row and checks that the columns agree.
    """
    job=Path(job_folder).resolve();meta_path=Path(metadata_path).expanduser().resolve()
    record_path=job/'layout_record.json'
    r=json.loads(record_path.read_text());meta=json.loads(meta_path.read_text())
    c=r['config']
    if meta.get('rtl_sha256')!=r['rtl_sha256'] or meta.get('clock_period_ns')!=c['clock_period_ns']:
        raise ValueError('Power report RTL/clock does not match this layout')
    if meta.get('corner') not in r.get('sta_corners',[]):raise ValueError('Power corner is not in the layout record')
    if meta.get('unit') not in ['W','mW','uW']:raise ValueError('Explicit power unit W/mW/uW required')
    if not re.fullmatch(r'[0-9a-fA-F]{64}',str(meta.get('workload_sha256',''))):
        raise ValueError('Provide the workload SHA256 from the exported study')
    if meta.get('split') not in ['calibration','test','stress']:
        raise ValueError('Power activity split must be explicit: calibration/test/stress')
    if not isinstance(meta.get('voltage_v'),(float,int)) or meta['voltage_v']<=0:raise ValueError('Voltage required')
    def source(name):
        p=Path(meta[name]);p=p if p.is_absolute() else meta_path.parent/p
        if not p.is_file():raise ValueError('Missing report/activity source: '+name)
        return p
    report,activity=source('report'),source('activity')
    lines=re.findall(r'^\s*Total\s+([+\-\deE.]+)\s+([+\-\deE.]+)\s+([+\-\deE.]+)\s+([+\-\deE.]+)',report.read_text(),re.M)
    if len(lines)!=1:raise ValueError('Expected one Internal/Switching/Leakage/Total row')
    values=list(map(float,lines[0]));total=values[3]
    if not all(math.isfinite(v) and v>=0 for v in values):raise ValueError('Invalid power values')
    if abs(sum(values[:3])-total)>max(1e-12,.005*total):raise ValueError('Power components do not sum to total')
    raw=job/'raw';raw.mkdir(exist_ok=True)
    for name,p in [('power_report.txt',report),('power_metadata.json',meta_path)]:
        shutil.copy2(p,raw/name);r.setdefault('evidence_files',{})['raw/'+name]=sha_file(raw/name)
    r['power_mw']=total*{'W':1000.,'mW':1.,'uW':.001}[meta['unit']]
    r['power_status']='post-route activity-linked estimate; not silicon measurement'
    r['power_provenance']={**meta,'activity_sha256':sha_file(activity),'activity_bytes':activity.stat().st_size}
    record_path.write_text(json.dumps(r,indent=2)+'\n');return r
