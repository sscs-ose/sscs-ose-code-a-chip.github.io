"""Submission bundle: one ZIP with the figures of this run, the selected core's RTL and routed layout, and the records.

    from mxlab.bundle import build, summary
    path = build(PROJECT_ROOT, lab=lab, hardware=hardware)     # results/submission_bundle.zip
    summary(PROJECT_ROOT, lab=lab, hardware=hardware)          # the key numbers of this run

Everything in the bundle is copied from files that exist in this checkout or were written by this run; nothing is
re-measured or estimated. The README inside lists every file and where it came from.
"""
from pathlib import Path
import datetime
import hashlib
import json
import zipfile

RECORDS = ['results/rtl_summary.json', 'results/timing_sweep/summary.json', 'results/recompute/hardware.json', 'results/system/study.json',
           'results/perf/validation_summary.json', 'results/workloads/study.json', 'evidence/generic_core/validation_summary.json', 'flow/environment.json']


def _sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def key_numbers(root, lab=None, hardware=None):
    """The headline numbers, read from the records and the lab session (the same sources the notebook prints)."""
    root = Path(root); j = lambda rel: json.loads((root / rel).read_text()) if (root / rel).exists() else None
    from .ui import cases_html, Session
    _, cases = cases_html(lab.s if lab else Session(root))
    sel = hardware or j('results/quick/hardware_selection.json'); f = sel['selected_f'] if sel else None
    phys = j(f'results/physical/f{f}.json') if f is not None else None
    rtl = j('results/rtl_summary.json') or []; gen = j('evidence/generic_core/validation_summary.json') or {}
    ws = j('results/workloads/study.json') or {}; sel_cells = [s for r in ws.values() for s in r['selections']]
    flag = j('results/recompute/hardware.json'); sysst = j('results/system/study.json'); val = j('results/perf/validation_summary.json')
    tops = (sysst or {}).get('tops', {})
    a = (tops.get('base_n4_k128_f6') or {}).get('post_route', {}).get('cell_area_um2'); b = (tops.get('sys_n4_k128_f2_q2_d24') or {}).get('post_route', {}).get('cell_area_um2')
    return dict(
        selection_workload=(sel or {}).get('workload'), selection_budget=(sel or {}).get('budget'), selection_total_budget=(sel or {}).get('total_budget'),
        selection_clock_ns=(sel or {}).get('clock_period_ns'), selection_status=(sel or {}).get('status'),
        selected_f=f, selected_w=None if f is None else 16 + f, selected_area_um2=phys['cell_area_um2'] if phys else None,
        setup_slack_ns=phys['setup_wns_ns'] if phys else None, hold_slack_ns=phys['hold_wns_ns'] if phys else None,
        drc=phys['drc_errors'] if phys else None, lvs=phys['lvs_errors'] if phys else None, sta_corners=phys.get('constraint_coverage_reports') if phys else None,
        case_a_saving_pct=cases['case_a_saving_pct'], case_b_saving_pct=cases['case_b_saving_pct'], f4_area_um2=cases['f4_area'], w18_mapped_um2=cases['w18_area'], w20_mapped_um2=cases['w20_area'],
        rtl_configurations=len(rtl), rtl_transactions=sum(r['transactions'] for r in rtl), rtl_mismatches=sum(r['mismatches'] for r in rtl),
        generic_rtl_configurations=gen.get('rtl_configurations'), generic_rtl_transactions=gen.get('rtl_transactions'), generic_rtl_mismatches=gen.get('rtl_mismatches'),
        generic_mapped=len(gen.get('mapped_implementations', [])),
        workloads=len(ws), study_cells=len(sel_cells), f4_cal_misses=sum(not s['fixed_f4_meets_budget'] for s in sel_cells),
        f4_test_misses=sum(not s['fixed_f4_test_pass'] for s in sel_cells), low_f_enough=sum(s['selected_f'] is not None and s['selected_f'] < 4 for s in sel_cells),
        flag_routed_pct_f2=(flag or {}).get('post_route', {}).get('2', {}).get('delta_area_pct'), flag_routed_pct_f4=(flag or {}).get('post_route', {}).get('4', {}).get('delta_area_pct'),
        system_top_um2=b, fixed_f6_top_um2=a, system_overhead_pct=None if not (a and b) else 100 * (b / a - 1),
        perf_cases=(val or {}).get('n_cases'), perf_events=(val or {}).get('total_events_compared'), perf_max_delta=(val or {}).get('max_abs_cycle_delta'))


def build(root, lab=None, hardware=None, out=None):
    """Write the bundle ZIP and print its contents. Returns the path.

    The evidence checks run again first (support files, raw signoff reports of F2 and F4, provenance of every
    implementation record, the cycle-model record); if any fails, an earlier bundle is deleted and none is written."""
    from mxacc.studies import evidence_gate
    root = Path(root).resolve(); out = Path(out or root / 'results/submission_bundle.zip')
    if out.exists(): out.unlink()                 # a bundle from an earlier run never survives a failed check
    passed = evidence_gate(root)                  # raises EvidenceError
    print(passed)
    files = {}
    for p in sorted((root / 'results/figures').glob('*.png')): files[f'figures/{p.name}'] = p
    for p in [root / 'assets/concept_mxfp4_core.png', root / 'assets/concept_generic_core.png', *sorted((root / 'images/paper').glob('fig*.png'))]:
        if p.exists(): files[f'diagrams/{p.name}'] = p
    for p in sorted((root / 'assets').glob('concept_*_core.svg')): files[f'diagrams/{p.name}'] = p
    if (root / 'scripts/draw_core_concepts.py').exists(): files['diagrams/draw_core_concepts.py'] = root / 'scripts/draw_core_concepts.py'
    n = key_numbers(root, lab, hardware); f = n['selected_f']
    if f is not None:
        for p in [root / 'rtl/dot_top.sv', root / f'rtl/dot_k128_f{f}.sv', root / 'rtl/dot_top_inexact.sv']:
            if p.exists(): files[f'rtl/{p.name}'] = p
        gds = root / f'results/physical/f{f}/final/gds/dot_k128_f{f}.gds'
        if gds.exists(): files[f'layout/{gds.name}'] = gds
        for p in sorted((root / f'evidence/mxfp4_core/K128_F{f}/layout').glob('*.png')): files[f'layout/{p.name}'] = p
        if (root / f'results/physical/f{f}.json').exists(): files[f'records/physical_f{f}.json'] = root / f'results/physical/f{f}.json'
    for rel in RECORDS:
        if (root / rel).exists(): files['records/' + rel.split('/', 1)[1].replace('/', '_')] = root / rel
    extra = {}
    if hardware is not None: extra['records/hardware_selection.json'] = json.dumps(hardware, indent=2)
    if lab is not None:
        export = lab.export(root / 'results/mx_precision_lab_export')
        for p in sorted(export.with_suffix('').glob('*')):
            if p.is_file() and p.name != 'README.md': files[f'records/lab_{p.name}'] = p
    extra['README.md'] = _readme(n, files, passed)
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, strict_timestamps=False) as z:
        for arc, p in files.items(): z.write(p, arc)
        for arc, text in extra.items(): z.writestr(arc, text)
    groups = {}
    for arc in list(files) + list(extra): groups[arc.split('/')[0] if '/' in arc else 'readme'] = groups.get(arc.split('/')[0] if '/' in arc else 'readme', 0) + 1
    print('contents: ' + ', '.join(f'{n} {g}' for g, n in sorted(groups.items())) + ' (the README inside lists every file with its SHA-256)')
    shown = out.relative_to(root) if out.resolve().is_relative_to(root) else out
    print(f'bundle: {shown} ({out.stat().st_size / 1e6:.1f} MB, {len(files) + len(extra)} files)')
    return out


def _readme(n, files, passed=''):
    lines = ['# MX Precision Lab: submission bundle', '', f"Generated {datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')} by Section 15 of submission.ipynb.", '',
             '## Key results', '',
             f"* Configuration of this run (panels): {_config_text(n)}.",
             (f"* Selected MXFP4 core: W{n['selected_w']} (F{n['selected_f']}), {n['selected_area_um2']:,.1f} µm² routed standard-cell area on GF180MCU, setup slack {n['setup_slack_ns']:+.2f} ns at {n['selection_clock_ns'] or 50:g} ns, DRC {n['drc']} / LVS {n['lvs']}."
              if n['selected_f'] is not None else f"* Selected MXFP4 core: none for this configuration; no candidate meets both budgets and every physical check ({n['selection_status']})."),
             f"* Case A (fixed worked decision, MNIST fc2, accumulation 0.1 %, total 12 %, 50 ns): W18 (F2) is {n['case_a_saving_pct']:.2f} % smaller than the equally qualified W20 (F4, {n['f4_area_um2']:,.1f} µm²).",
             f"* Generic MX core, MXFP4 example: W18 maps to {n['case_b_saving_pct']:.2f} % less area than W20 (synthesis stage).",
             f"* Workload study: fixed F4 misses the calibration budget in {n['f4_cal_misses']} of {n['study_cells']} cases; F0 or F2 suffice in {n['low_f_enough']}.",
             f"* RTL: {n['rtl_transactions']:,} regression transactions, {n['rtl_mismatches']} mismatches (MXFP4 core); {n['generic_rtl_transactions']:,} transactions, {n['generic_rtl_mismatches']} mismatches (generic core).",
             f"* Selective exact recompute: N4 top {n['system_overhead_pct']:+.1f} % area vs four fixed F6 cores; rejected.",
             f"* C++ performance model vs RTL: {n['perf_cases']} cases, {n['perf_events']:,} events, max cycle error {n['perf_max_delta']}.", '',
             '## Evidence', '', passed[:1].upper() + passed[1:] + '.' if passed else 'Evidence checks were not run.', '',
             '## Files', '', '| File | SHA-256 (first 16) |', '|:-|:-|']
    lines += [f'| `{arc}` | `{_sha(p)[:16]}` |' for arc, p in sorted(files.items())]
    lines += ['', 'Figures come from this notebook run. Diagrams, RTL, layout views and records are copies of files of the support package. The routed GDS is not in the support package, and its SHA-256 is in records/physical_f*.json.', 'License: Apache 2.0 (project code); GF180MCU files keep their own license.', '']
    return '\n'.join(lines)


def _config_text(n):
    if not n.get('selection_workload'): return 'not run'
    tb = n.get('selection_total_budget')
    return (f"{n['selection_workload']}, accumulation ≤ {100 * n['selection_budget']:g} %" + (f", total ≤ {100 * tb:g} %" if tb is not None else '')
            + (f", {n['selection_clock_ns']:g} ns" if n.get('selection_clock_ns') else ''))


def summary(root, lab=None, hardware=None):
    """Print the key numbers of this run in one block: the panel configuration first, then the fixed worked results."""
    n = key_numbers(root, lab, hardware)
    rule = '=' * 66
    rows = [('Configuration (panels)', _config_text(n))]
    if n['selected_f'] is None:
        rows.append(('Selected core', 'none: no candidate meets both budgets and every physical check' if n['selection_status'] == 'no_qualified_candidate_evaluated' else f"none ({n['selection_status']})"))
    else:
        rows += [('Selected core', f"MXFP4 W{n['selected_w']} (F{n['selected_f']}), K128, P4"),
                 ('Routed area (GF180MCU)', f"{n['selected_area_um2']:,.1f} µm²"),
                 (f"Timing at {n['selection_clock_ns'] or 50:g} ns", f"setup {n['setup_slack_ns']:+.2f} ns, hold {n['hold_slack_ns']:+.2f} ns, {n['sta_corners']} STA corners"),
                 ('Signoff', f"Magic DRC {n['drc']}, Netgen LVS {n['lvs']}")]
    rows += [('Case A (fixed, 0.1 %/12 %)', f"W18 (F2) {n['case_a_saving_pct']:.2f} % below W20 (F4), routed"),
            ('Generic MX core (MXFP4)', f"W18 maps to {n['case_b_saving_pct']:.2f} % less area than W20"),
            ('Workload study', f"fixed F4 misses {n['f4_cal_misses']} of {n['study_cells']} cases; F0/F2 suffice in {n['low_f_enough']}"),
            ('RTL regression', f"{n['rtl_transactions']:,} + {n['generic_rtl_transactions']:,} transactions, {n['rtl_mismatches'] + n['generic_rtl_mismatches']} mismatches"),
            ('Inexact flag (routed)', f"+{n['flag_routed_pct_f2']:.2f} % at F2, +{n['flag_routed_pct_f4']:.2f} % at F4"),
            ('Selective recompute top', f"{n['system_overhead_pct']:+.1f} % area vs fixed F6: rejected"),
            ('C++ model vs RTL', f"{n['perf_cases']} cases, {n['perf_events']:,} events, max error {n['perf_max_delta']} cycles")]
    print(rule); print('  MX Precision Lab · IEEE SSCS Code-a-Chip · ISSCC 2027'); print(rule)
    for k, v in rows: print(f'  {k:26s} {v}')
    print(rule); print('  License: Apache 2.0 · Tools: open source · PDK: GF180MCU (public)'); print(rule)
    return n
