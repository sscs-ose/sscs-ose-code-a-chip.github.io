"""OCP MX v1.0 element codecs and block-32 E8M0 quantization.

Numerical accumulation accepts finite values. Codecs identify NaN/Inf and the
RTL reports an invalid transaction instead of silently treating those as data.
FP8 element conversion supports SAT and OVF. The layer exporter uses SAT/RNE.
"""
from dataclasses import dataclass
from functools import lru_cache
import math
import numpy as np

SPEC_URL = "https://www.opencompute.org/documents/ocp-microscaling-formats-mx-v1-0-spec-final-pdf"


@dataclass(frozen=True)
class Format:
    name: str
    bits: int
    exponent_bits: int
    mantissa_bits: int
    bias: int
    unit_exp: int
    max_finite: float
    max_power: int
    kind: str = "float"


FORMATS = {
    "MXFP4_E2M1": Format("MXFP4_E2M1", 4, 2, 1, 1, -1, 6., 2),
    "MXFP6_E2M3": Format("MXFP6_E2M3", 6, 2, 3, 1, -3, 7.5, 2),
    "MXFP6_E3M2": Format("MXFP6_E3M2", 6, 3, 2, 3, -4, 28., 4),
    "MXFP8_E4M3": Format("MXFP8_E4M3", 8, 4, 3, 7, -9, 448., 8),
    "MXFP8_E5M2": Format("MXFP8_E5M2", 8, 5, 2, 15, -16, 57344., 15),
    "MXINT8": Format("MXINT8", 8, 0, 6, 0, -6, 127/64, 0, "int"),
}


def get_format(value):
    if isinstance(value, Format):
        return value
    if value not in FORMATS:
        raise ValueError(f"Unknown MX encoding: {value}. Choose {tuple(FORMATS)}")
    return FORMATS[value]


def decode_scales(codes):
    c=np.asarray(codes)
    if np.any(c<0) or np.any(c>255) or np.any(c!=np.floor(c)):
        raise ValueError('E8M0 scale code must be an integer in 0..255')
    return np.where(c==255,np.nan,np.ldexp(np.ones(c.shape),c.astype(np.int16)-127))


def decode_elements(codes, fmt):
    """Decode all bit patterns, including FP8 specials and INT8 -128."""
    fmt = get_format(fmt)
    c = np.asarray(codes)
    if np.any(c < 0) or np.any(c >= (1 << fmt.bits)) or np.any(c != np.floor(c)):
        raise ValueError("Element code is outside the encoding's bit range")
    c = c.astype(np.int64)
    if fmt.kind == "int":
        return np.where(c >= 128, c-256, c).astype(np.float64) / 64.
    sign = np.where(c >> (fmt.bits-1), -1., 1.)
    exponent = (c >> fmt.mantissa_bits) & ((1 << fmt.exponent_bits)-1)
    mantissa = c & ((1 << fmt.mantissa_bits)-1)
    value = np.ldexp(np.where(exponent == 0, mantissa / (1 << fmt.mantissa_bits), 1 + mantissa / (1 << fmt.mantissa_bits)),
                     np.where(exponent == 0, 1-fmt.bias, exponent-fmt.bias)) * sign
    if fmt.name == "MXFP8_E4M3":
        value = np.where((exponent == 15) & (mantissa == 7), np.nan, value)
    elif fmt.name == "MXFP8_E5M2":
        value = np.where(exponent == 31, np.where(mantissa == 0, sign*np.inf, np.nan), value)
    return value


@lru_cache(None)
def codebook(name):
    fmt = get_format(name)
    values = decode_elements(np.arange(1 << fmt.bits), fmt)
    integers = np.zeros(len(values), dtype=np.int64)
    valid = np.isfinite(values)
    integers[valid] = np.rint(np.ldexp(values[valid], -fmt.unit_exp)).astype(np.int64)
    return values, integers, valid


def encode_elements(values, fmt, overflow="sat"):
    """RNE element conversion. INT8 conversion uses the permitted symmetric range."""
    fmt = get_format(fmt)
    if overflow not in ("sat", "ovf"):
        raise ValueError("overflow must be 'sat' or 'ovf'")
    a = np.asarray(values, dtype=np.float64)
    if np.any(np.isnan(a)) and fmt.bits != 8 or (np.any(np.isnan(a)) and fmt.kind == "int"):
        raise ValueError("NaN conversion is not defined by this finite FP4/FP6/INT8 backend")
    if fmt.kind == "int":
        v = np.clip(np.rint(a * 64), -127, 127).astype(np.int16)
        return (v & 255).astype(np.uint8)
    codes = np.arange(1 << (fmt.bits-1), dtype=np.uint8)
    vals = decode_elements(codes, fmt)
    good = np.isfinite(vals)
    codes, vals = codes[good], vals[good]
    mag = np.nan_to_num(np.abs(a), nan=0., posinf=fmt.max_finite)
    mag = np.clip(mag, 0, fmt.max_finite)
    hi = np.clip(np.searchsorted(vals, mag, side="left"), 0, len(vals)-1)
    lo = np.maximum(hi-1, 0)
    dl, dh = mag-vals[lo], vals[hi]-mag
    pick_hi = (dh < dl) | ((dh == dl) & ((codes[hi] & 1) == 0))
    out = np.where(pick_hi, codes[hi], codes[lo]).astype(np.uint8)
    out = out | (np.signbit(a).astype(np.uint8) << (fmt.bits-1))
    if fmt.name.startswith("MXFP8"):
        if overflow == "ovf":
            last = int(codes[-1]); prev = vals[-2]
            threshold = fmt.max_finite + (fmt.max_finite-prev)/2
            ov = (np.abs(a) > threshold) | ((np.abs(a) == threshold) & (last & 1 == 1))
            ov |= np.isinf(a)
            special = 0x7c if fmt.name.endswith("E5M2") else 0x7f
            out = np.where(ov, special | (np.signbit(a).astype(np.uint8) << 7), out).astype(np.uint8)
        out = np.where(np.isnan(a), 0x7f, out).astype(np.uint8)
    return out


@dataclass
class Quantized:
    format: str
    codes: np.ndarray
    scales: np.ndarray
    integers: np.ndarray
    values: np.ndarray
    original_k: int
    clamped_scales: int


def quantize(array, fmt):
    """OCP section 6.3 floor-power scale rule, SAT/RNE; block size is 32.

    Zero-only blocks use scale code 0 (2^-127). FP32-range finite input is
    required. Final partial blocks are zero-padded and the original K is kept.
    """
    fmt = get_format(fmt)
    a = np.asarray(array, dtype=np.float64)
    if a.ndim != 2 or a.shape[1] < 1 or not np.all(np.isfinite(a)):
        raise ValueError("Expected a finite two-dimensional [rows,K] tensor")
    if np.max(np.abs(a), initial=0) > np.finfo(np.float32).max:
        raise ValueError("This backend's input contract is finite FP32-range data")
    k = a.shape[1]; b = (k+31)//32
    block = np.pad(a, ((0, 0), (0, b*32-k))).reshape(len(a), b, 32)
    maximum = np.max(np.abs(block), axis=-1)
    # frexp avoids log2 rounding immediately below an exact power of two.
    _, ex = np.frexp(maximum)
    scale = np.where(maximum > 0, ex-1-fmt.max_power, -127).astype(np.int64)
    clamped = int(np.count_nonzero((scale < -127) | (scale > 127)))
    scale = np.clip(scale, -127, 127)
    scaled = np.ldexp(block, -scale[..., None])
    codes = encode_elements(scaled, fmt, "sat")
    _, table, valid = codebook(fmt.name)
    if not np.all(valid[codes]):
        raise AssertionError("Finite block conversion produced a special encoding")
    integers = table[codes]
    decoded = np.ldexp(integers.astype(np.float64), scale[..., None]+fmt.unit_exp)
    return Quantized(fmt.name, codes, (scale+127).astype(np.uint8), integers,
                     decoded.reshape(len(a), b*32)[:, :k], k, clamped)
