"""Evidence-backed circuit views, GDS renders and the PPA table.

Schematics are extracted from actual Yosys netlists (RTLIL after `proc; opt`, and the technology-mapped
netlist). Dashed boxes are cut nets at the edge of the drawn cone, not inserted hardware. Layout images are
drawn from the real final GDS. Every image carries the hash of the RTL (and GDS) it was made from, and a
view is shown only when those hashes still match the files in the project.
"""
from pathlib import Path
from collections import defaultdict, deque
import base64, hashlib, html, json, re, subprocess
from .hardware import _tool, sha_file

HERE = Path(__file__).resolve()

VIEW_KINDS = {'RTLIL': 'RTL operator graph (Yosys RTLIL after proc/opt): arithmetic operators, muxes and registers as the RTL describes them',
              'technology-mapped': 'Gate-level graph after technology mapping (Yosys + ABC on the GF180 Liberty): real standard cells'}


def _q(s):
    return json.dumps(str(s), ensure_ascii=False)


def _write(path, text):
    Path(path).write_text(text, encoding='utf-8')


def _render_dot(dot, path, dot_tool=None):
    path = Path(path); _write(path.with_suffix('.dot'), dot)
    tool = _tool('dot', dot_tool)
    cp = subprocess.run([tool, '-Tsvg', str(path.with_suffix('.dot')), '-o', str(path.with_suffix('.svg'))], capture_output=True, text=True, timeout=180)
    if cp.returncode: raise RuntimeError(cp.stderr[-1000:])
    svg = path.with_suffix('.svg').read_text()
    def anchor(match):
        title = re.search(r'xlink:title="([^"]*)"', match.group())
        return '<g>' + ('<title>' + title.group(1) + '</title>' if title else '')
    svg = re.sub(r'<a\b[^>]*>', anchor, svg).replace('</a>', '</g>')
    _write(path.with_suffix('.svg'), svg)
    return path.with_suffix('.svg')


def _pretty(name):
    """Readable versions of Yosys-internal net names (no tool paths, no absolute file paths)."""
    n = name.replace('$flatten\\', '').replace('\\$0\\', '').replace('$0\\', '')
    n = re.sub(r'\$func\$[^$]*?:(\d+)\$(\d+)\.\$?', r'@L\1.', n)              # decode$func$rtl/dot_top.sv:74$174.$result -> decode@L74.result
    n = re.sub(r'\$(neg|add|sub|or|and|xor|not|mul|eq|ne|lt|le|gt|ge|shl|shr|sshl|sshr|mux|pmux|reduce_or|reduce_and|logic_not|logic_and|logic_or)\$[^$]*?:(\d+)\$(\d+)_?', r'\1@L\2 ', n)
    n = re.sub(r'\$auto\$opt_dff\.cc:\d+:make_patterns_logic\$(\d+)', r'enable logic #\1', n)
    n = re.sub(r'\$abc\$\d+\$new_n(\d+)', r'abc net n\1', n)
    n = re.sub(r'\$auto\$[^$]*\$(\d+)', r'internal #\1', n)
    return n.strip()


def cone_graph(model, target, depth=3, limit=52, title='Actual netlist connectivity', target_slice=None, strip_prefix=''):
    """Extract upstream cell/port connectivity from Yosys JSON without inventing wires."""
    cells = model['cells']; aliases = model['netnames']
    if target not in aliases: raise ValueError('Net not present in this netlist: ' + target)
    target_bits = aliases[target]['bits']; target_label = target
    if target_slice is not None:
        lo, hi = target_slice
        if not 0 <= lo < hi <= len(target_bits): raise ValueError('Invalid target bit slice')
        target_bits = target_bits[lo:hi]; target_label += f'[{hi-1}:{lo}]'
    drivers = defaultdict(list)
    for name, c in cells.items():
        for port, bits in c['connections'].items():
            if c['port_directions'].get(port) == 'output':
                for bit in bits: drivers[bit].append((name, port))
    selected = set(); todo = deque((bit, 0) for bit in target_bits); seen = set()
    while todo:
        bit, d = todo.popleft()
        if (bit, d) in seen or d > depth: continue
        seen.add((bit, d))
        for name, _ in drivers.get(bit, []):
            if name in selected or len(selected) >= limit: continue
            selected.add(name); c = cells[name]
            sequential = bool(re.search('dff|latch', c['type'], re.I))
            if sequential and d > 0: continue
            for port, bits in c['connections'].items():
                if c['port_directions'].get(port) == 'input': todo.extend((b, d + 1) for b in bits if isinstance(b, int))
    selected = sorted(selected); ids = {name: f'c{i}' for i, name in enumerate(selected)}
    bitnames = {}
    for name, v in sorted(aliases.items(), key=lambda kv: (kv[0].startswith('$'), len(kv[0]))):
        for i, bit in enumerate(v['bits']):
            if isinstance(bit, int): bitnames.setdefault(bit, name + (f'[{i + v.get("offset", 0)}]' if len(v['bits']) > 1 else ''))
    def label(bits):
        if bits and all(isinstance(b, str) for b in bits): return 'constant ' + (''.join(reversed(bits)) if len(bits) < 9 else str(len(bits)) + ' bits')
        if len(bits) == 1: return _pretty(bitnames.get(bits[0], str(bits[0])))
        names = [_pretty(bitnames.get(b, str(b))) for b in bits]; base = names[0].split('[')[0]
        if all(n.split('[')[0] == base for n in names):
            indices = [int(m.group(1)) for n in names if (m := re.search(r'\[(\d+)\]$', n))]
            if len(indices) == len(bits):
                lo, hi = min(indices), max(indices)
                if hi - lo + 1 == len(set(indices)): return f'{base}[{hi}:{lo}]' + (f' → {len(bits)}b' if len(set(indices)) < len(bits) else '')
            return f'{base} · {len(bits)}b'
        return f'{len(bits)} bits'
    dot = ['digraph G {', 'graph [rankdir=LR, bgcolor="white", pad=.25, nodesep=.35, ranksep=.55, fontname="Helvetica", fontsize=15, labelloc=t, label=' + _q(title) + '];',
           'node [fontname="Helvetica",fontsize=10,shape=record,style="rounded,filled",color="#71838e",fillcolor="#f4f7f9",margin=".11,.07"];',
           'edge [fontname="Helvetica",fontsize=8,color="#607888",arrowsize=.65];']
    registers = 0
    for name in selected:
        c = cells[name]; inputs = [p for p in c['connections'] if c['port_directions'].get(p) == 'input']; outputs = [p for p in c['connections'] if c['port_directions'].get(p) == 'output']
        kind = c['type'].replace('gf180mcu_fd_sc_mcu7t5v0__', '')
        if kind == '$mem_v2': kind = 'decode ROM'; inputs = ['RD_ADDR']; outputs = ['RD_DATA']
        sequential = bool(re.search('dff|latch', kind, re.I)); registers += sequential
        color = '#f9e8d5' if sequential else '#e7eff7'
        ports = {p: f'p{i}' for i, p in enumerate(inputs + outputs)}; c['_view_ports'] = ports
        shown = kind.replace('$', '')
        if sequential and outputs:                                  # name registers by the net they hold
            qbits = [b for b in c['connections'][outputs[0]] if isinstance(b, int)]
            if qbits: shown += ' · ' + label(qbits).replace(strip_prefix, '')
        rec = '{' + '|'.join('<' + ports[p] + '>' + p for p in inputs) + '}|' + shown + '|{' + '|'.join('<' + ports[p] + '>' + p for p in outputs) + '}'
        dot.append(f'{ids[name]} [label={_q("{" + rec + "}")},fillcolor="{color}",tooltip={_q(name.replace(strip_prefix, ""))}];')
    boundary = {}; edges = defaultdict(list)
    for name in selected:
        c = cells[name]
        for port, bits in c['connections'].items():
            if c['port_directions'].get(port) != 'input' or port not in c['_view_ports'] or not bits: continue
            for bit in bits:
                ds = [d for d in drivers.get(bit, []) if d[0] in ids]
                if ds:
                    for src, sp in ds: edges[(ids[src] + ':' + cells[src]['_view_ports'][sp], ids[name] + ':' + c['_view_ports'][port])].append(bit)
                else:
                    k = tuple(bits)
                    if k not in boundary:
                        node = f'b{len(boundary)}'; boundary[k] = node
                        dot.append(f'{node} [shape=box,style="rounded,dashed",fillcolor="white",color="#b4bec5",label={_q(label(bits).replace(strip_prefix, ""))}];')
                    edges[(boundary[k], ids[name] + ':' + c['_view_ports'][port])].append(bit)
    for (src, dst), bits in edges.items():
        unique = list(dict.fromkeys(bits)); width = len(bits)
        description = (str(width) + 'b' + (f' ({len(unique)} nets)' if width != len(unique) else '')) if width > 1 else ''
        dot.append(src + ' -> ' + dst + ' [label=' + _q(description) + '];')
    dot.append('out [shape=box,fillcolor="#e4efe9",label=' + _q(target_label.replace(strip_prefix, '') + f" · {len(target_bits)}b") + '];')
    grouped = defaultdict(list)
    for bit in target_bits:
        for name, port in drivers.get(bit, []):
            if name in ids: grouped[(name, port)].append(bit)
    for (name, port), bits in grouped.items(): dot.append(ids[name] + ':' + cells[name]['_view_ports'][port] + ' -> out [label=' + _q(str(len(bits)) + 'b') + '];')
    dot.append('}')
    for c in cells.values(): c.pop('_view_ports', None)
    return '\n'.join(dot), dict(target=target_label.replace(strip_prefix, ''), cells=selected, cell_count=len(selected), registers=registers, boundary_inputs=len(boundary), depth=depth,
                                boundary='dashed boxes are cut nets at the edge of the drawn cone, not inserted gates; static decode-ROM control pins omitted')


# ------------------------------------------------------------------------------------------------ view specifications
GENERIC_VIEWS = [('rtl_multiply', 'beat_sum', 3, 46, 'RTL · P parallel products and their sum (one beat)', 'The P decoded element pairs are multiplied and summed into beat_sum, which the block accumulator adds up over 32/P beats.'),
                 ('rtl_round', 'rounded', 2, 44, 'RTL · alignment shift and round-to-nearest-even of one block sum', 'block_hold is shifted by F + Eg − Emax; a right shift keeps guard/sticky bits and rounds to nearest even.'),
                 ('rtl_accumulator', 'total', 2, 38, 'RTL · W-bit accumulator register and its feedback', 'The rounded block value is added into the W-bit total register; its feedback edge is the cross-block accumulation.')]
MXFP4_VIEWS = [('rtl_multiply', 'core.sum4', 2, 46, 'RTL · four decoded products and the 4-way adder (one beat)', 'Four lanes decode two 4-bit codes each to signed 5-bit integers, multiply them (signed 10-bit products) and add them into sum4 (12 bits), which the 14-bit block accumulator adds up over eight beats.'),
               ('rtl_round', 'core.b_next', 2, 44, 'RTL · alignment shift and round-to-nearest-even of one block sum (align function)', 'a_sum (14 bits) is shifted by a_sh = F + Eg − Emax; for a right shift the guard and sticky bits form the RNE carry b_round; b_next carries {round, W-bit value}.'),
               ('rtl_accumulator', 'core.total', 2, 38, 'RTL · W-bit accumulator register (total) and its feedback', 'acc_next = total + b_val + b_round; the total register feeds back for the next block; this is the cross-block accumulation that F widens or narrows.')]


def _yosys_json(work, script_lines, yosys=None, log=None):
    work = Path(work); work.mkdir(parents=True, exist_ok=True)
    cp = subprocess.run([_tool('yosys', yosys), '-q', '-p', '; '.join(script_lines)], cwd=work, capture_output=True, text=True, timeout=600)
    _write(log or (work / 'schematic.log'), cp.stdout + cp.stderr)
    if cp.returncode: raise RuntimeError('Yosys extraction failed: ' + (cp.stdout + cp.stderr)[-1200:])


def _manifest(out, rtl_sha256, views, extra):
    for name in ('rtlil.json', 'rtl_full.dot', 'mapped_with_ports.json'):      # large intermediates: regenerable, not evidence
        (Path(out) / name).unlink(missing_ok=True)
    manifest = dict(schema='mxlab-schematic-v2', rtl_sha256=rtl_sha256, views=views, image_sha256={v['file']: sha_file(out / v['file']) for v in views},
                    legend='blue nodes: combinational cells/operators; orange nodes: registers (state); edge labels: bit widths; arrows: data direction; dashed boxes: cut nets at the cone boundary; green box: the drawn target net',
                    kinds=VIEW_KINDS, **extra)
    _write(out / 'manifest.json', json.dumps(manifest, indent=2) + '\n')
    return manifest


def render_generic_schematics(job, yosys=None, dot=None, liberty=None, full=False):
    """Views of a generic-core job (mx_dot.sv + contract.json [+ mapped.json])."""
    job = Path(job).resolve(); contract = json.loads((job / 'contract.json').read_text())
    if sha_file(job / 'mx_dot.sv') != contract['rtl_sha256']: raise ValueError('RTL does not match its contract')
    out = job / 'visuals'; out.mkdir(exist_ok=True)
    previous = json.loads((out / 'manifest.json').read_text()) if (out / 'manifest.json').exists() else {}
    _yosys_json(job, ['read_verilog -sv mx_dot.sv', 'hierarchy -check -top mx_dot', 'proc', 'opt', 'memory_collect', 'opt', 'check', 'write_json visuals/rtlil.json',
                      'show -format dot -width -signed -prefix visuals/rtl_full mx_dot'], yosys)
    model = json.loads((out / 'rtlil.json').read_text())['modules']['mx_dot']
    views = []
    for stem, target, depth, limit, title, caption in GENERIC_VIEWS:
        graph, info = cone_graph(model, target, depth, limit, title)
        path = _render_dot(graph, out / stem, dot); views.append(dict(file=path.name, kind='RTLIL', title=title, caption=caption, **info))
    if (job / 'mapped.json').exists():
        r = json.loads((job / 'synthesis_record.json').read_text())
        liberty = Path(liberty) if liberty else _project_root(job) / 'tech' / r['liberty_name']
        if not liberty.is_file() or sha_file(liberty) != r['liberty_sha256']: raise ValueError('Provide the exact mapping Liberty to recover mapped cell pin directions')
        _yosys_json(job, [f'read_liberty -lib {_q(liberty.resolve())}', 'read_json mapped.json', 'hierarchy -top mx_dot', 'write_json visuals/mapped_with_ports.json'], yosys)
        mapped = json.loads((out / 'mapped_with_ports.json').read_text())['modules']['mx_dot']
        graph, info = cone_graph(mapped, 'out_mantissa', 3, 24, 'Gate level · GF180 cells driving out_mantissa[1:0]', target_slice=(0, 2))
        path = _render_dot(graph, out / 'mapped_output', dot)
        views.append(dict(file=path.name, kind='technology-mapped', title='Gate level · GF180 cells driving out_mantissa[1:0]', caption='The real standard cells (after ABC mapping on the GF180 Liberty) that drive the two least significant output bits; the rest of the core is cut at the dashed boundary.', **info))
        selected = {name: mapped['cells'][name] for name in info['cells']}
        _write(out / 'mapped_subset.json', json.dumps(dict(cells=selected, netnames={'out_mantissa': mapped['netnames']['out_mantissa']}), indent=2))
    elif previous.get('rtl_sha256') == contract['rtl_sha256']:
        for v in previous.get('views', []):
            p = out / v['file']
            if v.get('kind') == 'technology-mapped' and p.exists() and sha_file(p) == previous.get('image_sha256', {}).get(v['file']):
                v = dict(v); v.setdefault('title', 'Gate level · GF180 cells driving out_mantissa[1:0]'); v.setdefault('registers', 2); v.setdefault('boundary_inputs', 0)
                v.setdefault('caption', 'The real standard cells (after ABC mapping on the GF180 Liberty) that drive the two least significant output bits; the rest of the core is cut at the dashed boundary. Kept from the original mapping run (hash-checked); the mapped netlist itself is not shipped.')
                views.append(v)
    if full:
        _render_dot((out / 'rtl_full.dot').read_text(), out / 'rtl_full', dot)
        views.append(dict(file='rtl_full.svg', kind='RTLIL', title='Whole module', caption='Every RTLIL cell of the module.', target='whole module', cell_count=len(model['cells'])))
    return _manifest(out, contract['rtl_sha256'], views, dict(backend='generic_core', rtl_files=['mx_dot.sv'], top='mx_dot',
                                                                 mapped_netlist_sha256=sha_file(job / 'mapped.json') if (job / 'mapped.json').exists() else previous.get('mapped_netlist_sha256')))


def render_mxfp4_schematics(root, f, k=128, yosys=None, dot=None):
    """Views of the MXFP4 core at (K, F): RTL cones from rtl/dot_top.sv + the wrapper, mapped cone from results/synthesis/f{f}/netlist.json."""
    root = Path(root).resolve(); top = f'dot_k{k}_f{f}'
    files = [root / 'rtl/dot_top.sv', root / f'rtl/{top}.sv']
    for p in files:
        if not p.exists(): raise FileNotFoundError(p)
    out = root / 'evidence/mxfp4_core' / f'K{k}_F{f}' / 'visuals'; out.mkdir(parents=True, exist_ok=True)
    rel = out.relative_to(root).as_posix()
    _yosys_json(root, ['read_verilog -sv ' + ' '.join(_q(p.relative_to(root).as_posix()) for p in files), f'hierarchy -check -top {top}', 'flatten', 'proc', 'opt', 'memory_collect', 'opt', 'check', f'write_json {rel}/rtlil.json'], yosys, log=out / 'schematic.log')
    model = json.loads((out / 'rtlil.json').read_text())['modules'][top]
    views = []
    for stem, target, depth, limit, title, caption in MXFP4_VIEWS:
        graph, info = cone_graph(model, target, depth, limit, title, strip_prefix='core.')
        path = _render_dot(graph, out / stem, dot); views.append(dict(file=path.name, kind='RTLIL', title=title, caption=caption, **info))
    mapped_path = root / f'results/synthesis/f{f}/netlist.json'; extra = dict(backend='mxfp4_core', rtl_files=[str(p.relative_to(root)) for p in files], top=top)
    if mapped_path.exists():
        mapped = json.loads(mapped_path.read_text())['modules'][top]
        graph, info = cone_graph(mapped, 'out_int', 3, 24, 'Gate level · GF180 cells driving out_int[1:0]', target_slice=(0, 2))
        path = _render_dot(graph, out / 'mapped_output', dot)
        views.append(dict(file=path.name, kind='technology-mapped', title='Gate level · GF180 cells driving out_int[1:0]', caption='The real standard cells (Yosys + ABC on the GF180 Liberty, the exploratory mapping of results/synthesis) that drive the two least significant output bits; the rest of the core is cut at the dashed boundary.', **info))
        extra['mapped_netlist'] = str(mapped_path.relative_to(root)); extra['mapped_netlist_sha256'] = sha_file(mapped_path)
    return _manifest(out, sha_file(root / 'rtl/dot_top.sv'), views, extra)


def _project_root(job):
    for p in [Path(job).resolve()] + list(Path(job).resolve().parents):
        if (p / 'src/mxlab').is_dir() or (p / 'mxlab').is_dir(): return p
    return Path(job).resolve().parent.parent


# ------------------------------------------------------------------------------------------------ layout renders
def render_layout(gds, out_dir, rtl_sha256, title, prefix='layout'):
    from .gds import render_views
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    rendered = render_views(gds, out, prefix, title)
    manifest = dict(schema='mxlab-layout-v1', rtl_sha256=rtl_sha256, gds=str(gds), gds_sha256=sha_file(gds), rendered=rendered, title=title,
                    views={'overview': 'Metal1 to Metal5 over the whole die: the routed core and its power grid',
                           'routing_zoom': 'A 35 µm window at the die centre: routing metals and vias',
                           'devices_zoom': 'The same window: Nwell, COMP (active), Poly2, Contact and Metal1, the transistors of the standard cells'},
                    layers='GF180MCU mask layers (official layer map): 21 Nwell, 22 COMP, 30 Poly2, 33 Contact, 34 Metal1, 35 Via1, 36 Metal2, 38 Via2, 42 Metal3, 40 Via3, 46 Metal4, 41 Via4, 81 Metal5',
                    source='actual GDS polygons; no inferred connectivity or signoff claim')
    _write(out / f'{prefix}_manifest.json', json.dumps(manifest, indent=2) + '\n')
    return manifest


def render_mxfp4_layout(root, f, k=128):
    root = Path(root).resolve(); gds = root / f'results/physical/f{f}/final/gds/dot_k{k}_f{f}.gds'
    if not gds.exists(): raise FileNotFoundError(gds)
    out = root / 'evidence/mxfp4_core' / f'K{k}_F{f}' / 'layout'
    return render_layout(gds, out, sha_file(root / 'rtl/dot_top.sv'), f'dot_k{k}_f{f} · post-route GDS (GF180MCU, 50 ns)')


def render_generic_layout(job):
    from .evidence import load_records
    job = Path(job).resolve(); records = [r for r in load_records(job) if r.get('current_rtl') and r['stage'] == 'post_route']
    if not records: raise ValueError('No matching completed physical run; run or import a layout first')
    record = records[-1]
    if not str(record.get('pdk', '')).lower().startswith('gf180'): raise ValueError('The named layer palette is GF180-specific; provide a layer map for another process')
    return render_layout(job / 'raw/layout.gds', job / 'layout', record['rtl_sha256'], f"{job.name} · post-route GDS ({record.get('pdk')})")


# ------------------------------------------------------------------------------------------------ HTML fragments
def image_html(path, height=None, alt=''):
    path = Path(path); ext = 'svg+xml' if path.suffix == '.svg' else 'png'
    data = base64.b64encode(path.read_bytes()).decode()
    style = 'max-width:none;width:auto;height:auto;display:block;margin:12px auto' if height else 'max-width:100%;height:auto;display:block;margin:12px auto'
    return (f'<div class="mxlab-zoom" style="overflow:auto;border:1px solid #e1e6ea;' + (f'max-height:{height}px;' if height else '') + '">'
            f'<img style="{style}" src="data:image/{ext};base64,{data}" alt="{html.escape(alt or path.stem)}"></div>')


def _p(text, muted=False):
    return f'<p style="{"font-size:13px;color:#61707c;" if muted else ""}margin:6px 0">{text}</p>'


def schematic_manifest(folder):
    m = Path(folder) / 'visuals/manifest.json'
    return json.loads(m.read_text()) if m.exists() else None


def schematic_html(folder, view, rtl_sha256_now):
    """One schematic view with its caption, or an explanation of why it is not shown."""
    folder = Path(folder); m = schematic_manifest(folder)
    if not m: return _p(f'No circuit diagram has been generated for this configuration yet. Press <b>Generate circuit views</b> (needs Yosys and Graphviz) or run <code>python scripts/render_hardware.py schematic {html.escape(str(folder))}</code>.')
    if m['rtl_sha256'] != rtl_sha256_now: return _p('The stored diagrams were made from a different RTL hash than the RTL in this project; regenerate them before trusting them.')
    v = next((v for v in m['views'] if v['file'] == view), None)
    p = folder / 'visuals' / view
    if v is None or not p.exists(): return _p('This view is not available for this configuration. The gate-level view needs a technology-mapped netlist (run synthesis first).')
    if m.get('image_sha256', {}).get(view) != sha_file(p): return _p('The image file does not match the hash recorded in the manifest; regenerate it.')
    kind = VIEW_KINDS.get(v['kind'], v['kind'])
    head = (f"<p><b>{html.escape(v.get('title', view))}</b><br>{html.escape(kind)}.<br>"
            f"Drawn net: <code>{html.escape(v['target'])}</code> · {v['cell_count']} cells in the cone, {v.get('registers', 0)} of them registers, {v.get('boundary_inputs', 0)} cut inputs · cone depth {v.get('depth', '')}.</p>")
    cap = _p(html.escape(v.get('caption', '')))
    legend = _p('Legend: blue = combinational cell or operator, orange = register (state), green = the target net, dashed = a net cut at the boundary of the drawn cone (not a gate). Edge labels are bit widths; arrows show data direction. The box scrolls; the exported HTML report has a zoom slider.', muted=True)
    return head + cap + image_html(p, 520, v.get('title', view)) + legend


def layout_html(folder, view, rtl_sha256_now, gds_path=None, prefix='layout'):
    folder = Path(folder); m = folder / 'layout' / f'{prefix}_manifest.json'
    if not m.exists(): return None
    r = json.loads(m.read_text()); image = folder / 'layout' / f'{prefix}_{view}.png'
    if r['rtl_sha256'] != rtl_sha256_now: return _p('The layout images belong to a different RTL hash than the RTL in this project.')
    if gds_path and Path(gds_path).exists() and sha_file(gds_path) != r['gds_sha256']: return _p('The GDS file changed since these images were rendered; re-render them.')
    if not image.exists() or sha_file(image) != r['rendered'][view]['image_sha256']: return _p('The layout image does not match the hash in its manifest; re-render it.')
    info = r['rendered'][view]
    head = f"<p><b>{html.escape(r['title'])} · {html.escape(r['views'][view])}</b><br>{info['polygons_rendered']:,} polygons drawn from GDS <code>{r['gds_sha256'][:16]}…</code>; window x {info['box_um'][0]:.1f} to {info['box_um'][2]:.1f} µm, y {info['box_um'][1]:.1f} to {info['box_um'][3]:.1f} µm.</p>"
    return head + image_html(image, None, r['views'][view]) + _p(html.escape(r['layers']) + '. The image shows geometry only; connectivity, DRC, LVS and timing are established by their reports in the PPA table.', muted=True)


def fmt_num(v, unit='', digits=None):
    if v is None: return 'Not measured'
    if isinstance(v, float):
        s = f'{v:,.{digits}f}' if digits is not None else f'{v:,.6g}'
    else: s = f'{v:,}'
    return f'{s} {unit}'.strip()


def ppa_rows(row):
    """The PPA table of one joined candidate row, every field with its source, 'Not measured' when absent."""
    r = row.get('record') or {}; routed = row.get('routed_record'); synth = row.get('synthesis_record'); con = row
    power = (routed or {}).get('power') or {}
    rows = [('Area · technology-mapped (synthesis)', fmt_num(synth['cell_area_um2'] if synth else None, 'µm²', 1), synth['source'] if synth else 'no synthesis record'),
            ('Area · routed standard cells', fmt_num(routed['cell_area_um2'] if routed else None, 'µm²', 1), (routed['source'] + f"; die {fmt_num(routed.get('die_area_um2'), 'µm²', 0)}") if routed else 'no routed record'),
            ('Timing · target clock', f"{con.get('clock_period_ns', routed['clock_period_ns'] if routed else 50.0):g} ns ({1e3 / float(con.get('clock_period_ns', 50.0)):.1f} MHz)", 'a target, not an achieved fmax'),
            ('Timing · post-route setup slack (worst corner)', fmt_num(routed.get('setup_slack_ns') if routed else None, 'ns', 3), f"{len(routed.get('sta_corners', []))} STA corners" if routed else 'post-route STA not run'),
            ('Timing · post-route hold slack (worst corner)', fmt_num(routed.get('hold_slack_ns') if routed else None, 'ns', 3), 'checked separately from setup' if routed else 'post-route STA not run'),
            ('Schedule · initiation interval', f"{con['ii_no_stall']} cycles per dot product", 'no-stall interface, one transaction at a time'),
            ('Schedule · latency', f"{con.get('latency_cycles', con['ii_no_stall'] - 1)} cycles (start accept → result valid)", 'no input/output stalls'),
            ('Rate at the target clock', f"{row.get('rate_dot_s', 1e9 / 50.0 / con['ii_no_stall']):,.0f} dot products/s", 'f_clk / II; only meaningful if timing closes'),
            ('Signoff · DRC / LVS', (f"{fmt_num(routed.get('drc_errors'))} / {fmt_num(routed.get('lvs_errors'))} errors") if routed else 'Not measured', 'Magic DRC and Netgen LVS' if routed and row['backend'] == 'mxfp4_core' else ('from the imported run' if routed else 'needs a completed layout')),
            ('Signoff · electrical (max slew / max cap violations)', (f"{fmt_num(routed.get('max_slew_violations'))} / {fmt_num(routed.get('max_cap_violations'))}") if routed else 'Not measured', 'post-route STA checks' if routed else 'needs a completed layout'),
            ('Power', (f"{power['value_mw']:.2f} mW" if power.get('value_mw') is not None else 'Not measured'),
             (f"{power.get('method', '')}; corner {power.get('corner')}, {power.get('voltage_v')} V, activity: {power.get('activity')}. {power.get('note', '')}" if power.get('value_mw') is not None else 'no activity-annotated power report for a workload')),
            ('RTL hash of the evaluated core', ((r.get('rtl_sha256') or con.get('rtl_sha256') or '')[:16] + '…') if (r.get('rtl_sha256') or con.get('rtl_sha256')) else 'no implementation record',
             ('current' if r.get('rtl_current', True) else 'STALE: the RTL changed since the record') if r else 'nothing was measured on this configuration'),
            ('Qualification', ('qualified' if row.get('physically_eligible') else ('not qualified' if routed else 'not qualified (no routed record)')), '; '.join(row.get('qualification_reasons', [])) or 'every check passed')]
    return rows


def ppa_html(row):
    body = ''.join('<tr>' + ''.join(f'<td style="padding:7px;border-bottom:1px solid #d7dde2;vertical-align:top">{html.escape(str(v))}</td>' for v in r) + '</tr>' for r in ppa_rows(row))
    head = f"<p><b>PPA evidence · {html.escape(row['backend'])} · {html.escape(row['format_x'])} · W{row['accumulator_bits']} · K{row['k']} · P{row['lanes']}</b><br>Unmeasured fields stay <i>Not measured</i>; a target clock is never reported as an achieved frequency; synthesis area is never reported as a routed result.</p>"
    return head + '<table style="width:100%;border-collapse:collapse;font-size:13px"><tr><th style="text-align:left;padding:7px">Metric</th><th style="text-align:left;padding:7px">Value</th><th style="text-align:left;padding:7px">Source / condition</th></tr>' + body + '</table>'


def export_visual_report(root, backend, folder, row, target, rtl_sha256_now, gds_path=None):
    body = f'<h1>MX Precision Lab · hardware evidence</h1><p>{html.escape(backend.title)} · {html.escape(row["format_x"])} · W{row["accumulator_bits"]} · K{row["k"]} · P{row["lanes"]}</p>'
    body += '<h2>Circuit views (actual netlists)</h2>'
    m = schematic_manifest(folder)
    for v in (m['views'] if m else []): body += schematic_html(folder, v['file'], rtl_sha256_now)
    body += '<h2>Layout views (actual GDS)</h2>'
    for view in ('overview', 'routing_zoom', 'devices_zoom'):
        h = layout_html(folder, view, rtl_sha256_now, gds_path); body += h or _p('No layout for this configuration: not measured.')
    body += '<h2>PPA evidence</h2>' + ppa_html(row)
    script = '''<script>document.querySelectorAll('.mxlab-zoom').forEach(box=>{const img=box.querySelector('img');box.style.maxHeight='760px';const bar=document.createElement('div');bar.style.cssText='display:flex;gap:10px;align-items:center;padding:8px;background:#f1f4f6';const label=document.createElement('span');label.textContent='Zoom';const slider=document.createElement('input');slider.type='range';slider.min='25';slider.max='300';slider.value='100';const fit=document.createElement('button');fit.textContent='Fit width';bar.append(label,slider,fit);box.before(bar);let base=img.naturalWidth||1200;const update=()=>{img.style.maxWidth='none';img.style.width=(base*slider.value/100)+'px';img.style.height='auto';};img.addEventListener('load',()=>{base=img.naturalWidth;fit.click();});slider.addEventListener('input',update);fit.addEventListener('click',()=>{slider.value=Math.max(25,Math.min(300,100*box.clientWidth/base));update();});if(img.complete)fit.click();});</script>'''
    text = ('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MX hardware evidence</title>'
            '<style>body{font:16px/1.6 Arial,sans-serif;color:#20262d;max-width:1200px;margin:30px auto;padding:20px}h2{margin-top:40px;border-top:1px solid #cad4dc;padding-top:20px}td,th{padding:9px;text-align:left;border-bottom:1px solid #cad4dc}table{width:100%;border-collapse:collapse}img{max-width:100%}button{padding:5px 12px;border:1px solid #bcc8d0;background:white;color:#245c7c}p{max-width:1050px}</style>'
            + body + script + '</html>')
    _write(target, text); return Path(target)
