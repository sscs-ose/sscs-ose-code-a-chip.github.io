"""Provenance checks: a cached result is shown as *current* only when the sources that produced it
hash to the same values now, and a checkout is compared file by file with its manifest (SHA256SUMS)."""
from pathlib import Path
import hashlib

# Sources that determine the RTL-vs-C++ validation, the burstiness study and the system decision.
PERF_SOURCES = ['docs/perf_contract.md', 'rtl/dot_top_rc.sv', 'rtl/rc_merge.sv', 'rtl/mxsys_top.sv',
                'cpp/CMakeLists.txt', 'cpp/include/mxacc/perf_model.hpp', 'cpp/src/perf_model.cpp', 'cpp/src/main.cpp',
                'src/mxacc/perf_stimulus.py', 'src/mxacc/perf_rtl.py', 'src/mxacc/perf_trace.py', 'src/mxacc/perf_backend.py']
VALIDATION_SOURCES = PERF_SOURCES + ['scripts/run_perf_validation.py']
STUDY_SOURCES = PERF_SOURCES + ['scripts/run_perf_study.py']
DECISION_SOURCES = PERF_SOURCES + ['scripts/run_perf_study.py', 'src/mxacc/qualify.py', 'scripts/perf_decision.py']
# What the notebook compares with SHA256SUMS right after locating the project (outputs the notebook itself rewrites are excluded).
MANIFEST_PREFIXES = ('src/', 'rtl/', 'cpp/', 'scripts/', 'docs/', 'tests/', 'configs/', 'flow/', 'data/', 'images/',
                     'results/perf/', 'results/system/', 'results/system_rtl/', 'results/recompute/', 'results/physical/', 'results/workloads/', 'results/rtl/',
                     'evidence/', 'assets/', 'tech/')
MANIFEST_EXCLUDE = ('results/notebook_', 'build/')


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_hashes(root, files):
    root = Path(root)
    return {f: (sha256(root / f) if (root / f).exists() else None) for f in files}


def compare_sources(root, recorded):
    """(current, [(file, recorded, now)]) — current only if every recorded source hashes the same today."""
    if not recorded: return False, [('<no source hashes recorded>', None, None)]
    now = source_hashes(root, list(recorded))
    diffs = [(f, recorded[f], now[f]) for f in recorded if recorded[f] != now[f]]
    return not diffs, diffs


def verify_manifest(root, prefixes=MANIFEST_PREFIXES, exclude=MANIFEST_EXCLUDE, manifest='SHA256SUMS'):
    """Compare the project files with the SHA256SUMS manifest for the listed prefixes."""
    root = Path(root); m = root / manifest
    if not m.exists(): return {'manifest': None, 'checked': 0, 'mismatch': [], 'missing': [], 'ok': False}
    checked = 0; mismatch = []; missing = []
    for line in m.read_text().splitlines():
        if not line.strip(): continue
        digest, rel = line.split(None, 1); rel = rel.strip().lstrip('*')
        if not rel.startswith(prefixes) or rel.startswith(exclude): continue
        p = root / rel; checked += 1
        if not p.exists(): missing.append(rel)
        elif sha256(p) != digest: mismatch.append(rel)
    return {'manifest': sha256(m), 'checked': checked, 'mismatch': mismatch, 'missing': missing, 'ok': checked > 0 and not mismatch and not missing}
