"""A small, auditable MXFP4 arithmetic and hardware experiment."""
__version__ = "0.6.0"
