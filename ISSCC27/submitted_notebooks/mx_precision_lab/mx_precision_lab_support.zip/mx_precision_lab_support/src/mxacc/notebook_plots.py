"""Figures of the MXFP4 core studies in submission.ipynb (Sections 11 to 13).

The functions only draw: their inputs are the dictionaries that mxacc.studies computes, and they never change them.
Zero is plotted at zero (symlog axes); qualification uses the same colours as the cost chart of the main panels.
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.patches import Rectangle

# the palette of mxlab.ui.qualification_chart (separable under colour-vision deficiency), plus one accent
GREEN, BLUE, RED, GRAY = '#4DA83A', '#1E58A6', '#9C2E2E', '#7C8790'
ORANGE, INK = '#B56528', '#192C3B'

STYLE = {'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.titlesize': 11, 'axes.titleweight': 'bold', 'axes.labelsize': 10,
         'axes.labelcolor': INK, 'text.color': INK, 'xtick.color': INK, 'ytick.color': INK, 'axes.spines.top': False,
         'axes.spines.right': False, 'axes.linewidth': .7, 'axes.edgecolor': GRAY, 'grid.color': '#DCE2E6', 'grid.linewidth': .6,
         'legend.frameon': False, 'legend.fontsize': 9, 'figure.dpi': 110}


def _style():
    plt.rcParams.update(STYLE)


def plot_precision_matrix(matrix, budgets):
    """Selected F per workload and budget; a frozen choice that fails the independent test is outlined and starred."""
    _style()
    ids = list(matrix); fs = [0, 2, 4, 6, 8, 12, 16, 24]
    colors = ['#F0F5F7', '#DCEBF1', '#B8D4E3', '#8AB8CE', '#5B98B8', '#367A9F', '#225775', '#163B52']
    z = np.full((len(ids), len(budgets)), np.nan)
    for i, wid in enumerate(ids):
        for j, d in enumerate(matrix[wid]['selections']):
            if d['selected_f'] is not None: z[i, j] = fs.index(d['selected_f'])
    cmap = ListedColormap(colors); cmap.set_bad('#E9E9E9')
    fig, ax = plt.subplots(figsize=(11.2, max(5.4, .38 * len(ids) + 1.7)))
    fig.subplots_adjust(left=.29, right=.88, top=.84, bottom=.16)
    ax.imshow(np.ma.masked_invalid(z), cmap=cmap, vmin=-.5, vmax=len(fs) - .5, aspect='auto', interpolation='nearest')
    ax.set_xticks(range(len(budgets)), ['exact' if b == 0 else f'{b:.0e}' for b in budgets])
    ax.xaxis.set_ticks_position('top'); ax.xaxis.set_label_position('top')
    ax.set_xlabel('Calibration accumulation NRMSE budget', labelpad=12)
    labels = []
    for wid in ids:
        prefix = 'BERT Tiny FFN' if wid == 'bert_tiny_ffn_k128' else wid.replace('mnist_', 'MNIST ').replace('syn_', '').replace('_k128', '').replace('_k512', '').replace('_', ' ')
        labels.append(f"{prefix}  [K{matrix[wid]['k']}]")
    ax.set_yticks(range(len(ids)), labels); ax.tick_params(length=0, pad=8)
    for i, wid in enumerate(ids):
        for j, d in enumerate(matrix[wid]['selections']):
            f = d['selected_f']; failed = f is not None and not d['test_pass']
            ax.text(j, i, 'none' if f is None else f'F{f}' + ('*' if failed else ''), ha='center', va='center',
                    color='white' if f is not None and f >= 12 else INK, fontweight='bold' if failed else 'normal', fontsize=10)
            if failed: ax.add_patch(Rectangle((j - .48, i - .48), .96, .96, fill=False, edgecolor=RED, linewidth=1.5))
        ax.text(len(budgets) - .24, i, str(matrix[wid]['disparity_cal']['max_disparity_bits']), ha='left', va='center', color=GRAY, clip_on=False, fontsize=9)
    ax.text(len(budgets) - .24, -.9, 'Cal. spread\n(bits)', ha='left', va='bottom', color=GRAY, clip_on=False, fontsize=9)
    ax.set_xticks(np.arange(-.5, len(budgets), 1), minor=True); ax.set_yticks(np.arange(-.5, len(ids), 1), minor=True)
    ax.grid(which='minor', color='white', linewidth=2); ax.tick_params(which='minor', length=0)
    for sp in ax.spines.values(): sp.set_visible(False)
    fig.suptitle('Required precision depends on the workload and the error budget', x=.05, y=.995, ha='left', fontsize=13, fontweight='bold')
    fig.text(.05, .07, '*  Frozen calibration choice fails the independent test; the choice is kept, not reselected.', color=RED, fontsize=10)
    fig.text(.05, .025, 'Cell label = selected F.  none = no candidate meets the calibration budget.  Colour follows the discrete F candidates.', color=GRAY, fontsize=9)
    return fig


def plot_recompute(rows_rc, workload):
    """Flag frequency and accumulation error are different quantities: two panels, test split, strict policy."""
    _style()
    rows = rows_rc['test']; f = [r['f'] for r in rows]; x = np.arange(len(f))
    flag = [100 * r['flagged_fraction'] for r in rows]; error = [r['nrmse_before'] for r in rows]; after = [r['policies'][0]['nrmse_after'] for r in rows]
    fig, axs = plt.subplots(1, 2, figsize=(11.2, 4.35))
    fig.subplots_adjust(left=.085, right=.98, bottom=.23, top=.82, wspace=.28)
    axs[0].plot(x, flag, 'o-', color=ORANGE, ms=5, label='strict loss flag')
    axs[0].set_yscale('symlog', linthresh=.01, linscale=.6); axs[0].set_ylim(-.004, 110)
    axs[0].set_yticks([0, .01, .1, 1, 10, 100], ['0', '.01', '.1', '1', '10', '100'])
    axs[0].set_ylabel('Flagged dot products on test (%)'); axs[0].set_title('(a) How often an exact path is requested', loc='left'); axs[0].legend(loc='upper right')
    for i, v in enumerate(flag):
        if v > 0: axs[0].annotate(f'{v:.4g}%', (i, v), xytext=(5, 9), textcoords='offset points', fontsize=9, color=ORANGE)
    axs[1].plot(x, error, 'o-', color=BLUE, ms=5, label='without recompute')
    axs[1].plot(x, after, 's', ls=(0, (4, 3)), color=GREEN, ms=5, label='strict recompute')
    axs[1].set_yscale('symlog', linthresh=1e-6, linscale=.6); axs[1].set_ylim(-2e-7, max(error + after + [1e-3]) * 3)
    axs[1].set_yticks([0, 1e-6, 1e-4, 1e-2], ['0', '$10^{-6}$', '$10^{-4}$', '$10^{-2}$'])
    axs[1].set_ylabel('Accumulation NRMSE vs exact MXFP4'); axs[1].set_title('(b) Detection is not an error magnitude', loc='left'); axs[1].legend(loc='upper right')
    for ax in axs:
        ax.set_xticks(x, [f'F{v}' for v in f]); ax.set_xlabel('Alignment precision'); ax.grid(axis='y'); ax.set_axisbelow(True)
    fig.suptitle(workload, x=.085, y=.96, ha='left', fontsize=13, fontweight='bold')
    fig.text(.085, .065, 'Zero is zero: the symlog axes have a small linear region around the origin. Test split; strict policy only.', fontsize=9, color=GRAY)
    fig.text(.085, .022, 'Flag = a discarded non-zero bit. Flagged blocks can cancel; an unflagged dot product is exact.', fontsize=9, color=GRAY)
    return fig


def plot_system_cost(sys_record):
    """Measured components and measured N4 full tops, on separate axes."""
    _style()
    c = sys_record['components']
    keys = ['core_f2_plain', 'core_f2_flag', 'core_f2_record', 'merge_d24']
    names = ['F2 core', '+ loss flag', '+ record store / port', 'Shared merge']
    vals = [c[k]['post_route'] for k in keys]
    fig, axs = plt.subplots(1, 2, figsize=(11.2, 4.8))
    fig.subplots_adjust(left=.075, right=.98, bottom=.29, top=.85, wspace=.32)
    for i, (v, col) in enumerate(zip(vals, [BLUE, BLUE, ORANGE, ORANGE])):
        axs[0].bar(i, v / 1000, color=col, width=.62); axs[0].text(i, v / 1000 + 1.4, f'{v / 1000:.1f}', ha='center', fontsize=10)
    axs[0].axhline(c['fixed']['f6']['post_route'] / 1000, color=GRAY, ls=(0, (4, 3)), lw=1, label='fixed F6 core')
    axs[0].set_xticks(range(4), names, rotation=18, ha='right'); axs[0].set_ylabel('Component area (10³ µm²)')
    axs[0].set_title('(a) Saving bits vs keeping exact records', loc='left'); axs[0].legend(loc='upper left', bbox_to_anchor=(0, 1.01), fontsize=8.5)
    axs[0].set_ylim(0, max(vals) / 1000 * 1.22)
    tops = sys_record['tops']
    a = tops['base_n4_k128_f6']['post_route']['cell_area_um2']; b = tops['sys_n4_k128_f2_q2_d24']['post_route']['cell_area_um2']
    axs[1].bar([0, 1], np.array([a, b]) / 1000, color='white', edgecolor=[BLUE, ORANGE], hatch='///', linewidth=1.4, width=.6)
    for i, v in enumerate([a, b]): axs[1].text(i, v / 1000 + 6, f'{v / 1000:.1f}', ha='center', fontsize=11)
    axs[1].set_xticks([0, 1], ['N4 fixed F6', 'N4 selective recompute\nF2 / Q2 / D24']); axs[1].set_ylabel('Full-top area (10³ µm²)')
    axs[1].set_title(f'(b) Measured full top: +{100 * (b / a - 1):.1f}%', loc='left'); axs[1].set_ylim(0, b / 1000 * 1.22)
    for ax in axs: ax.grid(axis='y'); ax.set_axisbelow(True)
    fig.text(.075, .13, 'Record core and merge component have cap violations.', fontsize=9, color=RED)
    fig.text(.565, .13, 'Both full tops fail electrical qualification.', fontsize=9, color=RED)
    fig.text(.075, .055, 'Same GF180MCU / LibreLane flow, 50 ns. Bars are measured standard-cell area, not deployable qualified systems.', fontsize=9, color=GRAY)
    return fig


def plot_live_sweep(live_rows, ns, qs, label='BERT F2'):
    """Flagged-record P99 latency vs queue depth, for the same transactions in three issue orders."""
    _style()
    fig, axs = plt.subplots(1, len(ns), figsize=(5.6 * len(ns), 4.1), squeeze=False)
    axs = axs.ravel(); fig.subplots_adjust(left=.075, right=.98, top=.83, bottom=.24, wspace=.25)
    colors = {'original': BLUE, 'shuffled': GREEN, 'burst': ORANGE}; markers = {'original': 'o', 'shuffled': 's', 'burst': '^'}
    for ax, n in zip(axs, ns):
        for order, col in colors.items():
            rs = [next(r for r in live_rows if r['n'] == n and r['q'] == q and r['ordering'] == order) for q in qs]
            ys = [np.nan if r['p99'] is None else r['p99'] for r in rs]      # no flagged record in the window: no point
            ax.plot(range(len(qs)), ys, marker=markers[order], color=col, lw=1.8, ms=7 if order == 'original' else 5, markerfacecolor='white', label=order)
        ax.set_xticks(range(len(qs)), qs); ax.set_xlabel('Queue depth Q'); ax.set_ylabel('Flagged-record P99 latency (cycles)')
        ax.set_title(f'{label}, N = {n}', loc='left'); ax.grid(axis='y'); ax.set_axisbelow(True); ax.set_ylim(bottom=0)
    axs[0].legend(ncol=3, loc='upper left', bbox_to_anchor=(-.02, 1.26))
    fig.text(.075, .07, 'Same transaction multiset in three orders. Latency = return handshake − first record valid; window cohort.', fontsize=9, color=GRAY)
    fig.text(.075, .022, 'Hollow markers: fewer than 1,000 flagged samples. These empirical P99 values have no confidence interval.', fontsize=9, color=ORANGE)
    return fig
