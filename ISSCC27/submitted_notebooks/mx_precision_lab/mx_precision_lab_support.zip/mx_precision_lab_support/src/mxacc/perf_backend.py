"""Python entry to the C++ performance model (cpp/): locate or build the executable, translate a
stimulus manifest into command-line arguments, run it, and return its summary with provenance
(binary hash, compiler, model version, input hashes). Nothing here falls back to the Python
cycle model: a missing executable is reported as such.
"""
from pathlib import Path
import hashlib, json, os, shutil, subprocess

ROOT_MARKER = 'cpp/CMakeLists.txt'


def find_binary(root, build=True, log=print):
    """Path of mxacc_perf: $MXACC_PERF_BIN, build/perf/mxacc_perf, or a fresh cmake build (reported, never silent)."""
    root = Path(root)
    env = os.environ.get('MXACC_PERF_BIN')
    if env and Path(env).exists(): return Path(env)
    for cand in (root / 'build/perf/mxacc_perf', root / 'build/perf/Release/mxacc_perf.exe', root / 'build/perf/mxacc_perf.exe'):
        if cand.exists(): return cand
    if not build: raise FileNotFoundError('mxacc_perf not built: run  cmake -S cpp -B build/perf -DCMAKE_BUILD_TYPE=Release && cmake --build build/perf --parallel')
    if shutil.which('cmake'):
        log('== building the C++ performance model (cmake -S cpp -B build/perf)')
        for cmd in (['cmake', '-S', str(root / 'cpp'), '-B', str(root / 'build/perf'), '-DCMAKE_BUILD_TYPE=Release'], ['cmake', '--build', str(root / 'build/perf'), '--parallel']):
            cp = subprocess.run(cmd, text=True, capture_output=True)
            if cp.returncode: raise RuntimeError('C++ build failed:\n' + (cp.stdout + cp.stderr)[-3000:])
        return find_binary(root, build=False)
    cxx = shutil.which('c++') or shutil.which('g++') or shutil.which('clang++')
    if not cxx: raise FileNotFoundError('mxacc_perf not built: neither cmake nor a C++ compiler (c++/g++/clang++) is installed; a C++17 compiler is required')
    (root / 'build/perf').mkdir(parents=True, exist_ok=True)
    log(f'== building the C++ performance model with {cxx} directly (cmake not installed): same sources, -std=c++17 -O2 -DNDEBUG, no fast-math')
    cmd = [cxx, '-std=c++17', '-O2', '-DNDEBUG', '-fno-fast-math', '-Wall', '-I', str(root / 'cpp/include'), str(root / 'cpp/src/main.cpp'), str(root / 'cpp/src/perf_model.cpp'), '-o', str(root / 'build/perf/mxacc_perf')]
    cp = subprocess.run(cmd, text=True, capture_output=True)
    if cp.returncode: raise RuntimeError('C++ build failed:\n' + ' '.join(cmd) + '\n' + (cp.stdout + cp.stderr)[-3000:])
    return find_binary(root, build=False)


def binary_info(exe):
    out = subprocess.run([str(exe), '--version'], text=True, capture_output=True).stdout.strip()
    return {'path': str(exe), 'sha256': hashlib.sha256(Path(exe).read_bytes()).hexdigest(), 'version_line': out}


def run_case(root, case_dir, out_dir, trace=True, window=None, exe=None, timeout=3600):
    """Run the C++ model on a stimulus case; returns the summary dict (also written to out_dir/summary_cpp.json)."""
    root = Path(root); case_dir = Path(case_dir); out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    exe = Path(exe) if exe else find_binary(root)
    man = json.loads((case_dir / 'manifest.json').read_text()); p = man['params']
    cmd = [str(exe), '--n', str(p['n']), '--k', str(p['k']), '--f', str(p['f']), '--q', str(p['q']), '--dmax', str(p['dmax']), '--id-w', str(p['id_w']),
           '--tx-dir', str(case_dir), '--masks', str(case_dir / 'masks.txt'), '--max-cycles', str(man['max_cycles']), '--summary', str(out_dir / 'summary_cpp.json')]
    for r, l in man['resets']: cmd += ['--reset', f'{r}:{l}']
    win = window or man.get('window')
    if win: cmd += ['--window', f'{win[0]}:{win[1]}']
    if trace: cmd += ['--trace-cycles', str(out_dir / 'cycles_cpp.csv'), '--trace-events', str(out_dir / 'events_cpp.csv')]
    cp = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
    (out_dir / 'run_cpp.log').write_text(' '.join(cmd) + '\n' + cp.stdout + cp.stderr)
    if cp.returncode not in (0, 3) or not (out_dir / 'summary_cpp.json').exists():
        raise RuntimeError(f'mxacc_perf failed (exit {cp.returncode}):\n' + (cp.stdout + cp.stderr)[-3000:])
    summary = json.loads((out_dir / 'summary_cpp.json').read_text())
    summary['provenance'] = {'binary': binary_info(exe), 'case': man.get('case'), 'input_files': man['files'], 'stimulus_version': man.get('stimulus_version'),
                             'rtl_sha256': man.get('rtl_sha256'), 'command': ' '.join(cmd)}
    (out_dir / 'summary_cpp.json').write_text(json.dumps(summary, indent=1))
    return summary


def run_generated(root, tx_dir, out_dir, params, seed, thresholds, max_cycles, resets=((0, 3),), window=None, exe=None, trace=False, timeout=3600):
    """Run with the built-in mask generator (study mode): thresholds = dict ret/start/meta/data/out."""
    root = Path(root); out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    exe = Path(exe) if exe else find_binary(root)
    gen = f"{seed}:{thresholds['ret']}:{thresholds['start']}:{thresholds['meta']}:{thresholds['data']}:{thresholds['out']}"
    cmd = [str(exe), '--n', str(params['n']), '--k', str(params['k']), '--f', str(params['f']), '--q', str(params['q']), '--dmax', str(params['dmax']), '--id-w', str(params.get('id_w', 8)),
           '--tx-dir', str(tx_dir), '--mask-gen', gen, '--max-cycles', str(int(max_cycles)), '--summary', str(out_dir / 'summary_cpp.json')]
    for r, l in resets: cmd += ['--reset', f'{r}:{l}']
    if window: cmd += ['--window', f'{window[0]}:{window[1]}']
    if trace: cmd += ['--trace-cycles', str(out_dir / 'cycles_cpp.csv'), '--trace-events', str(out_dir / 'events_cpp.csv')]
    cp = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
    (out_dir / 'run_cpp.log').write_text(' '.join(cmd) + '\n' + cp.stdout + cp.stderr)
    if cp.returncode not in (0, 3) or not (out_dir / 'summary_cpp.json').exists():
        raise RuntimeError(f'mxacc_perf failed (exit {cp.returncode}):\n' + (cp.stdout + cp.stderr)[-3000:])
    summary = json.loads((out_dir / 'summary_cpp.json').read_text())
    summary['provenance'] = {'binary': binary_info(exe), 'mask_gen': gen, 'command': ' '.join(cmd)}
    return summary
