"""Exact integer references. Floating point is used only for presentation/metrics."""
from dataclasses import dataclass
from fractions import Fraction
import hashlib
import math
import numpy as np

U_TABLE = np.array([0, 1, 2, 3, 4, 6, 8, 12], dtype=np.int64)
FP4 = U_TABLE.astype(np.float64) / 2
MID = (FP4[:-1] + FP4[1:]) / 2
CANDIDATES = (0, 2, 4, 6, 8, 12, 16, 24)


def decode(codes):
    c = np.asarray(codes)
    if not np.issubdtype(c.dtype,np.integer) or np.any(c < 0) or np.any(c > 15):
        raise ValueError("FP4 codes must be integers in [0,15]")
    c = c.astype(np.uint8)
    return U_TABLE[c & 7] * np.where(c & 8, -1, 1)


def rne_shift(value: int, shift: int) -> int:
    """Round value * 2**shift, nearest, ties to even, symmetric for negatives."""
    value, shift = int(value), int(shift)
    if shift >= 0:
        return value << shift
    divisor = 1 << -shift
    q, r = divmod(abs(value), divisor)
    q += int(2*r > divisor or (2*r == divisor and q % 2 == 1))
    return -q if value < 0 else q


def width(k, f):
    if k not in (32, 128, 512) or f not in CANDIDATES:
        raise ValueError("Supported K:32/128/512; F:0,2,4,6,8,12,16,24")
    return 14 + (k // 32 - 1).bit_length() + f


def quantize(values):
    """OCP E2M1/E8M0 encoding; groups along the last axis, 32 elements."""
    a = np.asarray(values, dtype=np.float64)
    if a.ndim != 2 or a.shape[1] % 32 or not a.size or not np.all(np.isfinite(a)):
        raise ValueError("Expected nonempty finite [N,K] values, K multiple of 32")
    a = a.reshape(a.shape[0], -1, 32)
    maxima = np.max(np.abs(a), axis=-1)
    exponents = np.frexp(maxima)[1].astype(np.int16) - 3
    exponents[maxima == 0] = 0
    clipped = int(np.count_nonzero((exponents < -127) | (exponents > 127)))
    exponents = np.clip(exponents, -127, 127)
    scaled = np.abs(a) / np.exp2(exponents[..., None])
    idx = np.searchsorted(MID, scaled, side="left")
    on_tie = (idx < 7) & (scaled == MID[np.minimum(idx, 6)])
    idx += on_tie & ((idx & 1) == 1)
    codes = idx.astype(np.uint8) | (np.signbit(a).astype(np.uint8) << 3)
    codes[a == 0] = 0
    return codes, (exponents + 127).astype(np.uint8), {"scale_clips": clipped}


@dataclass
class Groups:
    sums: np.ndarray
    exponents: np.ndarray
    invalid: np.ndarray


def groups(x_codes, x_scales, w_codes, w_scales):
    x, w = decode(x_codes), decode(w_codes)
    xs, ws = np.asarray(x_scales), np.asarray(w_scales)
    if x.ndim != 3 or w.ndim != 3 or x.shape[1:] != w.shape[1:] or x.shape[-1] != 32:
        raise ValueError("codes must have shape [N,B,32] and [M,B,32]")
    if xs.shape != x.shape[:2] or ws.shape != w.shape[:2]:
        raise ValueError("scale shapes do not match blocks")
    sg = np.einsum("nbj,mbj->nmb", x, w, dtype=np.int64)
    eg = xs.astype(np.int16)[:, None, :] + ws.astype(np.int16)[None, :, :] - 256
    invalid = np.any((xs[:, None, :] == 255) | (ws[None, :, :] == 255), axis=-1)
    return Groups(sg, eg, invalid)


def exact(g):
    """Return J and E_min such that the exact value is J*2**E_min."""
    emin = g.exponents.min(axis=-1)
    shifts = g.exponents - emin[..., None]
    b = g.sums.shape[-1]
    if int(shifts.max()) + 14 + (b-1).bit_length() < 63:
        j = np.sum(np.left_shift(g.sums, shifts), axis=-1, dtype=np.int64)
    else:
        j = np.empty(emin.shape, dtype=object)
        for idx in np.ndindex(emin.shape):
            j[idx] = sum(int(v) << int(d) for v,d in zip(g.sums[idx], shifts[idx]))
    return j, emin


def accumulate(g, f):
    width(g.sums.shape[-1] * 32, f)
    emax = g.exponents.max(axis=-1)
    shifts = f + g.exponents - emax[..., None]
    terms = np.zeros_like(g.sums)
    left = shifts >= 0
    terms[left] = np.left_shift(g.sums[left], shifts[left])
    right = (shifts < 0) & (shifts > -14)
    n = -shifts[right]
    mag = np.abs(g.sums[right])
    q = np.right_shift(mag, n)
    rem = mag & (np.left_shift(np.ones_like(n, dtype=np.int64), n)-1)
    half = np.left_shift(np.ones_like(n, dtype=np.int64), n-1)
    q += (rem > half) | ((rem == half) & ((q & 1) != 0))
    terms[right] = np.where(g.sums[right] < 0, -q, q)
    t = terms.sum(axis=-1, dtype=np.int64)
    eo = emax - f
    t = np.where(g.invalid, 0, t)
    eo = np.where(g.invalid, 0, eo)
    return t, eo


def as_float(j, e):
    return np.ldexp(np.asarray(j, dtype=np.float64), np.asarray(e, dtype=np.int32))


def exact_difference(j1, e1, j2, e2):
    """Subtract integer/exponent pairs exactly BEFORE converting to float64."""
    emin = np.minimum(e1, e2)
    d1, d2 = np.asarray(e1)-emin, np.asarray(e2)-emin
    bits1 = max((abs(int(v)).bit_length() for v in np.asarray(j1).flat), default=0)
    bits2 = max((abs(int(v)).bit_length() for v in np.asarray(j2).flat), default=0)
    if np.asarray(j1).dtype != object and np.asarray(j2).dtype != object and max(bits1+int(d1.max()), bits2+int(d2.max())) < 62:
        d = np.left_shift(j1, d1) - np.left_shift(j2, d2)
    else:
        d = np.empty(emin.shape, dtype=object)
        for idx in np.ndindex(emin.shape):
            d[idx] = (int(j1[idx]) << int(d1[idx])) - (int(j2[idx]) << int(d2[idx]))
    return as_float(d, emin)


def metrics(g, f, golden=None):
    if np.any(g.invalid):
        raise ValueError("Numeric metrics exclude invalid scale transactions")
    j, emin = golden if golden is not None else exact(g)
    t, eo = accumulate(g, f)
    errors = exact_difference(t, eo, j, emin)
    ref = as_float(j, emin)
    denom = max(float(np.linalg.norm(ref)), 1e-12)
    absolute = np.abs(errors)
    bound = g.sums.shape[-1]/2 * np.exp2(g.exponents.max(axis=-1)-f)
    return {"f": int(f), "w": width(g.sums.shape[-1]*32, f),
            "nrmse": float(np.linalg.norm(errors)/denom),
            "max_abs": float(absolute.max()), "p99_abs": float(np.quantile(absolute,.99)),
            "max_bound": float(bound.max()),
            "bound_violations": int(np.count_nonzero(absolute > bound)),
            "dot_products": int(ref.size)}


def scalar_dot(xc, xs, wc, ws, f, e_bound=None):
    k = len(xc)
    width(k, f)
    if len(wc) != k or len(xs) != k//32 or len(ws) != k//32:
        raise ValueError("Transaction length mismatch")
    if 255 in xs or 255 in ws:
        return 0, 0, True, False
    es = [int(a)+int(b)-256 for a,b in zip(xs,ws)]
    ss = [sum(int(a)*int(b) for a,b in zip(decode(xc[g*32:(g+1)*32]), decode(wc[g*32:(g+1)*32]))) for g in range(k//32)]
    em = max(es)
    t = sum(rne_shift(v, e-em+f) for v,e in zip(ss,es))
    return t, em-f, False, bool(e_bound is not None and em > e_bound)


def bound_candidates(k, e_bound, abs_tol, candidates=CANDIDATES):
    if not math.isfinite(abs_tol) or abs_tol <= 0:
        raise ValueError("abs_tol must be finite and positive")
    return [f for f in candidates if math.ldexp(k/64, int(e_bound)-f) <= abs_tol]


def array_hash(*arrays):
    h = hashlib.sha256()
    for a in arrays:
        a = np.ascontiguousarray(a)
        h.update(str(a.shape).encode()); h.update(str(a.dtype).encode()); h.update(a.tobytes())
    return h.hexdigest()
