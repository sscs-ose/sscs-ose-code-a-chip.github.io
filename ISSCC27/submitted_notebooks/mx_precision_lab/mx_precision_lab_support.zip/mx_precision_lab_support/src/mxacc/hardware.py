from pathlib import Path
import hashlib,json,re,shutil,subprocess
import numpy as np
from .arithmetic import scalar_dot,width,quantize,CANDIDATES
from .recompute import scalar_inexact

# Variants of the core kept as separate RTL files so that the hashed earlier records stay valid.
VARIANTS={None:{'module':'dot_top','file':'rtl/dot_top.sv','suffix':'','extra_ports':'','extra_names':[]},
          'inexact':{'module':'dot_top_inexact','file':'rtl/dot_top_inexact.sv','suffix':'_inexact',
                     'extra_ports':',\n output wire inexact','extra_names':['inexact']}}

PORTS='''input wire clk,rst,start,output wire start_ready,
 input wire meta_valid,output wire meta_ready,input wire [7:0] x_scale,w_scale,
 input wire in_valid,output wire in_ready,input wire [15:0] x_codes,w_codes,
 output wire out_valid,input wire out_ready,output wire signed [@W@:0] out_int,
 output wire signed [9:0] out_exp,output wire invalid,out_of_contract'''
NAMES='clk,rst,start,start_ready,meta_valid,meta_ready,x_scale,w_scale,in_valid,in_ready,x_codes,w_codes,out_valid,out_ready,out_int,out_exp,invalid,out_of_contract'.split(',')


def generate(root,f,k=128,e_bound=None,variant=None):
    root=Path(root); v=VARIANTS[variant]; name=f'dot_k{k}_f{f}'; w=width(k,f)
    if e_bound is not None:name+=f'_bound_{int(e_bound)}'.replace('-','m')
    name+=v['suffix']
    path=root/'rtl'/f'{name}.sv'
    ports=PORTS.replace('@W@',str(w-1))+v['extra_ports']
    connections=','.join(f'.{n}({n})' for n in NAMES+v['extra_names'])
    path.write_text(f'// SPDX-License-Identifier: Apache-2.0\nmodule {name}({ports});\n'
                    f"{v['module']} #(.K({k}),.F({f}),.USE_BOUND({int(e_bound is not None)}),.E_BOUND({int(e_bound or 0)})) core({connections});\nendmodule\n")
    return path,name


def transactions(k,f,n=1000,seed=20261017,data=None,flag_cases=False):
    rng=np.random.default_rng(seed); b=k//32; cases=[]
    def add(x,w,xs=None,ws=None):
        cases.append((np.array(x,dtype=np.uint8),np.full(b,127,dtype=np.uint8) if xs is None else np.array(xs,dtype=np.uint8),
                      np.array(w,dtype=np.uint8),np.full(b,127,dtype=np.uint8) if ws is None else np.array(ws,dtype=np.uint8)))
    for a in range(16):
        for z in range(16):
            x=np.zeros(k,dtype=np.uint8); w=x.copy(); x[0]=a; w[0]=z;add(x,w)
    for a,z in [(0,0),(7,7),(15,7),(15,15),(8,8)]:add(np.full(k,a),np.full(k,z))
    x=np.tile([7,15],k//2);add(x,np.full(k,7))
    if b>1:
        for sg in [-7,-5,-3,-1,1,3,5,7]:
            for r in [1,2,13,14]:
                x=np.zeros(k,dtype=np.uint8);w=x.copy()
                x[:abs(sg)]=9 if sg<0 else 1;w[:abs(sg)]=1
                xs=np.full(b,128);ws=np.full(b,128);xs[0]=128-f-r
                add(x,w,xs,ws)
        xs=np.zeros(b);ws=np.zeros(b);xs[-1]=254;ws[-1]=254
        add(np.full(k,7),np.full(k,15),xs,ws)
    if flag_cases and b>1:
        # Directed coverage for the inexact flag: right shifts that discard only zeros (even sums,
        # must NOT flag), right shifts that discard a one (must flag), blocks dropped entirely
        # (shift <= -14: flag iff S_g != 0), and two rounding errors that cancel (flag, exact result).
        for sg in [2,4,6,-2,-4,-6,8,-8]:
            for r in [1,2,3,13,14,15]:
                x=np.zeros(k,dtype=np.uint8);w=x.copy();x[:abs(sg)]=9 if sg<0 else 1;w[:abs(sg)]=1
                xs=np.full(b,128);ws=np.full(b,128);xs[0]=128-f-r;add(x,w,xs,ws)
        for r in [14,15,20]:
            x=np.zeros(k,dtype=np.uint8);w=x.copy();xs=np.full(b,128);ws=np.full(b,128);xs[0]=128-f-r;add(x,w,xs,ws)   # S_0 = 0: dropped, exact
            x[0]=1;w[0]=1;add(x,w,xs,ws)                                                                                  # S_0 = 1: dropped, inexact
        x=np.zeros(k,dtype=np.uint8);w=x.copy();x[0]=1;w[0]=1;x[32]=9;w[32]=1   # S_0=+1, S_1=-1, block 2 sets E_max
        xs=np.full(b,128);ws=np.full(b,128);xs[2]=129-f;add(x,w,xs,ws)         # F0: both shifted by 1 -> RNE(0.5)+RNE(-0.5)=0, exact but flagged
    for _ in range(n):add(rng.integers(0,16,k),rng.integers(0,16,k),rng.integers(0,255,b),rng.integers(0,255,b))
    # NaN scale at beginning/end; transaction must still consume every beat.
    for i in [0,b-1]:
        xs=np.full(b,127);xs[i]=255;add(np.full(k,7),np.full(k,7),xs)
    if data is not None:
        d=np.load(data,allow_pickle=False);xc,xs,_=quantize(d['x']);wc,ws,_=quantize(d['w'])
        for i in range(min(64,len(xc))):
            m=i%len(wc);add(xc[i].flatten(),wc[m].flatten(),xs[i],ws[m])
    return cases


TB=r'''`timescale 1ns/1ps
module tb;
 localparam K=@K@,F=@F@,B=K/32,W=@W@;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,start=0,meta_valid=0,in_valid=0,out_ready=0;
 reg [7:0] x_scale=0,w_scale=0;
 reg [15:0] x_codes=0,w_codes=0;
 wire start_ready,meta_ready,in_ready,out_valid,invalid,out_of_contract;@EXTRA_WIRES@
 wire signed [W-1:0] out_int;wire signed [9:0] out_exp;
 @MODULE@ #(.K(K),.F(F),.USE_BOUND(@USE@),.E_BOUND(@BOUND@)) dut(.*);
 reg [8*B-1:0] xs,ws;reg [4*K-1:0] xc,wc;
 reg [W-1:0] expected_t;integer expected_e,expected_bad,expected_bound@EXTRA_DECL@;
 integer file,rc,count=0,g,beat,j,seed=20261017;
 integer cycle=0,last_start=-1,starts=0,base_ii=-1;
 always @(posedge clk)cycle<=cycle+1;
 task reset_dut;
 begin
   @(negedge clk);rst=1;start=0;meta_valid=0;in_valid=0;out_ready=0;
   repeat(2)@(negedge clk);rst=0;
 end endtask
 initial begin
   j=$urandom(seed);reset_dut();
   // Continuous handshakes: measure the interval between accepted starts.
   // Sampled on the negedge (all stimulus changes on the negedge), so the
   // DUT state and the cycle counter are settled; requires four accepted
   // starts and identical intervals between them.
   start=1;meta_valid=1;in_valid=1;out_ready=1;x_scale=127;w_scale=127;
   while(starts<4)begin
     @(negedge clk);
     if(start && start_ready)begin
       if(last_start>=0)begin
         if(base_ii<0)base_ii=cycle-last_start;
         if(base_ii!=cycle-last_start)$fatal(1,"II not stable: %0d then %0d",base_ii,cycle-last_start);
       end
       last_start=cycle;starts=starts+1;
     end
   end
   $display("BASE_II=%0d",base_ii);reset_dut();
   // Reset during metadata, then during data, must abandon the transaction.
   start=1;@(negedge clk);start=0;meta_valid=1;x_scale=127;w_scale=127;
   @(negedge clk);reset_dut();
   start=1;@(negedge clk);start=0;meta_valid=1;
   repeat(B)@(negedge clk);meta_valid=0;in_valid=1;
   repeat(3)@(negedge clk);reset_dut();
   file=$fopen("vectors.txt","r");if(file==0)$fatal(1,"missing vectors");
   while(!$feof(file))begin
     rc=$fscanf(file,"%h %h %h %h %h %d %d %d@EXTRA_FMT@\n",xs,ws,xc,wc,expected_t,expected_e,expected_bad,expected_bound@EXTRA_ARGS@);
     if(rc!=@NFIELDS@)$fatal(1,"bad vector row");
     @(negedge clk);while(!start_ready)@(negedge clk);start=1;
     @(negedge clk);start=0;
     for(g=0;g<B;g=g+1)begin
       repeat($urandom_range(0,2))@(negedge clk);
       x_scale=xs[g*8+:8];w_scale=ws[g*8+:8];meta_valid=1;
       while(!meta_ready)@(negedge clk);
       @(negedge clk);meta_valid=0;
     end
     for(g=0;g<B;g=g+1)begin
       for(beat=0;beat<8;beat=beat+1)begin
         repeat($urandom_range(0,2))@(negedge clk);
         x_codes=xc[(g*32+beat*4)*4+:16];w_codes=wc[(g*32+beat*4)*4+:16];in_valid=1;
         while(!in_ready)@(negedge clk);
         @(negedge clk);in_valid=0;
       end
     end
     while(!out_valid)@(negedge clk);
     // Output backpressure: all result fields must remain stable.
     repeat(3)begin
       if(out_int!==expected_t || $signed(out_exp)!=expected_e || invalid!==expected_bad[0] || out_of_contract!==expected_bound[0]@EXTRA_CHECK@)
         $fatal(1,"mismatch row %0d T=%0d E=%0d expected T=%0d E=%0d",count,$signed(out_int),$signed(out_exp),$signed(expected_t),expected_e);
       @(negedge clk);
     end
     out_ready=1;@(negedge clk);out_ready=0;count=count+1;
   end
   $display("PASS transactions=%0d",count);$finish;
 end
 initial begin #100000000;$fatal(1,"timeout");end
endmodule
'''


def verify(root,f,k=128,n=1000,e_bound=None,result_dir='rtl',variant=None,extra_data=()):
    root=Path(root);v=VARIANTS[variant];generate(root,f,k,e_bound=e_bound,variant=variant); w=width(k,f)
    if not re.fullmatch(r'[a-zA-Z0-9_]+',result_dir):raise ValueError('Invalid results directory')
    out=root/'results'/result_dir/f'k{k}_f{f}'
    if e_bound is not None:out=out.with_name(out.name+'_bounded')
    if variant:out=out.with_name(out.name+v['suffix'])
    out.mkdir(parents=True,exist_ok=True)
    cases=transactions(k,f,n,data=root/'data/mnist_calibration.npz' if k==128 and (root/'data/mnist_calibration.npz').exists() else None,
                       flag_cases=variant=='inexact')
    for extra in extra_data:   # additional real-data vectors (e.g. the BERT layer) for the variant
        d=np.load(extra,allow_pickle=False);xc_,xs_,_=quantize(d['x']);wc_,ws_,_=quantize(d['w'])
        if xc_.shape[1]*32!=k:continue
        for i in range(min(64,len(xc_))):
            m=i%len(wc_);cases.append((xc_[i].flatten().astype(np.uint8),xs_[i].astype(np.uint8),wc_[m].flatten().astype(np.uint8),ws_[m].astype(np.uint8)))
    def packed(a,bits):return sum(int(v)<<(bits*i) for i,v in enumerate(a))
    lines=[];flagged=0;right_shift_exact=0
    for xc,xs,wc,ws in cases:
        t,e,bad,contract=scalar_dot(xc.tolist(),xs.tolist(),wc.tolist(),ws.tolist(),f,e_bound)
        row=f'{packed(xs,8):x} {packed(ws,8):x} {packed(xc,4):x} {packed(wc,4):x} {t&((1<<w)-1):x} {e} {int(bad)} {int(contract)}'
        if variant=='inexact':
            flag=scalar_inexact(xc.tolist(),xs.tolist(),wc.tolist(),ws.tolist(),f);row+=f' {int(flag)}';flagged+=flag
            if not bad and not flag:
                es=[int(a)+int(b)-256 for a,b in zip(xs,ws)]
                if any(ee-max(es)+f<0 for ee in es):right_shift_exact+=1
        lines.append(row)
    (out/'vectors.txt').write_text('\n'.join(lines)+'\n')
    tb=TB
    extra={'MODULE':v['module'],'EXTRA_WIRES':' wire inexact;' if variant=='inexact' else '','EXTRA_DECL':',expected_inexact' if variant=='inexact' else '',
           'EXTRA_FMT':' %d' if variant=='inexact' else '','EXTRA_ARGS':',expected_inexact' if variant=='inexact' else '',
           'NFIELDS':9 if variant=='inexact' else 8,'EXTRA_CHECK':' || inexact!==expected_inexact[0]' if variant=='inexact' else ''}
    for key,val in [('K',k),('F',f),('W',w),('USE',int(e_bound is not None)),('BOUND',e_bound or 0)]+list(extra.items()):tb=tb.replace('@'+key+'@',str(val))
    (out/'tb.sv').write_text(tb)
    exe=shutil.which('iverilog');vvp=shutil.which('vvp')
    if not exe or not vvp:raise RuntimeError('Install Icarus Verilog (iverilog and vvp) to run RTL verification')
    compile_cmd=[exe,'-g2012','-s','tb','-o','sim.vvp',str((root/v['file']).resolve()),'tb.sv']
    cp=subprocess.run(compile_cmd,cwd=out,text=True,capture_output=True)
    (out/'compile.log').write_text(cp.stdout+cp.stderr)
    if cp.returncode:raise RuntimeError(cp.stderr)
    run=subprocess.run([vvp,'sim.vvp'],cwd=out,text=True,capture_output=True,timeout=180)
    (out/'simulation.log').write_text(run.stdout+run.stderr)
    if run.returncode or 'PASS transactions=' not in run.stdout:raise RuntimeError(run.stdout+run.stderr)
    ii=int(re.search(r'BASE_II=(\d+)',run.stdout)[1])
    row={'k':k,'f':f,'w':w,'transactions':len(cases),'mismatches':0,'ii_no_stall':ii,'status':'pass',
         'e_bound':e_bound,'rtl_sha256':hashlib.sha256((root/v['file']).read_bytes()).hexdigest(),
         'vectors_sha256':hashlib.sha256((out/'vectors.txt').read_bytes()).hexdigest(),
         'iverilog_version':subprocess.run([exe,'-V'],text=True,capture_output=True).stdout.splitlines()[0]}
    if variant:
        row.update(variant=variant,rtl_file=v['file'],flagged_vectors=int(flagged),unflagged_vectors=len(cases)-int(flagged),
                   right_shift_but_exact_vectors=int(right_shift_exact),
                   flag_check='inexact compared with mxacc.recompute.scalar_inexact on every transaction; result equality checked as in the baseline')
    (out/'summary.json').write_text(json.dumps(row,indent=2));return row
