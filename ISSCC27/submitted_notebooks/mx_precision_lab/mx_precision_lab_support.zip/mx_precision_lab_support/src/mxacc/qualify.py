"""Qualification-first system selection (v0.4.2).

Data flow (the point of this module): the selection sees **only** the calibration split, the
declared contract and the physical records. Every candidate keeps its test-split numbers in a
separate field, `reported_after_freeze`, that `choose_system` never reads; `frozen_test_check`
scores the frozen choice on the test split afterwards and reports, it never re-selects. A
regression test perturbs every test value and asserts the decision does not change.

Checks, in order, with every elimination recorded:
  1. exactness contract: the calibration (or declared) block-exponent spread vs D_MAX under the
     out-of-contract policy
  2. numeric budget on calibration (after recompute for the recompute mode); performance-model
     scope covers (N, Q)
  3. physical qualification of the *whole* candidate: every check pass; a missing check is 'unknown'
  4. throughput and P99 recompute latency at the declared clock (C++ model, calibration split)
  5. among the survivors, the smallest area per core with a consistent system boundary

Single-core qualified != N-core top qualified. The single-core selection of mxacc.experiment
stays the recommended hardware; the system selection is strict (no fully qualified system top
-> 'none / not_qualified') and the exploration ranking is listed separately with its labels.
Area labels: measured_single_core | measured_full_top | component_scaled_estimate | synthesis_only | unknown.
"""
import numpy as np

DFF_AREA_UM2 = 63.66   # GF180MCU 7T DFF; used only for the Q != 2 queue estimate (labelled as an estimate)
VALIDATED_CONFIGS = {(1, 1), (1, 2), (1, 4), (4, 1), (4, 2), (4, 4), (16, 1), (16, 2), (16, 4)}
D_MAX = 24


def block_spread_max(x, w):
    """max over all (activation, output) pairs of max_g E_g - min_g E_g, from raw float layers."""
    from .arithmetic import quantize
    _, xs, _ = quantize(x); _, ws, _ = quantize(w)
    es = xs.astype(np.int16)[:, None, :] + ws.astype(np.int16)[None, :, :] - 256
    return int((es.max(axis=-1) - es.min(axis=-1)).max())


def _phys_status(rec):
    """pass / fail / unknown and the reasons, from a routed record (study.json top or component)."""
    if not rec: return 'unknown', ['no routed record']
    reasons = []
    if rec.get('setup_wns_ns') is not None and rec['setup_wns_ns'] < 0: reasons.append(f"setup WNS {rec['setup_wns_ns']:.2f} ns")
    if rec.get('hold_wns_ns') is not None and rec['hold_wns_ns'] < 0: reasons.append(f"hold WNS {rec['hold_wns_ns']:.2f} ns")
    for k, name in (('max_slew_violations', 'slew violations'), ('max_cap_violations', 'cap violations'), ('drc_errors', 'DRC errors'), ('lvs_errors', 'LVS errors'), ('xor_differences', 'XOR differences')):
        if rec.get(k) is None: reasons.append(f'{name}: unknown')
        elif rec[k]: reasons.append(f'{rec[k]} {name}')
    if any('unknown' in r for r in reasons) and not any('unknown' not in r for r in reasons): return 'unknown', reasons
    return ('fail' if reasons else 'pass'), reasons


def system_candidates(workload, f_low, sysst, perf_rows, hardware, recompute_entry, numeric, ns=(4, 8, 16, 32), qs=(1, 2, 4, 8, 16), rtl_hashes=None, model_version=None):
    """Candidate list for one workload: the qualified single core, N x fixed-F tops, and (F_low, N, Q) recompute systems.

    `numeric` is the numeric record of mxacc.experiment (its calibration rows give the selection error of the fixed-F
    candidates); `perf_rows` must come from the calibration split (rows from any other split are ignored)."""
    cands = []
    comps = sysst['components']; tops = sysst['tops']; pc = sysst['per_core_cost']['post_route']
    sel = hardware.get('selected_f')
    cal_err = {r['f']: r['nrmse'] for r in numeric.get('calibration', [])}
    test_fixed = (hardware.get('final_test') or {}).get('test_nrmse')
    core_rec = next((c for c in hardware['costs'] if c['f'] == sel), None) if sel is not None else None
    cands.append({'id': f'single_core_F{sel}', 'mode': 'fixed_f', 'f': sel, 'n': 1, 'q': None, 'boundary': 'one core (500 um die)',
                  'area_um2': core_rec['cell_area_um2'] if core_rec else None, 'area_per_core_um2': core_rec['cell_area_um2'] if core_rec else None,
                  'area_source': 'measured_single_core' if core_rec else 'unknown', 'qualification': 'pass' if core_rec and core_rec.get('eligible') else 'fail',
                  'qualification_reasons': core_rec.get('qualification_reasons', []) if core_rec else ['no selected fixed-F core'], 'qualification_scope': 'single core',
                  'validation_scope': 'RTL regression (single core)', 'cal_nrmse': cal_err.get(sel), 'p99_cycles': 0, 'throughput_loss_pct': 0.0,
                  'reported_after_freeze': {'test_nrmse': test_fixed},
                  'rtl_sha256': (core_rec or {}).get('rtl_sha256'), 'contract': f'fixed F{sel}: alignments with spread <= F{sel} exact; larger spreads rounded within the budget'})
    f_area = comps['fixed'].get(f'f{sel}', {}).get('post_route') if sel is not None else None
    for n in ns:
        top = tops.get(f'base_n{n}_k128_f{sel}', {}) if sel is not None else {}
        pr = top.get('post_route'); sy = top.get('synthesis')
        if pr and pr.get('cell_area_um2'): area, src, qual, qr = pr['cell_area_um2'], 'measured_full_top', *_phys_status(pr)
        elif sy and sy.get('cell_area_um2'): area, src, qual, qr = sy['cell_area_um2'], 'synthesis_only', 'unknown', ['synthesis only, no routed top']
        elif f_area: area, src, qual, qr = n * f_area, 'component_scaled_estimate', 'unknown', [f'{n} x routed single core; no routed top']
        else: area, src, qual, qr = None, 'unknown', 'unknown', ['no data']
        cands.append({'id': f'fixed_F{sel}_N{n}', 'mode': 'fixed_f_top', 'f': sel, 'n': n, 'q': None, 'boundary': f'{n} cores, no shared unit (1000 um die)', 'area_um2': area,
                      'area_per_core_um2': None if area is None else area / n, 'area_source': src, 'qualification': qual, 'qualification_reasons': qr, 'qualification_scope': f'{n}-core top',
                      'validation_scope': 'RTL regression (single core)', 'cal_nrmse': cal_err.get(sel), 'p99_cycles': 0, 'throughput_loss_pct': 0.0,
                      'reported_after_freeze': {'test_nrmse': test_fixed}, 'contract': f'fixed F{sel} (budgeted rounding)'})
    per_f = {r['f']: r for r in recompute_entry['per_f']}; rf = per_f.get(f_low, {})
    cal_rows = [r for r in perf_rows if r.get('split', 'calibration') == 'calibration']
    rec_w = None
    for n in ns:
        for q in qs:
            row = next((r for r in cal_rows if r['workload'] == workload and r['f'] == f_low and r['n'] == n and r['q'] == q and r['ordering'] == 'original' and r['masks'] == 'saturated'), None)
            burst = next((r for r in cal_rows if r['workload'] == workload and r['f'] == f_low and r['n'] == n and r['q'] == q and r['ordering'] == 'burst' and r['masks'] == 'saturated'), None)
            rec_w = row['traffic_bits']['record_width'] if row else rec_w
            top = tops.get(f'sys_n{n}_k128_f{f_low}_q{q}_d24', {}); pr = top.get('post_route'); sy = top.get('synthesis')
            if pr and pr.get('cell_area_um2'): area, src, qual, qr = pr['cell_area_um2'], 'measured_full_top', *_phys_status(pr)
            else:
                cost = pc.get(str(n))
                if cost and f_low == 2:
                    area = cost['per_core_total'] * n; src = 'component_scaled_estimate'
                    if q != 2 and rec_w: area += (q - 2) * rec_w * DFF_AREA_UM2; qr = [f'queue depth {q} estimated as (Q-2) x {rec_w} flops x {DFF_AREA_UM2} um2 over the measured Q = 2']
                    else: qr = []
                    qual = 'unknown'; qr = qr + ['no routed top for this (N, Q); components routed, glue scaled from the N = 4 synthesis top']
                    if sy and sy.get('cell_area_um2'): qr.append(f"synthesis top measured: {sy['cell_area_um2']:.0f} um2")
                elif cost and comps.get(f'core_f{f_low}_record', {}).get('post_route'):
                    area = (comps[f'core_f{f_low}_record']['post_route'] + cost['merge_share'] + cost['glue_share']) * n; src = 'component_scaled_estimate'; qual = 'unknown'; qr = ['record core routed; shares from the F2 system']
                else: area, src, qual, qr = None, 'unknown', 'unknown', ['no cost data']
            cands.append({'id': f'recompute_F{f_low}_N{n}_Q{q}', 'mode': 'recompute', 'f': f_low, 'n': n, 'q': q, 'dmax': D_MAX, 'boundary': f'{n} low-F cores + queue (Q={q}) + arbiter + shared merge unit (1000 um die)',
                          'area_um2': area, 'area_per_core_um2': None if area is None else area / n, 'area_source': src, 'qualification': qual, 'qualification_reasons': qr, 'qualification_scope': f'{n}-core recompute top',
                          'validation_scope': 'RTL-validated (N,Q)' if (n, q) in VALIDATED_CONFIGS else 'architecture exploration prediction (C++ model outside the RTL-validated set)',
                          'cal_nrmse': rf.get('cal_nrmse_after_strict_recompute'), 'recompute_fraction': rf.get('cal_flagged_fraction'),
                          'p99_cycles': None if row is None else row['rc_p99'], 'p99_sample': None if row is None else row['rc_count'], 'p99_burst_cycles': None if burst is None else burst['rc_p99'],
                          'throughput_loss_pct': None if row is None else row['throughput_loss_pct'], 'throughput_loss_burst_pct': None if burst is None else burst['throughput_loss_pct'],
                          'rho0': None if row is None else row['rho0'], 'cycle_source': 'C++ performance model, calibration split, original order, saturated input (study.json)',
                          'reported_after_freeze': {'test_nrmse': rf.get('test_nrmse_after_strict_recompute'), 'test_recompute_fraction': rf.get('test_flagged_fraction')},
                          'rtl_sha256': rtl_hashes, 'model_version': model_version,
                          'contract': f'F{f_low} core + exact merge with D_MAX = {D_MAX}: flagged transactions returned exact when spread <= {D_MAX}, out_of_contract otherwise'})
    return cands


def choose_system(cands, budget, requirements, calibration_spread_max=None, declared_spread_max=None, strict=True):
    """Apply the ordered checks on calibration data / declared contract only; never reads `reported_after_freeze`."""
    clock = requirements['clock_period_ns']; min_rate = requirements['min_dot_products_per_s']; max_p99 = requirements.get('max_p99_latency_cycles'); ooc_policy = requirements.get('ooc_policy', 'reject')
    ii0 = requirements.get('ii0', 40)
    spread = declared_spread_max if declared_spread_max is not None else calibration_spread_max
    spread_src = 'declared contract' if declared_spread_max is not None else 'calibration split'
    rows = []
    for c0 in cands:
        c = {k: v for k, v in c0.items() if k != 'reported_after_freeze'}       # the selection cannot see test numbers
        status = []; alive = True
        if c['mode'] == 'recompute' and spread is not None and spread > c['dmax'] and ooc_policy == 'reject':
            alive = False; status.append(f"contract: {spread_src} spread {spread} > D_MAX {c['dmax']} and ooc policy = reject")
        if c.get('cal_nrmse') is None: alive = False; status.append('budget: no calibration NRMSE')
        elif c['cal_nrmse'] > budget: alive = False; status.append(f"budget: calibration NRMSE {c['cal_nrmse']:.2e} > {budget:g}")
        if c['mode'] == 'recompute' and strict and 'prediction' in c['validation_scope']: alive = False; status.append('model scope: (N, Q) outside the RTL-validated set (prediction only)')
        if c['mode'] == 'recompute' and c.get('p99_cycles') is None: alive = False; status.append('model scope: no performance data')
        if c['qualification'] != 'pass':
            alive = False; status.append(f"qualification {c['qualification']}: " + '; '.join(c['qualification_reasons'][:3]))
        rate = 1e9 / clock / ii0 * (c['n'] if c['mode'] != 'fixed_f' else 1)
        loss = c.get('throughput_loss_pct') or 0.0
        if rate * (1 - loss / 100) < min_rate * (c['n'] if c['mode'] != 'fixed_f' else 1): alive = False; status.append(f'throughput {rate * (1 - loss / 100):,.0f} dot/s below requirement')
        if max_p99 is not None and c.get('p99_cycles') is not None and c['p99_cycles'] > max_p99: alive = False; status.append(f"P99 {c['p99_cycles']} cycles > limit {max_p99}")
        if c.get('area_um2') is None: alive = False; status.append('area unknown')
        rows.append({**c0, 'eliminated_by': status, 'survives_strict': alive})
    survivors = [r for r in rows if r['survives_strict'] and r['mode'] != 'fixed_f']
    single = next((r for r in rows if r['mode'] == 'fixed_f'), None)
    best = min(survivors, key=lambda r: r['area_per_core_um2']) if survivors else None
    expl = []
    for r in rows:
        if r['mode'] != 'recompute' or r.get('p99_cycles') is None or r.get('area_um2') is None: continue
        perf_ok = (max_p99 is None or r['p99_cycles'] <= max_p99) and (r.get('throughput_loss_pct') or 0) < 5 and (r.get('cal_nrmse') is not None and r['cal_nrmse'] <= budget)
        expl.append({'id': r['id'], 'n': r['n'], 'q': r['q'], 'performance_feasible': perf_ok, 'p99_cycles': r['p99_cycles'], 'p99_burst_cycles': r.get('p99_burst_cycles'), 'throughput_loss_pct': r['throughput_loss_pct'],
                     'area_per_core_um2': r['area_per_core_um2'], 'area_source': r['area_source'], 'qualification': r['qualification'], 'validation_scope': r['validation_scope'],
                     'vs_single_core_pct': None if single is None or single.get('area_per_core_um2') is None else 100 * (r['area_per_core_um2'] / single['area_per_core_um2'] - 1)})
    expl.sort(key=lambda e: (not e['performance_feasible'], e['area_per_core_um2'], e['id']))
    return {'budget': budget, 'requirements': requirements, 'spread_used': spread, 'spread_source': spread_src,
            'selection_inputs': 'calibration split (numeric error, flag fraction, C++ cycle rows), declared contract, physical records; the test split is not read',
            'single_core_selection': None if single is None else {k: single[k] for k in ('id', 'f', 'area_um2', 'area_source', 'qualification', 'cal_nrmse')},
            'strict_system_selection': None if best is None else {k: best[k] for k in ('id', 'mode', 'f', 'n', 'q', 'area_um2', 'area_per_core_um2', 'area_source', 'qualification')},
            'strict_system_status': 'selected' if best else 'none / not_qualified',
            'strict_rule': 'contract -> calibration budget -> model scope (RTL-validated) -> full-top qualification pass -> throughput and P99 -> smallest area per core with a consistent boundary',
            'exploration_ranking': expl, 'candidates': rows}


def frozen_test_check(decision, test_spread_max, budget):
    """Score the frozen choice on the test split (reported, never used to re-select)."""
    rows = {r['id']: r for r in decision['candidates']}
    out = {}
    sc = decision['single_core_selection']
    if sc:
        t = rows[sc['id']]['reported_after_freeze'].get('test_nrmse')
        out['single_core'] = {'id': sc['id'], 'test_nrmse': t, 'pass': None if t is None else t <= budget}
    best = next((e for e in decision['exploration_ranking'] if e['performance_feasible']), None)
    if best:
        r = rows[best['id']]; t = r['reported_after_freeze']
        out['exploration_choice'] = {'id': best['id'], 'test_nrmse_after_recompute': t.get('test_nrmse'), 'test_recompute_fraction': t.get('test_recompute_fraction'),
                                     'test_spread_max': test_spread_max, 'within_contract': test_spread_max <= r['dmax'],
                                     'pass': (t.get('test_nrmse') is not None and t['test_nrmse'] <= budget) and test_spread_max <= r['dmax']}
    return out
