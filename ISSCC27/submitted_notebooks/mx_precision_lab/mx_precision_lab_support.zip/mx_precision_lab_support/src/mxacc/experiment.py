"""Numerical screening and hardware selection are deliberately separate stages.

Data flow:
  load_workload(root, WORKLOAD)  ->  numeric_experiment(...)  ->  choose_hardware(numeric, costs, ...)
The numeric result carries the workload id, data hash, K, lanes and the budget;
choose_hardware only admits implementation records whose (K, lanes, F) match
that numeric result, and reports the frozen hardware choice's independent-test
error afterwards. Nothing downstream re-reads a default dataset.
"""
from pathlib import Path
import json,math
import numpy as np
from .arithmetic import quantize,groups,bound_candidates,CANDIDATES
from .workloads import load_workload,study

DEFAULT_WORKLOAD='mnist_relu_fc2'


def numeric_experiment(root,tolerance=.001,e_bound=0,abs_tol=.01,out=None,workload=DEFAULT_WORKLOAD,lanes=4,
                       candidates=CANDIDATES,total_tolerance=None):
    """Calibration-only selection of F for one workload; the frozen choice is scored once on the test split.

    `tolerance` bounds the accumulation NRMSE (against exact accumulation of the same MX inputs); `total_tolerance`,
    when given, also bounds the total NRMSE against the FP32 layer, as the panels do. A candidate is feasible only if
    it meets every budget given."""
    root=Path(root); out=Path(out) if out else root/'results/quick';out.mkdir(parents=True,exist_ok=True)
    if not math.isfinite(tolerance) or tolerance<=0:raise ValueError('NRMSE tolerance must be finite and positive')
    if total_tolerance is not None and (not math.isfinite(total_tolerance) or total_tolerance<=0):raise ValueError('total NRMSE budget must be finite and positive')
    wl=load_workload(root,workload,lanes=lanes)
    k=wl['k']
    res=study(wl['x_cal'],wl['x_test'],wl['w'],k,budgets=(tolerance,),candidates=candidates)
    rows=res['calibration']
    def meets(r,acc,total):
        return r['nrmse']<=acc and (total is None or r['nrmse_vs_fp32']<=total)
    for r in rows:r['meets_accumulation_budget']=r['nrmse']<=tolerance;r['meets_total_budget']=None if total_tolerance is None else r['nrmse_vs_fp32']<=total_tolerance
    feasible=[r['f'] for r in rows if meets(r,tolerance,total_tolerance)]
    f=min(feasible) if feasible else None
    by_test={r['f']:r for r in res['test']}
    heldout=by_test[f] if f is not None else None
    bounded=bound_candidates(k,e_bound,abs_tol,candidates)
    bounded_f=min(bounded) if bounded else None
    bounded_test=by_test[bounded_f] if bounded_f is not None else None
    # Scale-contract bookkeeping needs the quantized groups themselves.
    wc,ws,_=quantize(wl['w']);xc,xs,_=quantize(wl['x_cal']);tc,ts,_=quantize(wl['x_test'])
    gc=groups(xc,xs,wc,ws);gt=groups(tc,ts,wc,ws)
    def recommendation(budget):
        choices=[r['f'] for r in rows if meets(r,budget,total_tolerance)]
        return min(choices) if choices else None
    result={"source":"current_run","workload":wl['id'],"workload_source":wl['source'],"workload_path":wl['path'],
            "workload_kind":wl['kind'],"data_sha256":wl['data_sha256'],
            "k":k,"lanes":wl['lanes'],"outputs":wl['outputs'],
            "calibration_samples":res['calibration_samples'],"test_samples":res['test_samples'],
            "tolerance":tolerance,"total_tolerance":total_tolerance,"calibration":rows,"test":res['test'],
            "quantization_cal":res['quantization_cal'],"quantization_test":res['quantization_test'],
            "spread_bits":res['spread_bits'],"sufficient_exact_candidate_f":res['sufficient_exact_candidate_f'],
            "smallest_zero_error_candidate_f":res['smallest_zero_error_candidate_f'],
            "accumulation_feasible_f":[r['f'] for r in rows if r['nrmse']<=tolerance],"feasible_f":feasible,"numeric_recommendation_f":f,
            "numeric_recommendation_rule":"minimum F whose calibration accumulation NRMSE (and total NRMSE, when a total budget is given) meets the budget; hardware selection is a separate constrained stage",
            "heldout":heldout,"heldout_budget_pass":None if heldout is None else meets(heldout,tolerance,total_tolerance),
            "calibration_hash":res['calibration_hash'],"test_hash":res['test_hash'],
            "bounded":{"e_bound":e_bound,"abs_tol":abs_tol,"feasible_f":bounded,
                       "numeric_recommendation_f":bounded_f,"heldout_metrics":bounded_test,
                       "calibration_out_of_contract":int(np.count_nonzero(gc.exponents.max(axis=-1)>e_bound)),
                       "test_out_of_contract":int(np.count_nonzero(gt.exponents.max(axis=-1)>e_bound))},
            "infeasible_demo":{"mode":"bounded","e_bound":0,"abs_tol":1e-12,"feasible_f":bound_candidates(k,0,1e-12,candidates),
                               "meaning":"no candidate satisfies this conservative bound; not a proof that all actual errors exceed tolerance"},
            "budget_sweep":[{"tolerance":x,"recommended_f":recommendation(x)} for x in [.01,.001,.00001,.0000001]],
            "selected_hardware_f":None,"hardware_status":"not_evaluated"}
    (out/'numeric.json').write_text(json.dumps(result,indent=2));return result


def _not_evaluated_row(f,k,lanes):
    return {'f':f,'k':k,'lanes':lanes,'stage':'not_evaluated','cell_area_um2':None,'clock_period_ns':None,
            'setup_wns_ns':None,'hold_wns_ns':None,'unconstrained_paths':None,'max_slew_violations':None,
            'max_cap_violations':None,'unannotated_signal_nets':None,'drc_errors':None,'lvs_errors':None,
            'ii_no_stall':None,'rtl_pass':None,'provenance_pass':None,'comparison_signature':None}


def choose_hardware(numerical,costs,clock_period_ns,min_rate,candidates=CANDIDATES):
    """Pick the smallest qualified implementation among records that match the numeric result's (K, lanes).

    `numerical` is the output of numeric_experiment (or any dict with feasible_f, k, lanes and
    optional calibration/test rows). Records for another architecture are never used as a cost
    proxy: a workload whose K has no implementation record yields stage 'not_evaluated' per F.
    """
    if not all(math.isfinite(v) and v>0 for v in [clock_period_ns,min_rate]):
        raise ValueError('Clock period and minimum throughput must be positive')
    k=int(numerical.get('k',128));lanes=int(numerical.get('lanes',4))
    architecture_stated='k' in numerical and 'lanes' in numerical
    def finite(value):
        return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)
    matching_costs=[c for c in costs if (c.get('k'),c.get('lanes'))==(k,lanes)]
    other=[c for c in costs if (c.get('k'),c.get('lanes'))!=(k,lanes)]
    by_f={}
    for c in matching_costs:
        old=by_f.get(c['f'])
        if old is None or (c.get('stage')=='post_route' and old.get('stage')!='post_route'):by_f[c['f']]=c
    wanted=sorted(set(candidates)|set(by_f))
    checked=[]
    for f in wanted:
        r=dict(by_f.get(f) or _not_evaluated_row(f,k,lanes));reasons=[]
        r['numeric_pass']=f in numerical['feasible_f']
        routed=r.get('stage')=='post_route'
        trusted=r.get('provenance_pass') is True
        evaluated=routed and all(finite(r.get(key)) for key in ['setup_wns_ns','hold_wns_ns','unconstrained_paths'])
        matching=r.get('clock_period_ns')==clock_period_ns
        electrical_keys=['max_slew_violations','max_cap_violations','unannotated_signal_nets']
        electrical_known=routed and all(finite(r.get(key)) for key in electrical_keys)
        r['electrical_checks_pass']=all(r[key]==0 for key in electrical_keys) if electrical_known else None
        timing=bool(evaluated and matching and trusted and r['setup_wns_ns']>=0
                    and r['hold_wns_ns']>=0 and r['unconstrained_paths']==0)
        r['timing_pass']=timing if evaluated else None
        ii=r.get('ii_no_stall')
        # The operating rate is only claimed when timing and the electrical design rules both hold.
        r['dot_products_per_s']=1e9/clock_period_ns/ii if timing and r['electrical_checks_pass'] is True and finite(ii) and ii>0 else None
        r['throughput_pass']=None if r['dot_products_per_s'] is None else r['dot_products_per_s']>=min_rate
        signoff_known=routed and all(finite(r.get(key)) for key in ['drc_errors','lvs_errors'])
        r['physical_checks_pass']=bool(r['drc_errors']==0 and r['lvs_errors']==0) if signoff_known else None
        valid_area=finite(r.get('cell_area_um2')) and r['cell_area_um2']>0
        if not r['numeric_pass']:
            cal_row=next((x for x in numerical.get('calibration',[]) if x['f']==f),None)
            total_tol=numerical.get('total_tolerance')
            over_total=cal_row is not None and total_tol is not None and cal_row.get('nrmse_vs_fp32',0)>total_tol
            over_acc=cal_row is None or cal_row['nrmse']>numerical.get('tolerance',math.inf)
            if over_acc or not over_total:reasons.append('calibration accumulation error exceeds budget')
            if over_total:reasons.append('calibration total error exceeds the total budget')
        if r.get('stage')=='not_evaluated':reasons.append(f'no implementation record for K{k}/P{lanes} F{f}')
        elif not routed:reasons.append('post-route implementation not evaluated')
        if r.get('stage')!='not_evaluated' and not trusted:reasons.append('implementation provenance not verified')
        if routed and not matching:reasons.append('requested clock differs from implemented clock')
        if not timing:reasons.append('setup/hold/unconstrained timing not qualified')
        if r['electrical_checks_pass'] is not True:reasons.append('slew/cap/parasitic-coverage checks not qualified')
        if r['throughput_pass'] is not True and timing and r['electrical_checks_pass'] is True:reasons.append('required dot-product throughput not qualified')
        elif r['throughput_pass'] is not True and not timing:reasons.append('required dot-product throughput not qualified (timing not qualified)')
        if r.get('rtl_pass') is not True:reasons.append('current RTL verification missing')
        if not valid_area:reasons.append('valid cell area missing')
        if r['physical_checks_pass'] is not True:reasons.append('zero DRC and LVS errors not established')
        if r.get('stage')=='not_evaluated':   # the missing record is the whole story; downstream checks are moot
            reasons=[x for x in reasons if (x.startswith('calibration ') and 'error exceeds' in x) or x.startswith('no implementation record')]
        r['eligible']=not reasons;r['qualification_reasons']=reasons
        checked.append(r)
    candidates_ok=[r for r in checked if r['eligible']]
    signatures={r.get('comparison_signature') for r in candidates_ok}
    comparable=len(signatures)<=1 and (not candidates_ok or None not in signatures)
    if not comparable:
        for r in candidates_ok:
            r['eligible']=False;r['qualification_reasons'].append('implementation conditions are not comparable')
        candidates_ok=[]
    errors={r['f']:r['nrmse'] for r in numerical.get('calibration',[])}
    best=min(candidates_ok,key=lambda r:(r['cell_area_um2'],errors.get(r['f'],math.inf),r['f'])) if candidates_ok else None
    selected=None if best is None else best['f']
    # Independent test of the hardware actually selected (frozen choice, scored once; never used to re-pick).
    test_rows={r['f']:r for r in numerical.get('test',[])}
    budget=numerical.get('tolerance');total_budget=numerical.get('total_tolerance')
    final_test=None
    if selected is not None and selected in test_rows:
        t=test_rows[selected]
        acc_ok=None if budget is None else t['nrmse']<=budget
        total_ok=None if total_budget is None else t.get('nrmse_vs_fp32',math.inf)<=total_budget
        final_test={'f':selected,'test_nrmse':t['nrmse'],'test_max_abs':t.get('max_abs'),'test_total_nrmse':t.get('nrmse_vs_fp32'),
                    'budget':budget,'total_budget':total_budget,'pass':None if acc_ok is None else bool(acc_ok and total_ok is not False),
                    'test_hash':numerical.get('test_hash'),'test_samples':numerical.get('test_samples')}
    if not matching_costs:
        status='no_implementation_evaluated_for_architecture'
    elif best:status='selected_within_evaluated_candidates'
    elif not comparable:status='incomparable_implementation_conditions'
    else:status='no_qualified_candidate_evaluated'
    return {'selected_f':selected,'costs':checked,'status':status,
            'workload':numerical.get('workload'),'data_sha256':numerical.get('data_sha256'),
            'calibration_hash':numerical.get('calibration_hash'),'test_hash':numerical.get('test_hash'),
            'k':k,'lanes':lanes,'architecture_stated_by_numeric_result':architecture_stated,
            'budget':budget,'total_budget':total_budget,'numeric_recommendation_f':numerical.get('numeric_recommendation_f'),
            'numeric_feasible_f':list(numerical.get('feasible_f',[])),
            'final_test':final_test,
            'ignored_records_other_architecture':sorted({(c.get('k'),c.get('lanes'),c.get('f')) for c in other}),
            'clock_period_ns':clock_period_ns,'minimum_dot_products_per_s':min_rate,
            'scope':f'K{k}/P{lanes} records only; matching implementation conditions; verified RTL, post-route timing, throughput, DRC and LVS'}


def comparison_table(numerical,hardware,reference_f=4,higher=(8,12,24)):
    """Same-platform comparison of selection policies for one workload at one budget.

    Every row is evaluated under identical conditions: the same K/lanes core, the same clock,
    the same implementation flow, the same calibration/test split and the same budget. Area
    comes only from records that match (K, lanes, F); a policy whose F has no such record
    shows 'not_evaluated'.
    """
    costs={c['f']:c for c in hardware['costs']}
    cal={r['f']:r for r in numerical['calibration']};test={r['f']:r for r in numerical.get('test',[])}
    budget=numerical['tolerance'];total=numerical.get('total_tolerance')
    def ok(r):
        return r['nrmse']<=budget and (total is None or r.get('nrmse_vs_fp32',math.inf)<=total)
    def row(policy,f,note=''):
        c=costs.get(f,{}) if f is not None else {}
        area=c.get('cell_area_um2') if c.get('stage')=='post_route' else None
        return {'policy':policy,'f':f,'w':cal[f]['w'] if f in cal else None,
                'cal_nrmse':cal[f]['nrmse'] if f in cal else None,'test_nrmse':test[f]['nrmse'] if f in test else None,
                'test_total_nrmse':test[f].get('nrmse_vs_fp32') if f in test else None,
                'cal_nrmse_vs_fp32':cal[f].get('nrmse_vs_fp32') if f in cal else None,
                'meets_budget_cal':None if f not in cal else ok(cal[f]),
                'meets_budget_test':None if f not in test else ok(test[f]),
                'stage':c.get('stage','not_evaluated') if f is not None else None,
                'post_route_area_um2':area,'qualified':bool(c.get('eligible',False)) if f is not None else False,
                'qualification_reasons':list(c.get('qualification_reasons',[])) if f is not None else ['no candidate'],'note':note}
    rows=[row(f'fixed F{reference_f} (no selection)',reference_f)]
    rows+=[row(f'fixed F{f} (higher precision)',f) for f in higher if f!=reference_f]
    b=numerical.get('bounded',{})
    rows.append(row(f"bounded (E_bound={b.get('e_bound')}, abs_tol={b.get('abs_tol')})",b.get('numeric_recommendation_f'),'data-free scale contract'))
    rows.append(row('calibrated minimum F (numeric stage only)',numerical.get('numeric_recommendation_f'),'minimum bits, no hardware check'))
    rows.append(row('calibrated + qualified hardware (this tool)',hardware.get('selected_f'),hardware.get('status','')))
    ref=rows[0]['post_route_area_um2']
    for r in rows:
        a=r['post_route_area_um2']
        r['area_vs_fixed_f4_pct']=100*(1-a/ref) if isinstance(a,(int,float)) and isinstance(ref,(int,float)) else None
    return {'conditions':{'workload':numerical.get('workload'),'k':hardware.get('k'),'lanes':hardware.get('lanes'),
                          'clock_period_ns':hardware.get('clock_period_ns'),'minimum_dot_products_per_s':hardware.get('minimum_dot_products_per_s'),
                          'budget':budget,'total_budget':total,'calibration_hash':numerical.get('calibration_hash'),'test_hash':numerical.get('test_hash'),
                          'quantization_nrmse_vs_fp32_cal':(numerical.get('quantization_cal') or {}).get('nrmse_vs_fp32'),
                          'quantization_nrmse_vs_fp32_test':(numerical.get('quantization_test') or {}).get('nrmse_vs_fp32')},
            'rows':rows}
