"""RTL trace testbench for the cycle contract (v0.4): drives rtl/mxsys_top.sv from a shared
stimulus case (mxacc.perf_stimulus) with cycle-indexed offer masks, checks every result and
return against the bit-exact expectations in the transaction rows, and writes the per-cycle
trace in the format of docs/perf_contract.md section 7. The hashed RTL sources are not touched;
every internal signal is read hierarchically from the testbench.
"""
from pathlib import Path
import hashlib, json, re, shutil, subprocess

RTL_FILES = ['rtl/dot_top_rc.sv', 'rtl/rc_merge.sv', 'rtl/mxsys_top.sv']

TB = r'''`timescale 1ns/1ps
module tb;
 localparam N=@N@,K=@K@,F=@F@,B=K/32,W=@W@,WH=@WH@,DMAX=@DMAX@,Q=@Q@,IDW=8,CW=@CW@,QW=@QW@;
 localparam MB=4*N+1, NR=@NR@, MAXCYC=@MAXCYC@, PD=1024;
 localparam IDLE=0, META=1, DATA=2, DRAIN=3, OUT=4;
 localparam PH_START=0, PH_META=1, PH_DATA=2, PH_WAIT=3, PH_DONE=4;
 reg clk=0; always #5 clk=~clk;
 reg rst=1, rst_prev=0;
 reg [N-1:0] start=0, meta_valid=0, in_valid=0, out_ready=0;
 reg [N*8-1:0] x_scale=0, w_scale=0; reg [N*16-1:0] x_codes=0, w_codes=0;
 wire [N-1:0] start_ready, meta_ready, in_ready, out_valid, invalid, out_of_contract, inexact, rc_pending;
 wire [N*W-1:0] out_int; wire [N*10-1:0] out_exp; wire [N*IDW-1:0] out_id;
 wire ret_valid; reg ret_ready=0; wire [CW-1:0] ret_core; wire [IDW-1:0] ret_id; wire signed [WH-1:0] ret_int; wire signed [9:0] ret_exp; wire ret_out_of_contract;
 wire [QW-1:0] queue_count;
 mxsys_top #(.N(N),.K(K),.F(F),.D_MAX(DMAX),.Q(Q),.ID_W(IDW)) dut(.*);
 // hierarchical probes (constant generate indices)
 wire [N-1:0] c_outdone, c_rcdone; wire [N*3-1:0] c_state;
 genvar gc;
 generate for (gc=0; gc<N; gc=gc+1) begin: probe
   assign c_outdone[gc] = dut.cores[gc].core.out_done;
   assign c_rcdone[gc] = dut.cores[gc].core.rc_done;
   assign c_state[gc*3+:3] = dut.cores[gc].core.state;
 end endgenerate
 // reset plan
 integer reset_r [0:NR-1]; integer reset_l [0:NR-1];
 initial begin
@RESETS@
 end
 function rst_at(input integer t); integer i; begin rst_at=0; for(i=0;i<NR;i=i+1) if(t>=reset_r[i] && t<reset_r[i]+reset_l[i]) rst_at=1; end endfunction
 // masks
 integer mfile, mrc; reg [MB-1:0] mrow=0, nrow=0;
 // transaction files and driver state
 integer tfile [0:N-1]; integer d_idx [0:N-1], d_phase [0:N-1], d_g [0:N-1], d_i [0:N-1]; integer d_arr [0:N-1];
 reg [8*B-1:0] t_xs [0:N-1], t_ws [0:N-1]; reg [4*K-1:0] t_xc [0:N-1], t_wc [0:N-1];
 reg [W-1:0] t_t [0:N-1]; integer t_e [0:N-1], t_bad [0:N-1], t_inex [0:N-1], t_ooc [0:N-1], t_bound [0:N-1], t_ord [0:N-1], t_spread [0:N-1]; reg [WH-1:0] t_et [0:N-1]; integer t_ee [0:N-1];
 // the transaction currently inside each core (accepted start, not yet left OUT)
 reg k_valid [0:N-1]; integer e_id [0:N-1], k_id [0:N-1]; integer k_ord [0:N-1], k_bad [0:N-1], k_inex [0:N-1], k_ooc [0:N-1], k_bound [0:N-1], k_e [0:N-1], k_ee [0:N-1]; reg [W-1:0] k_t [0:N-1]; reg [WH-1:0] k_et [0:N-1];
 // pending returns per core (FIFO in enqueue order)
 integer p_head [0:N-1], p_tail [0:N-1]; integer p_ord [0:N*PD-1], p_id [0:N*PD-1], p_ooc [0:N*PD-1], p_ee [0:N*PD-1]; reg [WH-1:0] p_et [0:N*PD-1];
 integer trace, cyc=0, epoch=0, c, j, idx, stall, pend_total=0;
 integer t_start=0, t_done=0, t_enq=0, t_pop=0, t_ret=0, t_ooc_n=0, t_abort=0, t_resets=0, qpeak=0, errors=0;
 reg [N-1:0] s_hs, m_hs, d_hs, o_hs, r_hs, grant_s, leave; reg pop_s, ret_hs_s, all_done, space_s; reg [2:0] mstate_s; reg [43:0] cw;
 reg [8*B-1:0] rxs, rws; reg [4*K-1:0] rxc, rwc; reg [W-1:0] rt; integer re, rbad, rinex, rooc, rbound, rord, rarr, rspread, rrc; reg [WH-1:0] ret_; integer ree;
 task load_row(input integer cc);
   begin
     rrc = $fscanf(tfile[cc], "%d %d %d %d %d %d %h %h %h %h %h %d %d %h %d\n", rord, rarr, rbad, rinex, rooc, rspread, rxs, rws, rxc, rwc, rt, re, rbound, ret_, ree);
     if (rrc == 15) begin
       t_ord[cc]=rord; d_arr[cc]=rarr; t_bad[cc]=rbad; t_inex[cc]=rinex; t_ooc[cc]=rooc; t_spread[cc]=rspread; t_xs[cc]=rxs; t_ws[cc]=rws; t_xc[cc]=rxc; t_wc[cc]=rwc;
       t_t[cc]=rt; t_e[cc]=re; t_bound[cc]=rbound; t_et[cc]=ret_; t_ee[cc]=ree; d_phase[cc]=PH_START;
       if (rord != d_idx[cc]) begin $display("ERROR: core %0d row ordinal %0d expected %0d", cc, rord, d_idx[cc]); errors=errors+1; end
     end else begin
       if (rrc > 0) begin $display("ERROR: core %0d short row (%0d fields)", cc, rrc); errors=errors+1; end
       d_phase[cc]=PH_DONE;
     end
   end
 endtask
 initial begin
   mfile=$fopen("@MASKS@","r"); if(mfile==0) $fatal(1,"missing masks");
   mrc=$fscanf(mfile,"%h\n",mrow); if(mrc!=1) $fatal(1,"empty mask file");
   trace=$fopen("@TRACE@","w"); if(trace==0) $fatal(1,"cannot open trace");
   $fwrite(trace,"cycle,rst,epoch,qcount,space,grant,enq,pop,mstate,ret_valid,ret_ready,ret_hs,ret_core,ret_id,ret_ooc");
   for(c=0;c<N;c=c+1) $fwrite(trace,",c%0d",c);
   $fwrite(trace,"\n");
   for(c=0;c<N;c=c+1) begin
     tfile[c]=$fopen($sformatf("@TXDIR@/tx_c%0d.txt",c),"r"); if(tfile[c]==0) $fatal(1,"missing tx file");
     d_idx[c]=0; d_g[c]=0; d_i[c]=0; d_arr[c]=0; k_valid[c]=0; e_id[c]=0; k_id[c]=0; p_head[c]=0; p_tail[c]=0; load_row(c);
   end
   rst = rst_at(0); rst_prev = 0;
 end
 always @(posedge clk) begin
   // ---------- pre-edge sampling (cycle `cyc`)
   grant_s = rst ? {N{1'b0}} : dut.grant; pop_s = rst ? 1'b0 : dut.pop; space_s = (cyc==0) ? 1'b1 : dut.space; mstate_s = (cyc==0) ? 3'd0 : dut.merge.state;
   ret_hs_s = !rst && ret_valid && ret_ready;
   for(c=0;c<N;c=c+1) begin
     s_hs[c] = !rst && start[c] && start_ready[c];
     m_hs[c] = !rst && meta_valid[c] && meta_ready[c];
     d_hs[c] = !rst && in_valid[c] && in_ready[c];
     o_hs[c] = !rst && out_valid[c] && out_ready[c];
     r_hs[c] = !rst && rc_pending[c] && grant_s[c];
     leave[c] = !rst && (c_state[c*3+:3]==OUT) && (o_hs[c] || c_outdone[c]) && (!(inexact[c] && !invalid[c]) || r_hs[c] || c_rcdone[c]);
   end
   if (cyc>0 && queue_count>qpeak) qpeak=queue_count;
   all_done = (cyc>0) && (queue_count==0) && (mstate_s==0) && !ret_valid && (rc_pending==0) && !rst;
   for(c=0;c<N;c=c+1) if (d_phase[c]!=PH_DONE || k_valid[c] || p_head[c]!=p_tail[c]) all_done=0;
   // ---------- trace row
   $fwrite(trace,"%0d,%0d,%0d,%0d,%0d,%h,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d", cyc, rst, epoch, (cyc==0)?0:queue_count, space_s, grant_s, |grant_s, pop_s, mstate_s,
           (cyc==0)?0:ret_valid, ret_ready, ret_hs_s, (cyc==0)?0:ret_core, (cyc==0)?0:ret_id, (cyc==0)?0:ret_out_of_contract);
   for(c=0;c<N;c=c+1) begin
     stall = 0;
     if (!rst) begin
       if ((d_phase[c]==PH_START && cyc>=d_arr[c] && !mrow[1+4*c]) || (d_phase[c]==PH_META && !mrow[2+4*c]) || (d_phase[c]==PH_DATA && !mrow[3+4*c])) stall = stall | 1;
       if (start[c] && !start_ready[c]) stall = stall | 2;
       if (out_valid[c] && !out_ready[c]) stall = stall | 4;
       if (rc_pending[c] && !space_s) stall = stall | 8;
       if (rc_pending[c] && space_s && !grant_s[c]) stall = stall | 16;
       if (d_phase[c]==PH_START && cyc<d_arr[c]) stall = stall | 32;
     end
     cw = {stall[5:0], (cyc==0)?1'b0:inexact[c], r_hs[c], (cyc==0)?1'b0:rc_pending[c], o_hs[c], out_ready[c], (cyc==0)?1'b0:out_valid[c], d_hs[c], m_hs[c], s_hs[c], start[c],
           (cyc==0)?3'd0:c_state[c*3+:3], (cyc==0)?8'd0:out_id[c*IDW+:IDW], d_idx[c][15:0]};
     $fwrite(trace,",%011h", cw);
   end
   $fwrite(trace,"\n");
   if (all_done) begin
     $display("PERF_RTL_DONE cycles=%0d starts=%0d completed=%0d enq=%0d pop=%0d returns=%0d ooc=%0d aborted=%0d resets=%0d qpeak=%0d epochs=%0d errors=%0d",
              cyc+1, t_start, t_done, t_enq, t_pop, t_ret, t_ooc_n, t_abort, t_resets, qpeak, epoch+1, errors);
     $fclose(trace); $finish;
   end
   if (cyc+1 >= MAXCYC) $fatal(1, "mask file exhausted at cycle %0d (run did not finish)", cyc);
   // ---------- state update at this edge
   if (rst) begin
     if (!rst_prev && cyc>0) begin
       // first edge of a mid-run reset pulse: abort everything accepted and not complete
       epoch = epoch + 1; t_resets = t_resets + 1;
       for(c=0;c<N;c=c+1) begin
         if (k_valid[c]) begin t_abort = t_abort + 1; k_valid[c]=0; end
         e_id[c]=0;
         t_abort = t_abort + (p_tail[c]-p_head[c]); p_head[c]=0; p_tail[c]=0;
         if (d_phase[c]==PH_META || d_phase[c]==PH_DATA || d_phase[c]==PH_WAIT) begin d_idx[c]=d_idx[c]+1; load_row(c); end
       end
     end
   end else begin
     t_enq = t_enq + (|grant_s); t_pop = t_pop + pop_s;
     if (ret_hs_s) begin
       t_ret = t_ret + 1; t_ooc_n = t_ooc_n + ret_out_of_contract;
       c = ret_core;
       if (p_head[c]==p_tail[c]) begin $display("ERROR: unexpected return core=%0d id=%0d cycle=%0d", ret_core, ret_id, cyc); errors=errors+1; end
       else begin
         idx = c*PD + (p_head[c] % PD);
         if (p_id[idx]!==ret_id) begin $display("ERROR: return id mismatch core=%0d got %0d expected %0d (ordinal %0d) cycle=%0d", c, ret_id, p_id[idx], p_ord[idx], cyc); errors=errors+1; end
         if (ret_out_of_contract!==p_ooc[idx][0] || (!p_ooc[idx] && (ret_int!==$signed(p_et[idx]) || $signed(ret_exp)!=p_ee[idx])))
           begin $display("ERROR: return value mismatch core=%0d ordinal=%0d got T=%0d E=%0d ooc=%0d expected T=%0d E=%0d ooc=%0d", c, p_ord[idx], $signed(ret_int), $signed(ret_exp), ret_out_of_contract, $signed(p_et[idx]), p_ee[idx], p_ooc[idx]); errors=errors+1; end
         p_head[c] = p_head[c] + 1; t_done = t_done + 1;
       end
     end
     for(c=0;c<N;c=c+1) begin
       case (d_phase[c])
         PH_START: if (s_hs[c]) begin
           d_phase[c]=PH_META; d_g[c]=0; t_start=t_start+1; k_id[c]=e_id[c]; e_id[c]=(e_id[c]+1)%256;
           k_valid[c]=1; k_ord[c]=t_ord[c]; k_bad[c]=t_bad[c]; k_inex[c]=t_inex[c]; k_ooc[c]=t_ooc[c]; k_bound[c]=t_bound[c]; k_t[c]=t_t[c]; k_e[c]=t_e[c]; k_et[c]=t_et[c]; k_ee[c]=t_ee[c];
         end
         PH_META: if (m_hs[c]) begin d_g[c]=d_g[c]+1; if (d_g[c]==B) begin d_phase[c]=PH_DATA; d_i[c]=0; end end
         PH_DATA: if (d_hs[c]) begin d_i[c]=d_i[c]+1; if (d_i[c]==8*B) d_phase[c]=PH_WAIT; end
         PH_WAIT: if (o_hs[c]) begin
           if (out_int[c*W+:W]!==k_t[c] || $signed(out_exp[c*10+:10])!=k_e[c] || invalid[c]!==k_bad[c][0] || out_of_contract[c]!==k_bound[c][0] || inexact[c]!==k_inex[c][0] || out_id[c*IDW+:IDW]!==k_id[c][7:0])
             begin $display("ERROR: core %0d ordinal %0d result mismatch: T=%0d E=%0d inv=%0d ooc=%0d inexact=%0d id=%0d expected T=%0d E=%0d inv=%0d inexact=%0d", c, k_ord[c], $signed(out_int[c*W+:W]), $signed(out_exp[c*10+:10]), invalid[c], out_of_contract[c], inexact[c], out_id[c*IDW+:IDW], $signed(k_t[c]), k_e[c], k_bad[c], k_inex[c]); errors=errors+1; end
           if (!(k_inex[c] && !k_bad[c])) t_done=t_done+1;
           d_idx[c]=d_idx[c]+1; load_row(c);
         end
       endcase
       if (r_hs[c]) begin
         idx = c*PD + (p_tail[c] % PD);
         if (p_tail[c]-p_head[c] >= PD) begin $display("ERROR: pending FIFO overflow core %0d", c); errors=errors+1; end
         p_ord[idx]=k_ord[c]; p_id[idx]=out_id[c*IDW+:IDW]; p_ooc[idx]=k_ooc[c]; p_et[idx]=k_et[c]; p_ee[idx]=k_ee[c]; p_tail[c]=p_tail[c]+1;
       end
       if (leave[c]) k_valid[c]=0;
     end
   end
   // ---------- outputs for cycle cyc+1
   mrc=$fscanf(mfile,"%h\n",nrow); if(mrc!=1) $fatal(1,"mask file exhausted at cycle %0d", cyc+1);
   rst_prev <= rst; rst <= rst_at(cyc+1);
   ret_ready <= nrow[0] && !rst_at(cyc+1);
   for(c=0;c<N;c=c+1) begin
     start[c] <= (d_phase[c]==PH_START) && (cyc+1>=d_arr[c]) && nrow[1+4*c] && !rst_at(cyc+1);
     meta_valid[c] <= (d_phase[c]==PH_META) && nrow[2+4*c] && !rst_at(cyc+1);
     x_scale[c*8+:8] <= t_xs[c][d_g[c]*8+:8]; w_scale[c*8+:8] <= t_ws[c][d_g[c]*8+:8];
     in_valid[c] <= (d_phase[c]==PH_DATA) && nrow[3+4*c] && !rst_at(cyc+1);
     x_codes[c*16+:16] <= t_xc[c][d_i[c]*16+:16]; w_codes[c*16+:16] <= t_wc[c][d_i[c]*16+:16];
     out_ready[c] <= (d_phase[c]==PH_WAIT) && nrow[4+4*c] && !rst_at(cyc+1);
   end
   mrow <= nrow; cyc <= cyc + 1;
 end
 initial begin #4000000000; $fatal(1,"timeout"); end
endmodule
'''


def run_rtl(root, case_dir, out_dir, timeout=3600):
    """Compile and run the trace testbench on one case; returns the RTL summary dict (trace at out_dir/cycles_rtl.csv)."""
    root = Path(root); case_dir = Path(case_dir).resolve(); out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    man = json.loads((case_dir / 'manifest.json').read_text()); p = man['params']
    if not man.get('rtl_consumable', True): raise ValueError('case is not RTL-consumable (light transaction rows)')
    resets = man['resets']
    lines = '\n'.join(f'   reset_r[{i}]={r}; reset_l[{i}]={l};' for i, (r, l) in enumerate(resets))
    tb = TB
    for key, val in [('N', p['n']), ('K', p['k']), ('F', p['f']), ('W', p['w']), ('WH', p['w_h']), ('DMAX', p['dmax']), ('Q', p['q']), ('CW', p['core_w']),
                     ('QW', p['q'].bit_length()), ('NR', len(resets)), ('MAXCYC', man['max_cycles']), ('RESETS', lines),
                     ('MASKS', (case_dir / 'masks.txt').as_posix()), ('TXDIR', case_dir.as_posix()), ('TRACE', (out_dir.resolve() / 'cycles_rtl.csv').as_posix())]:
        tb = tb.replace('@' + key + '@', str(val))
    (out_dir / 'tb.sv').write_text(tb)
    exe = shutil.which('iverilog'); vvp = shutil.which('vvp')
    if not exe or not vvp: raise RuntimeError('Icarus Verilog (iverilog/vvp) is required for the RTL trace run')
    srcs = [str((root / f).resolve()) for f in RTL_FILES]
    cp = subprocess.run([exe, '-g2012', '-s', 'tb', '-o', 'sim.vvp'] + srcs + ['tb.sv'], cwd=out_dir, text=True, capture_output=True)
    (out_dir / 'compile.log').write_text(cp.stdout + cp.stderr)
    if cp.returncode: raise RuntimeError('iverilog failed:\n' + (cp.stdout + cp.stderr)[-3000:])
    run = subprocess.run([vvp, 'sim.vvp'], cwd=out_dir, text=True, capture_output=True, timeout=timeout)
    (out_dir / 'simulation.log').write_text(run.stdout + run.stderr)
    m = re.search(r'PERF_RTL_DONE cycles=(\d+) starts=(\d+) completed=(\d+) enq=(\d+) pop=(\d+) returns=(\d+) ooc=(\d+) aborted=(\d+) resets=(\d+) qpeak=(\d+) epochs=(\d+) errors=(\d+)', run.stdout)
    if run.returncode or not m: raise RuntimeError('RTL run failed:\n' + (run.stdout + run.stderr)[-3000:])
    keys = ['cycles', 'starts', 'completed', 'enqueues', 'pops', 'returns', 'ooc_returns', 'aborted', 'resets', 'queue_peak', 'epochs', 'value_errors']
    summary = {k: int(v) for k, v in zip(keys, m.groups())}
    summary.update({'status': 'pass' if summary['value_errors'] == 0 else 'fail', 'simulator': 'icarus',
                    'iverilog_version': subprocess.run([exe, '-V'], text=True, capture_output=True).stdout.splitlines()[0],
                    'rtl_sha256': {f: hashlib.sha256((root / f).read_bytes()).hexdigest() for f in RTL_FILES},
                    'tb_sha256': hashlib.sha256(tb.encode()).hexdigest(), 'trace': str(out_dir / 'cycles_rtl.csv')})
    (out_dir / 'summary_rtl.json').write_text(json.dumps(summary, indent=1))
    return summary
