"""Design-point explorer: evaluate ONE point a reader picks from the notebook menus (section 2.5).

The explorer does not choose anything. It takes an architecture, F, N, Q, issue order and workload, and
evaluates that point with the same rules the selectors use -- `mxacc.experiment.choose_hardware` for a single
core, `mxacc.qualify.system_candidates` / `choose_system` for N-core tops -- and labels where every number
comes from:

  error   computed now on the calibration split with the bit-exact integer model
  area    imported routed/synthesis records (hash-checked by `load_implementations`, results/system/study.json),
          with the same area-source labels as the system selector
  timing  core records (setup/hold, II0) and, for the recompute path, the C++ performance model: a cached
          row of results/perf/study.json when that record is current, otherwise a live run in this runtime

The test split is not read unless `reveal_test=True`; then its numbers are reported for the point as given,
never used to change it.
"""
from pathlib import Path
import json, shutil
import numpy as np
from .arithmetic import CANDIDATES, quantize, groups, exact, accumulate, exact_difference, as_float, metrics, width
from .recompute import inexact_flags
from .workloads import load_workload
from .qualify import system_candidates, choose_system, VALIDATED_CONFIGS, D_MAX

ARCHITECTURES = {'single core, fixed F': 'single', 'N cores, fixed F': 'fixed_top', 'N low-F cores + selective recompute': 'recompute'}
ORDERINGS = ('original', 'shuffled', 'burst')
LANES = 4
SEED = 20261018


def _split_numerics(x, w, f, f_values=CANDIDATES, dmax=D_MAX):
    """Bit-exact error of every candidate F on one split, and the recompute view at the chosen F."""
    xc, xs, _ = quantize(x); wc, ws, _ = quantize(w); g = groups(xc, xs, wc, ws); gold = exact(g)
    rows = [metrics(g, ff, gold) for ff in sorted(set(f_values) | {f})]
    t, eo = accumulate(g, f); err = exact_difference(t, eo, *gold); ref = as_float(*gold)
    denom = max(float(np.linalg.norm(ref)), 1e-12)
    flag = inexact_flags(g, f)
    spread_tx = g.exponents.max(axis=-1) - g.exponents.min(axis=-1)     # all blocks, as the contract check of choose_system
    ooc = flag & (spread_tx > dmax)                                      # flagged records the D_MAX merge returns out_of_contract
    residual = np.where(flag & ~ooc, 0.0, err)
    me = next(r for r in rows if r['f'] == f)
    return {'rows': rows, 'nrmse': me['nrmse'], 'max_abs': me['max_abs'], 'max_bound': me['max_bound'], 'w': me['w'],
            'transactions': int(flag.size), 'flagged_fraction': float(flag.mean()), 'spread_max': int(spread_tx.max()),
            'ooc_fraction': float(ooc.mean()), 'nrmse_after_recompute': float(np.linalg.norm(residual) / denom)}


def _thresholds():
    from .perf_stimulus import threshold
    return {k: threshold(1.0) for k in ('ret', 'start', 'meta', 'data', 'out')}


def _live_rows(root, scratch, exe, workload, f, n, q, orderings, tx_per_core, log=None):
    """C++ model on the calibration split (saturated input), same window and loss rules as scripts/run_perf_study.py."""
    from .perf_stimulus import real_case
    from .perf_backend import run_generated
    wl = load_workload(root, workload); total = len(wl['x_cal']) * wl['outputs']
    per = max(1, min(int(tx_per_core), total // n)); sat = _thresholds(); tag = Path(str(workload)).name
    rows = []; ref = None
    for ordering in dict.fromkeys(('original',) + tuple(orderings)):
        d = Path(scratch) / f'X_{tag}_f{f}_{ordering}_n{n}_t{per}'
        if not (d / 'manifest.json').exists():
            if log: log(f'   building {ordering} stimulus: {n} cores x {per} transactions ...')
            real_case(root, d, workload, n, 1, f, tx_per_core=per, split='calibration', ordering=ordering, name=d.name, light=True)
        man = json.loads((d / 'manifest.json').read_text())
        p = dict(man['params']); p['q'] = q; per_core = max(man['stats']['per_core']); ii0 = p['ii0']; t_nom = per_core * ii0
        window = (min(1000, t_nom // 10), int(0.9 * t_nom)); max_cycles = int(t_nom * 1.5 + n * per_core * p['s0'] + 5000)
        s = run_generated(root, d, Path(scratch) / f'run_{d.name}_q{q}', p, SEED, sat, max_cycles, window=window, exe=exe)
        if ref is None:   # no-flag twin: same rows with every flag forced to 0 -> throughput reference for the recompute loss
            twin = Path(scratch) / f'{d.name}_noflags'
            if not (twin / 'tx_c0.txt').exists():
                twin.mkdir(parents=True, exist_ok=True)
                for c in range(n):
                    lines = []
                    for l in (d / f'tx_c{c}.txt').read_text().splitlines():
                        parts = l.split()
                        if parts: parts[3] = '0'; parts[4] = '0'; lines.append(' '.join(parts))
                    (twin / f'tx_c{c}.txt').write_text('\n'.join(lines) + '\n')
            pt = dict(p); pt['q'] = 1
            ref = run_generated(root, twin, Path(scratch) / f'run_{twin.name}', pt, SEED, sat, max_cycles, window=window, exe=exe)['window']['useful_throughput_per_cycle']
        win = s['window']; lat = win['recompute_latency']; flagged = man['stats']['flagged']; txs = man['stats']['transactions']
        rows.append({'workload': str(workload), 'f': f, 'split': 'calibration', 'ordering': ordering, 'n': n, 'q': q, 'masks': 'saturated',
                     'transactions': txs, 'tx_per_core': per, 'flagged': flagged, 'flagged_fraction': flagged / max(1, txs),
                     'rho0': n * (flagged / max(1, txs)) * p['s0'] / ii0, 'rc_p50': lat['p50'], 'rc_p99': lat['p99'], 'rc_count': lat['count'],
                     'throughput_loss_pct': max(0.0, 100 * (1 - win['useful_throughput_per_cycle'] / ref)) if ref else None,
                     'throughput_loss_vs_ideal_pct': 100 * (1 - win['useful_throughput_per_cycle'] / (n / ii0)),
                     'queue_peak': s['queue']['peak'], 'merge_busy_fraction': s['merge']['compute_busy_fraction'], 'ooc_returns': s['counts']['ooc_returns'],
                     'traffic_bits': s['traffic_bits'], 'source': 'live C++ run (this runtime)', 'status': s['status']})
    return rows


def _scope(n, q, k):
    if k != 128: return f'architecture exploration prediction (K{k}: the RTL-validated grid is K128)'
    return 'RTL-validated (N,Q)' if (n, q) in VALIDATED_CONFIGS else 'architecture exploration prediction (C++ model outside the RTL-validated set)'


def design_point(root, architecture, f, n=4, q=2, ordering='original', workload='mnist_relu_fc2', budget=1e-3, clock_ns=50.0,
                 min_rate=1e5, max_p99=200, ooc_policy='reject', run_cpp=True, tx_per_core=4096, scratch=None, exe=None,
                 reveal_test=False, log=None):
    """Evaluate one point; returns a card (dict) whose every number carries its source label."""
    from .implementation import load_implementations
    from .experiment import choose_hardware
    from .provenance import compare_sources
    root = Path(root); arch = ARCHITECTURES.get(architecture, architecture)
    if arch not in ARCHITECTURES.values(): raise ValueError(f'architecture must be one of {list(ARCHITECTURES)}')
    if ordering not in ORDERINGS: raise ValueError(f'ordering must be one of {ORDERINGS}')
    f, n, q = int(f), int(n), int(q)
    if arch == 'single': n = 1
    if arch == 'fixed_top' and n == 1: arch = 'single'
    wl = load_workload(root, workload); wid = wl.get('id') or Path(str(workload)).name; k = wl['k']; b = k // 32; ii0 = 9 * b + 4
    cal = _split_numerics(wl['x_cal'], wl['w'], f)
    numeric = {'workload': wid, 'k': k, 'lanes': LANES, 'tolerance': budget, 'calibration': cal['rows'],
               'feasible_f': [r['f'] for r in cal['rows'] if r['nrmse'] <= budget]}
    imp = load_implementations(root)
    hw = choose_hardware(numeric, imp['costs'], clock_ns, min_rate)
    core = next((c for c in hw['costs'] if c['f'] == f), None)
    sel = hw['selected_f']; sel_core = next((c for c in hw['costs'] if c['f'] == sel), None) if sel is not None else None
    sysst = json.loads((root / 'results/system/study.json').read_text())
    req = {'clock_period_ns': clock_ns, 'min_dot_products_per_s': min_rate, 'max_p99_latency_cycles': max_p99, 'ooc_policy': ooc_policy, 'ii0': ii0}
    rc_entry = {'per_f': [{'f': f, 'cal_nrmse_after_strict_recompute': cal['nrmse_after_recompute'], 'cal_flagged_fraction': cal['flagged_fraction']}]}

    # ---- timing rows for the recompute path: cached study row (current record only) or a live C++ run
    perf_rows, timing_src, p99_curve, notes = [], None, [], []
    study_p = root / 'results/perf/study.json'
    study = json.loads(study_p.read_text()) if study_p.exists() else None
    study_current = bool(study) and compare_sources(root, study.get('source_sha256'))[0]
    if arch == 'recompute':
        if study_current:
            mine = [r for r in study['rows'] if r['workload'] == wid and r['f'] == f and r['n'] == n and r['masks'] == 'saturated' and r.get('split', 'calibration') == 'calibration']
            if any(r['q'] == q and r['ordering'] == 'original' for r in mine):
                perf_rows = mine; timing_src = 'cached study.json row (CURRENT; calibration split, all transactions)'
                p99_curve = sorted((r['q'], r['rc_p99'], r['rc_count'], _scope(n, r['q'], k).startswith('RTL')) for r in mine if r['ordering'] == ordering)
        elif study:
            notes.append('results/perf/study.json is STALE (its sources changed): cached timing rows are not used')
        if not perf_rows and run_cpp:
            from .perf_backend import find_binary
            try:
                exe = exe or find_binary(root, log=log or (lambda *a: None))
            except Exception as e:      # noqa: BLE001 - reported, never replaced by a Python fallback
                notes.append(f'C++ model unavailable ({e}); timing not evaluated')
            else:
                scratch = Path(scratch or root / 'results/notebook_perf/explore'); scratch.mkdir(parents=True, exist_ok=True)
                perf_rows = _live_rows(root, scratch, exe, workload, f, n, q, (ordering,), tx_per_core, log=log)
                timing_src = f"live C++ run in this runtime (calibration split, {perf_rows[0]['tx_per_core']} transactions per core)"
                p99_curve = [(r['q'], r['rc_p99'], r['rc_count'], _scope(n, r['q'], k).startswith('RTL')) for r in perf_rows if r['ordering'] == ordering]
        if not perf_rows and not run_cpp: notes.append('no cached timing row for this point and live C++ runs are off: timing not evaluated')

    # ---- candidates: the selector's single core first (the reference), then the reader's point under each architecture
    ref = system_candidates(wid, f, sysst, perf_rows, hw, rc_entry, numeric, ns=(n,), qs=(q,))                  # [selector's single core, ..., recompute F N Q]
    yours = system_candidates(wid, f, sysst, [], dict(hw, selected_f=f), rc_entry, numeric, ns=(n,) if n > 1 else (), qs=())   # [single core F, fixed F x N]
    cands = [ref[0]] + [c for c in yours if c['mode'] == 'fixed_f_top'] + [c for c in ref if c['mode'] == 'recompute']
    for c in cands:
        if c['mode'] == 'recompute': c['validation_scope'] = _scope(n, q, k)
        if k != 128 and c['mode'] in ('fixed_f_top', 'recompute'):
            c.update(area_um2=None, area_per_core_um2=None, area_source='unknown', qualification='unknown',
                     qualification_reasons=[f'no K{k} system implementation record (routed system evidence is K128 only)'])
    spread_cal = cal['spread_max']
    dec = choose_system(cands, budget, req, calibration_spread_max=spread_cal)
    rows = {r['id']: r for r in dec['candidates']}

    # ---- the reader's point
    core_src = {'post_route': 'measured_single_core', 'post_synthesis': 'synthesis_only'}.get((core or {}).get('stage'), 'unknown')
    core_phys = [x for x in (core or {}).get('qualification_reasons', ['no implementation record']) if not (x.startswith('calibration ') and 'error exceeds' in x)]
    core_qual = 'unknown' if core_src != 'measured_single_core' else ('pass' if not core_phys else 'fail')   # physical only; the budget is judged under ERROR
    if arch == 'single':
        point_id = f'single_core_F{f}'; area_pc = (core or {}).get('cell_area_um2'); area_src = core_src; qual = core_qual
        eligible = bool((core or {}).get('eligible')); reasons = list((core or {}).get('qualification_reasons', ['no implementation record']))
        point_row = {'qualification_reasons': core_phys}
    else:
        point_id = f'fixed_F{f}_N{n}' if arch == 'fixed_top' else f'recompute_F{f}_N{n}_Q{q}'
        point_row = rows[point_id]
        area_pc = point_row['area_per_core_um2']; area_src = point_row['area_source']; qual = point_row['qualification']
        eligible = point_row['survives_strict']; reasons = list(point_row['eliminated_by'])

    bars = [{'label': f'single core F{f}', 'per_core_um2': (core or {}).get('cell_area_um2'), 'source': core_src, 'qualification': core_qual, 'chosen': arch == 'single'}]
    for label, cid, a_ in ((f'{n} x fixed F{f}', f'fixed_F{f}_N{n}', 'fixed_top'), (f'recompute F{f}, N{n}, Q{q}', f'recompute_F{f}_N{n}_Q{q}', 'recompute')):
        x = rows.get(cid)
        if x and n > 1 or (x and a_ == 'recompute' == arch):
            bars.append({'label': label, 'per_core_um2': x['area_per_core_um2'], 'source': x['area_source'], 'qualification': x['qualification'], 'chosen': arch == a_})

    timing = {'ii0_cycles': ii0, 'clock_ns': clock_ns, 'rate_per_core_dot_s': 1e9 / clock_ns / ii0,
              'core_setup_wns_ns': (core or {}).get('setup_wns_ns'), 'core_hold_wns_ns': (core or {}).get('hold_wns_ns'),
              'core_record_clock_ns': (core or {}).get('clock_period_ns'), 'source': 'core implementation record + contract II0 = 9B+4'}
    if arch == 'recompute':
        pr = next((r for r in perf_rows if r['q'] == q and r['ordering'] == ordering), None)
        timing.update({'source': timing_src or 'not evaluated', 'validation_scope': _scope(n, q, k), 'ordering': ordering,
                       'p99_cycles': None if pr is None else pr['rc_p99'], 'p99_samples': None if pr is None else pr['rc_count'],
                       'p50_cycles': None if pr is None else pr.get('rc_p50'), 'throughput_loss_pct': None if pr is None else pr.get('throughput_loss_pct'),
                       'queue_peak': None if pr is None else pr.get('queue_peak'), 'rho0': None if pr is None else pr.get('rho0'),
                       'p99_vs_q': p99_curve, 'selector_uses': 'original order (the reader may inspect another order; the selector does not)'})
    rate = n * timing['rate_per_core_dot_s'] * (1 - (timing.get('throughput_loss_pct') or 0) / 100)
    timing['rate_dot_s'] = rate

    card = {'point': {'architecture': [kname for kname, v in ARCHITECTURES.items() if v == arch][0], 'arch': arch, 'id': point_id, 'workload': wid,
                      'k': k, 'b': b, 'f': f, 'w': width(k, f), 'n': n, 'q': q if arch == 'recompute' else None, 'ordering': ordering if arch == 'recompute' else None},
            'requirements': {'budget': budget, **req},
            'error': {'source': 'computed now: calibration split, bit-exact integer model', 'rows': [{'f': r['f'], 'nrmse': r['nrmse']} for r in cal['rows']],
                      'nrmse': cal['nrmse'], 'max_abs': cal['max_abs'], 'max_bound': cal['max_bound'], 'meets_budget': cal['nrmse'] <= budget,
                      'transactions': cal['transactions'], 'flagged_fraction': cal['flagged_fraction'], 'spread_max': spread_cal, 'd_max': D_MAX,
                      'ooc_fraction': cal['ooc_fraction'], 'nrmse_after_recompute': cal['nrmse_after_recompute'] if arch == 'recompute' else None},
            'area': {'per_core_um2': area_pc, 'total_um2': None if area_pc is None else area_pc * n, 'source': area_src, 'qualification': qual,
                     'bars': bars, 'reasons_from_record': point_row.get('qualification_reasons', [])},
            'timing': timing,
            'verdict': {'eligible': bool(eligible), 'reasons': reasons, 'rule': dec['strict_rule'] if arch != 'single' else 'choose_hardware: budget -> matching routed record -> provenance -> clock/setup/hold -> slew/cap -> rate -> RTL -> DRC/LVS',
                        'selector_single_core': None if sel is None else {'f': sel, 'area_um2': (sel_core or {}).get('cell_area_um2')},
                        'selector_status': hw['status']},
            'test': None, 'notes': notes}
    if reveal_test:
        tst = _split_numerics(wl['x_test'], wl['w'], f)
        card['test'] = {'source': 'test split, read after the point was fixed (reported, not used to change it)', 'nrmse': tst['nrmse'], 'meets_budget': tst['nrmse'] <= budget,
                        'flagged_fraction': tst['flagged_fraction'], 'spread_max': tst['spread_max'],
                        'nrmse_after_recompute': tst['nrmse_after_recompute'] if arch == 'recompute' else None, 'within_contract': tst['spread_max'] <= D_MAX}
    return card


def _fmt(v, spec=',.0f', none='-'):
    return none if v is None else format(v, spec)


def format_card(card):
    """Plain-text card: one line per number, each with its source label."""
    p, e, a, t, v, r = card['point'], card['error'], card['area'], card['timing'], card['verdict'], card['requirements']
    head = f"{p['architecture']}  |  F{p['f']} (W = {p['w']})" + (f"  |  N = {p['n']}" if p['n'] > 1 else '') + (f"  |  Q = {p['q']}, {p['ordering']} order" if p['q'] else '')
    L = [head, f"workload {p['workload']} (K{p['k']}, B = {p['b']})  |  budget {r['budget']:g}, clock {r['clock_period_ns']:g} ns, >= {r['min_dot_products_per_s']:,.0f} dot/s" + (f", P99 <= {r['max_p99_latency_cycles']} cycles, ooc {r['ooc_policy']}" if p['arch'] == 'recompute' else ''), '']
    L.append(f"ERROR   [{e['source']}]")
    L.append(f"  accumulation NRMSE at F{p['f']}        {e['nrmse']:.3g}   (budget {r['budget']:g}: {'meets' if e['meets_budget'] else 'EXCEEDS'})   max |err| {e['max_abs']:.3g}, bound {e['max_bound']:.3g}")
    L.append(f"  inexact-flagged dot products      {100 * e['flagged_fraction']:.4g} % of {e['transactions']:,}   block-exponent spread max {e['spread_max']} (D_MAX = {e['d_max']})")
    if e['nrmse_after_recompute'] is not None:
        L.append(f"  after exact recompute of flagged  {e['nrmse_after_recompute']:.3g}" + (f"   ({100 * e['ooc_fraction']:.3g} % out of contract, left as computed)" if e['ooc_fraction'] else '   (every flagged record within the D_MAX contract)'))
    L.append('')
    L.append(f"AREA    [{a['source']}]")
    L.append(f"  per core {_fmt(a['per_core_um2'])} um2" + (f"   total {_fmt(a['total_um2'])} um2" if p['n'] > 1 else '') + f"   qualification: {a['qualification']}")
    for bar in a['bars']:
        L.append(f"    {'>' if bar['chosen'] else ' '} {bar['label']:28s} {_fmt(bar['per_core_um2']):>9s} um2/core  {bar['source']}, {bar['qualification']}")
    sc = v['selector_single_core']
    if sc: L.append(f"  reference: the single-core selector picks F{sc['f']} ({_fmt(sc['area_um2'])} um2) for these requirements" +
                    (f"; this point is {100 * (a['per_core_um2'] / sc['area_um2'] - 1):+.1f} % per core" if a['per_core_um2'] and sc['area_um2'] else ''))
    else: L.append(f"  reference: the single-core selector finds no qualified core ({v['selector_status']})")
    L.append('')
    L.append(f"TIMING  [{t['source']}]")
    L.append(f"  one result every II0 = 9B+4 = {t['ii0_cycles']} cycles; {t['rate_per_core_dot_s']:,.0f} dot/s per core at {t['clock_ns']:g} ns" +
             (f"; core record: setup WNS {t['core_setup_wns_ns']:+.2f} ns, hold WNS {t['core_hold_wns_ns']:+.2f} ns at {t['core_record_clock_ns']:g} ns" if t['core_setup_wns_ns'] is not None else '; no routed core record'))
    if p['arch'] == 'recompute':
        L.append(f"  scope: {t['validation_scope']}")
        if t['p99_cycles'] is not None:
            L.append(f"  flagged-record P99 latency {t['p99_cycles']} cycles (P50 {t['p50_cycles']}, n = {t['p99_samples']}{', < 1000 samples: demonstration only' if (t['p99_samples'] or 0) < 1000 else ''}), "
                     f"queue peak {t['queue_peak']}, throughput loss vs no-flag twin {t['throughput_loss_pct']:.3f} %, rho0 = {t['rho0']:.3g}")
        elif t['p99_samples'] == 0: L.append('  no flagged record in the measurement window: recompute latency undefined (the selector rule then reports "no performance data")')
        else: L.append('  flagged-record latency: not evaluated')
    L.append(f"  system rate {t['rate_dot_s']:,.0f} dot/s ({p['n']} core{'s' if p['n'] > 1 else ''})")
    L.append('')
    L.append(f"VERDICT [{v['rule']}]")
    L.append('  ' + ('ELIGIBLE under every check' if v['eligible'] else 'NOT ELIGIBLE: ' + ('; '.join(v['reasons'][:4]) or 'see record')))
    if card['test']:
        T = card['test']; L.append(''); L.append(f"TEST    [{T['source']}]")
        L.append(f"  test NRMSE at F{p['f']} {T['nrmse']:.3g} ({'meets' if T['meets_budget'] else 'EXCEEDS'} the budget), flagged {100 * T['flagged_fraction']:.4g} %, spread max {T['spread_max']} ({'within' if T['within_contract'] else 'OUTSIDE'} D_MAX)" +
                 (f", after recompute {T['nrmse_after_recompute']:.3g}" if T['nrmse_after_recompute'] is not None else ''))
    for n_ in card['notes']: L.append('note: ' + n_)
    return '\n'.join(L)
