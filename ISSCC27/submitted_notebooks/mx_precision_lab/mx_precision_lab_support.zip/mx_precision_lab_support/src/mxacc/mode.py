"""Automatic mode decision (superseded by mxacc.qualify): fixed-F core vs low-F core + selective recompute.

Every feasibility input is from the calibration split (flag fraction, error after recompute, cycle sweep);
test-split numbers are copied into `reported_after_freeze` and never read by the decision.

Given the numeric result of a workload, the qualified fixed-F hardware selection, the
measured flag fractions, the measured system costs (per-core area of the recompute
system for N cores) and the cycle-model sweep, pick the cheapest configuration that
meets the error budget, the throughput requirement and the P99 latency limit, and say
why every other candidate lost. Everything is read from measured results; nothing is
estimated inside this function except linear interpolation of the cycle-model loss in
the flagged fraction when the exact workload was not simulated.
"""
import math


def _loss_and_latency(sweep, workload, f, n, q, p):
    """Cycle-model numbers for (workload, F, N, Q); fall back to the nearest flagged fraction at the same N, Q."""
    exact = [s for s in sweep if s['workload'] == workload and s['f'] == f and s['cores'] == n and s['queue_depth'] == q]
    if exact:
        s = exact[0]; return s['throughput_loss_vs_no_flags_pct'], s['latency_p99'], s['merge_utilization'], 'cycle model (this workload)'
    same = sorted([s for s in sweep if s['cores'] == n and s['queue_depth'] == q], key=lambda s: s['flagged_fraction'])
    if not same: return None, None, None, 'no cycle-model data'
    lo = max([s for s in same if s['flagged_fraction'] <= p], key=lambda s: s['flagged_fraction'], default=same[0])
    hi = min([s for s in same if s['flagged_fraction'] >= p], key=lambda s: s['flagged_fraction'], default=same[-1])
    if hi['flagged_fraction'] == lo['flagged_fraction']:
        return lo['throughput_loss_vs_no_flags_pct'], lo['latency_p99'], lo['merge_utilization'], 'cycle model (nearest flagged fraction)'
    w = (p - lo['flagged_fraction']) / (hi['flagged_fraction'] - lo['flagged_fraction'])
    mix = lambda k: lo[k] + w * (hi[k] - lo[k])
    return mix('throughput_loss_vs_no_flags_pct'), mix('latency_p99'), mix('merge_utilization'), 'cycle model (interpolated in flagged fraction)'


def choose_mode(numeric, hardware, recompute_entry, system_study, clock_period_ns, min_rate, max_p99_cycles=None, n_cores=16, queue_depth=2,
                low_fs=(0, 2, 4), ii=None):
    """Return the chosen mode and the full candidate table with reasons."""
    budget = numeric['tolerance']; k = numeric['k']; b = k // 32
    ii = ii or 1 + 9 * b + 3
    rate = 1e9 / clock_period_ns / ii
    candidates = []
    # ---- fixed-F candidate: the qualified hardware selection of the main selector
    sel = hardware.get('selected_f')
    if sel is not None:
        c = next(c for c in hardware['costs'] if c['f'] == sel)
        candidates.append({'mode': 'fixed_f', 'f': sel, 'area_per_core_um2': c['cell_area_um2'], 'area_source': c['stage'],
                           'cal_nrmse': next((r['nrmse'] for r in numeric.get('calibration', []) if r['f'] == sel), None),
                           'reported_after_freeze': {'test_nrmse': hardware['final_test']['test_nrmse'] if hardware.get('final_test') else None},
                           'throughput_dot_per_s': rate, 'throughput_loss_pct': 0.0, 'p99_latency_cycles': 0, 'recompute_fraction': 0.0,
                           'feasible': True, 'reasons': ['qualified routed candidate: budget, timing, electrical, DRC/LVS all met']})
    else:
        candidates.append({'mode': 'fixed_f', 'f': None, 'feasible': False, 'reasons': ['no qualified fixed-F candidate: ' + hardware.get('status', '')]})
    # ---- recompute candidates
    stage = 'post_route' if all(system_study['per_core_cost']['post_route'].get(str(n)) for n in (n_cores,)) else 'synthesis'
    per_f = {r['f']: r for r in recompute_entry['per_f']} if recompute_entry else {}
    sweep = system_study.get('cycle_sweep', [])
    for f in low_fs:
        if f not in per_f: continue
        r = per_f[f]; p = r['cal_flagged_fraction']
        cost = system_study['per_core_cost'][stage].get(str(n_cores))
        reasons = []
        if cost is None:
            candidates.append({'mode': 'recompute', 'f': f, 'feasible': False, 'reasons': [f'no system cost for N={n_cores}']}); continue
        if f != 2:
            # only the F2 system was synthesized/routed; other low F reuse its glue/merge share with their own record-core area when measured
            core = (system_study['components'].get(f'core_f{f}_record') or {}).get(stage)
            if core is None:
                candidates.append({'mode': 'recompute', 'f': f, 'feasible': False, 'reasons': [f'F{f} record core not implemented at this stage']}); continue
            area = core + cost['merge_share'] + (cost['glue_share'] or 0)
        else:
            area = cost['per_core_total']
        loss, p99, util, src = _loss_and_latency(sweep, recompute_entry['id'], f, n_cores, queue_depth, p)
        cal_after = r['cal_nrmse_after_strict_recompute']
        feasible = True
        if cal_after > budget: feasible = False; reasons.append('post-recompute calibration error exceeds the budget')
        if loss is None: feasible = False; reasons.append('no cycle-model data')
        else:
            thr = rate * (1 - loss / 100)
            if thr < min_rate: feasible = False; reasons.append(f'throughput {thr:,.0f} dot/s below the requirement after {loss:.1f} % recompute loss')
            if max_p99_cycles is not None and p99 > max_p99_cycles: feasible = False; reasons.append(f'P99 recompute latency {p99:.0f} cycles exceeds the limit')
            if n_cores * p * (b + 3) / ii >= 1: feasible = False; reasons.append(f'shared merge unit saturated: N*p*(B+3)/II = {n_cores * p * (b + 3) / ii:.2f} >= 1')
        if feasible and sel is not None and area >= candidates[0]['area_per_core_um2']:
            reasons.append(f'feasible but {100 * (area / candidates[0]["area_per_core_um2"] - 1):+.1f} % area per core vs fixed F{sel}: the record store/port and the shared unit cost more than the extra accumulator bits')
        elif feasible: reasons.append('feasible and smaller than the fixed-F candidate')
        candidates.append({'mode': 'recompute', 'f': f, 'n_cores': n_cores, 'queue_depth': queue_depth, 'area_per_core_um2': area, 'area_source': f'{stage} ({cost["source"]})',
                           'cal_nrmse': cal_after, 'recompute_fraction': p, 'reported_after_freeze': {'test_nrmse': r.get('test_nrmse_after_strict_recompute'), 'test_recompute_fraction': r.get('test_flagged_fraction')}, 'throughput_loss_pct': loss, 'throughput_dot_per_s': None if loss is None else rate * (1 - loss / 100),
                           'p99_latency_cycles': p99, 'merge_utilization': util, 'cycle_source': src, 'feasible': feasible, 'reasons': reasons})
    feasible = [c for c in candidates if c.get('feasible')]
    best = min(feasible, key=lambda c: c['area_per_core_um2']) if feasible else None
    return {'workload': numeric.get('workload'), 'budget': budget, 'k': k, 'requirements': {'clock_period_ns': clock_period_ns, 'min_dot_products_per_s': min_rate, 'max_p99_latency_cycles': max_p99_cycles, 'n_cores': n_cores, 'queue_depth': queue_depth},
            'chosen': None if best is None else {k2: best[k2] for k2 in ('mode', 'f', 'area_per_core_um2', 'throughput_dot_per_s', 'p99_latency_cycles', 'recompute_fraction')},
            'candidates': candidates,
            'rule': 'smallest per-core area among candidates that meet the budget (after recompute for the recompute mode), the throughput requirement and the P99 latency limit; costs are measured, not estimated'}
