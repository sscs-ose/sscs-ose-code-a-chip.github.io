"""The project as Section 1 of submission.ipynb unpacks it from mx_precision_lab_support.zip (the support package).

``SUPPORT.json`` at the project root states exactly what the package holds:

  embedded       {path: sha256}  every file of the package (SHA256SUMS lists the same files)
  attested       {path: sha256}  the historical record: evidence files that are not in the package (final layout views, the
                                 raw reports of the routed runs other than F2 and F4, simulation images, logs). A record
                                 that refers to one of them is checked against this hash, which was taken from the file
                                 itself when the notebook was built; the notebook cannot re-verify the content
  raw_reports_embedded [F]       routed candidates whose complete raw signoff reports are in the package
  regenerated    {layer: spec}   synthetic layers rebuilt from their documented generator and seed; the rebuilt arrays
                                 must reproduce the recorded content hash bit for bit
  recorded_test  {layer: spec}   layers whose test split is not in the package; their test results are the recorded ones

In a full checkout there is no SUPPORT.json, and every function here reads the files themselves.
"""
from pathlib import Path
import functools
import hashlib
import io
import json
import zipfile
import numpy as np

INDEX = 'SUPPORT.json'


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@functools.lru_cache(maxsize=8)
def _load(path, mtime):
    return json.loads(Path(path).read_text())


def index(root):
    """The support index of a project root, or None for a full checkout."""
    p = Path(root) / INDEX
    return _load(str(p.resolve()), p.stat().st_mtime) if p.exists() else None


def find_root(path):
    """The project root above a path inside it (the folder that holds src/mxacc), or None."""
    p = Path(path).resolve()
    for q in [p, *p.parents]:
        if (q / 'src/mxacc/embedded.py').exists() or (q / INDEX).exists(): return q
    return None


def file_digest(root, path):
    """SHA-256 of a project file. An evidence file that the notebook does not embed has its attested digest (historical record)."""
    root = Path(root).resolve(); p = Path(path); p = p if p.is_absolute() else root / p
    if p.is_file(): return _sha(p)
    idx = index(root)
    if not idx: return None
    try: rel = p.resolve().relative_to(root).as_posix()
    except ValueError: return None
    return idx.get('attested', {}).get(rel)


def regenerated(folder):
    """The regeneration spec of a layer folder, if the notebook rebuilt it from its generator."""
    folder = Path(folder).resolve(); root = find_root(folder)
    idx = index(root) if root else None
    return (idx or {}).get('regenerated', {}).get(folder.name) if idx and folder.parent == (root / 'data/workloads').resolve() else None


def raw_reports(root, f):
    """'raw' when every raw evidence file of the routed record of F is present (and so can be re-read), else 'historical'."""
    man = Path(root) / f'results/physical/f{f}/evidence/manifest.json'
    if not man.exists(): return None
    files = json.loads(man.read_text()).get('evidence_files', {})
    return 'raw' if files and all((man.parent / rel).is_file() for rel in files) else 'historical'


def recorded_test(root, layer_id):
    """The spec of a layer whose test split is not in the package (its recorded test results stand in), or None."""
    return ((index(root) or {}).get('recorded_test') or {}).get(layer_id)


def content_hash(x_cal, w, x_test):
    """The data hash of a layer as mxacc.workloads.load_workload computes it."""
    h = hashlib.sha256()
    for a in (x_cal, w, x_test): h.update(np.ascontiguousarray(a).tobytes())
    return h.hexdigest()


def synthetic_arrays(spec):
    """The arrays of one synthetic layer, rebuilt from its generator and seed."""
    from .workloads import synthetic
    xc, w = synthetic(spec['family'], k=spec['k'], n=spec['n_cal'], m=spec['m'], seed=spec['seed'], split=spec['calibration_split'])
    xt, _ = synthetic(spec['family'], k=spec['k'], n=spec['n_test'], m=spec['m'], seed=spec['seed'], split=spec['test_split'])
    def split(x):
        n = len(x)
        return dict(x=x, w=w, bias=np.zeros(spec['m'], np.float32), labels=np.zeros(n, np.int64), sample_ids=np.arange(n, dtype=np.int64))
    return split(xc), split(xt)


def _npz_bytes(arrays):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, a in arrays.items():
            info = zipfile.ZipInfo(name + '.npy', date_time=(1980, 1, 1, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED
            data = io.BytesIO(); np.lib.format.write_array(data, np.ascontiguousarray(a), allow_pickle=False); z.writestr(info, data.getvalue())
    return buf.getvalue()


def regenerate(root, log=print):
    """Rebuild every synthetic layer of the index; each must reproduce its recorded content hash exactly."""
    root = Path(root); idx = index(root) or {}; done = []
    for wid, spec in sorted(idx.get('regenerated', {}).items()):
        folder = root / 'data/workloads' / wid; folder.mkdir(parents=True, exist_ok=True)
        cal, test = synthetic_arrays(spec)
        got = content_hash(cal['x'], cal['w'], test['x'])
        if got != spec['data_sha256']:
            raise ValueError(f'{wid}: the regenerated layer does not reproduce the recorded data (sha256 {got[:12]} vs {spec["data_sha256"][:12]}); '
                             'this NumPy release draws a different random stream')
        (folder / 'calibration.npz').write_bytes(_npz_bytes(cal)); (folder / 'test.npz').write_bytes(_npz_bytes(test))
        done.append(wid)
    if done and log: log(f'regenerated {len(done)} synthetic layers from their generator and seed; every one reproduces its recorded data hash')
    return done


def summary(root):
    """Counts and sizes for the Section 1 report."""
    idx = index(root)
    if not idx: return None
    return dict(embedded=len(idx['embedded']), attested=len(idx['attested']), attested_bytes=idx.get('attested_bytes'), raw_reports_embedded=idx.get('raw_reports_embedded', []),
                regenerated=sorted(idx.get('regenerated', {})), recorded_test=sorted(idx.get('recorded_test', {})), payload_sha256=idx.get('payload_sha256'))
