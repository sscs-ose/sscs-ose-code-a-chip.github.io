"""Trace handling for the cycle contract (v0.4): parse per-cycle traces of both simulators,
derive the per-transaction event table from the raw signals with one reconstruction (so the
RTL and the C++ model are judged by the same rule), compare traces/events/summaries, and
recompute the summary counters independently.

Trace format: docs/perf_contract.md section 7.
"""
from pathlib import Path
import csv, json
import numpy as np

GLOBAL_COLS = ['cycle', 'rst', 'epoch', 'qcount', 'space', 'grant', 'enq', 'pop', 'mstate', 'ret_valid', 'ret_ready', 'ret_hs', 'ret_core', 'ret_id', 'ret_ooc']
RET_IDENTITY = ('ret_core', 'ret_id', 'ret_ooc')          # defined only when ret_valid = 1
CORE_FIELDS = [('ord', 0, 16), ('hw_id', 16, 8), ('state', 24, 3), ('start_v', 27, 1), ('start_hs', 28, 1), ('meta_hs', 29, 1), ('data_hs', 30, 1), ('out_v', 31, 1),
               ('out_rdy', 32, 1), ('out_hs', 33, 1), ('rc_v', 34, 1), ('rc_hs', 35, 1), ('inexact', 36, 1), ('stall', 37, 6)]
EVENTS = ('start_first_offer', 'first_input_accept', 'last_input_accept', 'normal_result_handshake', 'record_first_valid', 'record_enqueue',
          'merge_accept', 'return_first_valid', 'return_handshake', 'reset_abort')
STALL_NAMES = ('INPUT_MASK', 'START_BLOCKED', 'RESULT_BLOCKED', 'RECORD_WAIT_FULL', 'RECORD_WAIT_ARB', 'ARRIVAL_WAIT')


class Trace:
    def __init__(self, path):
        path = Path(path)
        with open(path) as f:
            header = f.readline().strip().split(',')
        self.n = len(header) - len(GLOBAL_COLS)
        if header[:len(GLOBAL_COLS)] != GLOBAL_COLS or any(header[len(GLOBAL_COLS) + c] != f'c{c}' for c in range(self.n)):
            raise ValueError(f'{path}: unexpected trace header')
        raw = np.loadtxt(path, delimiter=',', skiprows=1, dtype=str, ndmin=2)
        if raw.size == 0: raise ValueError(f'{path}: empty trace')
        self.g = {}
        for i, col in enumerate(GLOBAL_COLS):
            self.g[col] = np.array([int(v, 16) for v in raw[:, i]], dtype=np.int64) if col == 'grant' else raw[:, i].astype(np.int64)
        words = np.array([[int(v, 16) for v in row] for row in raw[:, len(GLOBAL_COLS):]], dtype=np.uint64).reshape(len(raw), self.n)
        self.c = {name: ((words >> np.uint64(shift)) & np.uint64((1 << width) - 1)).astype(np.int64) for name, shift, width in CORE_FIELDS}
        self.rows = len(raw)
        self.path = str(path)

    def row(self, t):
        d = {k: int(v[t]) for k, v in self.g.items()}
        d['cores'] = [{k: int(v[t, c]) for k, v in self.c.items()} for c in range(self.n)]
        return d


def compare_cycles(a, b, context=16):
    """First difference between two traces (None if identical in every defined column)."""
    if a.n != b.n: return {'where': 'header', 'detail': f'core count {a.n} vs {b.n}'}
    rows = min(a.rows, b.rows)
    diffs = []
    for col in GLOBAL_COLS:
        x, y = a.g[col][:rows], b.g[col][:rows]
        if col in RET_IDENTITY:
            m = (a.g['ret_valid'][:rows] == 1) & (b.g['ret_valid'][:rows] == 1)
            bad = np.nonzero((x != y) & m)[0]
        else:
            bad = np.nonzero(x != y)[0]
        if len(bad): diffs.append((int(bad[0]), col, None, int(x[bad[0]]), int(y[bad[0]])))
    for col in a.c:
        x, y = a.c[col][:rows], b.c[col][:rows]
        bad = np.nonzero(x != y)
        if len(bad[0]):
            i = int(np.argmin(bad[0])); t, c = int(bad[0][i]), int(bad[1][i])
            diffs.append((t, col, c, int(x[t, c]), int(y[t, c])))
    if a.rows != b.rows: diffs.append((rows, 'rows', None, a.rows, b.rows))
    if not diffs: return None
    t, col, core, va, vb = min(diffs, key=lambda d: (d[0], d[1]))
    lo, hi = max(0, t - context), min(rows, t + context + 1)
    window = [{'cycle': int(a.g['cycle'][i]), 'a': a.row(i), 'b': b.row(i)} for i in range(lo, hi)] if t < rows else []
    return {'cycle': t, 'column': col, 'core': core, 'a': va, 'b': vb, 'window': window,
            'all_first_diffs': [{'cycle': d[0], 'column': d[1], 'core': d[2], 'a': d[3], 'b': d[4]} for d in sorted(diffs)]}


def derive_events(tr, b):
    """Reconstruct the per-transaction events from the raw per-cycle signals.

    Returns (events, checks): events is a dict {(core, ordinal): {event: cycle, 'epoch', 'hw_id', ...}};
    checks lists internal consistency failures (occupancy reconstruction, return identity).
    """
    n = tr.n; checks = []
    ev = {}
    core_cur = [None] * n; data_count = [0] * n
    queue = []            # reconstructed queue contents in order: (core, ordinal, hw_id)
    in_merge = None; prev_ret_valid = 0; prev_rst = 1
    epoch = 0
    def rec(c, o):
        key = (c, o)
        if key not in ev: ev[key] = {'core': c, 'ordinal': o, 'epoch': None, 'hw_id': None}
        return ev[key]
    for t in range(tr.rows):
        g = {k: int(v[t]) for k, v in tr.g.items()}
        rst = g['rst']
        if len(queue) != g['qcount'] and t > 0:
            checks.append(f'cycle {t}: reconstructed occupancy {len(queue)} != qcount {g["qcount"]}')
        if rst:
            if not prev_rst and t > 0:
                epoch += 1
                if g['ret_valid'] and not prev_ret_valid and in_merge is not None:   # observable at the reset edge itself
                    rec(*in_merge[:2])['return_first_valid'] = t
                # abort everything accepted and incomplete
                for c in range(n):
                    if core_cur[c] is not None:
                        rec(c, core_cur[c])['reset_abort'] = t; core_cur[c] = None
                for (c, o, _) in queue: rec(c, o)['reset_abort'] = t
                if in_merge is not None: rec(*in_merge[:2])['reset_abort'] = t
                queue = []; in_merge = None
            prev_rst = 1; prev_ret_valid = 0; continue
        prev_rst = 0
        # return port
        if g['ret_valid'] and not prev_ret_valid:
            if in_merge is None: checks.append(f'cycle {t}: return valid with no record in the merge unit')
            else:
                c, o, hid = in_merge; rec(c, o)['return_first_valid'] = t
                if g['ret_core'] != c or g['ret_id'] != hid:
                    checks.append(f'cycle {t}: return identity core={g["ret_core"]} id={g["ret_id"]} but the merge unit holds core={c} id={hid} (ordinal {o})')
        if g['ret_hs']:
            if in_merge is None: checks.append(f'cycle {t}: return handshake with no record in the merge unit')
            else:
                c, o, hid = in_merge; r = rec(c, o); r['return_handshake'] = t; r['ret_ooc'] = g['ret_ooc']; in_merge = None
        prev_ret_valid = g['ret_valid']
        # merge accept (pop)
        popped = None
        if g['pop']:
            if not queue: checks.append(f'cycle {t}: pop from an empty reconstructed queue')
            else: popped = queue.pop(0); rec(*popped[:2])['merge_accept'] = t
        if popped is not None: in_merge = popped
        # cores
        for c in range(n):
            f = {k: int(v[t, c]) for k, v in tr.c.items()}
            if f['start_v'] and f['state'] == 0 and f['start_hs'] == 0: checks.append(f'cycle {t} core {c}: start offered in IDLE without handshake')
            if f['start_v']:
                r = rec(c, f['ord']); r.setdefault('start_first_offer', t)
            if f['start_hs']:
                r = rec(c, f['ord']); r['first_input_accept'] = t; r['epoch'] = epoch; core_cur[c] = f['ord']; data_count[c] = 0
                r['hw_id'] = None   # assigned from the next row's hw_id (the register is written at this edge)
            if f['data_hs'] and core_cur[c] is not None:
                data_count[c] += 1
                if data_count[c] == 8 * b: rec(c, core_cur[c])['last_input_accept'] = t
            if core_cur[c] is not None:
                r = rec(c, core_cur[c])
                if r['hw_id'] is None and t + 1 < tr.rows and int(tr.c['state'][t + 1, c]) != 0: r['hw_id'] = int(tr.c['hw_id'][t + 1, c])
                if f['rc_v'] and 'record_first_valid' not in r: r['record_first_valid'] = t
                if f['out_hs']: r['normal_result_handshake'] = t; r['inexact'] = f['inexact']
                if f['rc_hs']:
                    r['record_enqueue'] = t; queue.append((c, core_cur[c], f['hw_id']))
                    if not (g['grant'] >> c) & 1: checks.append(f'cycle {t} core {c}: rc handshake without grant bit')
                # leaving OUT: next row state is IDLE (or a reset follows); the next transaction cannot start before
                if f['state'] == 4 and t + 1 < tr.rows and int(tr.c['state'][t + 1, c]) == 0:
                    core_cur[c] = None
    # completion and bookkeeping
    for key, r in ev.items():
        flagged = r.get('inexact', 0) == 1 and 'record_first_valid' in r or 'record_enqueue' in r
        r['flagged'] = bool(flagged)
        done_out = 'normal_result_handshake' in r; done_ret = 'return_handshake' in r
        if 'reset_abort' in r: r['completion'] = None
        elif flagged: r['completion'] = max(r['normal_result_handshake'], r['return_handshake']) if (done_out and done_ret) else None
        else: r['completion'] = r['normal_result_handshake'] if done_out else None
    return ev, checks


def events_table(ev):
    rows = []
    for (c, o), r in sorted(ev.items()):
        for name in EVENTS:
            if name in r: rows.append((r['epoch'] if r['epoch'] is not None else -1, c, o, r['hw_id'] if r['hw_id'] is not None else -1, name, r[name]))
    return rows


def read_events_csv(path):
    rows = []
    with open(path) as f:
        for d in csv.DictReader(f):
            rows.append((int(d['epoch']), int(d['core']), int(d['ordinal']), int(d['hw_id']), d['event'], int(d['cycle'])))
    return rows


def compare_events(a, b, name_a='a', name_b='b'):
    """Per-event cycle deltas; both inputs are lists of (epoch, core, ordinal, hw_id, event, cycle)."""
    ka = {(c, o, e): (ep, h, t) for ep, c, o, h, e, t in a}; kb = {(c, o, e): (ep, h, t) for ep, c, o, h, e, t in b}
    missing_in_b = sorted(set(ka) - set(kb)); missing_in_a = sorted(set(kb) - set(ka))
    deltas = []; id_mismatch = []; epoch_mismatch = []
    for key in sorted(set(ka) & set(kb)):
        (ea, ha, ta), (eb, hb, tb) = ka[key], kb[key]
        if ta != tb: deltas.append({'core': key[0], 'ordinal': key[1], 'event': key[2], name_a: ta, name_b: tb, 'delta': tb - ta})
        if ha != hb and ha >= 0 and hb >= 0: id_mismatch.append({'core': key[0], 'ordinal': key[1], 'event': key[2], name_a: ha, name_b: hb})
        if ea != eb and ea >= 0 and eb >= 0: epoch_mismatch.append({'core': key[0], 'ordinal': key[1], 'event': key[2], name_a: ea, name_b: eb})
    max_delta = max((abs(d['delta']) for d in deltas), default=0)
    return {'compared': len(set(ka) & set(kb)), 'missing_in_' + name_b: [list(k) for k in missing_in_b[:50]], 'missing_in_' + name_a: [list(k) for k in missing_in_a[:50]],
            'n_missing_in_' + name_b: len(missing_in_b), 'n_missing_in_' + name_a: len(missing_in_a),
            'cycle_deltas': deltas[:50], 'n_cycle_deltas': len(deltas), 'max_abs_cycle_delta': max_delta,
            'hw_id_mismatches': id_mismatch[:50], 'n_hw_id_mismatches': len(id_mismatch), 'epoch_mismatches': epoch_mismatch[:20], 'n_epoch_mismatches': len(epoch_mismatch),
            'identical': not deltas and not missing_in_a and not missing_in_b and not id_mismatch and not epoch_mismatch}


def counts_from_trace(tr, ev):
    """Summary counters recomputed from the trace and the derived events."""
    g = tr.g
    not_rst = g['rst'] == 0
    completed = sum(1 for r in ev.values() if r.get('completion') is not None)
    aborted = sum(1 for r in ev.values() if 'reset_abort' in r)
    starts = sum(1 for r in ev.values() if 'first_input_accept' in r)
    returns = int((g['ret_hs'] * not_rst).sum()); ooc = int(((g['ret_hs'] == 1) & (g['ret_ooc'] == 1) & not_rst).sum())
    enq = int((g['enq'] * not_rst).sum()); pops = int((g['pop'] * not_rst).sum())
    resets = int(((g['rst'][1:] == 1) & (g['rst'][:-1] == 0)).sum())
    qpeak = int(g['qcount'][1:].max()) if tr.rows > 1 else 0
    occ = np.bincount(g['qcount'][1:], minlength=1).tolist() if tr.rows > 1 else [0]
    stalls = {name: int(((tr.c['stall'] >> i) & 1).sum()) for i, name in enumerate(STALL_NAMES)}
    union = int((tr.c['stall'] != 0).sum())
    merge_busy = int(((g['mstate'] == 1) | ((g['mstate'] == 2) & (g['ret_valid'] == 0))).sum()); blocked = int(((g['ret_valid'] == 1) & (g['ret_ready'] == 0)).sum())
    return {'cycles': tr.rows, 'starts': starts, 'completed': completed, 'aborted': aborted, 'returns': returns, 'ooc_returns': ooc, 'enqueues': enq, 'pops': pops,
            'resets': resets, 'queue_peak': qpeak, 'occupancy_cycles': occ, 'stalls': stalls, 'stall_union': union, 'merge_compute_busy': merge_busy, 'merge_output_blocked': blocked}


def nearest_rank(values, p):
    if not values: return None
    v = sorted(values); import math
    return v[max(1, math.ceil(p * len(v))) - 1]


def latencies_from_events(ev):
    e2e = [r['completion'] - r['first_input_accept'] for r in ev.values() if r.get('completion') is not None and 'first_input_accept' in r]
    rc = [r['return_handshake'] - r['record_first_valid'] for r in ev.values() if r.get('completion') is not None and 'return_handshake' in r and 'record_first_valid' in r]
    qw = [r['merge_accept'] - r['record_enqueue'] for r in ev.values() if r.get('completion') is not None and 'merge_accept' in r and 'record_enqueue' in r]
    stat = lambda v: {'count': len(v), 'p50': nearest_rank(v, .5), 'p99': nearest_rank(v, .99), 'max': max(v) if v else None}
    return {'e2e_latency': stat(e2e), 'recompute_latency': stat(rc), 'queue_wait': stat(qw)}


def coverage_from_trace(tr, ev, q):
    """Which contract behaviours the case exercised (never inferred: counted from the trace)."""
    g = tr.g; n = tr.n
    full = g['qcount'] == q
    same_cycle_enq_deq = int(((g['enq'] == 1) & (g['pop'] == 1)).sum())
    empty_to_nonempty = int(((g['qcount'][1:] > 0) & (g['qcount'][:-1] == 0)).sum()); full_cycles = int(full.sum())
    grants_while_full = int(((g['enq'] == 1) & full).sum())
    order = {'result_before_record': 0, 'record_before_result': 0, 'same_cycle': 0}
    for r in ev.values():
        if 'normal_result_handshake' in r and 'record_enqueue' in r:
            a, b = r['normal_result_handshake'], r['record_enqueue']
            order['result_before_record' if a < b else 'record_before_result' if b < a else 'same_cycle'] += 1
    simultaneous = int((np.array([bin(int(v)).count('1') for v in g['grant']]) >= 1).sum())
    multi_req = int(((tr.c['rc_v'].sum(axis=1)) >= 2).sum())
    arb_lost = int(((tr.c['stall'] >> 4) & 1).sum()); wait_full = int(((tr.c['stall'] >> 3) & 1).sum())
    per_core_tx = {c: 0 for c in range(n)}; wraps = 0
    for c in range(n):
        seq = [r['hw_id'] for (cc, o), r in sorted(ev.items()) if cc == c and 'first_input_accept' in r and r.get('hw_id') is not None]
        per_core_tx[c] = len(seq); wraps += sum(1 for a, b_ in zip(seq, seq[1:]) if a == 255 and b_ == 0)
    reset_edges = [int(t) for t in np.nonzero((g['rst'][1:] == 1) & (g['rst'][:-1] == 0))[0] + 1]
    reset_with_queue = [t for t in reset_edges if g['qcount'][t] > 0]; reset_with_merge_busy = [t for t in reset_edges if g['mstate'][t] != 0]
    reset_with_cores_busy = [t for t in reset_edges if int((tr.c['state'][t] != 0).sum()) > 0]
    ooc_returns = int(((g['ret_hs'] == 1) & (g['ret_ooc'] == 1)).sum()); exact_returns = int(((g['ret_hs'] == 1) & (g['ret_ooc'] == 0)).sum())
    return {'queue_full_cycles': full_cycles, 'grants_while_full': grants_while_full, 'same_cycle_enqueue_dequeue': same_cycle_enq_deq, 'empty_to_nonempty_transitions': empty_to_nonempty,
            'handshake_order': order, 'cycles_with_multiple_requests': multi_req, 'arbitration_lost_core_cycles': arb_lost, 'record_wait_full_core_cycles': wait_full,
            'grant_cycles': simultaneous, 'id_wraps': wraps, 'id_wrap_observed': wraps > 0,
            'max_transactions_per_core': max(per_core_tx.values(), default=0), 'reset_edges': reset_edges, 'reset_with_queue_nonempty': reset_with_queue,
            'reset_with_merge_busy': reset_with_merge_busy, 'reset_with_cores_busy': reset_with_cores_busy, 'exact_returns': exact_returns, 'out_of_contract_returns': ooc_returns,
            'input_mask_stall_core_cycles': int(((tr.c['stall'] >> 0) & 1).sum()), 'result_blocked_core_cycles': int(((tr.c['stall'] >> 2) & 1).sum()),
            'return_blocked_cycles': int(((g['ret_valid'] == 1) & (g['ret_ready'] == 0)).sum()), 'start_blocked_core_cycles': int(((tr.c['stall'] >> 1) & 1).sum())}


def mutate_trace(path, out, kind):
    """Write a deliberately corrupted copy of a per-cycle trace (comparator self-test)."""
    lines = Path(path).read_text().splitlines()
    header = lines[0]; rows = lines[1:]
    gi = {c: i for i, c in enumerate(GLOBAL_COLS)}
    def find(pred):
        for i, r in enumerate(rows):
            if pred(r.split(',')): return i
        raise ValueError('no row for mutation ' + kind)
    if kind == 'plus_one_cycle':        # delay one return handshake by a cycle: ret_hs moves from row i to i+1
        i = find(lambda f: f[gi['ret_hs']] == '1')
        a, b = rows[i].split(','), rows[i + 1].split(','); a[gi['ret_hs']] = '0'; b[gi['ret_hs']] = '1'; b[gi['ret_valid']] = '1'; b[gi['ret_core']] = a[gi['ret_core']]; b[gi['ret_id']] = a[gi['ret_id']]; b[gi['ret_ooc']] = a[gi['ret_ooc']]
        rows[i] = ','.join(a); rows[i + 1] = ','.join(b)
    elif kind == 'drop_return':         # remove one return handshake entirely
        i = find(lambda f: f[gi['ret_hs']] == '1'); a = rows[i].split(','); a[gi['ret_hs']] = '0'; rows[i] = ','.join(a)
    elif kind == 'swap_id':             # a return carries the wrong ID
        i = find(lambda f: f[gi['ret_hs']] == '1'); a = rows[i].split(','); a[gi['ret_id']] = str((int(a[gi['ret_id']]) + 1) % 256); rows[i] = ','.join(a)
    elif kind == 'occupancy':           # one occupancy value off by one
        i = find(lambda f: f[gi['qcount']] != '0'); a = rows[i].split(','); a[gi['qcount']] = str(int(a[gi['qcount']]) - 1); rows[i] = ','.join(a)
    else: raise ValueError(kind)
    Path(out).write_text('\n'.join([header] + rows) + '\n')
