"""Small NumPy MLP: real MNIST, 784->128->64->10, Adam, disjoint splits."""
from pathlib import Path
import gzip
import hashlib
import json
import struct
import urllib.request
import numpy as np

FILES = {
    "train-images-idx3-ubyte.gz": "f68b3c2dcbeaaa9fbdd348bbdeb94873",
    "train-labels-idx1-ubyte.gz": "d53e105ee54ea40749a09fcbcd1e9432",
    "t10k-images-idx3-ubyte.gz": "9fb629c4189551a2d022fa330f9573f3",
    "t10k-labels-idx1-ubyte.gz": "ec29112dd5afa0611ce80d1b7f02629c",
}
SOURCE = "https://storage.googleapis.com/cvdf-datasets/mnist/"


def load_mnist(directory):
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    loaded, manifest = [], {}
    for name, md5 in FILES.items():
        p = directory/name
        if not p.exists():
            with urllib.request.urlopen(SOURCE+name,timeout=60) as response:
                p.write_bytes(response.read())
        raw = p.read_bytes()
        if hashlib.md5(raw).hexdigest() != md5:
            raise ValueError(f"Checksum mismatch: {name}; remove this file and retry")
        manifest[name] = {"url":SOURCE+name,"md5":md5,"sha256":hashlib.sha256(raw).hexdigest()}
        buf = gzip.decompress(raw)
        magic, n = struct.unpack(">II",buf[:8])
        if magic == 2051:
            assert struct.unpack(">II",buf[8:16]) == (28,28)
            a = np.frombuffer(buf,dtype=np.uint8,offset=16).reshape(n,784).astype(np.float32)/255
        elif magic == 2049:
            a = np.frombuffer(buf,dtype=np.uint8,offset=8).astype(np.int64)
        else:
            raise ValueError("Invalid IDX header")
        loaded.append(a)
    return (*loaded,manifest)


def forward(p,x,return_hidden=False):
    h1 = np.maximum(x@p['w1']+p['b1'],0)
    h2 = np.maximum(h1@p['w2']+p['b2'],0)
    logits = h2@p['w3']+p['b3']
    return (h1,h2,logits) if return_hidden else logits


def accuracy(p,x,y):
    correct=0
    for i in range(0,len(x),512):
        correct += np.count_nonzero(forward(p,x[i:i+512]).argmax(axis=1)==y[i:i+512])
    return float(correct/len(x))


def loss_grad(p,x,y):
    h1,h2,logits=forward(p,x,True)
    prob=np.exp(logits-logits.max(axis=1,keepdims=True))
    prob/=prob.sum(axis=1,keepdims=True)
    loss=float(-np.log(np.maximum(prob[np.arange(len(y)),y],1e-20)).mean())
    prob[np.arange(len(y)),y]-=1; prob/=len(y)
    grad={'w3':h2.T@prob,'b3':prob.sum(axis=0)}
    d2=(prob@p['w3'].T)*(h2>0)
    grad.update(w2=h1.T@d2,b2=d2.sum(axis=0))
    d1=(d2@p['w2'].T)*(h1>0)
    grad.update(w1=x.T@d1,b1=d1.sum(axis=0))
    return loss,grad


def initialize(seed=20261017):
    rng=np.random.default_rng(seed); p={}
    for i,(a,b) in enumerate([(784,128),(128,64),(64,10)],1):
        p[f'w{i}']=(rng.standard_normal((a,b))*np.sqrt(2/a)).astype(np.float32)
        p[f'b{i}']=np.zeros(b,dtype=np.float32)
    return p


def train(x,y,train_ids,val_ids,epochs=10,seed=20261017):
    rng=np.random.default_rng(seed+1); p=initialize(seed)
    m={k:np.zeros_like(v) for k,v in p.items()}; v={k:np.zeros_like(a) for k,a in p.items()}
    best=None; best_acc=-1.; history=[]; step=0
    for epoch in range(epochs):
        losses=[]
        order=rng.permutation(train_ids)
        for i in range(0,len(order),256):
            idx=order[i:i+256]; loss,g=loss_grad(p,x[idx],y[idx]); losses.append(loss); step+=1
            for k in p:
                m[k]=.9*m[k]+.1*g[k]; v[k]=.999*v[k]+.001*g[k]*g[k]
                p[k]-=.001*(m[k]/(1-.9**step))/(np.sqrt(v[k]/(1-.999**step))+1e-8)
        val=accuracy(p,x[val_ids],y[val_ids])
        row={'epoch':epoch+1,'train_loss':float(np.mean(losses)),'model_validation_accuracy':val}
        history.append(row); print(json.dumps(row),flush=True)
        if val>best_acc: best_acc=val; best={k:a.copy() for k,a in p.items()}
    return best,history
