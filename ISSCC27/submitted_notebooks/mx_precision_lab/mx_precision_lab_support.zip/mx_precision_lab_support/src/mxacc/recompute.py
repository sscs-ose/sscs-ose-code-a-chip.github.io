"""Rounding-loss detection and selective recomputation (feasibility study).

The merge pipeline aligns every block sum S_g to the largest block exponent with
F fractional bits. A right shift discards low bits; the result of a transaction
is exactly the MXFP4 dot product whenever no block discarded a non-zero bit.
That condition is observable *inside* the datapath (the guard and sticky bits
the RNE stage already computes), so a low-F core can raise an `inexact` flag
per transaction and leave the few flagged results to a slower exact path.

This module measures, on real data, how often the flag fires and what a
selective recompute buys. Everything here is arithmetic feasibility on the
bit-exact software model; hardware cost of the flag and of the recompute path
is a separate measurement (see scripts/flag_experiment.py).

Guarantee (sufficient condition, mirrored in the RTL variant): flag == 0  =>
result == exact. The converse does not hold: rounding errors of different
blocks can cancel, so a flagged transaction may still be exact (counted as a
false positive below; never a false negative).
"""
import numpy as np
from .arithmetic import accumulate, exact, as_float, exact_difference, width, CANDIDATES


def discarded_nonzero(g, f):
    """Per (transaction, block): True when aligning S_g with F bits discards a non-zero bit."""
    width(g.sums.shape[-1] * 32, f)
    emax = g.exponents.max(axis=-1)
    shifts = f + g.exponents - emax[..., None]
    mag = np.abs(g.sums)
    lost = np.zeros(g.sums.shape, dtype=bool)
    right = (shifts < 0) & (shifts > -14)
    n = -shifts[right]
    lost[right] = (mag[right] & (np.left_shift(np.ones_like(n, dtype=np.int64), n) - 1)) != 0
    dropped = shifts <= -14                       # the RTL rounds these blocks to zero
    lost[dropped] = mag[dropped] != 0
    lost[g.invalid] = False                       # NaN-scale transactions are reported as invalid, not inexact
    return lost


def inexact_flags(g, f):
    """Per transaction: the sticky OR of discarded_nonzero over blocks (what the RTL flag computes)."""
    return discarded_nonzero(g, f).any(axis=-1)


def per_transaction_bound(g, f, lost=None):
    """|error| <= (#inexact blocks) * 2^(E_max - F - 1): one RNE half-ulp per lossy block."""
    lost = discarded_nonzero(g, f) if lost is None else lost
    emax = g.exponents.max(axis=-1)
    return lost.sum(axis=-1) * np.exp2(emax.astype(np.float64) - f - 1)


def recompute_study(g, f, golden=None, rel_tolerances=(0.0, 1e-3, 1e-2)):
    """Fraction of transactions a low-F core must hand to an exact path, and the error before/after.

    rel_tolerances: per-transaction relative-error tolerances for the *bounded pass* variant:
    a flagged transaction is still accepted when its error bound is <= tol * (|y_hat| - bound),
    i.e. when the bound proves the relative error is within tol without recomputing. tol = 0
    is the strict policy (every flagged transaction is recomputed).
    """
    j, emin = golden if golden is not None else exact(g)
    t, eo = accumulate(g, f)
    err = exact_difference(t, eo, j, emin)
    ref = as_float(j, emin)
    denom = max(float(np.linalg.norm(ref)), 1e-12)
    lost = discarded_nonzero(g, f)
    flag = lost.any(axis=-1)
    nonzero_err = err != 0
    false_negative = int(np.count_nonzero(nonzero_err & ~flag))      # must be 0: the flag is a sufficient condition
    false_positive = int(np.count_nonzero(flag & ~nonzero_err))      # rounding errors that cancelled exactly
    bound = per_transaction_bound(g, f, lost)
    yhat = np.abs(as_float(t, eo))
    out = {"f": int(f), "w": width(g.sums.shape[-1] * 32, f), "transactions": int(flag.size),
           "flagged": int(flag.sum()), "flagged_fraction": float(flag.mean()),
           "lossy_blocks_fraction": float(lost.mean()),
           "nrmse_before": float(np.linalg.norm(err) / denom), "max_abs_before": float(np.abs(err).max()),
           "false_negatives": false_negative, "false_positives_exact_after_cancellation": false_positive,
           "bound_violations": int(np.count_nonzero(np.abs(err) > bound + 1e-12 * bound)),
           "policies": []}
    for tol in rel_tolerances:
        if tol <= 0:
            recompute = flag
        else:
            # accept a flagged result when the bound proves |err|/|y| <= tol (y unknown: use |y_hat| - bound >= 0)
            provable = (yhat - bound > 0) & (bound <= tol * (yhat - bound))
            recompute = flag & ~provable
        fixed = np.where(recompute, 0.0, err)
        out["policies"].append({"rel_tolerance": float(tol), "recomputed": int(recompute.sum()),
                                "recomputed_fraction": float(recompute.mean()),
                                "nrmse_after": float(np.linalg.norm(fixed) / denom), "max_abs_after": float(np.abs(fixed).max())})
    return out


def sweep(g, f_values=CANDIDATES, golden=None, rel_tolerances=(0.0, 1e-3, 1e-2)):
    golden = golden if golden is not None else exact(g)
    return [recompute_study(g, f, golden, rel_tolerances) for f in f_values]


def scalar_inexact(xc, xs, wc, ws, f):
    """Reference for the RTL flag on one transaction (same conventions as arithmetic.scalar_dot)."""
    from .arithmetic import decode
    k = len(xc)
    if 255 in xs or 255 in ws:
        return False
    es = [int(a) + int(b) - 256 for a, b in zip(xs, ws)]
    ss = [sum(int(a) * int(b) for a, b in zip(decode(xc[g*32:(g+1)*32]), decode(wc[g*32:(g+1)*32]))) for g in range(k // 32)]
    em = max(es)
    for s, e in zip(ss, es):
        sh = e - em + f
        if sh >= 0 or s == 0:
            continue
        if sh <= -14:
            return True
        if abs(s) & ((1 << (-sh)) - 1):
            return True
    return False


def policy_rows(entry, area, flag_hw, budget, lanes=4, shares=(16, 64)):
    """Same-platform policy rows including 'low F + selective recompute' for one workload entry of
    results/recompute/study.json. Areas come only from (K, lanes, F)-matching routed records; the flag
    overhead is the measured post-route delta of the inexact variant when routed, else the synthesis delta
    applied to the routed baseline (labelled)."""
    from .implementation import area_for
    k = entry['k']; per_f = {r['f']: r for r in entry['per_f']}
    exact_unit = area_for(area, k, lanes, 24, 'post_route')
    def flag_area(f):
        base = area_for(area, k, lanes, f, 'post_route')
        if not isinstance(base, (int, float)):
            return None, 'not_evaluated'
        pr = (flag_hw or {}).get('post_route', {}).get(str(f))
        if pr and pr.get('delta_area_um2') is not None:
            return base + pr['delta_area_um2'], 'post_route (measured)'
        sy = (flag_hw or {}).get('synthesis', {}).get(str(f))
        if sy and sy.get('delta_area_pct') is not None:
            return base * (1 + sy['delta_area_pct'] / 100), 'routed baseline x synthesis delta (estimate)'
        return base, 'flag overhead not evaluated'
    rows = []
    def meets(v):
        return None if v is None else v <= budget
    for f in (4,):
        r = per_f[f]; a = area_for(area, k, lanes, f, 'post_route')
        rows.append({'policy': f'fixed F{f}, no recompute', 'f': f, 'cal_nrmse': r['cal_nrmse'], 'test_nrmse': r['test_nrmse'], 'meets_budget': meets(r['test_nrmse']) and meets(r['cal_nrmse']),
                     'recompute_fraction': 0.0, 'core_area_um2': a if isinstance(a, (int, float)) else None, 'area_source': 'post_route' if isinstance(a, (int, float)) else 'not_evaluated',
                     'effective_area_um2': {str(n): a for n in shares} if isinstance(a, (int, float)) else None})
    plain = entry.get('plain_selection_f')
    if plain is not None:
        r = per_f[plain]; a = area_for(area, k, lanes, plain, 'post_route')
        rows.append({'policy': f'calibrated minimum F{plain}, no recompute', 'f': plain, 'cal_nrmse': r['cal_nrmse'], 'test_nrmse': r['test_nrmse'], 'meets_budget': meets(r['test_nrmse']) and meets(r['cal_nrmse']),
                     'recompute_fraction': 0.0, 'core_area_um2': a if isinstance(a, (int, float)) else None, 'area_source': 'post_route' if isinstance(a, (int, float)) else 'not_evaluated',
                     'effective_area_um2': {str(n): a for n in shares} if isinstance(a, (int, float)) else None})
    for f in (0, 2, 4):
        r = per_f[f]; a, src = flag_area(f); p = r['test_flagged_fraction']
        eff = None if a is None or not isinstance(exact_unit, (int, float)) else {str(n): (a + exact_unit / n) if n * p <= 1 else None for n in shares}
        rows.append({'policy': f'F{f} + inexact flag + strict recompute', 'f': f, 'cal_nrmse': 0.0, 'test_nrmse': r['test_nrmse_after_strict_recompute'], 'meets_budget': True,
                     'recompute_fraction': p, 'max_cores_per_exact_unit': None if p == 0 else int(1 / p),
                     'core_area_um2': a, 'area_source': src, 'effective_area_um2': eff,
                     'note': 'effective area = flagged core + 1/N of one routed F24 unit; None when N*p > 1 (exact unit saturated)'})
        p3 = r['test_recompute_fraction_tol1e-3']
        rows.append({'policy': f'F{f} + flag + bound-relaxed recompute (rel. tol 1e-3)', 'f': f, 'cal_nrmse': None, 'test_nrmse': r['test_nrmse_after_tol1e-3'], 'meets_budget': meets(r['test_nrmse_after_tol1e-3']),
                     'recompute_fraction': p3, 'max_cores_per_exact_unit': None if p3 == 0 else int(1 / p3), 'core_area_um2': a, 'area_source': src,
                     'effective_area_um2': None if a is None or not isinstance(exact_unit, (int, float)) else {str(n): (a + exact_unit / n) if n * p3 <= 1 else None for n in shares}})
    return rows
