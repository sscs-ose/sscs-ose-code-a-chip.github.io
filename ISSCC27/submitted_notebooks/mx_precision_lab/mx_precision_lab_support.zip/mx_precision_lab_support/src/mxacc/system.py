"""Selective-recompute system: reference arithmetic for the shared merge
unit and a cycle-level model of N low-F cores sharing one exact merge unit.

Exactness contract (mirrors rtl/rc_merge.sv): a record {S_g, E_g} whose spread
max_g(E_max - E_g) is <= D_MAX is merged with F_H = D_MAX fractional bits, so every
alignment is a left shift and the result is the exact MXFP4 dot product. A record
with spread > D_MAX is reported out_of_contract (value 0), never silently rounded.
"""
from collections import deque
import numpy as np
from .arithmetic import decode, width, CANDIDATES


def record(xc, xs, wc, ws):
    """Block sums and exponents of one transaction (what dot_top_rc keeps in sums[]/exponents[])."""
    k = len(xc)
    es = [int(a) + int(b) - 256 for a, b in zip(xs, ws)]
    ss = [sum(int(a) * int(b) for a, b in zip(decode(xc[g*32:(g+1)*32]), decode(wc[g*32:(g+1)*32]))) for g in range(k // 32)]
    return ss, es


def merge_exact(sums, exps, dmax):
    """Reference for rc_merge: (T, E, out_of_contract). T*2^E is exact when in contract."""
    emax = max(exps)
    if any(emax - e > dmax for e in exps):
        return 0, 0, True
    t = sum(s << (dmax + e - emax) for s, e in zip(sums, exps))
    return t, emax - dmax, False


def simulate(flags_per_core, n_cores=None, q=2, ii=40, b=4, service=None, input_stall_p=0.0, ret_stall_p=0.0, seed=20261018):
    """Cycle-level model of mxsys_top.

    flags_per_core: one 0/1 sequence per core: whether each successive transaction of that core is
    flagged inexact (taken from real data so burstiness is real). A core starts its next transaction
    as soon as the previous one completed (II = `ii` cycles, plus random input stalls), except that a
    flagged transaction holds the core in OUT until the arbiter has taken its record (back-pressure,
    as in the RTL). The arbiter grants one record per cycle while the queue (depth q) has room; the
    merge unit takes `service` cycles per record (B+3 in the RTL) and its output waits for ret_ready
    (random stalls with probability ret_stall_p).

    Returns throughput relative to the ideal N/ii, stall statistics, recompute latency percentiles
    (transaction completion -> exact result returned), queue peak and merge-unit utilization.
    """
    rng = np.random.default_rng(seed)
    n = len(flags_per_core) if n_cores is None else n_cores
    service = (b + 3) if service is None else service
    cores = [{'seq': list(flags_per_core[c % len(flags_per_core)]), 'idx': 0, 'ready_at': 0, 'complete_at': None, 'flag': 0,
              'pending_at': None, 'stall_cycles': 0} for c in range(n)]
    total = sum(len(c['seq']) for c in cores)
    queue = deque(); merge_rec = None; merge_done_at = 0; ret_wait = None
    latencies = []; qpeak = 0; busy = 0; last = n - 1; done = 0; t = 0
    while done < total or queue or merge_rec is not None or ret_wait is not None or any(c['pending_at'] is not None for c in cores):
        if t > 50_000_000: raise RuntimeError('simulation did not converge')
        # ---- merge unit / return port
        if merge_rec is not None and t >= merge_done_at and ret_wait is None:
            ret_wait = merge_rec; merge_rec = None
        if ret_wait is not None and rng.random() >= ret_stall_p:
            latencies.append(t - ret_wait['complete_at']); ret_wait = None
        if merge_rec is None and ret_wait is None and queue:
            merge_rec = queue.popleft(); merge_done_at = t + service
        if merge_rec is not None: busy += 1
        # ---- arbiter: one grant per cycle into free queue space, round robin after `last`
        if len(queue) < q:
            for i in range(1, n + 1):
                c = (last + i) % n; core = cores[c]
                if core['pending_at'] is not None and core['pending_at'] <= t:
                    queue.append({'core': c, 'complete_at': core['complete_at']})
                    core['stall_cycles'] += (t + 1) - core['complete_at']   # OUT held from completion to the cycle after the grant
                    core['pending_at'] = None; core['ready_at'] = t + 1; core['complete_at'] = None; last = c
                    break
        qpeak = max(qpeak, len(queue))
        # ---- cores
        for c, core in enumerate(cores):
            if core['complete_at'] is not None and t == core['complete_at']:
                done += 1
                if core['flag']:
                    core['pending_at'] = t                 # record offered this cycle; core held until granted
                else:
                    core['ready_at'] = t; core['complete_at'] = None
            if core['complete_at'] is None and core['pending_at'] is None and core['idx'] < len(core['seq']) and t >= core['ready_at']:
                if rng.random() < input_stall_p:
                    core['ready_at'] = t + 1; continue
                core['flag'] = core['seq'][core['idx']]; core['idx'] += 1; core['complete_at'] = t + ii
        t += 1
    ideal = total * ii / n
    lat = np.array(latencies) if latencies else np.array([0])
    stalls = sum(c['stall_cycles'] for c in cores)
    return {'cores': n, 'queue_depth': q, 'transactions': total, 'cycles': t, 'ideal_cycles': ideal,
            'throughput_fraction': ideal / t, 'throughput_loss_pct': 100 * (1 - ideal / t),
            'flagged': int(len(latencies)), 'flagged_fraction': len(latencies) / total if total else 0,
            'stall_cycles': int(stalls), 'stall_cycles_per_flagged': stalls / max(len(latencies), 1),
            'stall_fraction_of_core_cycles': stalls / (t * n),
            'latency_p50': float(np.percentile(lat, 50)), 'latency_p99': float(np.percentile(lat, 99)), 'latency_max': int(lat.max()),
            'queue_peak': int(qpeak), 'merge_utilization': busy / t, 'service_cycles': service, 'ii': ii}
