"""Icarus Verilog verification of the selective-recompute system (rtl/mxsys_top.sv).

N cores are driven concurrently from per-core vector files with random input stalls,
random output back-pressure and a random-stalled return port. Every core result
(value, exponent, invalid, out_of_contract, inexact, id) is checked in order against
the Python model; every flagged transaction must produce exactly one return with the
exact value (or out_of_contract when the spread exceeds D_MAX), unflagged ones none.
A mid-run reset (while cores are busy and records are queued) must leave no stale
state: the second phase is checked in full.
"""
from pathlib import Path
import hashlib, json, re, shutil, subprocess
import numpy as np
from .arithmetic import scalar_dot, width, quantize
from .recompute import scalar_inexact
from .system import record, merge_exact

TB = r'''`timescale 1ns/1ps
module tb;
 localparam N=@N@,K=@K@,F=@F@,B=K/32,W=@W@,WH=@WH@,DMAX=@DMAX@,Q=@Q@,IDW=@IDW@,CW=@CW@,QW=@QW@;
 reg clk=0;always #5 clk=~clk;
 reg rst=1;
 reg [N-1:0] start=0,meta_valid=0,in_valid=0,out_ready=0;
 reg [N*8-1:0] x_scale=0,w_scale=0;reg [N*16-1:0] x_codes=0,w_codes=0;
 wire [N-1:0] start_ready,meta_ready,in_ready,out_valid,invalid,out_of_contract,inexact,rc_pending;
 wire [N*W-1:0] out_int;wire [N*10-1:0] out_exp;wire [N*IDW-1:0] out_id;
 wire ret_valid;reg ret_ready=0;wire [CW-1:0] ret_core;wire [IDW-1:0] ret_id;wire signed [WH-1:0] ret_int;wire signed [9:0] ret_exp;wire ret_out_of_contract;
 wire [QW-1:0] queue_count;
 mxsys_top #(.N(N),.K(K),.F(F),.D_MAX(DMAX),.Q(Q),.ID_W(IDW)) dut(.*);
 // expected returns, indexed by core*256+id
 reg [WH-1:0] exp_t [0:N*256-1];integer exp_e [0:N*256-1];reg exp_pend [0:N*256-1];reg exp_ooc [0:N*256-1];
 integer returns=0,ret_errors=0,phase=0,finished=0,qpeak=0,k;
 integer per_core_count [0:N-1];
 reg checking=0;
 initial begin for(k=0;k<N*256;k=k+1) begin exp_pend[k]=0;exp_t[k]=0;exp_e[k]=0;exp_ooc[k]=0; end end
 // return monitor
 always @(posedge clk) if(!rst && ret_valid && ret_ready && checking) begin
   k=ret_core*256+ret_id;
   if(!exp_pend[k]) begin $display("ERROR: unexpected return core=%0d id=%0d",ret_core,ret_id);ret_errors=ret_errors+1; end
   else begin
     if(ret_out_of_contract!==exp_ooc[k] || (!exp_ooc[k] && (ret_int!==$signed(exp_t[k]) || $signed(ret_exp)!=exp_e[k])))
       begin $display("ERROR: return mismatch core=%0d id=%0d got T=%0d E=%0d ooc=%0d expected T=%0d E=%0d ooc=%0d",ret_core,ret_id,$signed(ret_int),$signed(ret_exp),ret_out_of_contract,$signed(exp_t[k]),exp_e[k],exp_ooc[k]);ret_errors=ret_errors+1; end
     exp_pend[k]=0;returns=returns+1;
   end
 end
 always @(posedge clk) begin ret_ready<=($urandom%4)!=0; if(queue_count>qpeak) qpeak=queue_count; end
 // per-core drivers
 genvar c;
 generate for(c=0;c<N;c=c+1) begin: drv
   integer file,rc,count,g,beat,idx;
   reg [8*B-1:0] xs,ws;reg [4*K-1:0] xc,wc;reg [W-1:0] et;integer ee,ebad,ebound,einex,eooc,eexe;reg [WH-1:0] eext;
   reg [IDW-1:0] expect_id;
   task run_file(input integer check, input integer limit);
     begin
       file=$fopen($sformatf("vectors_c%0d.txt",c),"r");if(file==0)$fatal(1,"missing vectors");
       count=0;expect_id=0;
       while(!$feof(file) && (limit<0 || count<limit))begin
         rc=$fscanf(file,"%h %h %h %h %h %d %d %d %d %d %h %d\n",xs,ws,xc,wc,et,ee,ebad,ebound,einex,eooc,eext,eexe);
         if(rc!=12)$fatal(1,"bad vector row core %0d",c);
         if(check && einex && !ebad) begin idx=c*256+expect_id;exp_t[idx]=eext;exp_e[idx]=eexe;exp_ooc[idx]=eooc;exp_pend[idx]=1; end
         repeat($urandom_range(0,3))@(negedge clk);
         while(!start_ready[c])@(negedge clk);start[c]=1;@(negedge clk);start[c]=0;
         for(g=0;g<B;g=g+1)begin
           repeat($urandom_range(0,2))@(negedge clk);
           x_scale[c*8+:8]=xs[g*8+:8];w_scale[c*8+:8]=ws[g*8+:8];meta_valid[c]=1;
           while(!meta_ready[c])@(negedge clk);@(negedge clk);meta_valid[c]=0;
         end
         for(g=0;g<B;g=g+1)begin
           for(beat=0;beat<8;beat=beat+1)begin
             repeat($urandom_range(0,1))@(negedge clk);
             x_codes[c*16+:16]=xc[(g*32+beat*4)*4+:16];w_codes[c*16+:16]=wc[(g*32+beat*4)*4+:16];in_valid[c]=1;
             while(!in_ready[c])@(negedge clk);@(negedge clk);in_valid[c]=0;
           end
         end
         while(!out_valid[c])@(negedge clk);
         repeat($urandom_range(0,3))@(negedge clk);
         if(check) begin
           if(out_int[c*W+:W]!==et || $signed(out_exp[c*10+:10])!=ee || invalid[c]!==ebad[0] || out_of_contract[c]!==ebound[0] || inexact[c]!==einex[0] || out_id[c*IDW+:IDW]!==expect_id)
             $fatal(1,"core %0d row %0d mismatch: T=%0d E=%0d inv=%0d ooc=%0d inexact=%0d id=%0d expected T=%0d E=%0d inv=%0d inexact=%0d id=%0d",c,count,$signed(out_int[c*W+:W]),$signed(out_exp[c*10+:10]),invalid[c],out_of_contract[c],inexact[c],out_id[c*IDW+:IDW],$signed(et),ee,ebad,einex,expect_id);
         end
         out_ready[c]=1;@(negedge clk);out_ready[c]=0;
         count=count+1;expect_id=expect_id+1;
       end
       $fclose(file);
       per_core_count[c]=count;
     end
   endtask
 end endgenerate
 task reset_all;
   begin @(negedge clk);rst=1;start=0;meta_valid=0;in_valid=0;out_ready=0;repeat(3)@(negedge clk);rst=0; end
 endtask
 integer i,pend;
 initial begin
   reset_all();
   // phase 0: partial run on every core, then an abrupt reset while cores and the queue are busy
   checking=0;
   fork
@FORK0@
   join_none
   repeat(@RESET_AT@)@(negedge clk);
   disable fork;
   reset_all();
   if(queue_count!==0 || ret_valid!==0 || rc_pending!==0) $fatal(1,"state not cleared by reset");
   // phase 1: full checked run on every core
   checking=1;phase=1;
   fork
@FORK1@
   join
   // drain the return path
   repeat(2000)@(negedge clk);
   pend=0;for(i=0;i<N*256;i=i+1) if(exp_pend[i]) begin pend=pend+1;$display("ERROR: missing return idx %0d",i); end
   if(pend!=0 || ret_errors!=0) $fatal(1,"return path errors: missing=%0d errors=%0d",pend,ret_errors);
   $display("PASS cores=%0d transactions=%0d returns=%0d qpeak=%0d",N,@TOTAL@,returns,qpeak);$finish;
 end
 initial begin #400000000;$fatal(1,"timeout");end
endmodule
'''


def vectors_for_core(k, f, dmax, c, n_random, rng, data_cases=()):
    """Transaction list for one core: directed flag/contract cases + random + real data."""
    from .hardware import transactions
    cases = transactions(k, f, n_random, seed=20261018 + c, flag_cases=True)
    b = k // 32
    # out-of-contract records: spread > D_MAX with a non-zero shifted block (flagged, then reported ooc)
    for gap in (dmax + 1, dmax + 6):
        x = np.zeros(k, dtype=np.uint8); w = x.copy(); x[:3] = 1; w[:3] = 1
        xs = np.full(b, 128, dtype=np.uint8); ws = np.full(b, 128, dtype=np.uint8); xs[0] = 128 - gap
        cases.append((x, xs, w, ws))
    cases += list(data_cases)
    rng.shuffle(cases)
    return cases


def verify_system(root, n=4, f=2, dmax=24, q=2, k=128, n_random=40, n_data=24, data=(), result_dir='system_rtl', reset_at=600):
    root = Path(root)
    if not re.fullmatch(r'[a-zA-Z0-9_]+', result_dir): raise ValueError('bad result dir')
    b = k // 32; w = width(k, f); wh = 14 + (b - 1).bit_length() + dmax; idw = 8; cw = max(1, (n - 1).bit_length()); qw = q.bit_length()
    out = root / 'results' / result_dir / f'n{n}_k{k}_f{f}_q{q}_d{dmax}'; out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(7)
    real = []
    for path in data:
        d = np.load(path, allow_pickle=False); xc_, xs_, _ = quantize(d['x']); wc_, ws_, _ = quantize(d['w'])
        if xc_.shape[1] * 32 != k: continue
        for i in range(min(n_data, len(xc_))):
            m = i % len(wc_); real.append((xc_[i].flatten().astype(np.uint8), xs_[i].astype(np.uint8), wc_[m].flatten().astype(np.uint8), ws_[m].astype(np.uint8)))
    def packed(a, bits): return sum(int(v) << (bits * i) for i, v in enumerate(a))
    total = 0; flagged = 0; ooc_n = 0
    for c in range(n):
        cases = vectors_for_core(k, f, dmax, c, n_random, rng, real[c::n])
        lines = []
        for xc, xs, wc, ws in cases:
            t, e, bad, contract = scalar_dot(xc.tolist(), xs.tolist(), wc.tolist(), ws.tolist(), f, None)
            flag = (not bad) and scalar_inexact(xc.tolist(), xs.tolist(), wc.tolist(), ws.tolist(), f)
            if flag:
                ss, es = record(xc.tolist(), xs.tolist(), wc.tolist(), ws.tolist()); et, ee, ooc = merge_exact(ss, es, dmax)
            else:
                et, ee, ooc = 0, 0, False
            flagged += flag; ooc_n += (flag and ooc)
            lines.append(f'{packed(xs,8):x} {packed(ws,8):x} {packed(xc,4):x} {packed(wc,4):x} {t&((1<<w)-1):x} {e} {int(bad)} {int(contract)} {int(flag)} {int(ooc)} {et&((1<<wh)-1):x} {ee}')
        (out / f'vectors_c{c}.txt').write_text('\n'.join(lines) + '\n'); total += len(cases)
    fork0 = '\n'.join(f'     drv[{c}].run_file(0,-1);' for c in range(n))
    fork1 = '\n'.join(f'     drv[{c}].run_file(1,-1);' for c in range(n))
    tb = TB
    for key, val in [('N', n), ('K', k), ('F', f), ('W', w), ('WH', wh), ('DMAX', dmax), ('Q', q), ('IDW', idw), ('CW', cw), ('QW', qw),
                     ('FORK0', fork0), ('FORK1', fork1), ('RESET_AT', reset_at), ('TOTAL', total)]:
        tb = tb.replace('@' + key + '@', str(val))
    (out / 'tb.sv').write_text(tb)
    exe = shutil.which('iverilog'); vvp = shutil.which('vvp')
    if not exe or not vvp: raise RuntimeError('Icarus Verilog required')
    srcs = [str((root / p).resolve()) for p in ['rtl/dot_top_rc.sv', 'rtl/rc_merge.sv', 'rtl/mxsys_top.sv']]
    cp = subprocess.run([exe, '-g2012', '-s', 'tb', '-o', 'sim.vvp'] + srcs + ['tb.sv'], cwd=out, text=True, capture_output=True)
    (out / 'compile.log').write_text(cp.stdout + cp.stderr)
    if cp.returncode: raise RuntimeError(cp.stderr[-3000:])
    run = subprocess.run([vvp, 'sim.vvp'], cwd=out, text=True, capture_output=True, timeout=1800)
    (out / 'simulation.log').write_text(run.stdout + run.stderr)
    m = re.search(r'PASS cores=(\d+) transactions=(\d+) returns=(\d+) qpeak=(\d+)', run.stdout)
    if run.returncode or not m: raise RuntimeError((run.stdout + run.stderr)[-3000:])
    row = {'n': n, 'k': k, 'f': f, 'dmax': dmax, 'q': q, 'transactions_per_phase': total, 'checked_transactions': int(m[2]),
           'flagged_expected': int(flagged), 'returns': int(m[3]), 'out_of_contract_returns': int(ooc_n), 'queue_peak': int(m[4]),
           'mismatches': 0, 'status': 'pass', 'mid_run_reset': True,
           'rtl_sha256': {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in ['rtl/dot_top_rc.sv', 'rtl/rc_merge.sv', 'rtl/mxsys_top.sv']},
           'iverilog_version': subprocess.run([exe, '-V'], text=True, capture_output=True).stdout.splitlines()[0]}
    (out / 'summary.json').write_text(json.dumps(row, indent=2)); return row
