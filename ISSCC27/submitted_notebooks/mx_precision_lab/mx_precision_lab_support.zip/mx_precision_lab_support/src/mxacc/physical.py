"""Import completed post-route evidence, without accepting a user-supplied clock."""
from pathlib import Path
import json,re,shutil
from .implementation import sha256,json_hash,conditions,rtl_evidence

METRICS={
 'cell_area_um2':['design__instance__area__stdcell'],
 'setup_wns_ns':['timing__setup__ws'],
 'hold_wns_ns':['timing__hold__ws'],
 'unconstrained_paths':['timing__unconstrained__count'],
 'lvs_errors':['design__lvs_error__count'],
 'max_slew_violations':['design__max_slew_violation__count'],
 'max_cap_violations':['design__max_cap_violation__count'],
 'unannotated_signal_nets':['timing__unannotated_net_filtered__count'],
}


def parse_metrics(metrics):
    def pick(names):
        for key in names:
            if key in metrics:return metrics[key]
        return None
    row={key:pick(names) for key,names in METRICS.items()}
    row['total_instance_area_um2']=metrics.get('design__instance__area')
    row['filler_area_um2']=metrics.get('design__instance__area__class:fill_cell')
    # Keep the individual DRC engines visible. A failing engine cannot be hidden
    # by a zero count in another engine.
    drc={key:metrics[key] for key in ['route__drc_errors','magic__drc_error__count','klayout__drc_error__count','design__drc_error__count'] if key in metrics}
    row['drc_by_engine']=drc
    full_drc=any(k in drc for k in ['magic__drc_error__count','klayout__drc_error__count','design__drc_error__count'])
    row['drc_errors']=max(drc.values()) if full_drc else None
    return row


def constraint_coverage(reports):
    """Parse the explicit check_setup section, never absence of a whole report.

    OpenSTA check_setup warns when an unconstrained endpoint exists. Its verbose
    section is empty when there are no violations. All supplied corner reports
    must contain the completed command section and no missing-constraint warning.
    """
    if not reports:return None
    counts=[]
    for text in reports:
        marker=('check_setup -verbose -unconstrained_endpoints -multiple_clock '
                '-no_clock -no_input_delay -loops -generated_clocks')
        if marker not in text:return None
        tail=text.split(marker,1)[1]
        if not re.match(r'\s*={20,}\s*',tail):return None
        # The section starts with the command's remaining arguments and divider.
        # Any explicit warning concerning timing coverage prevents qualification.
        warnings=re.findall(r'(?:Warning|Error):[^\n]*',tail,re.I)
        unknown=[w for w in warnings if not re.search(r'unconstrained|no clock|no input delay',w,re.I)]
        if unknown:return None
        count=0
        for w in warnings:
            m=re.search(r'(?:There (?:are|is) )?(\d+) ',w)
            if not m:return None
            count+=int(m[1])
        # Empty section is the explicit, successful zero-violation result.
        if re.search(r'Error|STA-\d+',tail) and not warnings:return None
        counts.append(count)
    return max(counts)


def import_run(root,run_dir,f):
    root,run_dir=Path(root).resolve(),Path(run_dir).resolve()
    plan=json.loads((run_dir/'mxacc_input.json').read_text())
    if plan['f']!=f or plan['k']!=128 or plan['lanes']!=4:raise ValueError('Run architecture mismatch')
    config=json.loads((root/f'flow/f{f}/config.json').read_text())
    environment=json.loads((root/'flow/environment.json').read_text())
    if plan['conditions']!=conditions(config,environment):raise ValueError('Run conditions differ from current project')
    for rel,digest in plan['source_hashes'].items():
        if sha256(root/rel)!=digest:raise ValueError('RTL changed since run started: '+rel)
    resolved=json.loads((run_dir/'resolved.json').read_text())
    if resolved['DESIGN_NAME']!=plan['top'] or resolved['CLOCK_PERIOD']!=config['CLOCK_PERIOD']:
        raise ValueError('Resolved run top/clock does not match original plan')
    if resolved.get('PDK')!=environment['pdk'] or resolved.get('STD_CELL_LIBRARY')!=environment['scl']:
        raise ValueError('Resolved PDK/SCL mismatch')
    config_dir=(root/f'flow/f{f}').resolve()
    def same(key,value):
        got=resolved.get(key)
        if isinstance(value,str) and value.startswith('dir::'):
            # file settings are resolved by LibreLane to absolute paths; compare the files they name
            return got is not None and Path(str(got)).resolve()==(config_dir/value[5:]).resolve()
        return got==value
    for key,value in config.items():
        if key!='VERILOG_FILES' and not same(key,value):
            raise ValueError('Resolved implementation setting differs: '+key)
    resolved_sources={str(Path(p).resolve()) for p in resolved.get('VERILOG_FILES',[])}
    expected_sources={str((root/rel).resolve()) for rel in plan['source_hashes']}
    if resolved_sources!=expected_sources:raise ValueError('Resolved RTL file set mismatch')
    raw=json.loads((run_dir/'final/metrics.json').read_text())
    sta=sorted(p for p in run_dir.iterdir() if p.is_dir() and p.name.endswith('-openroad-stapostpnr'))
    if not sta or not (sta[-1]/'state_out.json').exists():raise ValueError('Post-route STA completion evidence missing')
    if not list((run_dir/'final').rglob('*.gds')):raise ValueError('Final GDS is missing')
    # Use post-route STA's own metrics for timing, not a pre-route metric left
    # behind in a partially completed flow.
    sta_state=json.loads((sta[-1]/'state_out.json').read_text())
    sta_raw=sta_state['metrics']; row=parse_metrics(raw)
    for key in ['setup_wns_ns','hold_wns_ns','unconstrained_paths','max_slew_violations','max_cap_violations','unannotated_signal_nets']:
        row[key]=parse_metrics(sta_raw)[key]
    checks=sorted(sta[-1].rglob('checks.rpt'))
    if row['unconstrained_paths'] is None:
        corners=resolved.get('STA_CORNERS',[])
        row['unconstrained_paths']=(constraint_coverage([p.read_text() for p in checks])
                                    if corners and len(checks)==len(corners) else None)
    rt=rtl_evidence(root,f)
    folder=root/f'results/physical/f{f}';folder.mkdir(parents=True,exist_ok=True)
    evidence=folder/'evidence';evidence.mkdir(exist_ok=True)
    sources={'metrics.json':run_dir/'final/metrics.json','resolved.json':run_dir/'resolved.json',
             'mxacc_input.json':run_dir/'mxacc_input.json','sta_state_out.json':sta[-1]/'state_out.json'}
    for i,p in enumerate(checks):sources[f'checks_{i}.rpt']=p
    for p in sorted(sta[-1].rglob('*.rpt')):
        if p.name in {'max.rpt','min.rpt','ws.max.rpt','ws.min.rpt'}:
            sources['sta/'+str(p.relative_to(sta[-1]))]=p
    for step in run_dir.iterdir():
        if step.is_dir() and step.name.endswith(('-magic-drc','-netgen-lvs','-klayout-xor','-klayout-drc','-checker-xor')):
            for p in step.rglob('*'):
                if p.is_file() and p.name not in {'state_in.json','state_out.json','config.json'} and p.suffix in {'.rpt','.log','.json','.xml'}:
                    sources['signoff/'+step.name+'/'+str(p.relative_to(step))]=p
    if (run_dir/'flow.log').exists():sources['flow.log']=run_dir/'flow.log'
    for name,p in sources.items():
        (evidence/name).parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p,evidence/name)
    # Keep the deliverable final views (layout, netlists, constraints, render, metrics);
    # the ODB database, Magic views, SPEF/SDF/lib and SPICE are regenerable and large.
    views=folder/'final'
    if views.exists():shutil.rmtree(views)
    keep={'gds','klayout_gds','def','lef','nl','pnl','sdc','render','json_h','vh'}
    for item in (run_dir/'final').iterdir():
        if item.is_dir() and item.name in keep:shutil.copytree(item,views/item.name)
        elif item.is_file():
            views.mkdir(parents=True,exist_ok=True);shutil.copy2(item,views/item.name)
    manifest={**plan,'completed_post_route':True,'original_run_dir':str(run_dir),
              'reported_metrics':dict(row),
              'evidence_files':{name:sha256(evidence/name) for name in sources},
              'final_view_hashes':{str(p.relative_to(folder)):sha256(p) for p in views.rglob('*') if p.is_file()}}
    mp=evidence/'manifest.json';mp.write_text(json.dumps(manifest,indent=2))
    row.update(schema_version='0.2',f=f,k=128,lanes=4,stage='post_route',
               clock_period_ns=resolved['CLOCK_PERIOD'],rtl_sha256=sha256(root/'rtl/dot_top.sv'),
               rtl_pass=rt is not None,ii_no_stall=None if rt is None else rt['ii_no_stall'],
               comparison_signature=manifest['comparison_signature'],
               evidence_manifest=str(mp.relative_to(root)),evidence_manifest_sha256=sha256(mp),
               metric_units={'area':'um^2','slack':'ns'},source='actual_librelane_run')
    row['sta_corners']=resolved.get('STA_CORNERS',[])
    row['constraint_coverage_reports']=len(checks)
    row['xor_differences']=raw.get('design__xor_difference__count')
    row['klayout_drc_status']=('not_evaluated: LibreLane 3.0.16 has no KLayout DRC runset for gf180mcu (step skipped by the tool)'
                               if raw.get('klayout__drc_error__count') is None else 'evaluated')
    row['xor_engine']='KLayout.XOR (native)'; row['drc_engine']='Magic drc(full)'
    output=root/f'results/physical/f{f}.json';output.write_text(json.dumps(row,indent=2));return row
