"""Shared stimulus for the C++ performance model and the RTL trace testbench (v0.4).

One case = one directory with
  manifest.json      parameters, reset plan, mask thresholds, window, hashes, provenance
  tx_c<c>.txt        the ordered transactions of core c (one row each, see ROW_FORMAT)
  masks.txt          one hex word per cycle: bit 0 = ret_ready offer, bits 4c+1..4c+4 =
                     start / metadata / data / result-ready offer of core c
Both consumers read exactly these files (docs/perf_contract.md section 5). The expected
values in the rows come from the bit-exact Python model (mxacc.arithmetic / recompute /
system) so that the RTL testbench keeps checking arithmetic while the C++ model only reads
the control columns (ordinal, arrival, bad, inexact, ooc, spread).
"""
from pathlib import Path
import hashlib, json
import numpy as np
from .arithmetic import quantize, groups, accumulate, exact, scalar_dot, width, decode
from .recompute import scalar_inexact, inexact_flags
from .system import record, merge_exact

STIMULUS_VERSION = '0.4.0'
ROW_FORMAT = 'ordinal arrival bad inexact ooc spread xs ws xc wc t e bound exact_t exact_e'
MASK_STREAMS = ('start', 'meta', 'data', 'out')          # per core, bits 4c+1 .. 4c+4
RTL_FILES = ['rtl/dot_top_rc.sv', 'rtl/rc_merge.sv', 'rtl/mxsys_top.sv']
INITIAL_RESET = (0, 3)

M64 = np.uint64(0xFFFFFFFFFFFFFFFF)


def splitmix64(x):
    """splitmix64 finaliser on uint64 arrays (wrapping arithmetic); identical in cpp/src/perf_model.cpp."""
    z = (x + np.uint64(0x9E3779B97F4A7C15)) & M64
    z = ((z ^ (z >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)) & M64
    z = ((z ^ (z >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)) & M64
    return z ^ (z >> np.uint64(31))


def mask_words(seed, stream, cycles):
    """16-bit words of stream `stream` (0 = ret, 1 + 4c + j for core c interface j) for cycles 0..cycles-1."""
    t = np.arange(cycles, dtype=np.uint64)
    x = (np.uint64(seed) ^ (np.uint64(stream) << np.uint64(48)) ^ (t << np.uint64(8))) & M64
    return (splitmix64(x) & np.uint64(0xFFFF)).astype(np.int64)


def threshold(p):
    """Offer probability p -> integer threshold: the bit is 1 iff word >= thr, so P(1) = p exactly in 1/65536 steps."""
    return int(round((1.0 - float(p)) * 65536))


def stream_id(core, iface):
    return 1 + 4 * core + MASK_STREAMS.index(iface)


def build_masks(seed, n, cycles, thresholds, segments=()):
    """Bool matrix [cycles, 4n+1]. thresholds: dict iface->thr for 'ret','start','meta','data','out'.
    segments: list of dict(iface, start, end, thr[, core]) overriding the threshold on a cycle range
    (core None = every core)."""
    nb = 4 * n + 1
    thr = np.zeros((cycles, nb), dtype=np.int64)
    thr[:, 0] = thresholds['ret']
    for c in range(n):
        for j, iface in enumerate(MASK_STREAMS):
            thr[:, 1 + 4 * c + j] = thresholds[iface]
    for s in segments:
        a, b = max(0, int(s['start'])), min(cycles, int(s['end']))
        if s['iface'] == 'ret':
            thr[a:b, 0] = s['thr']
        else:
            for c in ([s['core']] if s.get('core') is not None else range(n)):
                thr[a:b, 1 + 4 * c + MASK_STREAMS.index(s['iface'])] = s['thr']
    words = np.stack([mask_words(seed, sid, cycles) for sid in range(nb)], axis=1)
    return words >= thr


def masks_to_lines(bits):
    """Pack each row (LSB = column 0) into a hex word."""
    cycles, nb = bits.shape
    out = []
    for row in bits:
        v = 0
        for j in np.nonzero(row)[0]:
            v |= 1 << int(j)
        out.append(f'{v:x}')
    return out


def packed(a, bits):
    return sum(int(v) << (bits * i) for i, v in enumerate(a))


def tx_row(ordinal, arrival, xc, xs, wc, ws, f, dmax, k, light=False):
    """One transaction row (ROW_FORMAT). light=True writes '-' payload columns (C++-only files)."""
    xc, xs, wc, ws = [list(map(int, a)) for a in (xc, xs, wc, ws)]
    w = width(k, f); wh = 14 + (k // 32 - 1).bit_length() + dmax
    t, e, bad, bound = scalar_dot(xc, xs, wc, ws, f, None)
    flag = (not bad) and scalar_inexact(xc, xs, wc, ws, f)
    if bad:
        spread = 0; et, ee, ooc = 0, 0, False
    else:
        ss, es = record(xc, xs, wc, ws); spread = max(es) - min(es)
        et, ee, ooc = merge_exact(ss, es, dmax) if flag else (0, 0, False)
    ctrl = f'{ordinal} {arrival} {int(bad)} {int(flag)} {int(ooc)} {spread}'
    if light:
        return ctrl + ' - - - - - - - - -', flag, ooc, bad
    return (ctrl + f' {packed(xs, 8):x} {packed(ws, 8):x} {packed(xc, 4):x} {packed(wc, 4):x} '
            f'{t & ((1 << w) - 1):x} {e} {int(bound)} {et & ((1 << wh) - 1):x} {ee}'), flag, ooc, bad


def rows_from_arrays(xc, xs, wc, ws, pairs, f, dmax, arrivals=None, ordinal0=0, light=False, chunk=8192):
    """Vectorised rows for real data: pairs = list of (i, m) activation/weight indices.
    Returns (lines, flags, oocs, bads) in order. Evaluated in chunks to bound memory."""
    if len(pairs) > chunk:
        lines, flags, oocs, bads = [], [], [], []
        for s0 in range(0, len(pairs), chunk):
            l, fl, oo, bd = rows_from_arrays(xc, xs, wc, ws, pairs[s0:s0 + chunk], f, dmax, None if arrivals is None else arrivals[s0:s0 + chunk], ordinal0 + s0, light, chunk)
            lines += l; flags += fl; oocs += oo; bads += bd
        return lines, flags, oocs, bads
    k = xc.shape[1] * 32; b = k // 32
    ii = np.array([p[0] for p in pairs]); mm = np.array([p[1] for p in pairs])
    w = width(k, f); wh = 14 + (b - 1).bit_length() + dmax
    # evaluate pairwise (not all-pairs): loop over blocks with einsum on the selected pairs
    x = decode(xc[ii]); wv = decode(wc[mm])
    sums = np.einsum('nbj,nbj->nb', x, wv, dtype=np.int64)
    exps = xs[ii].astype(np.int16) + ws[mm].astype(np.int16) - 256
    invalid = np.any((xs[ii] == 255) | (ws[mm] == 255), axis=-1)
    from .arithmetic import Groups
    g = Groups(sums, exps, invalid)
    t_all, e_all = accumulate(g, f)
    flags = inexact_flags(g, f) & ~invalid
    emax = exps.max(axis=-1); emin = exps.min(axis=-1); spread = np.where(invalid, 0, emax - emin)
    lines = []; oocs = []
    for n in range(len(pairs)):
        ordinal = ordinal0 + n; arrival = 0 if arrivals is None else int(arrivals[n])
        bad = bool(invalid[n]); flag = bool(flags[n])
        if flag:
            et, ee, ooc = merge_exact([int(v) for v in sums[n]], [int(v) for v in exps[n]], dmax)
        else:
            et, ee, ooc = 0, 0, False
        oocs.append(ooc)
        ctrl = f'{ordinal} {arrival} {int(bad)} {int(flag)} {int(ooc)} {int(spread[n])}'
        if light:
            lines.append(ctrl + ' - - - - - - - - -'); continue
        lines.append(ctrl + f' {packed(xs[ii[n]], 8):x} {packed(ws[mm[n]], 8):x} {packed(xc[ii[n]].flatten(), 4):x} {packed(wc[mm[n]].flatten(), 4):x} '
                     f'{int(t_all[n]) & ((1 << w) - 1):x} {int(e_all[n])} 0 {et & ((1 << wh) - 1):x} {ee}')
    return lines, flags.tolist(), oocs, invalid.tolist()


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_case(case_dir, params, core_lines, masks_bits, resets, window, meta, root=None, max_cycles=None):
    """Write tx files, masks and manifest; return the manifest dict. masks_bits=None: no mask file (C++ generated masks,
    max_cycles must be given)."""
    case_dir = Path(case_dir); case_dir.mkdir(parents=True, exist_ok=True)
    n = params['n']
    for c in range(n):
        (case_dir / f'tx_c{c}.txt').write_text('\n'.join(core_lines[c]) + ('\n' if core_lines[c] else ''))
    files = {f'tx_c{c}.txt': sha256_file(case_dir / f'tx_c{c}.txt') for c in range(n)}
    if masks_bits is not None:
        (case_dir / 'masks.txt').write_text('\n'.join(masks_to_lines(masks_bits)) + '\n')
        files['masks.txt'] = sha256_file(case_dir / 'masks.txt'); max_cycles = int(masks_bits.shape[0])
    stats = {'transactions': int(sum(len(l) for l in core_lines)),
             'per_core': [len(l) for l in core_lines],
             'flagged': int(sum(int(l.split()[3]) for ls in core_lines for l in ls)),
             'out_of_contract': int(sum(int(l.split()[4]) for ls in core_lines for l in ls)),
             'invalid': int(sum(int(l.split()[2]) for ls in core_lines for l in ls))}
    manifest = {'stimulus_version': STIMULUS_VERSION, 'row_format': ROW_FORMAT, 'params': params,
                'resets': [list(r) for r in resets], 'max_cycles': int(max_cycles), 'window': list(window) if window else None,
                'stats': stats, 'files': files, **meta}
    if root is not None:
        manifest['rtl_sha256'] = {p: sha256_file(Path(root) / p) for p in RTL_FILES}
    (case_dir / 'manifest.json').write_text(json.dumps(manifest, indent=1))
    return manifest


def case_params(n, k, f, q, dmax, id_w=8):
    b = k // 32
    return {'n': n, 'k': k, 'b': b, 'f': f, 'q': q, 'dmax': dmax, 'id_w': id_w, 'w': width(k, f),
            'w_h': 14 + (b - 1).bit_length() + dmax, 'core_w': max(1, (n - 1).bit_length()),
            'rec_w': max(1, (n - 1).bit_length()) + id_w + 23 * b, 'ii0': 9 * b + 4, 's0': b + 3}


def estimate_cycles(per_core_counts, params, thresholds, resets=(), slack=4000):
    """Generous upper bound on the run length (mask rows to generate)."""
    worst = max(per_core_counts) if per_core_counts else 0
    p_in = max(min(1 - thresholds[i] / 65536 for i in ('start', 'meta', 'data', 'out')), 0.05)
    p_ret = max(1 - thresholds['ret'] / 65536, 0.1)
    n = len(per_core_counts)
    return int(worst * params['ii0'] / p_in * 1.2 + n * worst * params['s0'] / p_ret + sum(int(r[1]) for r in resets) + slack)


# ---------------------------------------------------------------- synthetic transactions
def _rand_codes(rng, k):
    return rng.integers(0, 16, k).astype(np.uint8)


def gen_exact(rng, k, f, n_tx):
    """Transactions whose block spread is <= F (all left shifts): never flagged."""
    b = k // 32; out = []
    while len(out) < n_tx:
        base = int(rng.integers(100, 150)); offs = rng.integers(0, f + 1, b) if f > 0 else np.zeros(b, dtype=int)
        xs = (base + offs).astype(np.uint8); ws = np.full(b, 128, dtype=np.uint8)
        xc, wc = _rand_codes(rng, k), _rand_codes(rng, k)
        if not scalar_inexact(xc.tolist(), xs.tolist(), wc.tolist(), ws.tolist(), f):
            out.append((xc, xs, wc, ws))
    return out


def gen_flagged(rng, k, f, dmax, n_tx, spread_lo=None, spread_hi=None):
    """Random transactions guaranteed flagged and in contract (spread in [F+1, min(12, D_MAX)])."""
    b = k // 32; out = []
    if b == 1: raise ValueError('a single-block transaction (K = 32) can never be flagged: its only alignment shift is +F')
    lo = f + 1 if spread_lo is None else spread_lo; hi = min(12, dmax) if spread_hi is None else spread_hi
    while len(out) < n_tx:
        base = int(rng.integers(110, 140)); offs = rng.integers(0, hi - lo + 1, b); offs[rng.integers(0, b)] = 0
        xs = (base - lo - offs).astype(np.uint8); xs[rng.integers(0, b)] = base    # one block at E_max, others lower
        ws = np.full(b, 128, dtype=np.uint8)
        xc, wc = _rand_codes(rng, k), _rand_codes(rng, k)
        es = [int(a) + int(c) - 256 for a, c in zip(xs, ws)]
        if max(es) - min(es) > dmax: continue
        if scalar_inexact(xc.tolist(), xs.tolist(), wc.tolist(), ws.tolist(), f):
            out.append((xc, xs, wc, ws))
    return out


def gen_contract_edge(k, f, dmax, gap):
    """Block 0 at E_max - gap with S_0 = 1 (odd): flagged; in contract iff gap <= D_MAX."""
    b = k // 32
    x = np.zeros(k, dtype=np.uint8); w = x.copy(); x[0] = 1; w[0] = 1
    xs = np.full(b, 128, dtype=np.uint8); ws = np.full(b, 128, dtype=np.uint8); xs[0] = 128 - gap
    if b == 1:   # single block: use a right shift inside the block's own exponent (cannot be > D_MAX)
        xs[0] = 128
    return (x, xs, w, ws)


def mix_flagged(rng, k, f, dmax, pattern):
    """pattern: list of 0/1 per transaction (1 = flagged). Returns transaction tuples."""
    n1 = int(sum(pattern)); n0 = len(pattern) - n1
    fl = gen_flagged(rng, k, f, dmax, n1); ex = gen_exact(rng, k, f, n0)
    out = []; i1 = i0 = 0
    for p in pattern:
        if p: out.append(fl[i1]); i1 += 1
        else: out.append(ex[i0]); i0 += 1
    return out


SCENARIOS = ('A_no_flags', 'B_all_flagged', 'C_arbitration_contract', 'D_fifo_boundary', 'E_backpressure', 'F_reset_idwrap')
DEV_CONFIGS = ((1, 1), (4, 2), (16, 4))
HELDOUT_CONFIGS = ((1, 2), (1, 4), (4, 1), (4, 4), (16, 1), (16, 2))


def case_seed(name):
    return int.from_bytes(hashlib.sha256(name.encode()).digest()[:4], 'little')


def synthetic_case(root, out_dir, scenario, n, q, k=128, f=2, dmax=24, tx_per_core=None):
    """Build one synthetic validation case (scenarios A-F of docs/perf_contract.md / the plan)."""
    name = f'{scenario}_n{n}_q{q}_k{k}_f{f}'
    seed = case_seed(name); rng = np.random.default_rng(seed)
    params = case_params(n, k, f, q, dmax); b = params['b']
    full = {'ret': threshold(1.0), 'start': threshold(1.0), 'meta': threshold(1.0), 'data': threshold(1.0), 'out': threshold(1.0)}
    thr = dict(full); segments = []; resets = [INITIAL_RESET]; arrivals = None
    per_core = []
    base_n = tx_per_core or {1: 80, 4: 60, 16: 40}.get(n, 40)
    if scenario == 'A_no_flags':
        for c in range(n): per_core.append(gen_exact(rng, k, f, base_n))
        thr.update(start=threshold(0.8), meta=threshold(0.9), data=threshold(0.9), out=threshold(0.9), ret=threshold(0.5))
    elif scenario == 'B_all_flagged':
        for c in range(n): per_core.append(gen_flagged(rng, k, f, dmax, base_n))
        thr.update(ret=threshold(0.75))
    elif scenario == 'C_arbitration_contract':
        for c in range(n):
            pat = []
            for j in range(base_n):
                if j < base_n // 3: pat.append(1)                                    # all cores request together (same timing)
                elif j < 2 * base_n // 3: pat.append(1 if (j + c) % max(n, 2) == 0 else 0)   # single requester, alternating
                else: pat.append(int(rng.random() < 0.5))
            txs = mix_flagged(rng, k, f, dmax, pat)
            txs.append(gen_contract_edge(k, f, dmax, dmax)); txs.append(gen_contract_edge(k, f, dmax, dmax + 1)); txs.append(gen_contract_edge(k, f, dmax, dmax + 7))
            per_core.append(txs)
        thr.update(ret=threshold(0.9))
    elif scenario == 'D_fifo_boundary':
        for c in range(n): per_core.append(gen_flagged(rng, k, f, dmax, base_n))
        thr.update(ret=threshold(0.7))
        ii0 = params['ii0']
        segments = [{'iface': 'ret', 'start': ii0 * 2, 'end': ii0 * 2 + (q + 3) * ii0, 'thr': threshold(0.0)},   # return blocked long enough to fill the queue
                    {'iface': 'ret', 'start': ii0 * (q + 12), 'end': ii0 * (q + 12) + 3 * ii0, 'thr': threshold(0.0)},
                    {'iface': 'ret', 'start': ii0 * (q + 20), 'end': ii0 * (q + 20) + 6 * ii0, 'thr': threshold(0.15)}]
    elif scenario == 'E_backpressure':
        for c in range(n): per_core.append(mix_flagged(rng, k, f, dmax, [int(rng.random() < 0.5) for _ in range(base_n)]))
        ii0 = params['ii0']; span = base_n * ii0 * 2 // 3
        segments = [{'iface': 'start', 'start': 0, 'end': span, 'thr': threshold(0.5)}, {'iface': 'meta', 'start': 0, 'end': span, 'thr': threshold(0.5)},
                    {'iface': 'data', 'start': 0, 'end': span, 'thr': threshold(0.6)},
                    {'iface': 'out', 'start': span, 'end': 2 * span, 'thr': threshold(0.25)},       # result taken late: record handshake first
                    {'iface': 'ret', 'start': 2 * span, 'end': 3 * span, 'thr': threshold(0.2)},   # return back-pressure: queue fills, record late
                    {'iface': 'ret', 'start': 2 * span + 5 * ii0, 'end': 2 * span + 6 * ii0, 'thr': threshold(0.0)}]
    elif scenario == 'F_reset_idwrap':
        n_tx = max(tx_per_core or 0, 320)
        ii0 = params['ii0']; r_at = 4 * ii0
        for c in range(n):
            pat = [1] * 8 + [int(rng.random() < 0.3) for _ in range(n_tx - 8)]
            per_core.append(mix_flagged(rng, k, f, dmax, pat))
        segments = [{'iface': 'ret', 'start': 0, 'end': r_at, 'thr': threshold(0.0)}]   # returns blocked until the reset: queue and merge are busy at the reset edge
        resets = [INITIAL_RESET, (r_at, 3)]
        thr.update(ret=threshold(0.8), start=threshold(0.9))
    else:
        raise ValueError(scenario)
    lines = []
    for c in range(n):
        ls = []
        for o, (xc, xs, wc, ws) in enumerate(per_core[c]):
            line, *_ = tx_row(o, 0, xc, xs, wc, ws, f, dmax, k); ls.append(line)
        lines.append(ls)
    cycles = estimate_cycles([len(l) for l in lines], params, thr, resets)
    cycles = max(cycles, max((s['end'] for s in segments), default=0) + 2000)
    bits = build_masks(seed, n, cycles, thr, segments)
    meta = {'case': name, 'scenario': scenario, 'kind': 'synthetic', 'seed': seed, 'mask_thresholds': thr, 'mask_segments': segments,
            'rtl_consumable': True, 'provenance': {'generator': 'mxacc.perf_stimulus.synthetic_case', 'stimulus_version': STIMULUS_VERSION}}
    return write_case(out_dir, params, lines, bits, resets, None, meta, root=root), name


def real_case(root, out_dir, workload, n, q, f, dmax=24, tx_per_core=1024, split='calibration', ordering='original',
              k=None, thresholds=None, name=None, light=False, resets=(INITIAL_RESET,), window=None, segments=()):
    """Real-data case: transactions (i, m) in activation-major order dispatched round-robin to cores.

    ordering: 'original' | 'shuffled' (per-core seeded permutation of the same list) | 'burst' (per core,
    the flagged transactions are moved into one contiguous run in the middle; the multiset is unchanged).
    """
    from .workloads import load_workload
    wl = load_workload(root, workload); x = wl['x_cal'] if split == 'calibration' else wl['x_test']
    xc, xs, _ = quantize(x); wc, ws, _ = quantize(wl['w'])
    k = xc.shape[1] * 32; m_out = wc.shape[0]
    total = tx_per_core * n
    pairs = [(i, m) for i in range(len(xc)) for m in range(m_out)]
    if total > len(pairs): raise ValueError(f'{workload}: only {len(pairs)} transactions in {split}, {total} requested')
    pairs = pairs[:total]
    per_core = [pairs[c::n] for c in range(n)]
    name = name or f'R_{workload}_f{f}_{ordering}_n{n}_q{q}'
    seed = case_seed(name); rng = np.random.default_rng(seed)
    params = case_params(n, k, f, q, dmax)
    lines = []; flag_counts = []
    multiset = []
    for c in range(n):
        ls, flags, oocs, bads = rows_from_arrays(xc, xs, wc, ws, per_core[c], f, dmax, light=light)
        order = list(range(len(ls)))
        if ordering == 'shuffled':
            order = list(rng.permutation(len(ls)))
        elif ordering == 'burst':
            fl = [i for i in order if flags[i]]; ex = [i for i in order if not flags[i]]
            half = len(ex) // 2; order = ex[:half] + fl + ex[half:]
        elif ordering != 'original':
            raise ValueError(ordering)
        # renumber ordinals in the new order (the ordinal is the position in the core's issue order)
        rows = []
        for o, i in enumerate(order):
            parts = ls[i].split(); parts[0] = str(o); rows.append(' '.join(parts))
        multiset.append(sorted(' '.join(l.split()[2:]) for l in rows))
        lines.append(rows); flag_counts.append(int(sum(flags)))
    thr = thresholds or {'ret': threshold(1.0), 'start': threshold(1.0), 'meta': threshold(1.0), 'data': threshold(1.0), 'out': threshold(1.0)}
    cycles = estimate_cycles([len(l) for l in lines], params, thr, resets)
    bits = None if light else build_masks(seed, n, cycles, thr, list(segments))   # light cases use the C++ mask generator (same function, no file)
    meta = {'case': name, 'scenario': 'real_vectors', 'kind': 'real', 'seed': seed, 'mask_thresholds': thr, 'mask_segments': list(segments),
            'rtl_consumable': not light, 'workload': {'id': wl['id'], 'data_sha256': wl['data_sha256'], 'split': split, 'k': k, 'outputs': m_out,
                                                       'selection': f'first {total} (activation, output) pairs in activation-major order, transaction j -> core j mod N',
                                                       'ordering': ordering, 'per_core_flagged': flag_counts},
            'multiset_sha256': hashlib.sha256('\n'.join('\n'.join(m) for m in multiset).encode()).hexdigest(),
            'provenance': {'generator': 'mxacc.perf_stimulus.real_case', 'stimulus_version': STIMULUS_VERSION}}
    return write_case(out_dir, params, lines, bits, resets, window, meta, root=root, max_cycles=cycles), name
