"""The MXFP4 core studies of submission.ipynb (Sections 2, 7, 8 and 9, 11 to 13), one function per notebook cell.

Each function computes from the bit-exact integer model or reads the hashed records, prints a compact table and
returns its data, so the notebook cells stay short and the tests can call the same code. Nothing here estimates a
missing measurement: an absent record is printed as "not evaluated".
"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import textwrap
import numpy as np
from .arithmetic import CANDIDATES, Groups, accumulate, as_float, exact, groups, metrics, quantize, width
from .workloads import disparity_stats, exactness_threshold, load_workload, study
from .recompute import recompute_study
from .experiment import choose_hardware, comparison_table, numeric_experiment
from .implementation import load_implementations

BUDGETS = (1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 0.0)


def _fmt(v, spec='.3g', none='n/a'):
    return none if v is None else format(v, spec)


class EvidenceError(AssertionError):
    """An evidence check failed. The cell stops with this error, so Run all stops there and Section 15 builds no bundle."""


def _require(problems, what):
    if problems:
        raise EvidenceError(f'{what} failed; the run stops here and no submission bundle is built:\n  ' + '\n  '.join(problems))


def _json(root, rel):
    p = Path(root) / rel
    return json.loads(p.read_text()) if p.exists() else None


# ------------------------------------------------------------------------------------------------ shared configuration
def panel_config(lab, section=None):
    """The configuration the panels of Sections 3 to 9 hold now; Sections 7 to 12 analyse exactly this one."""
    s = lab.s
    cfg = dict(workload=s.layer_id, path=Path(s.layer.path), name=s.layer.name, k=s.layer.k, budget=s.acc_budget, total_budget=s.total_budget,
               clock_ns=s.clock_ns, min_rate=s.min_rate, backend=s.backend_id, test_role=s.layer.test_role)
    notes = []
    if s.backend_id != 'mxfp4_core': notes.append('the panels show the generic MX core; these studies use the MXFP4 core on the same layer and budget')
    if s.layer.k not in (128, 512): notes.append(f'K = {s.layer.k}: the MXFP4 core supports K128 and K512 only')
    if s.layer.x_test is None: notes.append('the test split of this layer is not in the support package, so the test-dependent steps below report that instead of a result')
    head = f"Configuration{' for Section ' + str(section) if section else ''} (shared with the panels of Sections 3 to 9): "
    print(head + f"{s.layer.name} [{s.layer_id}], K{s.layer.k}, MXFP4 core, accumulation budget {100 * s.acc_budget:g} %, "
          f"total budget {100 * s.total_budget:g} %, clock {s.clock_ns:g} ns, at least {s.min_rate:,.0f} dot products/s")
    for n in notes: print('  note: ' + n)
    return cfg


def _fixed(text):
    print('Fixed study case (independent of the panels): ' + text)


# ------------------------------------------------------------------------------------------------ Section 2
def worked_example(block2_sum=3, block2_exp=-4):
    """Two non-zero blocks, 8 at E = 0 and block2_sum at block2_exp: result and error for F0 to F12."""
    toy = Groups(np.array([[[8, block2_sum, 0, 0]]], dtype=np.int64), np.array([[[0, block2_exp, 0, 0]]], dtype=np.int16), np.array([[False]]))
    j, emin = exact(toy); spread = int(toy.exponents.max() - toy.exponents.min())
    print(f"exact sum {float(as_float(j, emin)[0, 0])}, block exponent spread {spread} bits\n")
    print(f"{'F':>3} {'W':>3}  {'result':>9}  {'abs error':>10}  {'bound (B/2)·2^(Emax-F)':>22}")
    rows = []
    for f in (0, 2, 4, 8, 12):
        t, e = accumulate(toy, f); m = metrics(toy, f, (j, emin)); rows.append(dict(f=f, result=float(as_float(t, e)[0, 0]), abs_error=m['max_abs'], bound=m['max_bound']))
        print(f"{f:>3} {width(128, f):>3}  {rows[-1]['result']:>9g}  {m['max_abs']:>10.6g}  {m['max_bound']:>22.6g}" + ("   exact: F ≥ spread" if f >= spread else ""))
    assert all(metrics(toy, f, (j, emin))['max_abs'] == 0 for f in CANDIDATES if f >= spread), 'F >= spread must be exact'
    divisible = Groups(np.array([[[8, 4, 0, 0]]], dtype=np.int64), np.array([[[0, -2, 0, 0]]], dtype=np.int16), np.array([[False]]))
    assert metrics(divisible, 0)['max_abs'] == 0, 'a right shift whose discarded bits are zero is exact (sufficient, not necessary)'
    return dict(spread=spread, rows=rows)


# ------------------------------------------------------------------------------------------------ Section 7
def numeric_record(root, cfg, e_bound=0, abs_tol=0.01):
    """The numeric stage that the hardware stage consumes (calibration only; the test rows are not consulted).
    A candidate passes only if it meets both budgets of the panels: accumulation NRMSE and total NRMSE against FP32."""
    root = Path(root); out = root / 'results/notebook_run'
    workload = cfg['path'] if isinstance(cfg, dict) else root / 'data/workloads' / cfg
    budget = cfg['budget'] if isinstance(cfg, dict) else 1e-3
    total = cfg.get('total_budget') if isinstance(cfg, dict) else None
    numeric = numeric_experiment(root, budget, e_bound, abs_tol, out=out, workload=workload, total_tolerance=total)
    print(f"{numeric['workload']}: K{numeric['k']}, P{numeric['lanes']}, accumulation budget {numeric['tolerance']:g}"
          + (f", total budget {total:g}" if total is not None else '') + f", data {numeric['data_sha256'][:12]}…")
    if total is not None:
        print(f"  {'F':>3} {'accumulation NRMSE':>19} {'total NRMSE':>12}  meets both")
        for r in numeric['calibration']:
            print(f"  {r['f']:>3} {r['nrmse']:>19.4g} {r['nrmse_vs_fp32']:>12.4g}  {'yes' if r['f'] in numeric['feasible_f'] else 'no'}")
    f = numeric['numeric_recommendation_f']
    if f is None:
        floor = min(r['nrmse_vs_fp32'] for r in numeric['calibration'])
        why = (f"the total error is at least {100 * floor:.2f} % at every F (input quantization, which F cannot reduce), above the total budget {100 * total:g} %"
               if total is not None and floor > total else 'no candidate meets the budgets on calibration')
        print(f"  numeric minimum: none; {why}")
    else:
        print(f"  numeric minimum F{f} (W{width(numeric['k'], f)}); feasible F {numeric['feasible_f']}")
    print(f"  bounded mode (E_max ≤ {e_bound}, |error| ≤ {abs_tol:g}): F{numeric['bounded']['numeric_recommendation_f']} without data; "
          f"outside the contract (cal/test): {numeric['bounded']['calibration_out_of_contract']}/{numeric['bounded']['test_out_of_contract']}")
    print(f"  infeasible demo: {numeric['infeasible_demo']['feasible_f'] or 'no candidate'} ({numeric['infeasible_demo']['meaning']})")
    assert numeric['infeasible_demo']['feasible_f'] == [] and all(r['bound_violations'] == 0 for r in numeric['calibration'])
    return numeric


def rtl_check(root, numeric, run=True, in_colab=False, n=64):
    """Generate the candidate RTL and run a short Icarus regression of each against the integer model."""
    from .hardware import generate, verify
    root = Path(root); k = numeric['k']; sel = numeric['numeric_recommendation_f']
    fs = sorted({0, 2, 4, 24} | ({sel} if sel is not None else set()))
    for f in fs:
        path, top = generate(root, f, k=k); print(f"generated {top:14s} W{width(k, f)}")
    saved = json.loads((root / 'results/rtl_summary.json').read_text())
    print(f"\nsaved regression: {len(saved)} configurations, {sum(r['transactions'] for r in saved):,} transactions, {sum(r['mismatches'] for r in saved)} mismatches; "
          f"no-stall II (K: cycles) {dict(sorted({r['k']: r['ii_no_stall'] for r in saved}.items()))}")
    if run and not shutil.which('iverilog') and in_colab:
        subprocess.run(['apt-get', 'install', '-y', '-qq', 'iverilog'], check=True, capture_output=True)
    now = []
    if run and shutil.which('iverilog'):
        for f in fs:
            r = verify(root, f, k=k, n=n, result_dir='notebook_rtl'); now.append(r)
            print(f"this run: K{k} F{f:<2} {r['transactions']} transactions, {r['mismatches']} mismatches, II {r['ii_no_stall']}, {r['status']}")
    else:
        print('this run: RTL not simulated here (no iverilog); the saved regression above is the cached result')
    _require([f"saved regression K{r['k']} F{r['f']}: {r['mismatches']} mismatches" for r in saved if r['mismatches'] or r['status'] != 'pass']
             + [f"this run K{k} F{f}: {r['mismatches']} mismatches, status {r['status']}" for f, r in zip(fs, now) if r['mismatches'] or r['status'] != 'pass'],
             'the RTL regression check')
    return dict(saved=saved, now=now, candidates=fs)


# ------------------------------------------------------------------------------------------------ Section 8
def physical_selection(root, numeric, cfg, min_rate=None):
    """Match every record to (K, P, F), check it, and choose the smallest qualified routed core (cfg: panel_config, or a clock in ns)."""
    root = Path(root)
    if isinstance(cfg, dict):
        if (Path(numeric['workload_path']).resolve(), numeric['tolerance'], numeric.get('total_tolerance')) != (Path(cfg['path']).resolve(), cfg['budget'], cfg.get('total_budget')):
            raise ValueError('cell 7.1 ran for another layer or budget than the panels hold now; run Section 7 again first')
        clock_ns, min_rate = cfg['clock_ns'], cfg['min_rate']
    else: clock_ns = cfg
    implementation = load_implementations(root)
    hardware = choose_hardware(numeric, implementation['costs'], clock_ns, min_rate)
    (root / 'results/notebook_run').mkdir(parents=True, exist_ok=True)
    (root / 'results/notebook_run/hardware_selection.json').write_text(json.dumps(hardware, indent=2))
    tb = hardware.get('total_budget')
    print(f"{hardware['workload']}, K{hardware['k']}/P{hardware['lanes']}, accumulation budget {hardware['budget']:g}" + (f", total budget {tb:g}" if tb is not None else '')
          + f", {clock_ns:g} ns, ≥ {min_rate:,.0f} dot products/s")
    from .embedded import raw_reports
    print(f"{'F':>3} {'stage':14s} {'area µm²':>10} {'setup':>7} {'hold':>6} {'slew/cap':>8} {'DRC/LVS':>7} {'II':>3} {'evidence':>10}  qualified")
    for c in hardware['costs']:
        g = lambda key, p=2: '·' if c.get(key) is None else (f"{c[key]:.{p}f}" if isinstance(c[key], float) else str(c[key]))
        reason = '' if c['eligible'] else '  no: ' + c['qualification_reasons'][0]
        ev = (raw_reports(root, c['f']) or '·') if c['stage'] == 'post_route' else '·'
        print(f"{c['f']:>3} {c['stage']:14s} {g('cell_area_um2', 1):>10} {g('setup_wns_ns'):>7} {g('hold_wns_ns'):>6} "
              f"{g('max_slew_violations', 0) + '/' + g('max_cap_violations', 0):>8} {g('drc_errors', 0) + '/' + g('lvs_errors', 0):>7} {g('ii_no_stall', 0):>3} {ev:>10}  {'yes' if c['eligible'] else ''}{reason}")
    hist = [c['f'] for c in hardware['costs'] if c['stage'] == 'post_route' and raw_reports(root, c['f']) == 'historical']
    if hist:
        print(textwrap.fill(f"evidence: 'raw' = the raw signoff reports are here and re-read in cell 8.2; 'historical' (F{', F'.join(map(str, hist))}) = "
                            "the record and its summary metrics are here, but the raw reports are not; their SHA-256 values were taken when the notebook was built and cannot be re-verified from it", 118))
    print(f"\nselected: F{hardware['selected_f']} ({hardware['status']})" if hardware['selected_f'] is not None else f"\nselected: none ({hardware['status']})")
    ft = hardware.get('final_test')
    if ft:
        tot = f", total NRMSE {ft['test_total_nrmse']:.4g} (budget {ft['total_budget']:g})" if ft.get('total_budget') is not None else ''
        print(f"independent test of F{ft['f']}: accumulation NRMSE {ft['test_nrmse']:.4g} (budget {ft['budget']:g}){tot} {'PASS' if ft['pass'] else 'FAIL, kept, not reselected'}; {ft['test_samples']:,} test vectors")
    _require([f"F{d['f']} ({d['path']}): {'; '.join(d['reasons'])}" for d in implementation['diagnostics']], 'the provenance check of the implementation records')
    return hardware


def _signoff_rows(root, f):
    """The key numbers of F read from its raw reports, next to the record values; problems for anything unreadable or different."""
    from .physical import constraint_coverage, parse_metrics
    ev = root / f'results/physical/f{f}/evidence'; problems = []
    rec = json.loads((root / f'results/physical/f{f}.json').read_text()); man = json.loads((ev / 'manifest.json').read_text())
    bad = [rel for rel, d in man['evidence_files'].items() if not (ev / rel).is_file() or hashlib.sha256((ev / rel).read_bytes()).hexdigest() != d]
    problems += [f'F{f}: raw evidence file differs from the run manifest or is missing: {rel}' for rel in bad]
    def first(pattern, text, cast=float):
        m = re.search(pattern, text); return None if m is None else cast(m.group(1))
    def one(pattern):
        hits = sorted(ev.glob(pattern)); return hits[0].read_text() if len(hits) == 1 else ''
    ws = lambda name: [first(r':\s*(\S+)\s*$', p.read_text().strip()) for p in sorted(ev.glob(f'sta/*/{name}'))]
    checks = [p.read_text() for p in sorted(ev.glob('checks_*.rpt'))]
    def count(key):
        v = [first(key + r' (\d+)', t, int) for t in checks]; return None if not v or None in v else max(v)
    def low(values): return None if not values or None in values else min(values)
    corners = len(ws('ws.max.rpt'))
    lvs = one('signoff/*-netgen-lvs/reports/lvs.netgen.rpt')
    try: area = parse_metrics(json.loads((ev / 'metrics.json').read_text()))['cell_area_um2']
    except (OSError, ValueError, KeyError): area = None
    rows = {'setup WS, min of 9 corners (ns)': (low(ws('ws.max.rpt')), rec['setup_wns_ns'], 'STA worst-slack reports'),
            'hold WS, min of 9 corners (ns)': (low(ws('ws.min.rpt')), rec['hold_wns_ns'], 'STA worst-slack reports'),
            'unconstrained endpoints': (constraint_coverage(checks), rec['unconstrained_paths'], 'STA check reports'),
            'max slew violations': (count('max slew violation count'), rec['max_slew_violations'], 'STA check reports'),
            'max cap violations': (count('max cap violation count'), rec['max_cap_violations'], 'STA check reports'),
            'Magic DRC errors': (first(r'COUNT:\s*(\d+)', one('signoff/*-magic-drc/reports/drc.magic.rpt'), int), rec['drc_errors'], 'Magic DRC report'),
            'Netgen LVS errors': (0 if 'Final result: Circuits match uniquely.' in lvs else None, rec['lvs_errors'], 'Netgen LVS report'),
            'KLayout XOR differences': (first(r'Total XOR differences:\s*(\d+)', one('signoff/*-klayout-xor/klayout-xor.log'), int), rec['xor_differences'], 'KLayout XOR log'),
            'standard-cell area (µm²)': (area, rec['cell_area_um2'], 'flow metrics')}
    same = lambda a, b: a is not None and b is not None and (a == b or (isinstance(a, float) and abs(a - b) <= 1e-9 * max(1, abs(b))))
    problems += [f'F{f}: {key}: raw {_fmt(a)} vs record {_fmt(b)} ({src})' for key, (a, b, src) in rows.items() if not same(a, b)]
    if corners != len(rec.get('sta_corners', [])): problems.append(f"F{f}: {corners} STA corner reports for {len(rec.get('sta_corners', []))} corners in the record")
    return dict(files=(len(man['evidence_files']) - len(bad), len(man['evidence_files'])), corners=corners, rows=rows, problems=problems)


def signoff_recheck(root, fs=None, strict=True):
    """Re-read the raw signoff reports of F2 and F4 and compare every key number with the routed record it supports.
    Any difference, unreadable report or changed file raises EvidenceError (strict), after the table is printed."""
    from .embedded import raw_reports, index
    root = Path(root); fs = list(fs if fs is not None else ((index(root) or {}).get('raw_reports_embedded') or (2, 4)))
    _fixed(f"the raw signoff reports of F{', F'.join(map(str, fs))} (the selected core of the default configuration and its alternative)")
    problems = [f'F{f}: raw signoff reports are not present' for f in fs if raw_reports(root, f) != 'raw']
    by_f = {}
    for f in [f for f in fs if raw_reports(root, f) == 'raw']:
        try: by_f[f] = _signoff_rows(root, f)
        except (OSError, ValueError, KeyError, TypeError) as e: problems.append(f'F{f}: raw reports could not be read ({e})')
    for f, r in by_f.items(): problems += r['problems']
    if by_f:
        first_f = next(iter(by_f))
        print(f"{'quantity':34s} {'read from':28s}" + ''.join(f" {'F%d raw' % f:>10} {'record':>10}" for f in by_f))
        for key in by_f[first_f]['rows']:
            spec = '.4f' if '(ns)' in key else (',.1f' if 'area' in key else 'd')
            cells = ''.join(f" {_fmt(r['rows'][key][0], spec):>10} {_fmt(r['rows'][key][1], spec):>10}" for r in by_f.values())
            print(f"{key:34s} {by_f[first_f]['rows'][key][2]:28s}{cells}")
        for f, r in by_f.items():
            n_ok, n = r['files']
            print(f"F{f}: {n_ok}/{n} raw evidence files match the run manifest; {r['corners']} STA corners; every number above "
                  f"{'equals the record' if not r['problems'] else 'DIFFERS from the record'}")
    if strict: _require(problems, 'the signoff evidence check')
    return dict(by_f=by_f, problems=problems)


def evidence_gate(root):
    """Every evidence check a submission bundle depends on, run again without printing. Raises EvidenceError on any failure,
    otherwise returns one line that says what passed."""
    from .provenance import verify_manifest, compare_sources
    from .embedded import index
    root = Path(root); problems = []; done = []
    if index(root):
        m = verify_manifest(root, prefixes=('',), exclude=())
        problems += [f'support file changed: {p}' for p in m['mismatch']] + [f'support file missing: {p}' for p in m['missing']]
        if not m['checked']: problems.append('SHA256SUMS lists no support file')
        done.append(f"all {m['checked']} support files")
    import contextlib, io
    with contextlib.redirect_stdout(io.StringIO()): sr = signoff_recheck(root, strict=False)
    problems += sr['problems']; done.append('the raw signoff reports of F' + ' and F'.join(map(str, sr['by_f'])))
    imp = load_implementations(root)
    problems += [f"F{d['f']} ({d['path']}): {'; '.join(d['reasons'])}" for d in imp['diagnostics']]
    done.append(f"the provenance of {len(imp['all_records'])} implementation records")
    val = _json(root, 'results/perf/validation_summary.json')
    if val is not None:
        ok, diffs = compare_sources(root, val.get('source_sha256'))
        if not ok: problems.append('cycle-model validation record is stale: ' + ', '.join(d[0] for d in diffs[:4]))
        if val['n_pass'] != val['n_cases'] or val['max_abs_cycle_delta'] != 0: problems.append(f"cycle-model validation: {val['n_pass']}/{val['n_cases']} cases, max delta {val['max_abs_cycle_delta']}")
        done.append('the cycle-model validation record')
    _require(problems, 'the evidence gate of the submission bundle')
    return 'evidence checks passed before this bundle was written: ' + ', '.join(done[:-1]) + (' and ' if len(done) > 1 else '') + done[-1]


def policy_comparison(root, numeric, hardware):
    """The same core, clock, flow, split and budget under different selection policies."""
    comparison = comparison_table(numeric, hardware)
    (Path(root) / 'results/notebook_run/policy_comparison.json').write_text(json.dumps(comparison, indent=2))
    print(f"{'policy':44s} {'F':>4} {'test acc.':>9} {'test total':>10} {'budgets':>7} {'routed µm²':>11} {'saved':>7}  qualified")
    for r in comparison['rows']:
        f = 'none' if r['f'] is None else f"F{r['f']}"
        area = 'n/a' if r['post_route_area_um2'] is None else f"{r['post_route_area_um2']:,.1f}"
        vs = 'n/a' if r['area_vs_fixed_f4_pct'] is None else f"{r['area_vs_fixed_f4_pct']:+.2f}%"
        ok = 'n/a' if r['meets_budget_cal'] is None else ('pass' if r['meets_budget_cal'] and r['meets_budget_test'] else 'FAIL')
        print(f"{r['policy']:44s} {f:>4} {_fmt(r['test_nrmse']):>9} {_fmt(r.get('test_total_nrmse')):>10} {ok:>7} {area:>11} {vs:>7}  {'yes' if r['qualified'] else 'no: ' + '; '.join(r['qualification_reasons'][:1])}")
    return comparison


def timing_infeasibility(root):
    """The saved 35 ns experiment: when no F meets the clock, the selector returns none and names the bottleneck."""
    sweep = _json(root, 'results/timing_sweep/summary.json')
    _fixed('F2 and F24 re-implemented at 35 ns (saved post-route experiment)')
    if sweep is None: print('timing sweep not present in this checkout: not evaluated'); return None
    print(f"{'clock ns':>8} {'F':>3} {'setup WS':>9} {'hold WS':>8} {'slew':>5} {'cap':>4} {'area µm²':>10}  verdict")
    for r in sweep['runs']:
        print(f"{r['clock_period_ns']:>8g} {r['f']:>3} {r['setup_ws_ns']:>9.3f} {r['hold_ws_ns']:>8.3f} {r['max_slew_violations']:>5d} {r['max_cap_violations']:>4d} {r['cell_area_um2']:>10.1f}  {r['verdict']}")
    print('\n' + textwrap.fill(sweep['conclusion'].replace(' -> ', ' → '), 118))
    return sweep


# ------------------------------------------------------------------------------------------------ Section 9
def task_metrics(root, hardware):
    """Task accuracy with the F-bit layer plugged into each MNIST network (official 10,000 test images)."""
    ws = json.loads((Path(root) / 'results/workloads/study.json').read_text())
    _fixed('the three MNIST models, official 10,000-image test set (recorded task accuracy)')
    print(f"{'model':22s} {'FP32':>7} {'MX exact':>9} {'F0':>7} {'F2':>7} {'F4':>7} {'F24':>7}  test spread")
    for wid, r in ws.items():
        if 'task' not in r: continue
        t = r['task']
        print(f"{wid:22s} {t['fp32_accuracy']:>7.4f} {t['mxfp4_exact']['accuracy']:>9.4f} {t['f0']['accuracy']:>7.4f} {t['f2']['accuracy']:>7.4f} {t['f4']['accuracy']:>7.4f} {t['f24']['accuracy']:>7.4f}  {r['disparity_test']['max_disparity_bits']:>11d}")
    ft = hardware.get('final_test')
    if ft: print(f"\nfrozen hardware choice F{ft['f']}: layer test accumulation NRMSE {ft['test_nrmse']:.3g} ({'PASS' if ft['pass'] else 'FAIL'}); task accuracy is flat across F for this one-layer replacement")
    else: print('\nno frozen hardware choice for the panel configuration (Section 8 selected none); the recorded accuracies above do not depend on it')
    return ws


# ------------------------------------------------------------------------------------------------ Section 11
def _close(a, b, rtol=1e-9):
    """Equal records, floats to a relative tolerance (integers, flags and strings exactly)."""
    if isinstance(a, dict): return isinstance(b, dict) and a.keys() == b.keys() and all(_close(a[k], b[k], rtol) for k in a)
    if isinstance(a, (list, tuple)): return isinstance(b, (list, tuple)) and len(a) == len(b) and all(_close(x, y, rtol) for x, y in zip(a, b))
    if isinstance(a, float) or isinstance(b, float):
        if isinstance(a, bool) or isinstance(b, bool) or not isinstance(a, (int, float)) or not isinstance(b, (int, float)): return False
        return a == b or (a != a and b != b) or abs(a - b) <= rtol * max(abs(a), abs(b))      # NaN equals NaN here
    return a == b


def layer_study(root, entry, budgets=BUDGETS):
    """study() of one layer. If the notebook embeds only its calibration split, the calibration half is computed now and
    must equal the record (same data hash, same selections, every number within 1e-9 relative: the FP32 reference
    differs in the last bit between NumPy builds); the test half is the recorded one (results/workloads/study.json)."""
    w = load_workload(root, entry['path'], test_optional=True)
    if w['x_test'] is not None:
        r = study(w['x_cal'], w['x_test'], w['w'], w['k'], budgets); r['test_source'] = 'computed'; return w, r
    rec = json.loads((Path(root) / 'results/workloads/study.json').read_text())[w['id']]
    r = study(w['x_cal'], w['x_cal'], w['w'], w['k'], budgets)         # its test half is replaced below
    same = (r['calibration_hash'] == rec['calibration_hash'] and _close(r['calibration'], rec['calibration'])
            and [(s['budget'], s['selected_f'], s['fixed_f4_meets_budget']) for s in r['selections']] == [(s['budget'], s['selected_f'], s['fixed_f4_meets_budget']) for s in rec['selections']])
    if not same: raise ValueError(f"{w['id']}: the calibration study computed now differs from the record; the recorded test results cannot be used")
    for key in ('test', 'test_samples', 'quantization_test', 'disparity_test', 'test_hash'): r[key] = rec[key]
    r['scale_clips']['x_test'] = rec['scale_clips']['x_test']
    for s, rs in zip(r['selections'], rec['selections']): s.update({k: rs[k] for k in ('test_nrmse', 'test_pass', 'fixed_f4_test_pass')})
    r['test_source'] = 'recorded'
    return w, r


def catalogue(root, extra=None):
    """Every bundled workload (and an extra layer folder, if given)."""
    root = Path(root); cat = {}
    for p in sorted((root / 'data/workloads').glob('*/')):
        if (p / 'manifest.json').exists(): cat[p.name] = {'path': p, 'manifest': json.loads((p / 'manifest.json').read_text())}
    if extra and extra not in cat:
        d = Path(extra) if Path(extra).is_absolute() else root / extra
        if not (d / 'calibration.npz').exists(): raise FileNotFoundError(f'{extra}: no calibration.npz/test.npz there')
        cat[d.name] = {'path': d.resolve(), 'manifest': {'id': d.name, 'kind': 'layer_npz', 'description': f'layer_npz bundle at {d}'}}
    return cat


def exactness_table(root, cat):
    """F ≥ spread is sufficient for zero accumulation error; the measured smallest zero-error F is at most that candidate."""
    _fixed(f'all {len(cat)} layers of the catalogue, calibration splits')
    print(f"{'workload':24s} {'K':>4} {'spread':>6} {'first F ≥ spread':>17} {'smallest exact F':>17}")
    out = {}
    for wid, entry in cat.items():
        wl = load_workload(root, entry['path'], test_optional=True)
        xc, xs, _ = quantize(wl['x_cal']); wc, ws, _ = quantize(wl['w']); g = groups(xc, xs, wc, ws); gold = exact(g)
        spread = disparity_stats(g)['max_disparity_bits']; rows = [metrics(g, f, gold) for f in CANDIDATES]
        f_exact = next((r['f'] for r in rows if r['nrmse'] == 0), None); upper = exactness_threshold(spread)
        if upper is not None:
            assert f_exact is not None and f_exact <= upper, (wid, spread, f_exact, upper)
            assert all(r['nrmse'] == 0 for r in rows if r['f'] >= spread), (wid, spread)
        out[wid] = dict(k=wl['k'], spread=spread, sufficient=upper, smallest_exact=f_exact)
        print(f"{wid:24s} {wl['k']:>4d} {spread:>6d} {_fmt(upper, 'd', 'none'):>17} {_fmt(f_exact, 'd', 'none'):>17}")
    return out


def selection_matrix(root, cat, budgets=BUDGETS):
    """Calibration selection of F for every workload and budget, then one independent test of each frozen choice."""
    _fixed(f'all {len(cat)} layers × {len(budgets)} budgets; choice on calibration, one test of each frozen choice')
    matrix = {}
    for wid, entry in cat.items():
        w, matrix[wid] = layer_study(root, entry, budgets)
    cells = f4_cal = f4_test = low = fails = 0
    for wid, r in matrix.items():
        for s in r['selections']:
            cells += 1; f4_cal += not s['fixed_f4_meets_budget']; f4_test += not s['fixed_f4_test_pass']; low += s['selected_f'] is not None and s['selected_f'] < 4
            fails += s['selected_f'] is not None and not s['test_pass']
    rec = [w for w, r in matrix.items() if r['test_source'] == 'recorded']
    sizes = sorted({r['test_samples'] for r in matrix.values() if r['test_source'] != 'recorded'})
    print(f"test split computed now for {len(matrix) - len(rec)} layers ({sizes[0]:,} to {sizes[-1]:,} rows), recorded † for {', '.join(rec) or 'none'}")
    print(f"* in the figure: {fails} frozen calibration choices fail the budget on the independent test split (kept, not reselected)")
    if rec: print(f"† test split not in the support package ({', '.join(rec)}):\n  calibration computed now and identical to the record, test results are the recorded ones")
    print(f"{cells} workload × budget cases ({len(matrix)} workloads): fixed F4 misses the calibration budget in {f4_cal}, the test budget in {f4_test}; F0 or F2 would suffice in {low}.")
    return matrix, dict(cells=cells, f4_cal_fail=f4_cal, f4_test_fail=f4_test, low_f_enough=low)


def bert_layer(root, budgets=BUDGETS):
    """A real pretrained Transformer layer: BERT-Tiny encoder.layer.0 FFN dense (128 → 512) on WikiText-2 tokens."""
    root = Path(root); d = root / 'data/workloads/bert_tiny_ffn_k128'
    _fixed('BERT-Tiny FFN layer, 6 budgets')
    if not (d / 'calibration.npz').exists(): print('bert_tiny_ffn_k128 not present: not evaluated (scripts/prepare_bert_layer.py exports it)'); return None
    w = load_workload(root, d); man = w['manifest']; r = study(w['x_cal'], w['x_test'], w['w'], w['k'], budgets)
    print(f"{man.get('model', {}).get('id')}, {man.get('model', {}).get('layer')}; {r['calibration_samples']} validation / {r['test_samples']} test token vectors, {w['outputs']} outputs")
    print(f"input quantization error (exact MXFP4 vs FP32, independent of F): test NRMSE {r['quantization_test']['nrmse_vs_fp32']:.4g}; spread cal/test {r['disparity_cal']['max_disparity_bits']}/{r['disparity_test']['max_disparity_bits']} bits\n")
    print(f"{'F':>3} {'W':>3} {'cal NRMSE':>10} {'test NRMSE':>11} {'test max|err|':>13}")
    for c, t in zip(r['calibration'], r['test']):
        print(f"{c['f']:>3} {c['w']:>3} {c['nrmse']:>10.4g} {t['nrmse']:>11.4g} {t['max_abs']:>13.4g}")
    print('\nbudget:     ' + ' '.join(f"{s['budget']:>7g}" for s in r['selections']))
    print('selected F: ' + ' '.join(f"{'F' + str(s['selected_f']) if s['selected_f'] is not None else 'none':>7}" for s in r['selections']))
    print('test pass:  ' + ' '.join(f"{str(s['test_pass']):>7}" for s in r['selections']))
    print('fixed F4:   ' + ' '.join(f"{'ok' if s['fixed_f4_meets_budget'] else 'misses':>7}" for s in r['selections']))
    spread, first = r['disparity_cal']['max_disparity_bits'], r['smallest_zero_error_candidate_f']
    print(f"\nspread {spread} bits: F ≥ {spread} is already sufficient for exactness; among the scanned candidates {{{', '.join(map(str, CANDIDATES))}}} "
          f"the first exact configuration is F{first}")
    return r


# ------------------------------------------------------------------------------------------------ Section 12
def flag_study(root, cfg):
    """How often a low-F core discards a non-zero bit, and the error left after recomputing exactly those dot products."""
    root = Path(root); workload = cfg['workload'] if isinstance(cfg, dict) else cfg
    wl = load_workload(root, cfg['path'] if isinstance(cfg, dict) else root / 'data/workloads' / cfg); rows = {}
    for split, x in (('calibration', wl['x_cal']), ('test', wl['x_test'])):
        xc, xs, _ = quantize(x); wc, ws, _ = quantize(wl['w']); g = groups(xc, xs, wc, ws); gold = exact(g)
        rows[split] = [recompute_study(g, f, gold) for f in CANDIDATES]
        assert all(r['false_negatives'] == 0 and r['bound_violations'] == 0 for r in rows[split]), 'the flag must be a sufficient condition'
    print(f"{workload}, test split: flagged dot products, accumulation NRMSE before and after strict exact recompute")
    print(f"{'F':>3} {'W':>3} {'cal flagged':>12} {'test flagged':>13} {'NRMSE before':>13} {'after':>6} {'false pos.':>10}")
    for c, t in zip(rows['calibration'], rows['test']):
        print(f"{t['f']:>3} {t['w']:>3} {100 * c['flagged_fraction']:>11.4g}% {100 * t['flagged_fraction']:>12.4g}% {t['nrmse_before']:>13.3g} {t['policies'][0]['nrmse_after']:>6.2g} {t['false_positives_exact_after_cancellation']:>10}")
    rc = _json(root, 'results/recompute/study.json')
    if rc:
        f2 = {wid: next(r for r in e['per_f'] if r['f'] == 2)['test_flagged_fraction'] for wid, e in rc['workloads'].items()}
        lo, hi = min(f2, key=f2.get), max(f2, key=f2.get)
        print(f"\nacross all {len(f2)} workloads (cached study, test split), the F2 flagged fraction ranges from {100 * f2[lo]:.3g} % ({lo}) to {100 * f2[hi]:.3g} % ({hi})")
    print('\nzero false negatives on every transaction: flag = 0 proves the dot product is exact')
    return rows


def flag_cost(root):
    """Area of the optional inexact flag (rtl/dot_top_inexact.sv), same Yosys script and same LibreLane settings."""
    hw = _json(root, 'results/recompute/hardware.json')
    _fixed('the MXFP4 core with and without the optional flag, K128, 50 ns (implementation records)')
    if hw is None: print('results/recompute/hardware.json not present: flag cost not evaluated'); return None
    print(f"{'F':>3} {'mapped base':>12} {'mapped +flag':>13} {'delta':>7}   {'routed base':>12} {'routed +flag':>13} {'delta':>7}  checks")
    for f in CANDIDATES:
        sy = hw['synthesis'].get(str(f), {}); pr = hw['post_route'].get(str(f))
        s_ = f"{sy['baseline_cell_area_um2']:>12,.1f} {sy['variant_cell_area_um2']:>13,.1f} {sy['delta_area_pct']:>+6.2f}%" if sy else f"{'n/a':>12} {'n/a':>13} {'':>7}"
        if pr and pr.get('variant'):
            v = pr['variant']; b = pr['baseline'] or {}
            r_ = f"{b.get('cell_area_um2', float('nan')):>12,.1f} {v['cell_area_um2']:>13,.1f} {pr['delta_area_pct']:>+6.2f}%  {pr['verdict']}"
        else: r_ = f"{'':>12} {'not routed':>13}"
        print(f"{f:>3} {s_}   {r_}")
    return hw


def system_cost(root):
    """The complete retained-record recompute path, built, verified, synthesised and routed."""
    s = _json(root, 'results/system/study.json')
    _fixed('the recompute system as built: K128, F2 cores, 50 ns (implementation records)')
    if s is None: print('results/system/study.json not present: system study not evaluated'); return None
    comps = s['components']; g = lambda v: 'n/a' if v is None else f'{v:,.0f}'
    print(f"{'component':40s} {'mapped µm²':>11} {'routed µm²':>11}  verdict")
    for key, label in [('core_f2_plain', 'F2 core'), ('core_f2_flag', 'F2 + inexact flag'), ('core_f2_record', 'F2 + flag + record store and port'),
                       ('core_f4_record', 'F4 + flag + record store and port'), ('merge_d24', 'shared exact merge, D_MAX 24'), ('merge_d12', 'shared exact merge, D_MAX 12')]:
        c = comps.get(key, {}); print(f"{label:40s} {g(c.get('synthesis')):>11} {g(c.get('post_route')):>11}  {c.get('verdict', '')}")
    for f in (6, 8, 12): c = comps['fixed'][f'f{f}']; print(f"{'fixed F%d core (no recompute)' % f:40s} {g(c['synthesis']):>11} {g(c['post_route']):>11}")
    print(f"\n{'full top (same die, clock and flow)':40s} {'mapped µm²':>11} {'routed µm²':>11}  verdict")
    for name, t in s['tops'].items():
        sy, ro = t.get('synthesis'), t.get('post_route')
        print(f"{name:40s} {g(sy['cell_area_um2'] if sy else None):>11} {g(ro['cell_area_um2'] if ro and ro.get('cell_area_um2') else None):>11}  {ro.get('verdict_text', ro['verdict']) if ro else 'not routed'}")
    rtl = s.get('rtl_verification', [])
    print(f"\nsystem RTL: {len(rtl)} configurations, {sum(r['checked_transactions'] for r in rtl):,} checked transactions, {sum(r['returns'] for r in rtl):,} exact returns, 0 mismatches, reset in every run")
    a = s['tops']['base_n4_k128_f6']['post_route']['cell_area_um2']; b = s['tops']['sys_n4_k128_f2_q2_d24']['post_route']['cell_area_um2']
    print(f"N4 recompute top {b:,.0f} µm² vs N4 fixed F6 {a:,.0f} µm²: {100 * (b / a - 1):+.1f} %")
    return s


def _total_gate(dec, numeric, total):
    """The total budget of the panels, applied to every system candidate after the ordered checks of choose_system.
    Total NRMSE on calibration: a fixed-F candidate has the total error of its F; a strict exact-recompute system returns
    exact MX results for every flagged dot product, so its total error is bounded by quantization + accumulation after
    recompute. A candidate over the total budget leaves the strict set; the smallest-area rule is then applied again."""
    cal = {r['f']: r for r in numeric['calibration']}; q = (numeric.get('quantization_cal') or {}).get('nrmse_vs_fp32')
    def total_of(r):
        if r['mode'] != 'recompute': return (cal.get(r.get('f')) or {}).get('nrmse_vs_fp32')
        acc = r.get('cal_nrmse')
        return None if acc is None or q is None else q + acc * (1 + q)
    for r in dec['candidates']:
        t = total_of(r); r['cal_total_nrmse'] = t
        if t is None or t > total:
            r['survives_strict'] = False
            r['eliminated_by'].append('total budget: no calibration total NRMSE' if t is None else f'total budget: calibration total NRMSE {t:.3g} > {total:g}')
    survivors = [r for r in dec['candidates'] if r['survives_strict'] and r['mode'] != 'fixed_f']
    best = min(survivors, key=lambda r: r['area_per_core_um2']) if survivors else None
    dec['strict_system_selection'] = None if best is None else {k: best[k] for k in ('id', 'mode', 'f', 'n', 'q', 'area_um2', 'area_per_core_um2', 'area_source', 'qualification')}
    dec['strict_system_status'] = 'selected' if best else 'none / not_qualified'
    over = {r['id'] for r in dec['candidates'] if r['cal_total_nrmse'] is None or r['cal_total_nrmse'] > total}
    for e in dec['exploration_ranking']:
        if e['id'] in over: e['performance_feasible'] = False
    dec['exploration_ranking'].sort(key=lambda e: (not e['performance_feasible'], e['area_per_core_um2'], e['id']))
    dec['total_budget'] = total
    dec['strict_rule'] = dec['strict_rule'].replace('calibration budget', 'calibration budgets (accumulation and total)')


def system_choice(root, cfg, max_p99, ooc_policy, hardware, numeric):
    """Strict selection of an N-core system: contract, budget, model scope, full-top qualification, P99, then area."""
    from .qualify import system_candidates, choose_system, frozen_test_check, block_spread_max
    from .provenance import compare_sources
    root = Path(root); perf = root / 'results/perf'
    workload, budget, clock_ns, min_rate = cfg['workload'], cfg['budget'], cfg['clock_ns'], cfg['min_rate']
    study_, val, sysst, rc = _json(root, 'results/perf/study.json'), _json(root, 'results/perf/validation_summary.json'), _json(root, 'results/system/study.json'), _json(root, 'results/recompute/study.json')
    current = lambda rec: rec is not None and compare_sources(root, rec.get('source_sha256'))[0]
    _require([f'{name} record is stale (its sources changed)' for name, rec in (('performance study', study_), ('cycle-model validation', val)) if rec is not None and not current(rec)],
             'the provenance check of the performance records')
    if not (current(study_) and current(val) and sysst and rc and workload in rc['workloads'] and any(r['workload'] == workload for r in study_['rows'])):
        print(f'no current, validated performance evidence for {workload}: strict system selection = none / not_qualified'); return None
    wl = load_workload(root, cfg['path'])
    req = {'clock_period_ns': clock_ns, 'min_dot_products_per_s': min_rate, 'max_p99_latency_cycles': max_p99, 'ooc_policy': ooc_policy, 'ii0': 40}
    f_low = 4 if workload == 'syn_outlier_k128' else 2
    cands = system_candidates(workload, f_low, sysst, study_['rows'], hardware, rc['workloads'][workload], numeric, model_version=val['cpp_binary']['version_line'])
    dec = choose_system(cands, budget, req, calibration_spread_max=block_spread_max(wl['x_cal'], wl['w']))
    total = cfg.get('total_budget')
    if total is not None: _total_gate(dec, numeric, total)
    sc = dec['single_core_selection']
    print(f"{workload}: accumulation budget {budget:g}" + (f", total budget {total:g}" if total is not None else '')
          + f", P99 ≤ {max_p99} cycles, out-of-contract policy {ooc_policy}; contract checked with spread {dec['spread_used']} ({dec['spread_source']})")
    print(textwrap.fill('rule: ' + dec['strict_rule'].replace('->', '→'), 118, initial_indent='  ', subsequent_indent='        '))
    print(f"  single core (qualified): {sc['id']}, {sc['area_um2']:,.0f} µm²" if sc and sc.get('f') is not None else '  single core: none')
    print(f"  strict system selection: {dec['strict_system_status']}" + (f" ({dec['strict_system_selection']})" if dec['strict_system_selection'] else ''))
    print(f"\n  exploration ranking (predictions, labelled):\n  {'candidate':24s} {'P99':>4} {'burst P99':>9} {'µm²/core':>9} {'vs single':>9} {'feasible':>8}  area source / qualification")
    for e in dec['exploration_ranking'][:5]:
        vs = 'n/a' if e['vs_single_core_pct'] is None else f"{e['vs_single_core_pct']:+.1f}%"
        print(f"  {e['id']:24s} {str(e['p99_cycles']):>4} {str(e['p99_burst_cycles']):>9} {e['area_per_core_um2']:>9,.0f} {vs:>9} {'yes' if e['performance_feasible'] else 'no':>8}  {e['area_source']} / {e['qualification']}")
    routed = next((r for r in dec['candidates'] if r['mode'] == 'recompute' and r['n'] == 4 and r['q'] == 2), None)
    if routed: print(f"\n  the routed N4 recompute top is out: {'; '.join(routed['eliminated_by'])}")
    ft = frozen_test_check(dec, block_spread_max(wl['x_test'], wl['w']), budget)
    hw_test = hardware.get('final_test')
    if ft.get('single_core') and ft['single_core']['test_nrmse'] is not None:
        ok = hw_test['pass'] if hw_test and hw_test['f'] == sc.get('f') else ft['single_core']['pass']      # both budgets when Section 8 checked them
        print(f"  frozen test (after the choice): {ft['single_core']['id']} test accumulation NRMSE {ft['single_core']['test_nrmse']:.3g}, {'PASS' if ok else 'FAIL'}")
    return dec


# ------------------------------------------------------------------------------------------------ Section 13
def perf_validation(root):
    """The frozen cycle contract and the full RTL vs C++ validation record, summarised per configuration."""
    from .provenance import compare_sources
    root = Path(root); val = _json(root, 'results/perf/validation_summary.json'); contract = root / 'docs/perf_contract.md'
    _fixed('the validation suite of the cycle model (64 recorded cases)')
    print(f"cycle contract {hashlib.sha256(contract.read_bytes()).hexdigest()[:16]}: no-stall II0 = 9B + 4 (40 at K128), merge service B + 3")
    if val is None: print('validation record not present (scripts/run_perf_validation.py rebuilds it)'); return None
    ok, diffs = compare_sources(root, val.get('source_sha256'))
    print(f"validation record: {'current (every source that produced it hashes the same now)' if ok else 'STALE: ' + ', '.join(d[0] for d in diffs[:4])}")
    _require(([] if ok else ['stale validation record: ' + ', '.join(d[0] for d in diffs[:4])])
             + ([] if val['n_pass'] == val['n_cases'] else [f"{val['n_cases'] - val['n_pass']} of {val['n_cases']} cases fail"])
             + ([] if val['max_abs_cycle_delta'] == 0 else [f"max cycle delta {val['max_abs_cycle_delta']}"])
             + ([] if val['comparator_self_test']['status'] == 'pass' else ['comparator self-test ' + str(val['comparator_self_test']['status'])]),
             'the cycle-model validation check')
    print(f"C++ model binary {val['cpp_binary']['sha256'][:16]}; {val['n_pass']}/{val['n_cases']} cases pass, {val['total_events_compared']:,} events compared, "
          f"max |cycle delta| {val['max_abs_cycle_delta']}, comparator self-test {val['comparator_self_test']['status']}\n")
    groups_ = {}
    for c in val['cases']:
        key = c['config_role']; g = groups_.setdefault(key, dict(cases=0, tx=0, events=0, maxd=0, identical=True, cov=set(), nq=set()))
        g['nq'].add((c['config']['n'], c['config']['q']))
        g['cases'] += 1; g['tx'] += c['transactions']; g['events'] += c['events']['rtl_vs_cpp']['compared']; g['maxd'] = max(g['maxd'], c['events']['rtl_vs_cpp']['max_abs_cycle_delta'])
        g['identical'] &= c['cycle_trace_identical']; cv = c['coverage']
        for flag, on in (('queue full', cv['queue_full_cycles']), ('enq+deq', cv['same_cycle_enqueue_dequeue']), ('reset busy', cv['reset_with_queue_nonempty']),
                         ('ID wrap', cv['id_wrap_observed']), ('out of contract', cv['out_of_contract_returns']), ('back-pressure', cv['return_blocked_cycles'] or cv['result_blocked_core_cycles'])):
            if on: g['cov'].add(flag)
    print(f"{'role':12s} {'(N, Q) configurations':>22s} {'cases':>5} {'transactions':>12} {'events':>8} {'max|d|':>6}  traces")
    for role, g in sorted(groups_.items(), key=lambda kv: kv[0] != 'development'):
        print(f"{role:12s} {len(g['nq']):>22d} {g['cases']:>5} {g['tx']:>12,} {g['events']:>8,} {g['maxd']:>6}  {'identical' if g['identical'] else 'DIFFER'}")
    print('coverage in both roles: ' + ', '.join(sorted(set.intersection(*(g['cov'] for g in groups_.values())))))
    return val


def live_rtl_vs_cpp(root, scenario='E_backpressure', n=4, q=2, tx_per_core=24):
    """One case through the C++ model and, when Icarus is installed, through the RTL; traces compared cycle by cycle."""
    from .perf_backend import find_binary, run_case, binary_info
    from .perf_stimulus import synthetic_case
    from .perf_rtl import run_rtl
    from .perf_trace import Trace, derive_events, events_table, compare_events, compare_cycles
    root = Path(root); live = root / 'results/notebook_perf' / 'live'; shutil.rmtree(live, ignore_errors=True); live.mkdir(parents=True, exist_ok=True)
    _fixed(f'validation scenario {scenario}, {n} cores, queue depth {q}, {tx_per_core} transactions per core')
    exe = find_binary(root)                                   # builds the C++17 model with CMake on first use
    man, case = synthetic_case(root, live / 'case', scenario, int(n), int(q), tx_per_core=int(tx_per_core))
    cpp = run_case(root, live / 'case', live / 'out', exe=exe); tr_c = Trace(live / 'out/cycles_cpp.csv'); ev_c, _ = derive_events(tr_c, man['params']['b'])
    print(f"case {case}: {man['stats']['transactions']} transactions, {man['stats']['flagged']} flagged; C++ model binary {binary_info(exe)['sha256'][:16]}")
    print(f"C++: {cpp['cycles']} cycles, queue peak {cpp['queue']['peak']}, P99 recompute latency {cpp['all']['recompute_latency']['p99']} cycles")
    result = dict(case=case, cpp_cycles=cpp['cycles'], rtl=None)
    if not (shutil.which('iverilog') and shutil.which('vvp')):
        print('RTL comparison not run: Icarus Verilog is not installed here (reported as not run, never as passed)'); return result
    rtl = run_rtl(root, live / 'case', live / 'out'); tr_r = Trace(live / 'out/cycles_rtl.csv'); ev_r, _ = derive_events(tr_r, man['params']['b'])
    diff = compare_cycles(tr_r, tr_c); cmp_ = compare_events(events_table(ev_r), events_table(ev_c), 'rtl', 'cpp')
    print(f"RTL: {rtl['cycles']} cycles, {rtl['value_errors']} value errors; per-cycle trace identical: {diff is None}; {cmp_['compared']} events compared, max |delta| {cmp_['max_abs_cycle_delta']}")
    first = next((k for k in sorted(ev_r) if 'record_enqueue' in ev_r[k]), None)
    if first:
        print(f"\nfirst flagged transaction (core {first[0]}):  {'event':26s} {'RTL':>5} {'C++':>5}")
        for name in ('first_input_accept', 'last_input_accept', 'normal_result_handshake', 'record_enqueue', 'merge_accept', 'return_handshake'):
            print(f"{'':37s}{name:26s} {ev_r[first].get(name, '·'):>5} {ev_c[first].get(name, '·'):>5}")
    _require([f'RTL and C++ disagree: {diff or cmp_}'] if diff is not None or not cmp_['identical'] or rtl['value_errors'] else [], 'the RTL versus C++ check')
    result['rtl'] = dict(cycles=rtl['cycles'], identical=True, events=cmp_['compared']); return result


def issue_order_sweep(root, workload='bert_tiny_ffn_k128', f=2, ns=(4, 16), qs=(1, 2, 4), tx_per_core=4096):
    """The same transactions in three issue orders (real, shuffled, burst) through the C++ model; P99 per N and Q."""
    from .perf_backend import find_binary, run_generated
    from .perf_stimulus import real_case, threshold
    root = Path(root); live = root / 'results/notebook_perf'; exe = find_binary(root)
    _fixed(f'{workload} at F{f}, cores {ns}, queue depths {qs}, calibration split')
    lw = load_workload(root, root / 'data/workloads' / workload); total = len(lw['x_cal']) * lw['outputs']
    short = {'bert_tiny_ffn_k128': 'bert', 'mnist_gelu_ln_fc2': 'mnist_gelu', 'mnist_relu_fc2': 'mnist_relu', 'syn_outlier_k128': 'outlier'}.get(workload, workload)
    sat = {k: threshold(1.0) for k in ('ret', 'start', 'meta', 'data', 'out')}; rows = []
    for n in ns:
        for ordering in ('original', 'shuffled', 'burst'):
            d = live / f'S_{short}_f{f}_{ordering}_n{n}'
            man, _ = real_case(root, d, workload, n, 1, f, tx_per_core=min(tx_per_core, total // n), split='calibration', ordering=ordering, name=d.name, light=True)
            for q in qs:
                p = dict(man['params']); p['q'] = q; per_core = max(man['stats']['per_core']); t_nom = per_core * p['ii0']
                s = run_generated(root, d, live / f'run_{ordering}_n{n}_q{q}', p, 20261018, sat, int(t_nom * 1.5 + n * per_core * p['s0'] + 5000), window=(1000, int(0.9 * t_nom)), exe=exe)
                lat = s['window']['recompute_latency']
                rows.append(dict(n=n, q=q, ordering=ordering, p99=lat['p99'], count=lat['count'], peak=s['queue']['peak'], multiset=man['multiset_sha256']))
    for n in ns: assert len({r['multiset'] for r in rows if r['n'] == n}) == 1, 'the three orders must carry the same transaction multiset'
    counts = [r['count'] for r in rows]
    print(f"{workload} F{f}, calibration, up to {tx_per_core} transactions per core, saturated input (C++ model): "
          f"{len(rows)} runs, {min(counts)} to {max(counts)} flagged samples per point (P99 values in the figure below)")
    st = _json(root, 'results/perf/study.json')
    if st:
        ref = {r['ordering']: r['rc_p99'] for r in st['rows'] if r['workload'] == 'bert_tiny_ffn_k128' and r['n'] == 16 and r['q'] == 2 and r['masks'] == 'saturated'}
        print(f"\nfull cached sweep, BERT F2, N16 Q2: P99 by order {ref} cycles ({len(st['rows'])} runs)")
    return rows
