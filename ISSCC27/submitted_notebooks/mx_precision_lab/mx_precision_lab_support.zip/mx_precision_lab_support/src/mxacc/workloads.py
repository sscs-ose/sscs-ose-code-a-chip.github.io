"""Workload families for the precision-selection study.

Every workload is reduced to the common layer contract Y = X W^T with
X: [N, K] float32 activations and W: [M, K] float32 weights, then quantized once
to MXFP4 by mxacc.arithmetic.quantize. Three real MNIST layers (trained here in
NumPy on the official splits fixed in examples/mnist/manifest.json) and five
documented synthetic stress families (plan section 10) share the same core,
so the only variable is the workload statistics.
"""
from pathlib import Path
import hashlib
import json
import zlib
import numpy as np

from .arithmetic import quantize, groups, exact, metrics, accumulate, as_float, array_hash, CANDIDATES, width

SQRT_2_OVER_PI = 0.7978845608028654


# ----------------------------------------------------------------------------
# Minimal NumPy sequential network (float32, Adam), enough for MLPs with
# ReLU / GELU / LayerNorm. Each module caches what its backward pass needs.
# ----------------------------------------------------------------------------
class Linear:
    def __init__(self, rng, n_in, n_out, name):
        self.name = name
        self.w = (rng.standard_normal((n_in, n_out)) * np.sqrt(2 / n_in)).astype(np.float32)
        self.b = np.zeros(n_out, dtype=np.float32)

    def params(self):
        return {f"{self.name}.w": self.w, f"{self.name}.b": self.b}

    def forward(self, x):
        self.x = x
        return x @ self.w + self.b

    def backward(self, dy):
        self.grad = {f"{self.name}.w": self.x.T @ dy, f"{self.name}.b": dy.sum(axis=0)}
        return dy @ self.w.T


class ReLU:
    def params(self): return {}
    def forward(self, x):
        self.mask = x > 0
        return x * self.mask
    def backward(self, dy):
        self.grad = {}
        return dy * self.mask


class GELU:
    """tanh approximation (as used by BERT's intermediate layers)."""
    def params(self): return {}
    def forward(self, x):
        self.x = x
        u = SQRT_2_OVER_PI * (x + 0.044715 * x ** 3)
        self.t = np.tanh(u)
        return 0.5 * x * (1 + self.t)
    def backward(self, dy):
        x, t = self.x, self.t
        du = SQRT_2_OVER_PI * (1 + 3 * 0.044715 * x ** 2)
        self.grad = {}
        return dy * (0.5 * (1 + t) + 0.5 * x * (1 - t ** 2) * du)


class LayerNorm:
    def __init__(self, n, name, eps=1e-5):
        self.name, self.eps = name, eps
        self.g = np.ones(n, dtype=np.float32)
        self.b = np.zeros(n, dtype=np.float32)
    def params(self):
        return {f"{self.name}.g": self.g, f"{self.name}.b": self.b}
    def forward(self, x):
        mu = x.mean(axis=1, keepdims=True)
        var = x.var(axis=1, keepdims=True)
        self.inv = 1 / np.sqrt(var + self.eps)
        self.xhat = (x - mu) * self.inv
        return self.xhat * self.g + self.b
    def backward(self, dy):
        xhat, inv = self.xhat, self.inv
        self.grad = {f"{self.name}.g": (dy * xhat).sum(axis=0), f"{self.name}.b": dy.sum(axis=0)}
        dxhat = dy * self.g
        n = xhat.shape[1]
        return inv * (dxhat - dxhat.mean(axis=1, keepdims=True) - xhat * (dxhat * xhat).mean(axis=1, keepdims=True))


class Sequential:
    def __init__(self, modules):
        self.modules = modules
    def params(self):
        p = {}
        for m in self.modules: p.update(m.params())
        return p
    def forward(self, x, stop_before=None):
        """Run forward; if stop_before is a module name, return the input of that module."""
        for m in self.modules:
            if stop_before is not None and getattr(m, "name", None) == stop_before:
                return x
            x = m.forward(x)
        return x
    def backward(self, dy):
        grads = {}
        for m in reversed(self.modules):
            dy = m.backward(dy)
            grads.update(m.grad)
        return grads
    def module(self, name):
        return next(m for m in self.modules if getattr(m, "name", None) == name)


ARCHITECTURES = {
    # id: (description, builder)
    "mnist_relu_fc2": ("784-128-64-10, ReLU; target fc2 (K=128). Same architecture as the first MNIST checkpoint of the project.",
                       lambda rng: Sequential([Linear(rng, 784, 128, "fc1"), ReLU(), Linear(rng, 128, 64, "fc2"), ReLU(), Linear(rng, 64, 10, "fc3")])),
    "mnist_gelu_ln_fc2": ("784-128-GELU-LayerNorm-64-GELU-10; target fc2 (K=128). fc2 input is a LayerNorm output: zero-mean, mixed sign, as the FFN input of a Transformer block.",
                          lambda rng: Sequential([Linear(rng, 784, 128, "fc1"), GELU(), LayerNorm(128, "ln1"), Linear(rng, 128, 64, "fc2"), GELU(), Linear(rng, 64, 10, "fc3")])),
    "mnist_relu_fc2_k512": ("784-512-64-10, ReLU; target fc2 (K=512, B=16 blocks).",
                            lambda rng: Sequential([Linear(rng, 784, 512, "fc1"), ReLU(), Linear(rng, 512, 64, "fc2"), ReLU(), Linear(rng, 64, 10, "fc3")])),
}


def softmax_xent(logits, y):
    p = np.exp(logits - logits.max(axis=1, keepdims=True)); p /= p.sum(axis=1, keepdims=True)
    loss = float(-np.log(np.maximum(p[np.arange(len(y)), y], 1e-20)).mean())
    p[np.arange(len(y)), y] -= 1
    return loss, (p / len(y)).astype(np.float32)


def accuracy(net, x, y, batch=1024):
    correct = 0
    for i in range(0, len(x), batch):
        correct += int(np.count_nonzero(net.forward(x[i:i+batch]).argmax(axis=1) == y[i:i+batch]))
    return correct / len(x)


def train(net, x, y, train_ids, val_ids, epochs=10, seed=20261017, lr=1e-3, batch=256, log=print):
    rng = np.random.default_rng(seed + 1)
    p = net.params(); m = {k: np.zeros_like(v) for k, v in p.items()}; v = {k: np.zeros_like(a) for k, a in p.items()}
    best, best_acc, history, step = None, -1.0, [], 0
    for epoch in range(epochs):
        losses = []
        order = rng.permutation(train_ids)
        for i in range(0, len(order), batch):
            idx = order[i:i+batch]
            loss, dlogits = softmax_xent(net.forward(x[idx]), y[idx]); losses.append(loss); step += 1
            g = net.backward(dlogits)
            for k in p:
                m[k] = .9 * m[k] + .1 * g[k]; v[k] = .999 * v[k] + .001 * g[k] * g[k]
                p[k] -= (lr * (m[k] / (1 - .9 ** step)) / (np.sqrt(v[k] / (1 - .999 ** step)) + 1e-8)).astype(np.float32)
        val = accuracy(net, x[val_ids], y[val_ids])
        row = {"epoch": epoch + 1, "train_loss": float(np.mean(losses)), "model_validation_accuracy": val}
        history.append(row); log(json.dumps(row))
        if val > best_acc: best_acc, best = val, {k: a.copy() for k, a in p.items()}
    for k in p: p[k][...] = best[k]
    return history


def extract_layer(net, x, layer):
    """Return (X_in [N,K], W [M,K], bias [M]) of nn.Linear `layer` for inputs x."""
    lin = net.module(layer)
    xin = net.forward(x, stop_before=layer).astype(np.float32)
    return xin, lin.w.T.astype(np.float32), lin.b.astype(np.float32)


def task_metric_with_replacement(net, x, y, layer, replace_fn, batch=512):
    """Accuracy when the output of `layer` (pre-bias) is replaced by replace_fn(X_in, W)."""
    correct = 0; changed = 0
    for i in range(0, len(x), batch):
        xb, yb = x[i:i+batch], y[i:i+batch]
        ref = net.forward(xb).argmax(axis=1)
        xin, w, b = extract_layer(net, xb, layer)
        yrep = replace_fn(xin, w) + b
        # continue the forward pass after `layer`
        mods = net.modules; k = next(i for i, m in enumerate(mods) if getattr(m, "name", None) == layer)
        h = yrep.astype(np.float32)
        for m in mods[k+1:]: h = m.forward(h)
        pred = h.argmax(axis=1)
        correct += int(np.count_nonzero(pred == yb)); changed += int(np.count_nonzero(pred != ref))
    return {"accuracy": correct / len(x), "prediction_change_vs_fp32": changed / len(x)}


# ----------------------------------------------------------------------------
# Synthetic stress families (plan section 10). Distributions, exponent ranges
# and seeds are fixed here, before any experiment is run.
# ----------------------------------------------------------------------------
def synthetic(family, k=128, n=512, m=64, seed=20261017, split=0):
    rng = np.random.default_rng([seed, split, zlib.crc32(family.encode())])
    b = k // 32
    if family == "gauss":            # zero-centred, iid N(0,1); uniform block scales
        x = rng.standard_normal((n, k)); w = rng.standard_normal((m, k))
    elif family == "outlier":        # N(0,1) plus one element per vector scaled by 2^8 (Transformer-style outlier channel)
        x = rng.standard_normal((n, k)); pos = rng.integers(0, k, n); x[np.arange(n), pos] *= 256.0
        w = rng.standard_normal((m, k))
    elif family == "mixed_scale":    # each 32-block scaled by 2^u, u ~ U[-6, 6]
        x = rng.standard_normal((n, b, 32)) * np.exp2(rng.uniform(-6, 6, (n, b, 1))); x = x.reshape(n, k)
        w = rng.standard_normal((m, b, 32)) * np.exp2(rng.uniform(-6, 6, (m, b, 1))); w = w.reshape(m, k)
    elif family == "cancellation":   # x = [v, v], w = [u, -u + small]: exact terms cancel to ~1e-3 of their magnitude
        half = k // 2
        v = rng.standard_normal((n, half)); u = rng.standard_normal((m, half))
        x = np.concatenate([v, v], axis=1); w = np.concatenate([u, -u + 1e-3 * rng.standard_normal((m, half))], axis=1)
    elif family == "scale_gap":      # one block at scale 2^12, the rest at 2^0, values chosen near FP4 midpoints
        x = rng.choice([0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0], (n, k)) * rng.choice([-1, 1], (n, k)); x[:, :32] *= 4096.0
        w = rng.choice([0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0], (m, k)) * rng.choice([-1, 1], (m, k))
    else:
        raise ValueError(family)
    return x.astype(np.float32), w.astype(np.float32)


SYNTHETIC_FAMILIES = {
    "syn_gauss": "iid N(0,1) activations and weights (zero-centred, no scale structure)",
    "syn_outlier": "N(0,1) with one element per activation vector x256 (outlier channel)",
    "syn_mixed_scale": "per-32-block scale 2^U[-6,6] on both operands",
    "syn_cancellation": "x=[v,v], w=[u,-u+1e-3 n]: result is ~1e-3 of the summed term magnitude",
    "syn_scale_gap": "block 0 at 2^12, others at 2^0; FP4-exact values on rounding midpoints",
}


# ----------------------------------------------------------------------------
# Study: for one (X_cal, X_test, W) workload, compute everything the selector,
# the figures and the report need.
# ----------------------------------------------------------------------------
def disparity_stats(g):
    disp = g.exponents.max(axis=-1)[..., None] - g.exponents
    per_tx = disp.max(axis=-1)
    ref = as_float(*exact(g))
    magsum = np.sum(np.abs(g.sums.astype(np.float64)) * np.exp2(g.exponents.astype(np.float64)), axis=-1)
    canc = np.abs(ref) / np.maximum(magsum, 1e-300)
    return {"max_disparity_bits": int(per_tx.max()),
            "disparity_p50": float(np.percentile(per_tx, 50)), "disparity_p99": float(np.percentile(per_tx, 99)),
            "disparity_histogram": {int(k): int(v) for k, v in zip(*np.unique(per_tx, return_counts=True))},
            "cancellation_p01": float(np.percentile(canc, 1)), "cancellation_p10": float(np.percentile(canc, 10)),
            "cancellation_p50": float(np.percentile(canc, 50)),
            "all_zero_result_fraction": float(np.mean(ref == 0))}


def exactness_threshold(spread, candidates=CANDIDATES):
    """Smallest candidate F that satisfies the *sufficient* exactness condition F >= spread.

    F >= max block-exponent spread guarantees that every alignment is a left shift,
    hence zero accumulation error. It is not necessary: a right shift whose discarded
    bits are all zero is exact as well, so the smallest zero-error candidate can be
    below this value. None when no candidate reaches the spread.
    """
    return next((f for f in candidates if f >= spread), None)


def fp32_reference_metrics(x, w, g, golden=None):
    """Error of the exact MXFP4 dot product against the FP32 layer (FP4 *quantization* error).

    This is separate from the accumulation error that F controls: the exact
    MXFP4 product is the reference for every F, and this function reports how far
    that reference already is from Y = X W^T in float32.
    """
    ref32 = np.asarray(x, dtype=np.float64) @ np.asarray(w, dtype=np.float64).T
    mx = as_float(*(golden if golden is not None else exact(g)))
    err = mx - ref32
    denom = max(float(np.linalg.norm(ref32)), 1e-12)
    return {"nrmse_vs_fp32": float(np.linalg.norm(err) / denom), "max_abs_vs_fp32": float(np.abs(err).max()),
            "fp32_rms": float(np.sqrt(np.mean(ref32 ** 2)))}


def total_error_vs_fp32(x, w, g, f):
    """NRMSE of the F-bit MXFP4 result against FP32: quantization and accumulation error combined."""
    ref32 = np.asarray(x, dtype=np.float64) @ np.asarray(w, dtype=np.float64).T
    t, e = accumulate(g, f)
    err = as_float(t, e) - ref32
    return float(np.linalg.norm(err) / max(float(np.linalg.norm(ref32)), 1e-12))


def _as_layer_array(values, name, k=None):
    a = np.asarray(values)
    if a.ndim != 2 or not a.size:
        raise ValueError(f"{name} must be a nonempty 2-D array, got shape {a.shape}")
    if not np.issubdtype(a.dtype, np.floating):
        raise ValueError(f"{name} must be floating point, got {a.dtype}")
    if not np.isfinite(a).all():
        raise ValueError(f"{name} contains nonfinite values")
    if a.shape[1] % 32:
        raise ValueError(f"{name}: K={a.shape[1]} is not a multiple of the 32-element MX block")
    if k is not None and a.shape[1] != k:
        raise ValueError(f"{name}: K={a.shape[1]} differs from K={k}")
    return a.astype(np.float32)


def load_workload(root, workload, lanes=4, test_optional=False):
    """Resolve a workload name or directory to the common layer contract.

    Accepts a builtin id under <root>/data/workloads/<id>/ or any directory that
    contains calibration.npz and test.npz with keys x: [N,K] and w: [M,K] (the
    layer_npz entry point; extra keys such as bias or provenance columns are
    kept in `extra_keys` and ignored by the arithmetic). The weights stored with
    the test split must be identical to the calibration weights.
    """
    root = Path(root)
    name = str(workload)
    is_name = name == Path(name).name and not name.startswith((".", "~"))   # a bare id, not a path
    builtin = root / "data/workloads" / name if is_name else None
    folder = builtin if builtin is not None and builtin.is_dir() else Path(name).expanduser()
    recorded = None
    if (folder / "calibration.npz").exists() and not (folder / "test.npz").exists():
        from .embedded import recorded_test               # the notebook embeds this layer's calibration split only
        recorded = recorded_test(root, folder.name)
        if recorded is not None and not test_optional:
            raise FileNotFoundError(f"workload '{workload}': its test split is not in the support package (recorded results only); choose a layer with an included test split")
    if not (folder / "calibration.npz").exists() or (not (folder / "test.npz").exists() and recorded is None):
        raise FileNotFoundError(f"workload '{workload}': no calibration.npz/test.npz under {folder}")
    cal = np.load(folder / "calibration.npz", allow_pickle=False)
    tst = None if recorded is not None else np.load(folder / "test.npz", allow_pickle=False)
    for name, npz in (("calibration.npz", cal), ("test.npz", tst)):
        if npz is None: continue
        missing = {"x", "w"} - set(npz.files)
        if missing:
            raise ValueError(f"workload '{workload}': {name} lacks keys {sorted(missing)}")
    w = _as_layer_array(cal["w"], "calibration w")
    k = int(w.shape[1])
    x_cal = _as_layer_array(cal["x"], "calibration x", k)
    x_test = None if tst is None else _as_layer_array(tst["x"], "test x", k)
    if tst is not None:
        w_test = _as_layer_array(tst["w"], "test w", k)
        if w_test.shape != w.shape or not np.array_equal(w_test, w):
            raise ValueError(f"workload '{workload}': test.npz weights differ from calibration.npz weights")
    manifest = json.loads((folder / "manifest.json").read_text()) if (folder / "manifest.json").exists() else {}
    if manifest.get("k") not in (None, k):
        raise ValueError(f"workload '{workload}': manifest k={manifest.get('k')} but data K={k}")
    wid = manifest.get("id") or folder.name
    data_hash = hashlib.sha256()
    for a in (x_cal, w, x_test):
        if a is not None: data_hash.update(np.ascontiguousarray(a).tobytes())
    if recorded is not None:                              # calibration checked against the record; the full hash is the recorded one
        if data_hash.hexdigest() != recorded["calibration_sha256"]:
            raise ValueError(f"workload '{workload}': the calibration split in the support package differs from the recorded one")
        data_hash = hashlib.sha256(); data_hash.update(bytes.fromhex(recorded["data_sha256"]))
    is_builtin = folder.resolve().parent == (root / "data/workloads").resolve()
    return {"id": wid, "source": "builtin" if is_builtin else "layer_npz", "path": str(folder),
            "kind": manifest.get("kind", "layer_npz"), "description": manifest.get("description", ""),
            "manifest": manifest, "k": k, "lanes": int(lanes), "outputs": int(w.shape[0]),
            "x_cal": x_cal, "x_test": x_test, "w": w,
            "data_sha256": recorded["data_sha256"] if recorded is not None else data_hash.hexdigest(),
            "test_source": "recorded" if recorded is not None else "embedded",
            "extra_keys": sorted((set(cal.files) | set(tst.files if tst is not None else [])) - {"x", "w"})}


def study(x_cal, x_test, w, k, budgets=(1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 0.0), candidates=CANDIDATES):
    wc, ws, winfo = quantize(w)
    xc, xs, xinfo = quantize(x_cal); tc, ts, tinfo = quantize(x_test)
    gc = groups(xc, xs, wc, ws); gt = groups(tc, ts, wc, ws)
    gold_c, gold_t = exact(gc), exact(gt)
    cal = [metrics(gc, f, gold_c) for f in candidates]
    test = [metrics(gt, f, gold_t) for f in candidates]
    for rows, x, g in ((cal, x_cal, gc), (test, x_test, gt)):
        for r in rows:
            r["nrmse_vs_fp32"] = total_error_vs_fp32(x, w, g, r["f"])
    by_f_cal = {r["f"]: r for r in cal}; by_f_test = {r["f"]: r for r in test}
    selections = []
    for budget in budgets:
        feasible = [f for f in candidates if by_f_cal[f]["nrmse"] <= budget]
        f = min(feasible) if feasible else None
        selections.append({"budget": budget, "feasible_f": feasible, "selected_f": f,
                           "w": None if f is None else width(k, f),
                           "test_nrmse": None if f is None else by_f_test[f]["nrmse"],
                           "test_pass": None if f is None else by_f_test[f]["nrmse"] <= budget,
                           "fixed_f4_meets_budget": by_f_cal[4]["nrmse"] <= budget,
                           "fixed_f4_test_pass": by_f_test[4]["nrmse"] <= budget})
    disp_c, disp_t = disparity_stats(gc), disparity_stats(gt)
    spread = int(disp_c["max_disparity_bits"])
    return {"k": k, "calibration_samples": int(len(x_cal)), "test_samples": int(len(x_test)), "outputs": int(len(w)),
            "scale_clips": {"x_cal": xinfo["scale_clips"], "x_test": tinfo["scale_clips"], "w": winfo["scale_clips"]},
            "calibration": cal, "test": test, "selections": selections,
            "quantization_cal": fp32_reference_metrics(x_cal, w, gc, gold_c),
            "quantization_test": fp32_reference_metrics(x_test, w, gt, gold_t),
            "disparity_cal": disp_c, "disparity_test": disp_t,
            "spread_bits": spread,
            # F >= spread is sufficient for zero accumulation error; the smallest zero-error
            # candidate may be lower (discarded bits all zero) but never above this candidate.
            "sufficient_exact_candidate_f": exactness_threshold(spread, candidates),
            "smallest_zero_error_candidate_f": next((r["f"] for r in cal if r["nrmse"] == 0), None),
            "calibration_hash": array_hash(xc, xs, wc, ws), "test_hash": array_hash(tc, ts, wc, ws)}


def mx_layer_fn(f):
    """Return a function (X, W) -> Y_F in float32 for plugging into a model."""
    def fn(x, w):
        xc, xs, _ = quantize(x); wc, ws, _ = quantize(w)
        g = groups(xc, xs, wc, ws)
        if f is None:
            return as_float(*exact(g)).astype(np.float32)
        t, e = accumulate(g, f)
        return as_float(t, e).astype(np.float32)
    return fn
