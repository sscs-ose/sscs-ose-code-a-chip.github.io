"""One implementation-result reader for CLI reports and the teaching notebook.

Unknown is different from pass. Cached implementation evidence is checked against
the current RTL, configuration and archived source metrics before qualification.
"""
from pathlib import Path
import hashlib
import json


from .embedded import file_digest

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def conditions(config, environment):
    return {'config': {k: v for k, v in config.items()
                       if k not in {'DESIGN_NAME', 'VERILOG_FILES'}},
            'environment': environment}


def rtl_evidence(root, f):
    root = Path(root)
    p = root / f'results/rtl/k128_f{f}/summary.json'
    if not p.exists():
        return None
    row = json.loads(p.read_text())
    vectors, log = p.parent / 'vectors.txt', p.parent / 'simulation.log'
    valid = (row.get('k') == 128 and row.get('f') == f and row.get('e_bound') is None
             and row.get('status') == 'pass' and row.get('mismatches') == 0
             and row.get('rtl_sha256') == sha256(root / 'rtl/dot_top.sv')
             and isinstance(row.get('ii_no_stall'), int) and row['ii_no_stall'] > 0
             and vectors.exists() and row.get('vectors_sha256') == sha256(vectors)
             and log.exists() and f"PASS transactions={row['transactions']}" in log.read_text())
    return row if valid else None


def validate_physical(root, row):
    """Return reasons the imported evidence cannot qualify the current design."""
    root = Path(root)
    errors = []
    if row.get('schema_version') != '0.2':
        return ['physical record requires v0.2 run evidence; re-import the actual run']
    if (row.get('k'), row.get('lanes')) != (128, 4):
        errors.append('architecture mismatch')
    try:
        f = row['f']
        manifest_path = root / row['evidence_manifest']
        if not manifest_path.resolve().is_relative_to(root.resolve()):
            raise ValueError('evidence path outside project')
        manifest = json.loads(manifest_path.read_text())
        if sha256(manifest_path) != row['evidence_manifest_sha256']:
            errors.append('evidence manifest changed')
        for key,value in manifest['reported_metrics'].items():
            if row.get(key)!=value:errors.append('imported metric changed: '+key)
        if (manifest.get('f'),manifest.get('k'),manifest.get('lanes'))!=(f,128,4):
            errors.append('run manifest architecture mismatch')
        # file_digest: the file's own hash; in the notebook's embedded edition a large view or report that is not
        # embedded has the digest attested when the notebook was built (mxacc.embedded), never a pass by default
        for rel, digest in manifest['evidence_files'].items():
            p = manifest_path.parent / rel
            if not p.resolve().is_relative_to(manifest_path.parent.resolve()) or file_digest(root, p) != digest:
                errors.append('archived evidence changed: ' + rel)
        for rel,digest in manifest.get('final_view_hashes',{}).items():
            p=manifest_path.parent.parent/rel
            if not p.resolve().is_relative_to(manifest_path.parent.parent.resolve()) or file_digest(root, p)!=digest:
                errors.append('final layout evidence changed: '+rel)
        for rel, digest in manifest['source_hashes'].items():
            if file_digest(root, rel) != digest:
                errors.append('source changed: ' + rel)
        config = json.loads((root / f'flow/f{f}/config.json').read_text())
        environment = json.loads((root / 'flow/environment.json').read_text())
        expected = conditions(config, environment)
        if manifest['conditions'] != expected:
            errors.append('implementation conditions differ from current config/toolchain/PDK')
        expected_signature=json_hash(expected)
        if manifest['comparison_signature'] != expected_signature:
            errors.append('comparison signature mismatch')
        if row.get('comparison_signature')!=manifest['comparison_signature']:
            errors.append('result comparison signature mismatch')
        if environment.get('host_adapter') and file_digest(root, environment['host_adapter'])!=environment.get('host_adapter_sha256'):
            errors.append('host adapter changed')
        if not environment.get('pdk_revision'):
            errors.append('PDK revision is missing')
        if row.get('clock_period_ns') != config['CLOCK_PERIOD']:
            errors.append('clock differs from implementation configuration')
        if manifest.get('completed_post_route') is not True:
            errors.append('post-route completion not established')
    except (KeyError, OSError, ValueError, TypeError) as exc:
        errors.append('missing/invalid implementation evidence: ' + str(exc))
    return errors


def area_lookup(records):
    """Map (k, lanes, f) -> {stage: cell_area_um2}. Area is never borrowed across architectures."""
    area = {}
    for r in records:
        if r.get('cell_area_um2') is None or r.get('k') is None or r.get('lanes') is None:
            continue
        area.setdefault((int(r['k']), int(r['lanes']), int(r['f'])), {})[r['stage']] = r['cell_area_um2']
    return area


def area_for(area, k, lanes, f, stage=None):
    """Return the measured area for one architecture/F, or the string 'not_evaluated'."""
    stages = area.get((int(k), int(lanes), int(f)), {})
    if stage is not None:
        return stages.get(stage, 'not_evaluated')
    return stages if stages else 'not_evaluated'


def load_implementations(root):
    """Return both stages plus one preferred (post-route first) row per F."""
    root = Path(root)
    rows, diagnostics = [], []
    files = sorted((root / 'results/synthesis').glob('*/summary.json'))
    files += sorted((root / 'results/physical').glob('f*.json'))
    core = sha256(root / 'rtl/dot_top.sv')
    for path in files:
        row = json.loads(path.read_text())
        f = row['f']
        reasons = []
        if row.get('rtl_sha256') != core:
            reasons.append('RTL source changed')
        if row.get('stage') == 'post_route':
            reasons += validate_physical(root, row)
        elif row.get('stage') == 'post_synthesis':
            lib = root / 'tech/gf180_1x_tt_5v00.lib'
            if not lib.exists() or row.get('liberty_sha256') != sha256(lib):
                reasons.append('synthesis Liberty changed')
        else:
            reasons.append('unsupported implementation stage')
        rt = rtl_evidence(root, f)
        row.update(rtl_pass=rt is not None, ii_no_stall=None if rt is None else rt['ii_no_stall'],
                   provenance_pass=not reasons, provenance_errors=reasons,
                   record_path=str(path.relative_to(root)))
        if reasons:
            diagnostics.append({'f': f, 'path': row['record_path'], 'reasons': reasons})
        rows.append(row)
    preferred = {}
    for row in rows:
        old = preferred.get(row['f'])
        if old is None or row['stage'] == 'post_route':
            preferred[row['f']] = row
    return {'all_records': rows, 'costs': [preferred[f] for f in sorted(preferred)],
            'diagnostics': diagnostics}
