// SPDX-License-Identifier: Apache-2.0
module dot_k128_f12_inexact(input wire clk,rst,start,output wire start_ready,
 input wire meta_valid,output wire meta_ready,input wire [7:0] x_scale,w_scale,
 input wire in_valid,output wire in_ready,input wire [15:0] x_codes,w_codes,
 output wire out_valid,input wire out_ready,output wire signed [27:0] out_int,
 output wire signed [9:0] out_exp,output wire invalid,out_of_contract,
 output wire inexact);
dot_top_inexact #(.K(128),.F(12),.USE_BOUND(0),.E_BOUND(0)) core(.clk(clk),.rst(rst),.start(start),.start_ready(start_ready),.meta_valid(meta_valid),.meta_ready(meta_ready),.x_scale(x_scale),.w_scale(w_scale),.in_valid(in_valid),.in_ready(in_ready),.x_codes(x_codes),.w_codes(w_codes),.out_valid(out_valid),.out_ready(out_ready),.out_int(out_int),.out_exp(out_exp),.invalid(invalid),.out_of_contract(out_of_contract),.inexact(inexact));
endmodule
