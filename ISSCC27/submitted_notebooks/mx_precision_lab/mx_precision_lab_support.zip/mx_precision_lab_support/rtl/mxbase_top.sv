// SPDX-License-Identifier: Apache-2.0
// Baseline for the selective-recompute comparison: N independent fixed-F
// dot_top cores with the same flattened interface as mxsys_top (no flag, no
// record port, no shared unit). Routed with the same die, clock and flow
// settings as mxsys_top so the two tops differ only in the mechanism.
module mxbase_top #(
  parameter integer N = 4,
  parameter integer K = 128,
  parameter integer F = 6,
  parameter integer B = K/32,
  parameter integer W = 14 + $clog2(B) + F
) (
  input wire clk, rst,
  input wire [N-1:0] start,
  output wire [N-1:0] start_ready,
  input wire [N-1:0] meta_valid,
  output wire [N-1:0] meta_ready,
  input wire [N*8-1:0] x_scale, w_scale,
  input wire [N-1:0] in_valid,
  output wire [N-1:0] in_ready,
  input wire [N*16-1:0] x_codes, w_codes,
  output wire [N-1:0] out_valid,
  input wire [N-1:0] out_ready,
  output wire [N*W-1:0] out_int,
  output wire [N*10-1:0] out_exp,
  output wire [N-1:0] invalid, out_of_contract
);
  genvar c;
  generate for (c = 0; c < N; c = c + 1) begin: cores
    dot_top #(.K(K), .F(F)) core (
      .clk(clk), .rst(rst),
      .start(start[c]), .start_ready(start_ready[c]),
      .meta_valid(meta_valid[c]), .meta_ready(meta_ready[c]),
      .x_scale(x_scale[c*8+:8]), .w_scale(w_scale[c*8+:8]),
      .in_valid(in_valid[c]), .in_ready(in_ready[c]),
      .x_codes(x_codes[c*16+:16]), .w_codes(w_codes[c*16+:16]),
      .out_valid(out_valid[c]), .out_ready(out_ready[c]),
      .out_int(out_int[c*W+:W]), .out_exp(out_exp[c*10+:10]),
      .invalid(invalid[c]), .out_of_contract(out_of_contract[c]));
  end endgenerate
endmodule
