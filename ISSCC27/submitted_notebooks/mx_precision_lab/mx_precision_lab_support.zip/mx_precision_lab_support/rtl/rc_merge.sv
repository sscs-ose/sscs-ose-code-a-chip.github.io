// SPDX-License-Identifier: Apache-2.0
// Shared exact merge unit for selective recompute (v0.3.3).
//
// Input: one recompute record {core, id, S_g[0..B-1], E_g[0..B-1]} produced by a
// low-F dot_top_rc core whose result was flagged inexact. The block sums S_g
// are already exact (14 signed bits each), so this unit needs no multipliers:
// it re-does only the cross-block alignment and accumulation, with F_H = D_MAX
// fractional bits.
//
// Exactness contract: for every record whose block-exponent spread
// max_g(E_max - E_g) is <= D_MAX, every alignment is a LEFT shift and the
// output {out_int, out_exp} is the exact MXFP4 dot product (W_H = 14 +
// clog2(B) + D_MAX bits cannot overflow). A record with spread > D_MAX is
// reported with out_of_contract = 1 and out_int = 0 (no silent rounding).
//
// Throughput: B + 2 cycles per record (one block per cycle plus latch and
// output); in_ready is low while a record is being processed or an output is
// waiting for out_ready.
module rc_merge #(
  parameter integer B = 4,
  parameter integer D_MAX = 24,
  parameter integer ID_W = 8,
  parameter integer CORE_W = 4,
  parameter integer W_H = 14 + $clog2(B) + D_MAX
) (
  input wire clk, rst,
  input wire in_valid,
  output wire in_ready,
  input wire [CORE_W-1:0] in_core,
  input wire [ID_W-1:0] in_id,
  input wire [B*14-1:0] in_sums,
  input wire [B*9-1:0] in_exps,
  output reg out_valid,
  input wire out_ready,
  output reg [CORE_W-1:0] out_core,
  output reg [ID_W-1:0] out_id,
  output reg signed [W_H-1:0] out_int,
  output reg signed [9:0] out_exp,
  output reg out_of_contract
);
  localparam IDLE = 0, RUN = 1, DONE = 2;
  localparam GI = (B > 1) ? $clog2(B) : 1;
  localparam SW = $clog2(D_MAX + 1) + 1;   // shift amount 0..D_MAX, plus sign for the contract check
  reg [1:0] state;
  reg [GI-1:0] g;
  reg signed [13:0] sums [0:B-1];
  reg signed [8:0] exps [0:B-1];
  reg signed [8:0] emax;
  reg signed [W_H-1:0] acc;
  reg ooc;
  reg [CORE_W-1:0] core_r;
  reg [ID_W-1:0] id_r;
  integer k;

  // E_max of the incoming record (combinational tree over B exponents).
  function automatic signed [8:0] max_exp;
    input [B*9-1:0] e;
    integer i; reg signed [8:0] m, v;
    begin
      m = $signed(e[8:0]);
      for (i = 1; i < B; i = i + 1) begin
        v = $signed(e[i*9+:9]);
        if (v > m) m = v;
      end
      max_exp = m;
    end
  endfunction

  assign in_ready = (state == IDLE);

  wire signed [10:0] shift = D_MAX + $signed({{2{exps[g][8]}}, exps[g]}) - $signed({{2{emax[8]}}, emax});
  wire signed [W_H-1:0] ext = {{(W_H-14){sums[g][13]}}, sums[g]};
  wire [SW-1:0] lshift = shift[SW-1:0];
  wire signed [W_H-1:0] term = (shift >= 0) ? (ext <<< lshift) : {W_H{1'b0}};

  always @(posedge clk) begin
    if (rst) begin
      state <= IDLE; g <= 0; acc <= 0; ooc <= 0; emax <= 0; core_r <= 0; id_r <= 0;
      out_valid <= 0; out_core <= 0; out_id <= 0; out_int <= 0; out_exp <= 0; out_of_contract <= 0;
    end else begin
      case (state)
        IDLE: if (in_valid) begin
          for (k = 0; k < B; k = k + 1) begin
            sums[k] <= $signed(in_sums[k*14+:14]);
            exps[k] <= $signed(in_exps[k*9+:9]);
          end
          emax <= max_exp(in_exps);
          core_r <= in_core; id_r <= in_id;
          acc <= 0; ooc <= 0; g <= 0; state <= RUN;
        end
        RUN: begin
          if (shift < 0) ooc <= 1;
          acc <= acc + term;
          if (g == B-1) state <= DONE;
          else g <= g + 1'b1;
        end
        DONE: begin
          if (!out_valid) begin
            out_valid <= 1; out_core <= core_r; out_id <= id_r;
            out_int <= ooc ? {W_H{1'b0}} : acc;
            out_exp <= ooc ? 10'sd0 : ($signed({emax[8], emax}) - D_MAX);
            out_of_contract <= ooc;
          end else if (out_ready) begin
            out_valid <= 0; state <= IDLE;
          end
        end
        default: state <= IDLE;
      endcase
    end
  end
endmodule
