// SPDX-License-Identifier: Apache-2.0
// Selective-recompute system (v0.3.3): N low-F dot_top_rc cores, a round-robin
// arbiter, a small shared record queue (depth Q) and one shared exact merge
// unit (rc_merge, F_H = D_MAX). A core that finished an inexact transaction
// offers its record; the arbiter grants one core per cycle while the queue has
// room; the merge unit drains the queue at one record per B+3 cycles and
// returns {core, id, exact result} on a single return port. A core whose
// record is not yet accepted stays in OUT (back-pressure): nothing is lost,
// nothing is duplicated, and the queue can never overflow (the arbiter grants
// only into free space).
//
// Port vectors are flattened per core (index c occupies bits [c*WIDTH +: WIDTH]).
module mxsys_top #(
  parameter integer N = 4,
  parameter integer K = 128,
  parameter integer F = 2,
  parameter integer D_MAX = 24,
  parameter integer Q = 2,
  parameter integer ID_W = 8,
  parameter integer B = K/32,
  parameter integer W = 14 + $clog2(B) + F,
  parameter integer W_H = 14 + $clog2(B) + D_MAX,
  parameter integer CORE_W = (N > 1) ? $clog2(N) : 1
) (
  input wire clk, rst,
  // per-core transaction interface (same as dot_top, flattened)
  input wire [N-1:0] start,
  output wire [N-1:0] start_ready,
  input wire [N-1:0] meta_valid,
  output wire [N-1:0] meta_ready,
  input wire [N*8-1:0] x_scale, w_scale,
  input wire [N-1:0] in_valid,
  output wire [N-1:0] in_ready,
  input wire [N*16-1:0] x_codes, w_codes,
  output wire [N-1:0] out_valid,
  input wire [N-1:0] out_ready,
  output wire [N*W-1:0] out_int,
  output wire [N*10-1:0] out_exp,
  output wire [N-1:0] invalid, out_of_contract, inexact,
  output wire [N*ID_W-1:0] out_id,
  // shared return port: the exact result of a flagged transaction
  output wire ret_valid,
  input wire ret_ready,
  output wire [CORE_W-1:0] ret_core,
  output wire [ID_W-1:0] ret_id,
  output wire signed [W_H-1:0] ret_int,
  output wire signed [9:0] ret_exp,
  output wire ret_out_of_contract,
  // observability (for the testbench / cycle model): queue occupancy and grants
  output wire [$clog2(Q+1)-1:0] queue_count,
  output wire [N-1:0] rc_pending
);
  localparam REC_W = CORE_W + ID_W + B*14 + B*9;

  // ---------------- cores ----------------
  wire [N-1:0] rc_valid, rc_ready;
  wire [N*B*14-1:0] rc_sums;
  wire [N*B*9-1:0] rc_exps;
  wire [N*ID_W-1:0] rc_id;
  genvar c;
  generate for (c = 0; c < N; c = c + 1) begin: cores
    dot_top_rc #(.K(K), .F(F), .ID_W(ID_W)) core (
      .clk(clk), .rst(rst),
      .start(start[c]), .start_ready(start_ready[c]),
      .meta_valid(meta_valid[c]), .meta_ready(meta_ready[c]),
      .x_scale(x_scale[c*8+:8]), .w_scale(w_scale[c*8+:8]),
      .in_valid(in_valid[c]), .in_ready(in_ready[c]),
      .x_codes(x_codes[c*16+:16]), .w_codes(w_codes[c*16+:16]),
      .out_valid(out_valid[c]), .out_ready(out_ready[c]),
      .out_int(out_int[c*W+:W]), .out_exp(out_exp[c*10+:10]),
      .invalid(invalid[c]), .out_of_contract(out_of_contract[c]), .inexact(inexact[c]),
      .out_id(out_id[c*ID_W+:ID_W]),
      .rc_valid(rc_valid[c]), .rc_ready(rc_ready[c]),
      .rc_sums(rc_sums[c*B*14+:B*14]), .rc_exps(rc_exps[c*B*9+:B*9]), .rc_id(rc_id[c*ID_W+:ID_W]));
  end endgenerate
  assign rc_pending = rc_valid;

  // ---------------- round-robin arbiter (N is a power of two) ----------------
  // Rotate the request vector so that the core after `last` is at bit 0, isolate
  // the lowest set bit, rotate back. Purely combinational, no priority loop.
  reg [CORE_W-1:0] last;
  wire space;
  wire [2*N-1:0] req_dbl = {rc_valid, rc_valid} >> (last + 1'b1);
  wire [N-1:0] req_rot = req_dbl[N-1:0];
  wire [N-1:0] grant_rot = space ? (req_rot & (~req_rot + 1'b1)) : {N{1'b0}};
  wire [2*N-1:0] grant_dbl = {grant_rot, grant_rot} << (last + 1'b1);
  wire [N-1:0] grant = grant_dbl[2*N-1:N];
  assign rc_ready = grant;
  reg [CORE_W-1:0] gidx;
  integer i;
  always @(*) begin
    gidx = {CORE_W{1'b0}};
    for (i = 0; i < N; i = i + 1) if (grant[i]) gidx = i[CORE_W-1:0];
  end
  wire [REC_W-1:0] grec = {gidx, rc_id[gidx*ID_W+:ID_W], rc_sums[gidx*B*14+:B*14], rc_exps[gidx*B*9+:B*9]};
  wire any_grant = |grant;

  // ---------------- queue (depth Q, registers) ----------------
  reg [REC_W-1:0] qmem [0:Q-1];
  reg [$clog2(Q+1)-1:0] count;
  reg [(Q > 1 ? $clog2(Q) : 1)-1:0] rd, wr;
  assign space = (count < Q);
  assign queue_count = count;
  wire m_ready;
  wire m_valid = (count != 0);
  wire [REC_W-1:0] head = qmem[rd];
  wire pop = m_valid && m_ready;
  always @(posedge clk) begin
    if (rst) begin
      count <= 0; rd <= 0; wr <= 0; last <= 0;
    end else begin
      if (any_grant) begin
        qmem[wr] <= grec;
        wr <= (Q > 1) ? ((wr == Q-1) ? 0 : wr + 1'b1) : 0;
        last <= gidx;
      end
      if (pop) rd <= (Q > 1) ? ((rd == Q-1) ? 0 : rd + 1'b1) : 0;
      count <= count + (any_grant ? 1'b1 : 1'b0) - (pop ? 1'b1 : 1'b0);
    end
  end

  // ---------------- shared exact merge unit ----------------
  rc_merge #(.B(B), .D_MAX(D_MAX), .ID_W(ID_W), .CORE_W(CORE_W)) merge (
    .clk(clk), .rst(rst),
    .in_valid(m_valid), .in_ready(m_ready),
    .in_core(head[REC_W-1 -: CORE_W]),
    .in_id(head[REC_W-CORE_W-1 -: ID_W]),
    .in_sums(head[B*14+B*9-1 -: B*14]),
    .in_exps(head[B*9-1:0]),
    .out_valid(ret_valid), .out_ready(ret_ready),
    .out_core(ret_core), .out_id(ret_id), .out_int(ret_int), .out_exp(ret_exp), .out_of_contract(ret_out_of_contract));
endmodule
