// SPDX-License-Identifier: Apache-2.0
// MXFP4 E2M1/E8M0 dot-product core: exact dot32 per block, one RNE per block,
// no overflow. v0.3: the cross-block merge is a two-stage, free-running
// pipeline (align/round, then accumulate) that overlaps the next block's data
// phase. Arithmetic is bit-identical to v0.2 and to mxacc.arithmetic.
module dot_top #(
  parameter integer K = 128,
  parameter integer F = 8,
  parameter integer B = K/32,
  parameter integer W = 14 + $clog2(B) + F,
  parameter integer USE_BOUND = 0,
  parameter integer E_BOUND = 0
) (
  input wire clk, rst,
  input wire start,
  output wire start_ready,
  input wire meta_valid,
  output wire meta_ready,
  input wire [7:0] x_scale, w_scale,
  input wire in_valid,
  output wire in_ready,
  input wire [15:0] x_codes, w_codes,
  output wire out_valid,
  input wire out_ready,
  output reg signed [W-1:0] out_int,
  output reg signed [9:0] out_exp,
  output wire invalid, out_of_contract
);
  localparam IDLE=0, META=1, DATA=2, DRAIN=3, OUT=4;
  localparam GI = (B > 1) ? $clog2(B) : 1;
  localparam LW = (F > 0) ? $clog2(F+1) : 1;   // bits needed for a left shift of 0..F
  reg [2:0] state;
  reg [GI-1:0] meta_index, block_index;
  reg [2:0] beat;
  reg signed [8:0] exponents [0:B-1];
  reg signed [8:0] emax;
  reg signed [13:0] block_acc;
  reg bad_scale, bad_bound;
  // Per-block shift amount F + E_g - E_max, registered during the block's data phase.
  reg signed [10:0] cur_sh;
  // Stage A: completed block sum and its shift amount.
  reg a_valid, a_last;
  reg signed [13:0] a_sum;
  reg signed [10:0] a_sh;
  // Stage B: aligned value (floor for right shifts) and the RNE correction bit.
  reg b_valid, b_last, b_round;
  reg signed [W-1:0] b_val;
  // Stage C: running total.
  reg signed [W-1:0] total;

  wire signed [10:0] metadata_e = $signed({3'b0,x_scale}) + $signed({3'b0,w_scale}) - 11'sd256;
  assign start_ready = state == IDLE;
  assign meta_ready = state == META;
  assign in_ready = state == DATA;
  assign out_valid = state == OUT;
  assign invalid = bad_scale;
  assign out_of_contract = bad_bound && !bad_scale;

  function automatic signed [4:0] decode;
    input [3:0] c;
    reg signed [4:0] mag;
    begin
      case(c[2:0])
        0:mag=0; 1:mag=1; 2:mag=2; 3:mag=3;
        4:mag=4; 5:mag=6; 6:mag=8; default:mag=12;
      endcase
      decode = c[3] ? -mag : mag;
    end
  endfunction

  wire signed [9:0] products [0:3];
  genvar lane;
  generate for(lane=0;lane<4;lane=lane+1) begin: multiply_lanes
    assign products[lane] = decode(x_codes[4*lane+:4]) * decode(w_codes[4*lane+:4]);
  end endgenerate
  wire signed [11:0] sum4 =
    {{2{products[0][9]}},products[0]} + {{2{products[1][9]}},products[1]} +
    {{2{products[2][9]}},products[2]} + {{2{products[3][9]}},products[3]};
  wire signed [13:0] sum4_ext = {{2{sum4[11]}},sum4};

  // Alignment for one block. Returns {round_up, value}. For shift >= 0 the
  // value is the exact left shift. For -14 < shift < 0 the value is
  // floor(S_g * 2^shift) and round_up is the round-to-nearest-even correction
  // (guard & (sticky | lsb)), which the accumulator adds as a carry-in. Shifts
  // of -14 or less round to zero because |S_g| <= 4608 < 2^13.
  function automatic [W:0] align;
    input signed [13:0] sg;
    input signed [10:0] sh;
    reg signed [W-1:0] ext;
    reg signed [26:0] y;
    reg signed [13:0] q;
    reg guard, sticky;
    reg [3:0] r;
    reg [LW-1:0] l;
    begin
      ext = {{(W-14){sg[13]}},sg};
      if (sh >= 0) begin
        l = sh[LW-1:0];
        align = {1'b0, ext <<< l};
      end else if (sh <= -11'sd14) begin
        align = {(W+1){1'b0}};
      end else begin
        r = -sh[3:0];                      // 1..13
        y = $signed({sg, 13'b0}) >>> r;    // 13 fractional bits retained
        q = y[26:13];
        guard = y[12];
        sticky = |y[11:0];
        align = {guard & (sticky | q[0]), {{(W-14){q[13]}}, q}};
      end
    end
  endfunction

  wire [W:0] b_next = align(a_sum, a_sh);
  wire signed [W-1:0] acc_next = total + b_val + {{(W-1){1'b0}}, b_round};

  always @(posedge clk) begin
    if(rst) begin
      state<=IDLE; meta_index<=0; block_index<=0; beat<=0;
      block_acc<=0; total<=0; emax<=-9'sd256; cur_sh<=0;
      a_valid<=0; a_last<=0; a_sum<=0; a_sh<=0;
      b_valid<=0; b_last<=0; b_round<=0; b_val<=0;
      bad_scale<=0; bad_bound<=0; out_int<=0; out_exp<=0;
    end else begin
      // Free-running merge pipeline; at most one block completes per 8 cycles.
      a_valid<=0;
      b_valid<=a_valid; b_last<=a_last;
      if(a_valid) begin
        b_val<=b_next[W-1:0]; b_round<=b_next[W];
      end
      if(b_valid) total<=acc_next;
      cur_sh<=F + exponents[block_index] - emax;
      case(state)
        IDLE: if(start) begin
          state<=META; meta_index<=0; block_index<=0; beat<=0;
          block_acc<=0; total<=0; emax<=-9'sd256;
          a_valid<=0; b_valid<=0;
          bad_scale<=0; bad_bound<=0;
        end
        META: if(meta_valid) begin
          exponents[meta_index]<=metadata_e[8:0];
          if($signed(metadata_e)>$signed(emax)) emax<=metadata_e[8:0];
          if(x_scale==255 || w_scale==255) bad_scale<=1;
          if(USE_BOUND && $signed(metadata_e)>E_BOUND) bad_bound<=1;
          if(meta_index==B-1) state<=DATA;
          else meta_index<=meta_index+1'b1;
        end
        DATA: if(in_valid) begin
          if(beat==7) begin
            a_sum<=block_acc+sum4_ext; a_sh<=cur_sh; a_valid<=1;
            a_last<=(block_index==B-1);
            block_acc<=0; beat<=0;
            if(block_index==B-1) state<=DRAIN;
            else block_index<=block_index+1'b1;
          end else begin
            block_acc<=block_acc+sum4_ext; beat<=beat+1'b1;
          end
        end
        DRAIN: if(b_valid && b_last) begin
          out_int<=bad_scale ? {W{1'b0}} : acc_next;
          out_exp<=bad_scale ? 10'sd0 : ($signed(emax)-F);
          state<=OUT;
        end
        OUT: if(out_ready) state<=IDLE;
        default: state<=IDLE;
      endcase
    end
  end
endmodule
