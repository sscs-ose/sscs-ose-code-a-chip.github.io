# Fixed physical comparison

All candidates use GF180MCU D / `gf180mcu_fd_sc_mcu7t5v0`, a common 500 × 500 µm die, a 50 ns clock, 10 % input/output delay (5 ns each), the PDK's nine STA corners (nom/min/max parasitics × TT 25 °C 5 V, SS 125 °C 4.5 V, FF −40 °C 5.5 V) and the PDK's design-rule constraints as shipped with LibreLane (max transition 3 ns, max fanout 10, max capacitance 0.2 pF). Final numbers come from the run's resolved configuration and the post-route STA. This is an open-PDK implementation experiment, not foundry signoff or measured silicon.

The tool bundle (LibreLane 3.0.16 AppImage) and the Ciel PDK revision are pinned in `environment.json`. The settings shared by every candidate are in `flow_settings.json`; `scripts/run_flow.py` merges them into each `flow/f<F>/config.json`, so a candidate cannot be implemented with different settings by accident, and the comparison signature covers them.

## Why these settings

With LibreLane defaults, F2, F4 and F24 failed signoff at the SS corners (setup −5.2 ns, 129 max-slew violations, clock-root cap and fanout). That result was reproduced bit for bit before anything was changed; then two things changed:

1. **RTL (`rtl/dot_top.sv`):** the cross-block merge became a two-stage pipeline (align and round, then accumulate with the rounding bit as carry-in). This alone moves setup from −5.2 ns to +7.0 ns at 50 ns and reduces II from 42 to 40. The arithmetic is unchanged and re-verified (15 configurations, 0 mismatches).
2. **Flow settings (`flow_settings.json`):** the remaining failures were electrical, not timing.
   * `PNR_EXCLUDED_CELL_FILE` → `flow/pnr_exclude.cells`: the PDK's `drc_exclude.cells` plus the delay cells (`dlya/b/c/d_*`) and the weakest buffers (`buf_1`, `clkbuf_1`). The resizer was using them as fanout and max-cap buffers; their SS-corner output transitions exceed the 3 ns limit by construction.
   * `RUN_POST_GRT_DESIGN_REPAIR`, `RUN_POST_GRT_RESIZER_TIMING`: repeat design and timing repair on global-routing parasitics (off by default).
   * `DESIGN_REPAIR_MAX_SLEW_PCT` / `DESIGN_REPAIR_MAX_CAP_PCT` and the `GRT_*` counterparts: repair margins (default 20 % / 10 %) raised so the pre-signoff repair leaves headroom for RCX-extracted parasitics at the max-RC/SS corner. Margins of 35 to 40 % make OpenROAD's `repair_design` iterate over every net with growing memory (> 6 GB, out of memory) in this LibreLane build and are not usable.
   * `CTS_DISTANCE_BETWEEN_BUFFERS`: TritonCTS built a five-level H-tree but buffered only the last two levels, so the root buffer drove 16 branches (max fanout 10, max cap 0.2 pF). Forcing buffers on the upper levels brings the root within the constraints.

None of these relax a PDK constraint. Excluding weak cells *reduced* standard-cell area (fewer, stronger repair buffers).

## Setup on a supported Linux machine

```bash
# LibreLane 3.0.16 devshell AppImage (sha256 in environment.json); ciel enable the pinned gf180mcu revision
export PDK_ROOT=/path/to/pdks
ciel enable --pdk-family gf180mcu --pdk-root $PDK_ROOT 54435919abffb937387ec956209f9cf5fd2dfbee
# orchestration (NumPy) can run in any Python; LibreLane runs in the bundle's interpreter:
export MXACC_LIBRELANE_PYTHON=<devshell>/bin/python3
export MXACC_LIBRELANE_PYTHONPATH=$NIX_PYTHONPATH     # the bundle's site-packages (Yosys' embedded Python needs it on PYTHONPATH)
python scripts/run_flow.py --stage route --f 0 2 4 8 12 24 --pdk-root $PDK_ROOT --run-tag reproduce
python scripts/timing_sweep.py --f 2 24 --clock-ns 35 --pdk-root $PDK_ROOT
```

Yosys' embedded Python derives its prefix from the first `python3` on `PATH`, so the bundle's `bin` must come first on `PATH` when the flow runs. `run_flow.py` requires a fresh run tag, checks the enabled PDK revision, snapshots the RTL hashes before execution, and refuses to overwrite an existing run.

## Import and qualification

A completed run contains `mxacc_input.json`, `resolved.json`, `final/metrics.json`, the post-route STA step and the GDS final views. Import the whole run, not an isolated metrics file:

```bash
python scripts/collect_physical.py --run-dir flow/f2/runs/reproduce --f 2
```

The importer checks the resolved top, every explicit configuration setting (including `flow_settings.json`) and source-file set, then archives the raw metrics, resolved configuration, complete STA coverage reports, nine-corner setup and hold reports, DRC, LVS and XOR reports and final views under `results/physical/f<F>/`. The clock comes from the run.

Qualification (`mxacc.experiment.choose_hardware`) requires: numeric budget, current RTL evidence, provenance, matching clock, setup and hold ≥ 0 at every corner, zero unconstrained paths, zero max-slew and max-cap violations, zero unannotated signal nets, the required rate from `f_clk / II`, zero Magic DRC and Netgen LVS errors, and matching comparison signatures. The post-route cost objective is `design__instance__area__stdcell` (non-filler standard cells, including clock and repair buffers, tap and endcap cells).

`timing__setup__ws` / `timing__hold__ws` are LibreLane's worst slack (positive values retained). `unconstrained_paths` is the conservative coverage count parsed from the explicit `check_setup` sections of every corner report.

In the notebook's embedded project, the raw files a record refers to (layout views, STA and signoff reports) are not present; `EMBEDDED.json` holds their SHA-256, taken from the files when the notebook was built, and the records are checked against those digests.

## Signoff tools

Magic runs the full DRC (`drc(full)`); Netgen runs LVS; KLayout performs the GDS XOR and the render. **KLayout DRC is skipped by LibreLane 3.0.16 for gf180mcu (`KLAYOUT_DRC_RUNSET` is unset for this PDK) and is reported as `not_evaluated`**: this is a tool limitation, not a host restriction. Power is the flow's vectorless estimate only.

## Timing sweep

`scripts/timing_sweep.py` implements candidates at another clock under `flow/timing_sweep/` with identical settings and records post-route STA metrics in `results/timing_sweep/summary.json`. These runs are a labelled experiment for the selector's "no candidate meets the clock" answer and are never imported as cost candidates.
