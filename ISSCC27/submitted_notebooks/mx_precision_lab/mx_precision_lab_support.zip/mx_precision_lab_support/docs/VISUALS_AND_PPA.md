# Circuit views, layout views and the PPA table

Section 6 of `submission.ipynb` shows, for the current design point, the actual netlist connectivity, the real GDS polygons and the source of every cost metric. A picture never establishes timing, electrical legality or task accuracy; those come from the reports named in the PPA table.

## Three levels, always labelled

| Level | Where it comes from | What it is good for |
|---|---|---|
| **Concept** (`assets/concept_mxfp4_core.svg`, `assets/concept_generic_core.svg`, `scripts/draw_core_concepts.py`) | conceptual datapaths that follow the RTL dataflow; hardware outside the measured baseline (the MXFP4 core's optional inexact flag) is drawn dashed and unfilled, with its separately measured cost | naming the stages and the widths that matter for the precision decision |
| **RTL** (`evidence/*/visuals/rtl_multiply.svg`, `rtl_round.svg`, `rtl_accumulator.svg`) | Yosys RTLIL of the real source after `proc; opt; memory_collect; opt` (the MXFP4 core is flattened: `rtl/dot_top.sv`), cone of the target net cut at a fixed depth (`src/mxlab/visuals.py: cone_graph`) | seeing the products and the 4-way adder, the alignment shift with its guard/sticky RNE bit, and the accumulator register with its feedback as the RTL describes them |
| **Gate level** (`mapped_output.svg`) | the technology-mapped netlist (Yosys + ABC on `tech/gf180_1x_tt_5v00.lib`; pin directions from the Liberty), cone of the two least significant output bits | the real GF180 standard cells driving the output |

Every drawing is labelled with its kind, the drawn net, the number of cells, registers and cut inputs in the cone, and the cone depth. Blue boxes are combinational cells or operators, orange boxes registers (labelled `kind · net[hi:lo]`), green the target net, dashed boxes nets cut at the boundary of the cone (not gates); edge labels are bit widths and arrows show data direction. Static decode-ROM control pins are omitted in the local data-path views. Each `visuals/manifest.json` (schema `mxlab-schematic-v2`) stores the RTL hash, the image hashes and the list of original cell names of every view; a view whose RTL hash differs from the RTL in the checkout is reported as stale instead of being shown.

## Layout views

`src/mxlab/gds.py` is a pure-Python GDSII reader (BOUNDARY, BOX, PATH; SREF/AREF with mirror, rotation and magnification) checked once against `gdstk` on the F2 die (83,633 polygons in the overview). Three windows are rendered from the final GDS with the official GF180 mask-layer map: the whole die with Metal1–Metal5 (`layout_overview.png`), a 35 µm window with the routing layers and vias (`layout_routing_zoom.png`), and the same window with Nwell/COMP/Poly2/Contact/Metal1 (`layout_devices_zoom.png`). `layout_manifest.json` stores the GDS hash, the RTL hash, the window and the polygon count per image. The MXFP4 core's layouts exist for F2, F4 and F24 (`evidence/mxfp4_core/K128_F*/layout/`, from `results/physical/f*/final/gds/`); they are titled by their own F and never reused for another candidate. The generic core has no layout: the panel says **Not measured** and the run-hardware steps explain how to produce one (`hardware.run_layout` with an installed LibreLane + PDK, or `scripts/collect_layout.py` to import a finished run, which needs `raw/layout.gds` beside the record).

## The cost and qualification chart (Section 4)

One row per candidate that has an implementation record (candidates without one are counted in the title, not drawn). Left: standard-cell area with the qualification marking of the advanced notebook — **green** recommended (smallest qualified routed candidate meeting both budgets), **blue** other qualified routed candidates, **red cross-hatched** routed but a physical check fails (e.g. F24's max-cap violation), **grey diagonal-hatched** synthesis only (mapped area; cannot qualify). A **hollow** bar fails the error budget. Every bar also states its area and status in text, so colour is never the only cue; the colours were re-stepped from the advanced notebook's so green, blue and red stay distinguishable under colour-vision deficiency. Middle and right: the candidate's accumulation and total NRMSE against the dashed budgets (✕ = over budget). A synthesis-only bar is mapped area and is not comparable to a routed one.

## The PPA table (`src/mxlab/visuals.py: ppa_rows`)

One row per quantity, each with its value and its source or condition:

* **Area · technology-mapped** — Yosys/ABC on the GF180 Liberty (tool version in the record); exploratory, not routed.
* **Area · routed standard cells** — the LibreLane record (`design__instance__area__stdcell`: non-filler cells including clock/repair buffers, tap and endcap) with the die area.
* **Timing · target clock** — a target, never an achieved f_max. **Setup / hold slack** — worst corner of the post-route STA (nine corners for the MXFP4 records); "Not measured" when no STA was run.
* **Schedule · II and latency** — cycles from the contract and the RTL regression (no-stall interface); **rate** = f_clk / II, meaningful only if timing closes.
* **Signoff** — DRC / LVS error counts and max-slew / max-cap violations from the reports; "Not measured" without a layout.
* **Power** — the MXFP4 records carry LibreLane's post-route report at `nom_tt_025C_5v00`, 5.0 V with OpenSTA's default switching activity: labelled `flow_estimate_vectorless`, reference only, not a workload measurement and not comparable to an activity-annotated estimate. The generic core has no power report (`docs/POWER.md` describes how to import an activity-linked one).
* **RTL hash** and **qualification** — the record's RTL hash with its currency, and the list of reasons when a candidate is not qualified.

Unmeasured quantities stay "Not measured". A synthesis-area difference is never presented as a full PPA gain, and a configuration without a record shows no number at all.

## Rebuild

```bash
python scripts/render_hardware.py schematic evidence/generic_core/MXFP4_E2M1_W18_K128_P4      # Yosys + Graphviz
python scripts/render_hardware.py report evidence/generic_core/MXFP4_E2M1_W18_K128_P4 --output hardware_evidence.html
python -c "import sys; sys.path.insert(0,'src'); from mxlab.visuals import render_mxfp4_schematics, render_mxfp4_layout; render_mxfp4_schematics('.', 2); render_mxfp4_layout('.', 2)"
```

The notebook's *Generate circuit views* and *Draw layout from GDS* buttons run the same functions for the current design point; *Export HTML report* writes a standalone page with a zoom slider.

Sources: [Yosys scripting](https://yosyshq.readthedocs.io/projects/yosys/en/latest/getting_started/scripting_intro.html); [GF180 layer numbering](https://gf180mcu-pdk.readthedocs.io/en/latest/physical_verification/design_manual/drm_04_3.html).
