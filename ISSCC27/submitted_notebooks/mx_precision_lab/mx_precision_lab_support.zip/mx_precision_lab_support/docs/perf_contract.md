# Cycle contract of the selective-recompute system (v0.4 performance model)

This document freezes the cycle-level behaviour of `rtl/mxsys_top.sv` (N × `rtl/dot_top_rc.sv`,
round-robin arbiter, register queue of depth Q, one `rtl/rc_merge.sv`) as read from the RTL
source, so that the C++ performance model (`cpp/`) and the RTL trace testbench
(`src/mxacc/perf_rtl.py`) implement the same thing and can be compared cycle by cycle.
Every statement below was taken from the RTL text, not from the v0.3.3 notebook; where a
comment in the RTL disagrees with the state machine, the state machine wins and the
disagreement is noted. The RTL sources are not modified by v0.4 (their hashes are the ones
recorded in `results/system_rtl/summary.json` and `results/system/study.json`).

| source | sha256 |
|---|---|
| `rtl/dot_top_rc.sv` | `1d4c68311ef5a7b2e9a7740145f1d5d2ffa6658cf4623b5c2733b5c8f7c74472` |
| `rtl/rc_merge.sv` | `256bede9891bd6eb4f14b745fff5e1872e337f0e8d3a1ed4b14d3430fb366f06` |
| `rtl/mxsys_top.sv` | `21b3b998d629042c8c81063ce3a0067253341c3f21ffab9759ad4cf91d937155` |

Parameters: N cores (power of two), K elements per transaction, B = K/32 blocks, F fractional
bits of the low-F core, D_MAX of the merge unit, Q queue depth, ID_W = 8, CORE_W = clog2(N)
(1 for N = 1). Each transaction is one K-element dot product; each core processes one
transaction at a time (no overlap between transactions inside a core).

## 1. The single cycle rule

* `cycle = t` is the t-th rising clock edge of the simulation (edge 0 is the first edge after
  time zero). All event cycles below are the index of the edge at which the condition is
  *sampled*: a handshake "at cycle t" means `valid && ready` was stable before edge t and the
  transfer is committed at edge t. Register values written at edge t are visible from t+1.
* Every state element of the system is updated from the pre-edge values: the C++ model first
  evaluates every combinational signal and every event of cycle t from the current state, then
  commits all next states at once. Nothing updated at edge t may influence another decision of
  edge t (in particular the queue count used by the arbiter and the merge unit is the pre-edge
  count).
* The testbench drives every DUT input from registers that change immediately after an edge
  (non-blocking assignments in a `posedge` block) and samples every DUT output in a `posedge`
  block, so stimulus and observation are both pre-edge values of the same edge: no races.
* Per-cycle traces record the **pre-edge** queue occupancy (`qcount`). The post-edge occupancy
  is `qcount + enq - pop` of the same row and is not stored under another name.
* Reset is synchronous and active high in every module (`if (rst)` inside the `posedge` block,
  with priority over everything else). A reset edge is an edge at which `rst` is sampled 1.

## 2. Core (`dot_top_rc`)

States: IDLE, META, DATA, DRAIN, OUT. Interfaces, all valid/ready, all `ready` signals are
pure functions of the state:

| interface | ready | accepted when |
|---|---|---|
| start | `start_ready = (state == IDLE)` | `start` sampled 1 in IDLE (`start` is a valid; a start asserted in any other state has no effect) |
| metadata (one beat per block, B beats) | `meta_ready = (state == META)` | `meta_valid` sampled 1 in META |
| data (8 beats per block, 8B beats) | `in_ready = (state == DATA)` | `in_valid` sampled 1 in DATA |
| result | `out_valid = (state == OUT) && !out_done` | `out_valid && out_ready` |
| record | `rc_valid = (state == OUT) && inexact && !bad_scale && !rc_done` | `rc_valid && rc_ready` (rc_ready = arbiter grant) |

Timeline of one transaction whose start is accepted at edge S, with no stalls:

| edge | state during the cycle | what is accepted |
|---|---|---|
| S | IDLE | start; `out_id <= next_id`, `next_id++` |
| S+1 … S+B | META | metadata beat 0 … B-1 (exponent E_g stored, `bad_scale` latched if a scale is 255) |
| S+B+1 … S+9B | DATA | data beats; beat 7 of block g writes `sums[g]` (14 bits) |
| S+9B+1, S+9B+2 | DRAIN | nothing; the last block runs through the two pipeline stages (a → b) |
| from S+9B+3 | OUT | result (`out_valid`) and, if `inexact`, the record (`rc_valid`) are offered |

* Earliest result handshake: S+9B+3. Earliest next start: S+9B+4, so the no-stall issue
  interval is **II0 = 9B+4** (40 cycles at K128, 13 at K32, 148 at K512).
* The first-input latency (start accept → first cycle the result is offered) is 9B+2 cycles.
* DRAIN is exactly two edges regardless of data: the last beat accepted at edge E sets
  `a_valid`; edge E+1 moves it to `b_valid/b_last`; edge E+2 sees `b_valid && b_last`, writes
  the result registers and enters OUT. So OUT is first observable at edge E+3.
* Input stalls: a metadata or data beat that is not offered (driver `valid = 0`) at an edge in
  META/DATA simply delays everything after it by one cycle; the core never times out and holds
  no partial beat.
* OUT has two independent handshakes. `out_done` and `rc_done` latch each completed handshake;
  the core leaves OUT (to IDLE) at the edge at which the last outstanding handshake completes
  — in the same edge, not one later. A flagged transaction whose record is not granted keeps
  the core in OUT after the result has been taken (this is the record back-pressure); an
  unflagged transaction (`inexact = 0` or `bad_scale = 1`) needs only the result handshake.
  Both orders (result before record, record before result) and the same-edge case are legal.
* `inexact` and `out_id` are registered and stable for the whole OUT phase; `rc_id = out_id`.
* IDs: `next_id` is an 8-bit free-running counter, reset to 0, incremented at every accepted
  start; it wraps from 255 to 0 after 256 transactions of the core. The RTL has no protection
  against two in-flight records of one core carrying the same ID; this cannot happen in the
  system below unless a record stays in the queue/merge for more than 256 × II0 cycles, and the
  verification bookkeeping never relies on IDs alone: every return is matched to the oldest
  pending record of its core (records of one core enter the queue in transaction order and the
  queue/merge are FIFO) and the ID is then checked for equality.
* The exponents array is written in META and `sums[]` in DATA of the *next* transaction only
  after the core has left OUT, so the record contents are stable while `rc_valid` is high.
* Reset: synchronous, clears the state machine, counters, pipeline flags, `next_id`, `out_id`,
  `out_done`, `rc_done`. Memory contents (`sums[]`, `exponents[]`) are not cleared and are
  unreachable until rewritten.

## 3. Arbiter and queue (`mxsys_top`)

* `space = (count < Q)` and `m_valid = (count != 0)` use the **pre-edge** `count`. Therefore:
  a full queue grants nothing at an edge even if the merge unit pops at that same edge (no
  look-ahead to the pop); an empty queue offers nothing to the merge unit at the edge at which
  a record is enqueued (no bypass; a record enqueued at edge t is visible from t+1).
* Enqueue and dequeue at the same edge are possible whenever `0 < count < Q` (and when
  `count == Q` only the dequeue happens; when `count == 0` only the enqueue).
* Round robin: `last` holds the index of the core granted most recently (reset value 0);
  the request vector `rc_valid` is rotated so that core `(last+1) mod N` is at bit 0, the lowest
  set bit is isolated, and the result is rotated back. Exactly one core is granted per edge
  when `space` and at least one `rc_valid` is set; `last` is updated only on a grant. After a
  reset the first grant therefore goes to the requesting core with the smallest index greater
  than 0 (core 1, …, N-1, then 0). For N = 1 the only core is always granted when `space`.
* The arbiter does not advance when nothing is granted. A core that lost arbitration keeps
  `rc_valid` high and is considered again next edge.
* The granted record `{core, id, sums[B×14], exps[B×9]}` (REC_W = CORE_W + ID_W + 23·B bits)
  is written into `qmem[wr]` at the grant edge; `count <= count + grant - pop`.
* Reset clears `count`, `rd`, `wr`, `last`; `qmem` contents are not cleared and unreachable.
* Observability ports: `queue_count` (= `count`, pre-edge) and `rc_pending` (= `rc_valid`).
  The grant vector, `space`, the merge state and the core states are read hierarchically by
  the trace testbench (`dut.grant`, `dut.space`, `dut.merge.state`, `dut.cores[c].core.state`).

## 4. Merge unit (`rc_merge`)

States IDLE, RUN, DONE. `in_ready = (state == IDLE)`.

| edge | state | action |
|---|---|---|
| A | IDLE | record accepted (`in_valid && in_ready`): sums/exps/core/id latched, `emax` computed |
| A+1 … A+B | RUN | one block per edge: `shift = D_MAX + E_g − E_max`; `ooc` set if `shift < 0` |
| A+B+1 | DONE | `out_valid <= 1`, outputs registered (`out_int = 0` and `out_exp = 0` when `ooc`) |
| from A+B+2 | DONE | `out_valid` observable; at the first edge with `out_ready` sampled 1: `out_valid <= 0`, state → IDLE |

* Return first valid: A+B+2 (sampled). Earliest return handshake: A+B+2. Earliest next accept:
  A+B+3, so the no-back-pressure service interval is **S0 = B+3** (7 cycles at B = 4, 4 at
  B = 1, 19 at B = 16). The RTL header comment says "B + 2 cycles per record"; the state machine
  gives B+3 and B+3 is what the v0.3.3 Python model used. The contract value is B+3.
* The merge unit cannot accept a new record while an output waits for `out_ready`; return
  back-pressure therefore lengthens the service interval one-for-one.
* Exactness: a record with spread `max_g(E_max − E_g) ≤ D_MAX` is merged exactly (left shifts
  only, W_H = 14 + clog2(B) + D_MAX bits); a record with larger spread is returned with
  `out_of_contract = 1` and value 0 after the same B+3 cycles (it is counted as a return but
  not as a useful exact result). The core's `inexact` flag is zero for `bad_scale` (NaN scale)
  transactions, so those never produce a record.
* Reset clears the state machine and `out_valid`; a record inside the merge unit is lost
  (its transaction gets `reset_abort`).

## 5. Driver, masks, reset plan, epochs (testbench and C++ behave identically)

* Each core has one driver with an ordered list of transactions (`ordinal` 0, 1, 2, … per
  core, unique for the whole run) and an `arrival` cycle per transaction (0 = saturated).
* Offer masks are pre-generated per cycle and per interface and stored in `masks.txt` (one
  line per cycle, a hex number whose bit 0 is `ret_ready` and whose bits 4c+1 … 4c+4 are the
  start, metadata, data and result-ready masks of core c). A driver interface asserts `valid`
  (or `out_ready`) at cycle t iff it has a pending item and its mask bit for cycle t is 1; the
  mask is consulted again every cycle, so `valid` may be withdrawn and re-asserted while
  waiting (the RTL ready signals are pure state functions and tolerate this). An offered item
  is accepted iff `valid && ready` at that edge; the driver then advances to the next item at
  t+1. The driver offers the next transaction's start from the cycle after the result handshake
  of the previous one (and not before its `arrival`), whatever state the core is in; a start
  offered while the core is still in OUT is ignored by the core and is counted as the
  `START_BLOCKED` stall of that cycle.
* Mask bits are consumed by cycle index only (never by "number of random draws"), so both
  simulators see exactly the same stalls. A run that needs more cycles than the mask file holds
  is an error, never a silent extension.
* Reset plan: `[(R, L), …]` — `rst` is sampled 1 at edges R … R+L−1. The initial reset is
  (0, 3) and belongs to epoch 0 (no transaction is aborted by it). Every later pulse increments
  the epoch at its first edge; all transactions that were accepted (start) and not yet complete
  at that edge get the event `reset_abort` at cycle R and are not re-issued; records in the
  queue or merge unit are discarded; the drivers deassert every valid during the pulse and
  resume with their next unissued transaction at R+L. `epoch` is the epoch in which the
  transaction's start was accepted.
* Reset and a handshake at the same edge: the RTL `if (rst)` has priority, so nothing is
  accepted at a reset edge; the C++ model and the trace apply the same rule (no handshake event
  is recorded at a reset edge).

## 6. Events and metrics

Per-transaction events (`events.csv`: `epoch,core,ordinal,hw_id,event,cycle`):

| event | cycle at which |
|---|---|
| `start_first_offer` | the driver first asserts `start` for the transaction (mask bit 1, `arrival` reached) — the arrival reference of `arrival_to_completion` |
| `first_input_accept` | start accepted (S) |
| `last_input_accept` | last data beat accepted (E) |
| `normal_result_handshake` | `out_valid && out_ready` |
| `record_first_valid` | first edge with `rc_valid` sampled 1 (= E+3 if nothing else intervenes) |
| `record_enqueue` | `rc_valid && grant` (record written into the queue) |
| `merge_accept` | the record is popped from the queue head by the merge unit (A) |
| `return_first_valid` | first edge with `ret_valid` sampled 1 for this record (A+B+2 if not reset) |
| `return_handshake` | `ret_valid && ret_ready` |
| `reset_abort` | reset edge that cancelled an incomplete transaction |

Metric definitions (both simulators report them; the comparator recomputes them from the
traces):

* **completed**: unflagged → `normal_result_handshake` happened; flagged → `normal_result_handshake`
  and `return_handshake` both happened. **completion cycle** = max of the two handshake cycles.
* **end-to-end latency** = completion cycle − `first_input_accept`; **arrival-to-completion** =
  completion cycle − first cycle the start was offered (reported separately to show input queueing).
* **recompute latency** = `return_handshake` − `record_first_valid`; **queue wait** =
  `merge_accept` − `record_enqueue`.
* **throughput** = transactions completed inside the measurement window ÷ window length (cycles);
  **useful throughput** excludes transactions whose return is `out_of_contract` (and aborted ones).
  Conversion to dot products per second uses the declared clock (50 ns) and is labelled with the
  physical qualification of the core it refers to.
* **cohort**: transactions whose start was accepted inside the window; they are tracked to
  completion and their latencies are never truncated by the window end. **Makespan**: first
  start accept → last completion of the whole finite batch (reported separately from the window
  metrics). Reset epochs are reported per epoch and never mixed into steady-state curves.
* **percentiles**: nearest rank, the `ceil(p·n)`-th sorted value; `null` with `count = 0` when
  there is no sample; sample counts are always reported.
* **queue peak** and the cycle-weighted occupancy histogram (pre-edge occupancy per cycle).
* **merge utilization**: `compute_busy` (state RUN or the DONE latch cycle) and `output_blocked`
  (`ret_valid && !ret_ready`) are separate fractions of all cycles.
* **stall reasons** (per core per cycle, a bitmask; several bits may be set in one cycle; the
  per-reason totals and the union are reported separately):

  | bit | name | condition |
  |---|---|---|
  | 0 | `INPUT_MASK` | the driver has a pending start/metadata/data item but its mask bit is 0 |
  | 1 | `START_BLOCKED` | the driver offers `start` and the core is not in IDLE (held in OUT by the record or result handshake) |
  | 2 | `RESULT_BLOCKED` | `out_valid` is 1 and the driver's `out_ready` mask bit is 0 |
  | 3 | `RECORD_WAIT_FULL` | `rc_valid` is 1 and the queue has no space |
  | 4 | `RECORD_WAIT_ARB` | `rc_valid` is 1, the queue has space, another core was granted |
  | 5 | `ARRIVAL_WAIT` | the driver has no transaction to offer yet (`arrival` in the future) |

* **logical payload traffic** (bits, never converted to DRAM bandwidth, switching or power):
  `core_record_write_bits` = (B·14 + B·9 + ID_W) per accepted start (the RTL writes `out_id`,
  all B exponents and all B sums for every transaction, flagged or not);
  `core_to_queue_bits` = enqueues × REC_W; `queue_to_merge_bits` = pops × REC_W;
  `configured_queue_bits` = Q × REC_W; `discarded_by_reset_bits` = records lost in the queue or
  merge at a reset × REC_W. Per useful completed dot product as well as totals.

## 7. Per-cycle trace columns (`cycles.csv`)

`cycle,rst,epoch,qcount,space,grant,enq,pop,mstate,ret_valid,ret_ready,ret_hs,ret_core,ret_id,ret_ooc`
followed, for every core c, by one hex word `c<c>` packing (from the LSB):
`ord[15:0] | hw_id[7:0] | state[2:0] | start_v | start_hs | meta_hs | data_hs | out_v | out_rdy | out_hs | rc_v | rc_hs | inexact | stall[5:0]`.
`ret_core`, `ret_id`, `ret_ooc` are defined only when `ret_valid = 1` and are compared only then;
`grant` is a hex bitmask of the effective grant (0 at a reset edge); `enq` and `pop` are the
effective enqueue/dequeue (0 at a reset edge); `mstate` is 0/1/2 for IDLE/RUN/DONE. The pre-edge
`ord` is the ordinal of the transaction the driver is working on (its next one once the previous
result has been taken; one past the last when the driver is done), `hw_id` the core's `out_id`
register. At cycle 0 (before the first edge) the RTL state is undefined and both traces report
the DUT fields as 0. The trace ends with the row of the first cycle at which every driver is
done, no core holds a transaction, the queue is empty, the merge unit is idle and no return is
pending (`cycles` = that row index + 1).

## 8. Status

Implemented by `src/mxacc/perf_stimulus.py` (stimulus), `src/mxacc/perf_rtl.py` (RTL trace
testbench), `cpp/` (model), `src/mxacc/perf_trace.py` (reconstruction and comparison) and
`scripts/run_perf_validation.py`. The contract was checked against the RTL on the development
configurations first and then on the held-out ones (`results/perf/validation_summary.json`);
the hash of this file is recorded there, so any later edit of the contract is visible.
