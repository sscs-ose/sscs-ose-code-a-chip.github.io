# The two backends of MX Precision Lab

Every number the notebook shows belongs to one backend. Switching the backend switches the numerical model, the circuit views and the cost records together; the records of one core are never applied to the other. `src/mxlab/backends.py` gives both cores one interface:

| Method | Meaning |
|---|---|
| `supports(fmt, k, lanes)`, `supports_k(k)`, `widths(k)`, `formats` | what the core can be configured for |
| `contract(fmt, k, lanes, W)` | the configuration row: `backend, format_x, format_w, k, lanes, accumulator_bits, f, blocks, block_sum_bits, ii_no_stall, latency_cycles, rtl_module` |
| `evaluate(layer, fmt, W, split, lanes, cache)` | calibration or test metrics of one candidate: `quant_nrmse`, `acc_nrmse`, `total_nrmse`, `inexact_fraction`, `exact_fraction`, `max_abs`, `bound_max`, `vectors`, `data_sha256` |
| `records(root)` | the implementation records of this core, each with `stage` (`synthesis` / `post_route`), `cell_area_um2`, slacks, violation counts, `qualified`, `qualification_reasons`, `power`, `rtl_sha256`, `rtl_current`, `record_path`, `evidence_dir` |
| `evidence_dir(root, fmt, k, lanes, W)`, `config_name(...)` | where the circuit/layout views of a configuration live |

`join(rows, records, clock_ns, min_rate)` attaches to each evaluated candidate the records that match on **all** of `backend, format_x, format_w, k, lanes, accumulator_bits` and whose RTL hash is current; a routed record at the requested clock is preferred, the synthesis record is kept beside it. `select(rows)` chooses the smallest-area candidate among those that meet the calibration budgets *and* carry a qualified routed record; when none does it names the reason (`numerical:` no candidate meets the budgets; `evidence:` no implementation record; `physical:` only synthesis or a failed physical check; `comparison:` qualified candidates from different implementation groups) and, if possible, a shortlist candidate (smallest mapped area among the eligible un-routed ones) to implement next.

## MXFP4 core (`mxfp4_core`)

* **RTL** `rtl/dot_top.sv` (wrappers `rtl/dot_k{K}_f{F}.sv`), four lanes, exact signed 14-bit block sums, one F-dependent alignment with guard/sticky round-to-nearest-even, `W = 14 + log2 B + F` (W = 16 + F at K128), II0 = 9B + 4 cycles (40 at K128), latency 9B + 3. Candidates are named by F ∈ {0, 2, 4, 6, 8, 12, 16, 24}; K ∈ {32, 128, 512}, P = 4.
* **Numerics** `mxacc.arithmetic` (bit-exact model of the RTL; 15 RTL configurations, 16,165 transactions, 0 mismatches in `results/rtl/`).
* **Inexact flag: optional, not in the baseline.** `rtl/dot_top.sv` has no loss flag; the flag ("a discarded bit was non-zero") is the separate variant `rtl/dot_top_inexact.sv` (wrappers `rtl/dot_k128_f*_inexact.sv`). Every routed record, the cost chart and Case A are measured on the baseline without it. The variant was implemented separately with the same flow: +1.08 % mapped area at F2, routed +0.42 % (F2) and +0.10 % (F4) with every check met (`results/recompute/hardware.json`). The notebook's *inexact fraction* for this backend is what that variant would report.
* **Records** `results/physical/f*.json` (LibreLane 3.0.16 on GF180MCU at 50 ns: standard-cell area, nine-corner STA, max-slew/max-cap, Magic DRC, Netgen LVS, KLayout XOR; `flow/environment.json`) for F ∈ {0, 2, 4, 6, 8, 12, 24} and `results/synthesis/f*/summary.json` (Yosys mapping) for all eight F. F24 is routed but carries one max-cap violation and is not qualified; F16 is synthesis only. Power: the flow's vectorless post-route estimate (`results/physical/f*/evidence/metrics.json: power__total`) at `nom_tt_025C_5v00`, 5.0 V, labelled `flow_estimate_vectorless`.
* **Evidence folders** `evidence/mxfp4_core/K128_F{F}/visuals/` (circuit views; F2 and F4 include the gate-level view) and `.../layout/` (F2, F4, F24).

## Generic MX core (`generic_core`)

* **RTL** generated per configuration by `src/mxlab/hardware.py: generate` into `mx_dot.sv`: integer lift of any OCP MX v1.0 encoding (MXFP4 E2M1, MXFP6 E2M3 / E3M2, MXFP8 E4M3 / E5M2, MXINT8; mixed x/w formats allowed), exact block sums whose width follows the encoding, the same alignment-and-RNE rule, any W; serial schedule II = 2 + B(2 + 32/P) (42 at K128/P4), latency II − 1; P ∈ {1, 2, 4, 8, 16, 32}, any K. F = W − block-sum bits − ⌈log2 B⌉.
* **Inexact flag: built in.** Every generated `mx_dot.sv` has an `out_inexact` port; the RTL regression checks it and the mapped area includes it.
* **Numerics** `src/mxlab/numerics.py` (bit-exact model of the generated RTL; fast int64 path, exact Python-int fallback for wide sums, 16-bit limb split for E5M2). For MXFP4 at the same F both cores give identical errors and flags (`tests/test_mxlab_lab.py`).
* **Records** `evidence/generic_core/<format>_W<W>_K<K>_P<P>/`: `rtl_validation.json` (Icarus regression against the integer model: values, exponents, flags, stalls, reset, no-stall schedule; 31 configurations, 1,362 transactions, 0 mismatches, `validation_summary.json`), and for 10 configurations `synthesis_record.json` (the author's Yosys 0.33 + ABC mapping on `tech/gf180_1x_tt_5v00.lib`, re-audited by `scripts/lab_validate.py`, never re-synthesised here). No layout, timing closure, signoff or power exists for this core; the notebook's run-hardware steps can produce them (`hardware.run_layout` with LibreLane, `evidence.collect_layout` to import a run, `evidence.import_power` for an activity-linked power report — see `docs/POWER.md`).
* **Evidence folders** `evidence/generic_core/<config>/visuals/` (circuit views; the 10 mapped configurations include the gate-level view); new configurations are generated under `experiments/<config>/`.

## Stale evidence

A stored record, circuit view or layout image is used only when the RTL hash it stores equals the hash of the RTL in the checkout (`rtl/dot_top.sv` for the MXFP4 core, the configuration's `mx_dot.sv` for the generic core) and, for layouts, the GDS hash equals the file's. Otherwise the notebook shows the mismatch instead of the result. `tests/test_mxlab_lab.py` and `tests/test_mxlab_visuals.py` check every shipped record and image against the shipped RTL.
