# Import an actual activity-linked power report

Power is unknown until supplied. The importer does not estimate power from cell area or an invented toggle rate. A post-route estimate remains an estimate, not a silicon measurement.

After collecting the candidate's layout, create a metadata JSON alongside the actual report and its VCD/SAIF activity source:

```json
{
  "rtl_sha256": "COPY FROM THIS JOB'S contract.json",
  "clock_period_ns": 50.0,
  "corner": "COPY AN ACTUAL CORNER FROM THE LAYOUT RECORD",
  "voltage_v": 5.0,
  "unit": "W",
  "report": "power.rpt",
  "activity": "workload_activity.vcd",
  "method": "post-route STA with documented activity annotation",
  "workload_sha256": "COPY THE data_sha256 FROM THE EXPORTED STUDY",
  "split": "calibration"
}
```

The report must contain exactly one OpenSTA-style `Total <internal> <switching> <leakage> <total>` row. Units must be W, mW or uW, and component totals must agree. The RTL, period and corner must match the layout record. The report, metadata and activity hash are retained.

Use the notebook's advanced hardware panel or:

```python
from mxlab.evidence import import_power
record = import_power("experiments/MY_CANDIDATE", "power_metadata.json")
```

The caller remains responsible for appropriate activity annotation, representative workloads, clock/voltage, corner choice, and the report's stated unit. A functional RTL regression is not automatically a representative power workload. Missing annotation or activity assumptions must be reported alongside the estimate.

The notebook only joins power to the same workload hash and split. A power estimate from a different model layer, or from test activity, is not silently reused during calibration selection. Area can remain reusable for the same core; power is activity-dependent.
