// SPDX-License-Identifier: Apache-2.0
// mxacc_perf: command-line front end of the cycle-level performance model.
//   mxacc_perf --n N --k K --f F --q Q --dmax D --tx-dir DIR (--masks FILE | --mask-gen SEED:R:S:M:D:O --max-cycles M)
//              [--reset R:L]... [--window S:E] --summary out.json [--trace-cycles f.csv] [--trace-events f.csv] [--mask-dump f.txt]
// Inputs are plain text (transaction rows and mask rows written by mxacc.perf_stimulus); the manifest
// is translated into these arguments by src/mxacc/perf_backend.py.
#include "mxacc/perf_model.hpp"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

using namespace mxacc;

static std::string q(const std::string &s) { return "\"" + s + "\""; }

static void lat(std::ostringstream &o, const char *name, const LatencyStats &s) {
    o << q(name) << ":{\"count\":" << s.count;
    if (s.count) o << ",\"mean\":" << s.mean << ",\"p50\":" << s.p50 << ",\"p90\":" << s.p90 << ",\"p99\":" << s.p99 << ",\"max\":" << s.max;
    else o << ",\"mean\":null,\"p50\":null,\"p90\":null,\"p99\":null,\"max\":null";
    o << "}";
}

static std::vector<Tx> read_tx(const std::string &path) {
    std::ifstream in(path); if (!in) throw std::runtime_error("cannot open " + path);
    std::vector<Tx> v; std::string line; long expect = 0;
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        std::istringstream ss(line); Tx t; int bad, inex, ooc;
        if (!(ss >> t.ordinal >> t.arrival >> bad >> inex >> ooc >> t.spread)) throw std::runtime_error("bad transaction row in " + path + ": " + line);
        if (t.ordinal != expect) throw std::runtime_error("ordinal " + std::to_string(t.ordinal) + " out of order in " + path);
        t.bad = bad != 0; t.inexact = inex != 0; t.ooc = ooc != 0; v.push_back(t); ++expect;
    }
    return v;
}

int main(int argc, char **argv) {
    Config cfg; std::string tx_dir, masks, mask_gen, summary, trace_cycles, trace_events, mask_dump;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i]; auto next = [&]() { if (i + 1 >= argc) { std::fprintf(stderr, "missing value for %s\n", a.c_str()); std::exit(2); } return std::string(argv[++i]); };
        if (a == "--version") { std::printf("mxacc_perf %s compiler=%s build=%s\n", MODEL_VERSION, __VERSION__,
#ifdef NDEBUG
            "Release"
#else
            "Debug"
#endif
            ); return 0; }
        else if (a == "--n") cfg.n = std::stoi(next()); else if (a == "--k") cfg.k = std::stoi(next()); else if (a == "--f") cfg.f = std::stoi(next());
        else if (a == "--q") cfg.q = std::stoi(next()); else if (a == "--dmax") cfg.dmax = std::stoi(next()); else if (a == "--id-w") cfg.id_w = std::stoi(next());
        else if (a == "--tx-dir") tx_dir = next(); else if (a == "--masks") masks = next(); else if (a == "--mask-gen") mask_gen = next();
        else if (a == "--max-cycles") cfg.max_cycles = std::stol(next()); else if (a == "--summary") summary = next();
        else if (a == "--trace-cycles") trace_cycles = next(); else if (a == "--trace-events") trace_events = next(); else if (a == "--mask-dump") mask_dump = next();
        else if (a == "--reset") { std::string v = next(); size_t p = v.find(':'); cfg.resets.push_back({std::stol(v.substr(0, p)), std::stol(v.substr(p + 1))}); }
        else if (a == "--window") { std::string v = next(); size_t p = v.find(':'); cfg.win_start = std::stol(v.substr(0, p)); cfg.win_end = std::stol(v.substr(p + 1)); }
        else { std::fprintf(stderr, "unknown argument %s\n", a.c_str()); return 2; }
    }
    cfg.b = cfg.k / 32;
    if ((cfg.n & (cfg.n - 1)) != 0 || cfg.n < 1) { std::fprintf(stderr, "N must be a power of two\n"); return 2; }
    if (cfg.q < 1) { std::fprintf(stderr, "Q must be >= 1\n"); return 2; }
    if (cfg.resets.empty()) cfg.resets.push_back({0, 3});
    try {
        std::vector<std::vector<Tx>> txs;
        for (int c = 0; c < cfg.n; ++c) txs.push_back(read_tx(tx_dir + "/tx_c" + std::to_string(c) + ".txt"));
        std::shared_ptr<MaskSource> ms;
        if (!masks.empty()) { auto fm = std::make_shared<FileMasks>(masks, 4 * cfg.n + 1); if (cfg.max_cycles <= 0 || cfg.max_cycles > fm->rows()) cfg.max_cycles = fm->rows(); ms = fm; }
        else if (!mask_gen.empty()) {
            uint64_t seed; int thr[5]; char buf[256]; std::strncpy(buf, mask_gen.c_str(), 255); buf[255] = 0;
            unsigned long long sd; if (std::sscanf(buf, "%llu:%d:%d:%d:%d:%d", &sd, &thr[0], &thr[1], &thr[2], &thr[3], &thr[4]) != 6) { std::fprintf(stderr, "bad --mask-gen\n"); return 2; }
            seed = sd; if (cfg.max_cycles <= 0) { std::fprintf(stderr, "--mask-gen needs --max-cycles\n"); return 2; }
            ms = std::make_shared<GeneratedMasks>(seed, thr, cfg.max_cycles);
            if (!mask_dump.empty()) {   // identical format to masks.txt (for cross-checking against the Python generator)
                std::ofstream out(mask_dump); int nb = 4 * cfg.n + 1;
                for (long t = 0; t < cfg.max_cycles; ++t) {
                    std::string hex; int digits = (nb + 3) / 4;
                    for (int d = digits - 1; d >= 0; --d) { int v = 0; for (int j = 0; j < 4; ++j) { int bit = 4 * d + j; if (bit < nb && ms->bit(t, bit)) v |= 1 << j; } hex += "0123456789abcdef"[v]; }
                    size_t nz = hex.find_first_not_of('0'); out << (nz == std::string::npos ? "0" : hex.substr(nz)) << "\n";
                }
            }
        } else { std::fprintf(stderr, "--masks or --mask-gen required\n"); return 2; }
        Simulator sim(cfg, txs, ms);
        Summary S = sim.run(trace_cycles, trace_events);
        std::ostringstream o; o.precision(10);
        o << "{\"model\":{\"name\":\"mxacc_perf\",\"version\":" << q(MODEL_VERSION) << ",\"compiler\":" << q(__VERSION__) << ",\"contract\":\"docs/perf_contract.md\"},";
        o << "\"status\":" << (sim.error.empty() ? "\"finished\"" : "\"incomplete\"") << ",\"error\":" << (sim.error.empty() ? "null" : q(sim.error)) << ",";
        o << "\"config\":{\"n\":" << cfg.n << ",\"k\":" << cfg.k << ",\"b\":" << cfg.b << ",\"f\":" << cfg.f << ",\"q\":" << cfg.q << ",\"dmax\":" << cfg.dmax << ",\"id_w\":" << cfg.id_w
          << ",\"rec_w\":" << cfg.rec_w() << ",\"ii0\":" << cfg.ii0() << ",\"s0\":" << cfg.s0() << ",\"max_cycles\":" << cfg.max_cycles << ",\"resets\":[";
        for (size_t i = 0; i < cfg.resets.size(); ++i) o << (i ? "," : "") << "[" << cfg.resets[i].first << "," << cfg.resets[i].second << "]";
        o << "],\"mask_source\":" << q(masks.empty() ? "generated:" + mask_gen : "file") << "},";
        o << "\"cycles\":" << S.cycles << ",\"resets\":" << S.resets << ",\"epochs\":" << S.epochs << ",";
        o << "\"counts\":{\"starts\":" << S.starts << ",\"completed\":" << S.completed << ",\"useful_completed\":" << S.useful_completed << ",\"flagged_enqueued\":" << S.flagged_enqueued
          << ",\"returns\":" << S.returns << ",\"ooc_returns\":" << S.ooc_returns << ",\"aborted\":" << S.aborted << ",\"enqueues\":" << S.enqueues << ",\"pops\":" << S.pops << ",\"grants\":" << S.grants << "},";
        o << "\"queue\":{\"peak\":" << S.queue_peak << ",\"occupancy_cycles\":[";
        for (size_t i = 0; i < S.occupancy_cycles.size(); ++i) o << (i ? "," : "") << S.occupancy_cycles[i];
        o << "]},";
        double cyc = S.cycles > 0 ? (double)S.cycles : 1.0;
        o << "\"merge\":{\"compute_busy_cycles\":" << S.merge_compute_busy << ",\"output_blocked_cycles\":" << S.merge_output_blocked
          << ",\"compute_busy_fraction\":" << S.merge_compute_busy / cyc << ",\"output_blocked_fraction\":" << S.merge_output_blocked / cyc << "},";
        o << "\"arbiter\":{\"request_cycles\":" << S.request_cycles << ",\"multi_request_cycles\":" << S.multi_request_cycles << ",\"max_simultaneous_requests\":" << S.max_simultaneous_requests << "},";
        const char *names[6] = {"INPUT_MASK", "START_BLOCKED", "RESULT_BLOCKED", "RECORD_WAIT_FULL", "RECORD_WAIT_ARB", "ARRIVAL_WAIT"};
        o << "\"stalls\":{\"core_cycles\":" << (long)S.cycles * cfg.n << ",\"union_core_cycles\":" << S.stall_union << ",\"per_reason_core_cycles\":{";
        for (int i = 0; i < 6; ++i) o << (i ? "," : "") << q(names[i]) << ":" << S.stall_reason[i];
        o << "}},";
        o << "\"traffic_bits\":{\"record_width\":" << cfg.rec_w() << ",\"core_record_write_per_start\":" << 23 * cfg.b + cfg.id_w << ",\"core_record_write\":" << S.bits_core_record_write
          << ",\"core_to_queue\":" << S.bits_core_to_queue << ",\"queue_to_merge\":" << S.bits_queue_to_merge << ",\"configured_queue\":" << S.bits_configured_queue
          << ",\"discarded_by_reset\":" << S.bits_discarded_by_reset << ",\"per_useful_dot\":{";
        double u = S.useful_completed > 0 ? (double)S.useful_completed : 1.0;
        o << "\"core_record_write\":" << S.bits_core_record_write / u << ",\"core_to_queue\":" << S.bits_core_to_queue / u << ",\"queue_to_merge\":" << S.bits_queue_to_merge / u << "}},";
        long span = (S.first_start >= 0 && S.last_completion >= 0) ? (S.last_completion - S.first_start + 1) : 0;
        o << "\"batch\":{\"first_start\":" << S.first_start << ",\"last_completion\":" << S.last_completion << ",\"makespan_cycles\":" << span
          << ",\"throughput_per_cycle\":" << (span > 0 ? S.completed / (double)span : 0.0) << ",\"useful_throughput_per_cycle\":" << (span > 0 ? S.useful_completed / (double)span : 0.0) << "},";
        long wl = S.win_end - S.win_start;
        o << "\"window\":{\"start\":" << S.win_start << ",\"end\":" << S.win_end << ",\"completed_in_window\":" << S.win_completed << ",\"useful_completed_in_window\":" << S.win_useful
          << ",\"throughput_per_cycle\":" << (wl > 0 ? S.win_completed / (double)wl : 0.0) << ",\"useful_throughput_per_cycle\":" << (wl > 0 ? S.win_useful / (double)wl : 0.0)
          << ",\"cohort\":" << S.cohort << ",";
        lat(o, "e2e_latency", S.e2e_win); o << ","; lat(o, "arrival_to_completion", S.a2c_win); o << ","; lat(o, "recompute_latency", S.rc_win); o << ","; lat(o, "queue_wait", S.qw_win);
        o << "},\"all\":{";
        lat(o, "e2e_latency", S.e2e_all); o << ","; lat(o, "arrival_to_completion", S.a2c_all); o << ","; lat(o, "recompute_latency", S.rc_all); o << ","; lat(o, "queue_wait", S.qw_all);
        o << "},\"per_epoch\":[";
        for (size_t e = 0; e < S.per_epoch_starts.size(); ++e) o << (e ? "," : "") << "{\"epoch\":" << e << ",\"starts\":" << S.per_epoch_starts[e] << ",\"completed\":" << S.per_epoch_completed[e] << ",\"aborted\":" << S.per_epoch_aborted[e] << "}";
        o << "]}\n";
        if (summary.empty()) std::cout << o.str(); else { std::ofstream out(summary); out << o.str(); }
        if (!sim.error.empty()) { std::fprintf(stderr, "%s\n", sim.error.c_str()); return 3; }
        return 0;
    } catch (const std::exception &e) { std::fprintf(stderr, "error: %s\n", e.what()); return 1; }
}
