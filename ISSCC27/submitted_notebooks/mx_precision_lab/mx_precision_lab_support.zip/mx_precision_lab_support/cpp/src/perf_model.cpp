// SPDX-License-Identifier: Apache-2.0
// See include/mxacc/perf_model.hpp and docs/perf_contract.md. Every cycle: (1) all combinational
// values and handshakes are computed from the current state, (2) the trace row and the events of
// the cycle are recorded, (3) the next state of every element is committed at once.
#include "mxacc/perf_model.hpp"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <stdexcept>

namespace mxacc {

uint64_t splitmix64(uint64_t x) {
    uint64_t z = x + 0x9E3779B97F4A7C15ULL;
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}

FileMasks::FileMasks(const std::string &path, int nbits) : nbits_(nbits), words_((nbits + 63) / 64), nrows_(0) {
    std::ifstream in(path);
    if (!in) throw std::runtime_error("cannot open mask file " + path);
    std::string line;
    while (std::getline(in, line)) {
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
        if (line.empty()) continue;
        std::vector<uint64_t> w(words_, 0);
        int bit = 0;
        for (int i = (int)line.size() - 1; i >= 0; --i) {
            char ch = line[i]; int v;
            if (ch >= '0' && ch <= '9') v = ch - '0'; else if (ch >= 'a' && ch <= 'f') v = ch - 'a' + 10; else if (ch >= 'A' && ch <= 'F') v = ch - 'A' + 10;
            else throw std::runtime_error("bad hex in mask file");
            for (int j = 0; j < 4; ++j, ++bit) if ((v >> j) & 1) { if (bit < 64 * words_) w[bit / 64] |= (1ULL << (bit % 64)); }
        }
        data_.insert(data_.end(), w.begin(), w.end()); ++nrows_;
    }
}

bool FileMasks::bit(long t, int stream) const {
    if (t < 0 || (size_t)t >= nrows_) return false;
    return (data_[(size_t)t * words_ + stream / 64] >> (stream % 64)) & 1ULL;
}

bool GeneratedMasks::bit(long t, int stream) const {
    int cls = stream == 0 ? 0 : 1 + ((stream - 1) % 4);
    uint64_t x = seed_ ^ ((uint64_t)stream << 48) ^ ((uint64_t)t << 8);
    return (int)(splitmix64(x) & 0xFFFFULL) >= thr_[cls];
}

namespace {
enum CoreState { IDLE = 0, META = 1, DATA = 2, DRAIN = 3, OUT = 4 };
enum Phase { PH_START = 0, PH_META = 1, PH_DATA = 2, PH_WAIT = 3, PH_DONE = 4 };

struct Core {
    int state = IDLE, meta_index = 0, block_index = 0, beat = 0;
    bool a_valid = false, a_last = false, b_valid = false, b_last = false;
    bool inexact = false, bad_scale = false, out_done = false, rc_done = false;
    int next_id = 0, out_id = 0;
    long cur = -1;      // ordinal of the transaction inside the core (accepted start, not yet left OUT)
    void reset() { *this = Core(); }
};
struct Driver { size_t idx = 0; int phase = PH_START, g = 0, i = 0; };
struct Rec { int core = 0; long ordinal = 0; int id = 0; bool ooc = false; };
struct Queue { int count = 0, rd = 0, wr = 0, last = 0; std::vector<Rec> mem; };
struct Merge { int state = 0, g = 0; Rec rec, out_rec; bool out_valid = false; };

LatencyStats stats_of(std::vector<long> &v) {
    LatencyStats s; s.count = (long)v.size();
    if (v.empty()) return s;
    std::sort(v.begin(), v.end());
    double sum = 0; for (long x : v) sum += (double)x; s.mean = sum / (double)v.size();
    auto nr = [&](double p) { size_t idx = (size_t)std::ceil(p * (double)v.size()); if (idx == 0) idx = 1; return v[idx - 1]; };
    s.p50 = nr(0.5); s.p90 = nr(0.9); s.p99 = nr(0.99); s.max = v.back();
    return s;
}
} // namespace

Simulator::Simulator(const Config &cfg, std::vector<std::vector<Tx>> txs, std::shared_ptr<MaskSource> masks)
    : cfg_(cfg), txs_(std::move(txs)), masks_(std::move(masks)) {
    recs_.resize(cfg_.n);
    for (int c = 0; c < cfg_.n; ++c) {
        recs_[c].resize(txs_[c].size());
        for (size_t i = 0; i < txs_[c].size(); ++i) {
            recs_[c][i].ordinal = txs_[c][i].ordinal; recs_[c][i].flagged = txs_[c][i].inexact && !txs_[c][i].bad;
            recs_[c][i].bad = txs_[c][i].bad; recs_[c][i].ooc = txs_[c][i].ooc;
        }
    }
}

Summary Simulator::run(const std::string &trace_cycles, const std::string &trace_events) {
    const Config &C = cfg_; const int N = C.n, B = C.b, Q = C.q; const int ID_MASK = (1 << C.id_w) - 1;
    const long REC_W = C.rec_w(), CORE_REC_BITS = 23L * B + C.id_w;
    std::vector<Core> core(N); std::vector<Driver> drv(N); Queue queue; queue.mem.resize(Q); Merge merge;
    for (int c = 0; c < N; ++c) if (txs_[c].empty()) drv[c].phase = PH_DONE;
    Summary S; S.occupancy_cycles.assign(Q + 1, 0); S.bits_configured_queue = (long)Q * REC_W;
    S.per_epoch_starts.push_back(0); S.per_epoch_completed.push_back(0); S.per_epoch_aborted.push_back(0);
    std::FILE *fc = nullptr, *fe = nullptr;
    if (!trace_cycles.empty()) { fc = std::fopen(trace_cycles.c_str(), "w"); if (!fc) throw std::runtime_error("cannot open " + trace_cycles);
        std::fprintf(fc, "cycle,rst,epoch,qcount,space,grant,enq,pop,mstate,ret_valid,ret_ready,ret_hs,ret_core,ret_id,ret_ooc");
        for (int c = 0; c < N; ++c) std::fprintf(fc, ",c%d", c);
        std::fprintf(fc, "\n"); }
    if (!trace_events.empty()) { fe = std::fopen(trace_events.c_str(), "w"); if (!fe) throw std::runtime_error("cannot open " + trace_events);
        std::fprintf(fe, "epoch,core,ordinal,hw_id,event,cycle\n"); }
    auto ev = [&](int, long, const char *, long) {};   // events are written from the records at the end (final hw_id/epoch on every row)
    auto in_reset = [&](long t) { for (auto &r : C.resets) if (t >= r.first && t < r.first + r.second) return true; return false; };
    auto complete = [&](int c, long o, long t) {
        TxRec &r = recs_[c][o]; if (r.completion >= 0) return;
        r.completion = t; S.completed++; S.per_epoch_completed[r.epoch]++;
        bool useful = !(r.flagged && r.ooc);
        if (useful) S.useful_completed++;
        if (S.last_completion < 0 || t > S.last_completion) S.last_completion = t;
    };
    long t = 0; bool rst_prev = false; int epoch = 0;
    std::vector<char> start_v(N), meta_v(N), data_v(N), out_rdy(N), s_hs(N), m_hs(N), d_hs(N), o_hs(N), r_hs(N), rc_valid(N), out_valid(N), leave(N);
    std::vector<int> stall(N);
    for (;; ++t) {
        if (C.max_cycles > 0 && t >= C.max_cycles) { error = "mask source exhausted at cycle " + std::to_string(t) + " (run did not finish)"; S.cycles = t; break; }
        const bool rst = in_reset(t);
        // ---------------- driver outputs and DUT combinational values (pre-edge)
        for (int c = 0; c < N; ++c) {
            Driver &d = drv[c]; const Tx *tx = d.idx < txs_[c].size() ? &txs_[c][d.idx] : nullptr;
            start_v[c] = !rst && d.phase == PH_START && tx && t >= tx->arrival && masks_->bit(t, 1 + 4 * c);
            meta_v[c] = !rst && d.phase == PH_META && masks_->bit(t, 2 + 4 * c);
            data_v[c] = !rst && d.phase == PH_DATA && masks_->bit(t, 3 + 4 * c);
            out_rdy[c] = !rst && d.phase == PH_WAIT && masks_->bit(t, 4 + 4 * c);
            Core &k = core[c];
            out_valid[c] = k.state == OUT && !k.out_done;
            rc_valid[c] = k.state == OUT && k.inexact && !k.bad_scale && !k.rc_done;
        }
        const bool ret_rdy = !rst && masks_->bit(t, 0);
        const bool space = queue.count < Q, m_valid = queue.count != 0, m_ready = merge.state == 0;
        const bool pop = !rst && m_valid && m_ready;
        int grant_idx = -1;
        if (!rst && space) {
            int r = N > 1 ? ((queue.last + 1) & (N - 1)) : 0;
            for (int i = 0; i < N; ++i) { int c = (i + r) & (N - 1); if (N == 1) c = 0; if (rc_valid[c]) { grant_idx = c; break; } }
        }
        const bool ret_valid = merge.out_valid; const bool ret_hs = !rst && ret_valid && ret_rdy;
        bool any_pending = false;
        for (int c = 0; c < N; ++c) {
            Core &k = core[c];
            s_hs[c] = !rst && start_v[c] && k.state == IDLE;
            m_hs[c] = !rst && meta_v[c] && k.state == META;
            d_hs[c] = !rst && data_v[c] && k.state == DATA;
            o_hs[c] = !rst && out_valid[c] && out_rdy[c];
            r_hs[c] = !rst && rc_valid[c] && grant_idx == c;
            leave[c] = !rst && k.state == OUT && (o_hs[c] || k.out_done) && (!(k.inexact && !k.bad_scale) || r_hs[c] || k.rc_done);
            int st = 0;
            if (!rst) {
                const Driver &d = drv[c]; const Tx *tx = d.idx < txs_[c].size() ? &txs_[c][d.idx] : nullptr;
                if ((d.phase == PH_START && tx && t >= tx->arrival && !masks_->bit(t, 1 + 4 * c)) || (d.phase == PH_META && !masks_->bit(t, 2 + 4 * c)) || (d.phase == PH_DATA && !masks_->bit(t, 3 + 4 * c))) st |= 1;
                if (start_v[c] && k.state != IDLE) st |= 2;
                if (out_valid[c] && !out_rdy[c]) st |= 4;
                if (rc_valid[c] && !space) st |= 8;
                if (rc_valid[c] && space && grant_idx != c) st |= 16;
                if (d.phase == PH_START && tx && t < tx->arrival) st |= 32;
            }
            stall[c] = st;
            if (drv[c].phase != PH_DONE || k.cur >= 0) any_pending = true;
        }
        // pending returns: records in the queue or merge
        if (queue.count != 0 || merge.state != 0) any_pending = true;
        { int nreq = 0; for (int c = 0; c < N; ++c) if (rc_valid[c]) ++nreq; if (nreq >= 2) S.multi_request_cycles++; if (nreq > S.max_simultaneous_requests) S.max_simultaneous_requests = nreq; if (nreq >= 1) S.request_cycles++; }
        const bool all_done = t > 0 && !rst && !any_pending && queue.count == 0 && merge.state == 0 && !ret_valid;
        // ---------------- statistics of the cycle (pre-edge)
        if (t > 0) { S.occupancy_cycles[queue.count]++; if (queue.count > S.queue_peak) S.queue_peak = queue.count; }
        if (merge.state == 1 || (merge.state == 2 && !merge.out_valid)) S.merge_compute_busy++;
        if (ret_valid && !ret_rdy) S.merge_output_blocked++;
        for (int c = 0; c < N; ++c) { for (int b = 0; b < 6; ++b) if (stall[c] >> b & 1) S.stall_reason[b]++; if (stall[c]) S.stall_union++; }
        // ---------------- trace row
        if (fc) {
            unsigned gmask = grant_idx >= 0 ? (1u << grant_idx) : 0u;
            std::fprintf(fc, "%ld,%d,%d,%d,%d,%x,%d,%d,%d,%d,%d,%d,%d,%d,%d", t, rst ? 1 : 0, epoch, queue.count, space ? 1 : 0, gmask, grant_idx >= 0, pop ? 1 : 0, merge.state,
                         ret_valid ? 1 : 0, ret_rdy ? 1 : 0, ret_hs ? 1 : 0, ret_valid ? merge.out_rec.core : 0, ret_valid ? merge.out_rec.id : 0, ret_valid ? (merge.out_rec.ooc ? 1 : 0) : 0);
            for (int c = 0; c < N; ++c) {
                const Core &k = core[c];
                uint64_t w = (uint64_t)(drv[c].idx & 0xFFFF) | ((uint64_t)(k.out_id & 0xFF) << 16) | ((uint64_t)(k.state & 7) << 24)
                    | ((uint64_t)(start_v[c] ? 1 : 0) << 27) | ((uint64_t)(s_hs[c] ? 1 : 0) << 28) | ((uint64_t)(m_hs[c] ? 1 : 0) << 29) | ((uint64_t)(d_hs[c] ? 1 : 0) << 30)
                    | ((uint64_t)(out_valid[c] ? 1 : 0) << 31) | ((uint64_t)(out_rdy[c] ? 1 : 0) << 32) | ((uint64_t)(o_hs[c] ? 1 : 0) << 33) | ((uint64_t)(rc_valid[c] ? 1 : 0) << 34)
                    | ((uint64_t)(r_hs[c] ? 1 : 0) << 35) | ((uint64_t)(k.inexact ? 1 : 0) << 36) | ((uint64_t)(stall[c] & 63) << 37);
                std::fprintf(fc, ",%011llx", (unsigned long long)w);
            }
            std::fprintf(fc, "\n");
        }
        if (all_done) { S.cycles = t + 1; break; }
        // ---------------- events of this edge and next state
        if (rst) {
            if (!rst_prev && t > 0) {
                epoch++; S.resets++; S.epochs = epoch + 1;
                S.per_epoch_starts.push_back(0); S.per_epoch_completed.push_back(0); S.per_epoch_aborted.push_back(0);
                long lost = 0;
                for (int i = 0; i < queue.count; ++i) { const Rec &r = queue.mem[(queue.rd + i) % Q]; recs_[r.core][r.ordinal].abort = t; ev(r.core, r.ordinal, "reset_abort", t); S.aborted++; S.per_epoch_aborted[epoch - 1]++; lost++; }
                if (merge.state != 0) { const Rec &r = merge.rec; recs_[r.core][r.ordinal].abort = t; ev(r.core, r.ordinal, "reset_abort", t); S.aborted++; S.per_epoch_aborted[epoch - 1]++; lost++; }
                S.bits_discarded_by_reset += lost * REC_W;
                for (int c = 0; c < N; ++c) {
                    Core &k = core[c]; Driver &d = drv[c];
                    if (k.cur >= 0) { recs_[c][k.cur].abort = t; ev(c, k.cur, "reset_abort", t); S.aborted++; S.per_epoch_aborted[epoch - 1]++; }
                    if (d.phase == PH_META || d.phase == PH_DATA || d.phase == PH_WAIT) { d.idx++; d.phase = d.idx < txs_[c].size() ? PH_START : PH_DONE; }
                }
            }
            for (int c = 0; c < N; ++c) core[c].reset();
            queue.count = 0; queue.rd = 0; queue.wr = 0; queue.last = 0; merge = Merge();
            rst_prev = true; continue;
        }
        rst_prev = false;
        // return port
        if (ret_hs) {
            const Rec &r = merge.out_rec; TxRec &rec = recs_[r.core][r.ordinal];
            rec.ret_hs = t; ev(r.core, r.ordinal, "return_handshake", t); S.returns++; if (r.ooc) S.ooc_returns++;
            if (rec.out_hs >= 0) complete(r.core, r.ordinal, std::max(rec.out_hs, t));
        }
        // queue pop -> merge accept
        Rec popped;
        if (pop) { popped = queue.mem[queue.rd]; TxRec &rec = recs_[popped.core][popped.ordinal]; rec.merge_acc = t; ev(popped.core, popped.ordinal, "merge_accept", t); S.pops++; S.bits_queue_to_merge += REC_W; }
        // cores and drivers
        for (int c = 0; c < N; ++c) {
            Core &k = core[c]; Driver &d = drv[c];
            if (start_v[c] && d.idx < txs_[c].size() && recs_[c][d.idx].offer < 0) { recs_[c][d.idx].offer = t; ev(c, (long)d.idx, "start_first_offer", t); }
            if (rc_valid[c] && k.cur >= 0 && recs_[c][k.cur].rc_first < 0) { recs_[c][k.cur].rc_first = t; ev(c, k.cur, "record_first_valid", t); }
            // next state of the core (mirrors dot_top_rc)
            bool a_valid_n = false, a_last_n = k.a_last, b_valid_n = k.a_valid, b_last_n = k.a_last;
            switch (k.state) {
            case IDLE:
                if (start_v[c]) {
                    k.state = META; k.meta_index = 0; k.block_index = 0; k.beat = 0; b_valid_n = false; k.bad_scale = txs_[c][d.idx].bad;
                    k.out_id = k.next_id; k.next_id = (k.next_id + 1) & ID_MASK; k.out_done = false; k.rc_done = false;
                    k.cur = (long)d.idx; TxRec &rec = recs_[c][d.idx]; rec.start = t; rec.epoch = epoch; rec.hw_id = k.out_id; ev(c, k.cur, "first_input_accept", t);
                    S.starts++; S.per_epoch_starts[epoch]++; S.bits_core_record_write += CORE_REC_BITS; if (S.first_start < 0) S.first_start = t;
                    d.phase = PH_META; d.g = 0;
                }
                break;
            case META:
                if (meta_v[c]) { if (k.meta_index == B - 1) k.state = DATA; else k.meta_index++; d.g++; if (d.g == B) { d.phase = PH_DATA; d.i = 0; } }
                break;
            case DATA:
                if (data_v[c]) {
                    if (k.beat == 7) { a_valid_n = true; a_last_n = (k.block_index == B - 1); k.beat = 0; if (k.block_index == B - 1) k.state = DRAIN; else k.block_index++; }
                    else k.beat++;
                    d.i++; if (d.i == 8 * B) { d.phase = PH_WAIT; recs_[c][k.cur].last_in = t; ev(c, k.cur, "last_input_accept", t); }
                }
                break;
            case DRAIN:
                if (k.b_valid && k.b_last) { k.inexact = k.bad_scale ? false : txs_[c][k.cur].inexact; k.state = OUT; }
                break;
            case OUT: {
                bool od = k.out_done, rd = k.rc_done;
                if (o_hs[c]) { k.out_done = true; TxRec &rec = recs_[c][k.cur]; rec.out_hs = t; ev(c, k.cur, "normal_result_handshake", t);
                    if (!rec.flagged) complete(c, k.cur, t); else if (rec.ret_hs >= 0) complete(c, k.cur, std::max(rec.ret_hs, t));
                    d.idx++; d.phase = d.idx < txs_[c].size() ? PH_START : PH_DONE; }
                if (r_hs[c]) { k.rc_done = true; TxRec &rec = recs_[c][k.cur]; rec.enq = t; ev(c, k.cur, "record_enqueue", t); S.enqueues++; S.grants++; S.flagged_enqueued++; S.bits_core_to_queue += REC_W;
                    Rec r; r.core = c; r.ordinal = k.cur; r.id = k.out_id; r.ooc = rec.ooc; queue.mem[queue.wr] = r; queue.wr = Q > 1 ? (queue.wr == Q - 1 ? 0 : queue.wr + 1) : 0; queue.last = c; }
                if ((od || o_hs[c]) && (!(k.inexact && !k.bad_scale) || rd || r_hs[c])) { k.state = IDLE; k.cur = -1; }
                break; }
            }
            k.a_valid = a_valid_n; k.a_last = a_last_n; k.b_valid = b_valid_n; k.b_last = b_last_n;
        }
        // queue count / read pointer
        if (pop) queue.rd = Q > 1 ? (queue.rd == Q - 1 ? 0 : queue.rd + 1) : 0;
        queue.count += (grant_idx >= 0 ? 1 : 0) - (pop ? 1 : 0);
        // merge unit next state (mirrors rc_merge)
        switch (merge.state) {
        case 0: if (m_valid) { merge.rec = popped; merge.g = 0; merge.state = 1; } break;
        case 1: if (merge.g == B - 1) merge.state = 2; else merge.g++; break;
        case 2:
            if (!merge.out_valid) { merge.out_valid = true; merge.out_rec = merge.rec; TxRec &rec = recs_[merge.rec.core][merge.rec.ordinal]; rec.ret_first = t + 1; ev(merge.rec.core, merge.rec.ordinal, "return_first_valid", t + 1); }
            else if (ret_rdy) { merge.out_valid = false; merge.state = 0; }
            break;
        }
    }
    if (fc) std::fclose(fc);
    if (fe) {
        for (int c = 0; c < N; ++c) for (const TxRec &r : recs_[c]) {
            if (r.start < 0 && r.offer < 0) continue;
            auto row = [&](const char *name, long cyc) { if (cyc >= 0) std::fprintf(fe, "%d,%d,%ld,%d,%s,%ld\n", r.epoch, c, r.ordinal, r.hw_id, name, cyc); };
            row("start_first_offer", r.offer); row("first_input_accept", r.start); row("last_input_accept", r.last_in); row("normal_result_handshake", r.out_hs);
            row("record_first_valid", r.rc_first); row("record_enqueue", r.enq); row("merge_accept", r.merge_acc); row("return_first_valid", r.ret_first);
            row("return_handshake", r.ret_hs); row("reset_abort", r.abort);
        }
        std::fclose(fe);
    }
    // ---------------- latency statistics
    S.win_start = C.win_start >= 0 ? C.win_start : 0; S.win_end = C.win_end >= 0 ? C.win_end : S.cycles;
    std::vector<long> e2e, a2c, rcl, qw, e2e_w, a2c_w, rcl_w, qw_w;
    for (int c = 0; c < N; ++c) for (const TxRec &r : recs_[c]) {
        if (r.completion < 0) continue;
        bool in_win = r.start >= S.win_start && r.start < S.win_end;
        if (r.completion >= S.win_start && r.completion < S.win_end) { S.win_completed++; if (!(r.flagged && r.ooc)) S.win_useful++; }
        if (in_win) S.cohort++;
        e2e.push_back(r.completion - r.start); if (in_win) e2e_w.push_back(r.completion - r.start);
        long arrival = r.offer >= 0 ? r.offer : r.start;
        a2c.push_back(r.completion - arrival); if (in_win) a2c_w.push_back(r.completion - arrival);
        if (r.flagged && r.ret_hs >= 0 && r.rc_first >= 0) { rcl.push_back(r.ret_hs - r.rc_first); if (in_win) rcl_w.push_back(r.ret_hs - r.rc_first); }
        if (r.flagged && r.merge_acc >= 0 && r.enq >= 0) { qw.push_back(r.merge_acc - r.enq); if (in_win) qw_w.push_back(r.merge_acc - r.enq); }
    }
    S.e2e_all = stats_of(e2e); S.a2c_all = stats_of(a2c); S.rc_all = stats_of(rcl); S.qw_all = stats_of(qw);
    S.e2e_win = stats_of(e2e_w); S.a2c_win = stats_of(a2c_w); S.rc_win = stats_of(rcl_w); S.qw_win = stats_of(qw_w);
    return S;
}

} // namespace mxacc
