// SPDX-License-Identifier: Apache-2.0
// Cycle-level performance model of rtl/mxsys_top.sv (N dot_top_rc cores, round-robin arbiter,
// register queue, shared rc_merge). Control only: the arithmetic is not modelled; the inexact
// flag, the invalid flag and the contract status of every transaction come from the stimulus
// rows (produced by the bit-exact Python model). Semantics: docs/perf_contract.md.
#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <utility>
#include <memory>

namespace mxacc {

constexpr const char *MODEL_VERSION = "0.4.0";

struct Config {
    int n = 1, k = 128, b = 4, f = 2, q = 1, dmax = 24, id_w = 8;
    std::vector<std::pair<long, long>> resets;   // (first cycle, length); the initial pulse included
    long max_cycles = 0;                          // rows available in the mask source (hard cap)
    long win_start = -1, win_end = -1;            // measurement window [start, end); -1 = whole run
    int core_w() const { int w = 0; while ((1 << w) < n) ++w; return w < 1 ? 1 : w; }
    int rec_w() const { return core_w() + id_w + 23 * b; }
    int ii0() const { return 9 * b + 4; }
    int s0() const { return b + 3; }
};

struct Tx {
    long ordinal = 0, arrival = 0;
    bool bad = false, inexact = false, ooc = false;
    int spread = 0;
};

// Mask source: bit(t, stream) with stream 0 = ret_ready, 1+4c+j = core c interface j (start, meta, data, out).
class MaskSource {
public:
    virtual ~MaskSource() = default;
    virtual bool bit(long t, int stream) const = 0;
    virtual long rows() const = 0;          // number of cycles available
};

class FileMasks : public MaskSource {
public:
    FileMasks(const std::string &path, int nbits);
    bool bit(long t, int stream) const override;
    long rows() const override { return (long)nrows_; }
private:
    int nbits_, words_;
    size_t nrows_;
    std::vector<uint64_t> data_;
};

class GeneratedMasks : public MaskSource {
public:
    // thresholds: [ret, start, meta, data, out]; bit = (splitmix64(seed ^ stream<<48 ^ t<<8) & 0xFFFF) >= thr
    GeneratedMasks(uint64_t seed, const int thr[5], long rows) : seed_(seed), rows_(rows) { for (int i = 0; i < 5; ++i) thr_[i] = thr[i]; }
    bool bit(long t, int stream) const override;
    long rows() const override { return rows_; }
    uint64_t seed_; int thr_[5]; long rows_;
};

uint64_t splitmix64(uint64_t x);

// Per-transaction record of event cycles (-1 = did not happen).
struct TxRec {
    long ordinal = 0; int epoch = 0; int hw_id = -1;
    long offer = -1, start = -1, last_in = -1, out_hs = -1, rc_first = -1, enq = -1, merge_acc = -1, ret_first = -1, ret_hs = -1, abort = -1;
    long completion = -1;
    bool flagged = false, bad = false, ooc = false;
};

struct LatencyStats { long count = 0; double mean = 0; long p50 = -1, p90 = -1, p99 = -1, max = -1; };

struct Summary {
    long cycles = 0, resets = 0, epochs = 1;
    long starts = 0, completed = 0, useful_completed = 0, flagged_enqueued = 0, returns = 0, ooc_returns = 0, aborted = 0, enqueues = 0, pops = 0, grants = 0;
    long queue_peak = 0; std::vector<long> occupancy_cycles;   // index = pre-edge occupancy
    long merge_compute_busy = 0, merge_output_blocked = 0;
    long multi_request_cycles = 0, max_simultaneous_requests = 0, request_cycles = 0;
    long stall_reason[6] = {0, 0, 0, 0, 0, 0}; long stall_union = 0;
    long bits_core_record_write = 0, bits_core_to_queue = 0, bits_queue_to_merge = 0, bits_configured_queue = 0, bits_discarded_by_reset = 0;
    long first_start = -1, last_completion = -1;
    // window cohort
    long win_start = 0, win_end = 0, win_completed = 0, win_useful = 0, cohort = 0;
    LatencyStats e2e_all, a2c_all, rc_all, qw_all, e2e_win, a2c_win, rc_win, qw_win;
    std::vector<long> per_epoch_starts, per_epoch_completed, per_epoch_aborted;
};

class Simulator {
public:
    Simulator(const Config &cfg, std::vector<std::vector<Tx>> txs, std::shared_ptr<MaskSource> masks);
    // Runs to completion (or the mask cap). Optional CSV trace paths ("" = none).
    Summary run(const std::string &trace_cycles, const std::string &trace_events);
    std::string error;    // non-empty when the run did not finish (mask exhausted)
    const std::vector<std::vector<TxRec>> &records() const { return recs_; }
private:
    Config cfg_;
    std::vector<std::vector<Tx>> txs_;
    std::shared_ptr<MaskSource> masks_;
    std::vector<std::vector<TxRec>> recs_;
};

} // namespace mxacc
