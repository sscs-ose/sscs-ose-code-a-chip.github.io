`timescale 1ns/1ps
module tb;
 reg clk=0;always #25 clk=~clk;reg rst=1;
 reg start_valid=0,meta_valid=0,data_valid=0,out_ready=0;
 wire start_ready,meta_ready,data_ready,out_valid;
 reg [7:0] scale_x=0,scale_w=0;reg [63:0] x_codes=0;reg [63:0] w_codes=0;
 wire signed [23:0] out_mantissa;wire signed [10:0] out_exponent;wire out_inexact,out_invalid;
 mx_dot dut(.*);
 integer fd,scan,t,g,beat,cycles=0,errors=0;reg [23:0] expected;reg [10:0] exp_expected;reg flag_expected,invalid_expected;
 reg [7:0] sx,sw;reg [63:0] xc;reg [63:0] wc;
 task step;begin @(posedge clk);#0.001;cycles=cycles+1;if(cycles>1000000)$fatal(1,"timeout");end endtask
 initial begin
   repeat(3)step();@(negedge clk);rst=0;
   // Reset an incomplete transaction: no result is allowed to leak afterward.
   @(negedge clk);start_valid=1;step();@(negedge clk);start_valid=0;rst=1;step();@(negedge clk);rst=0;step();
   if(out_valid)$fatal(1,"reset leaked output");
   fd=$fopen("vectors.txt","r");if(!fd)$fatal(1,"vectors missing");
   for(t=0;t<40;t=t+1)begin
     scan=$fscanf(fd,"%h %h %h %h\n",expected,exp_expected,flag_expected,invalid_expected);if(scan!=4)$fatal(1,"bad header");
     while(!start_ready)step();@(negedge clk);start_valid=1;step();@(negedge clk);start_valid=0;
     for(g=0;g<16;g=g+1)begin
       scan=$fscanf(fd,"%h %h\n",sx,sw);if(scan!=2)$fatal(1,"bad metadata");
       if((t+g)%3==0)begin @(negedge clk);meta_valid=0;step();end
       @(negedge clk);meta_valid=1;scale_x=sx;scale_w=sw;while(!meta_ready)step();step();@(negedge clk);meta_valid=0;
     end
     for(g=0;g<16;g=g+1)for(beat=0;beat<4;beat=beat+1)begin
       scan=$fscanf(fd,"%h %h\n",xc,wc);if(scan!=2)$fatal(1,"bad input");
       if((t+beat)%5==0)begin @(negedge clk);data_valid=0;step();end
       @(negedge clk);data_valid=1;x_codes=xc;w_codes=wc;while(!data_ready)step();step();@(negedge clk);data_valid=0;
     end
     while(!out_valid)step();
     if(out_invalid!==invalid_expected || (!invalid_expected && (out_mantissa!==expected || out_exponent!==exp_expected || out_inexact!==flag_expected)))begin
       $display("MISMATCH t=%0d got=%h e=%0d flag=%b invalid=%b expected=%h e=%0d flag=%b invalid=%b",t,out_mantissa,out_exponent,out_inexact,out_invalid,expected,$signed(exp_expected),flag_expected,invalid_expected);errors=errors+1;
     end
     // Output must stay stable during backpressure.
     repeat(t%4)begin step();if(!out_valid)$fatal(1,"dropped out_valid");
       if(out_invalid!==invalid_expected || (!invalid_expected && (out_mantissa!==expected || out_exponent!==exp_expected || out_inexact!==flag_expected)))$fatal(1,"unstable output");end
     @(negedge clk);out_ready=1;step();@(negedge clk);out_ready=0;
   end
   if(errors)$fatal(1,"%0d mismatches",errors);
   $display("PASS transactions=40 cycles=%0d",cycles);$finish;
 end
endmodule
