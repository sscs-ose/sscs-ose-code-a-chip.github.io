`timescale 1ns/1ps
module schedule_tb;
reg clk=0;always #25 clk=~clk;reg rst=1;
wire start_ready,meta_ready,data_ready,out_valid;wire signed [19:0] out_mantissa;wire signed [10:0] out_exponent;wire out_inexact,out_invalid;
mx_dot dut(.clk(clk),.rst(rst),.start_valid(1'b1),.start_ready(start_ready),.meta_valid(1'b1),.meta_ready(meta_ready),.scale_x(8'd127),.scale_w(8'd127),.data_valid(1'b1),.data_ready(data_ready),.x_codes(24'd0),.w_codes(24'd0),.out_valid(out_valid),.out_ready(1'b1),.out_mantissa(out_mantissa),.out_exponent(out_exponent),.out_inexact(out_inexact),.out_invalid(out_invalid));
integer cycle=0,last_start=-1,returns=0;
initial begin repeat(3)@(negedge clk);rst=0;end
always @(posedge clk)if(!rst)begin
  if(start_ready)begin if(last_start>=0 && cycle-last_start!=42)$fatal(1,"II mismatch");last_start=cycle;end
  if(out_valid)begin
    if(cycle-last_start!=41)$fatal(1,"latency mismatch");
    if(out_mantissa!==0 || out_inexact!==0 || out_invalid!==0)$fatal(1,"zero result mismatch");
    returns=returns+1;if(returns==4)begin $display("SCHEDULE_PASS II=42 latency=41");$finish;end
  end
  cycle=cycle+1;if(cycle>100000)$fatal(1,"timeout");
end
endmodule
