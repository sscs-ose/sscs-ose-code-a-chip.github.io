#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${MX_PDK:?Set MX_PDK to the installed PDK name}"
: "${MX_SCL:?Set MX_SCL to its standard-cell library}"
python -m librelane --pdk "$MX_PDK" --scl "$MX_SCL" config.json
