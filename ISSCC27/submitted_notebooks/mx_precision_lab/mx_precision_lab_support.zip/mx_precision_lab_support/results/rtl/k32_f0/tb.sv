`timescale 1ns/1ps
module tb;
 localparam K=32,F=0,B=K/32,W=14;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,start=0,meta_valid=0,in_valid=0,out_ready=0;
 reg [7:0] x_scale=0,w_scale=0;
 reg [15:0] x_codes=0,w_codes=0;
 wire start_ready,meta_ready,in_ready,out_valid,invalid,out_of_contract;
 wire signed [W-1:0] out_int;wire signed [9:0] out_exp;
 dot_top #(.K(K),.F(F),.USE_BOUND(0),.E_BOUND(0)) dut(.*);
 reg [8*B-1:0] xs,ws;reg [4*K-1:0] xc,wc;
 reg [W-1:0] expected_t;integer expected_e,expected_bad,expected_bound;
 integer file,rc,count=0,g,beat,j,seed=20261017;
 integer cycle=0,last_start=-1,starts=0,base_ii=-1;
 always @(posedge clk)cycle<=cycle+1;
 task reset_dut;
 begin
   @(negedge clk);rst=1;start=0;meta_valid=0;in_valid=0;out_ready=0;
   repeat(2)@(negedge clk);rst=0;
 end endtask
 initial begin
   j=$urandom(seed);reset_dut();
   // Continuous handshakes: measure the interval between accepted starts.
   // Sampled on the negedge (all stimulus changes on the negedge), so the
   // DUT state and the cycle counter are settled; requires four accepted
   // starts and identical intervals between them.
   start=1;meta_valid=1;in_valid=1;out_ready=1;x_scale=127;w_scale=127;
   while(starts<4)begin
     @(negedge clk);
     if(start && start_ready)begin
       if(last_start>=0)begin
         if(base_ii<0)base_ii=cycle-last_start;
         if(base_ii!=cycle-last_start)$fatal(1,"II not stable: %0d then %0d",base_ii,cycle-last_start);
       end
       last_start=cycle;starts=starts+1;
     end
   end
   $display("BASE_II=%0d",base_ii);reset_dut();
   // Reset during metadata, then during data, must abandon the transaction.
   start=1;@(negedge clk);start=0;meta_valid=1;x_scale=127;w_scale=127;
   @(negedge clk);reset_dut();
   start=1;@(negedge clk);start=0;meta_valid=1;
   repeat(B)@(negedge clk);meta_valid=0;in_valid=1;
   repeat(3)@(negedge clk);reset_dut();
   file=$fopen("vectors.txt","r");if(file==0)$fatal(1,"missing vectors");
   while(!$feof(file))begin
     rc=$fscanf(file,"%h %h %h %h %h %d %d %d\n",xs,ws,xc,wc,expected_t,expected_e,expected_bad,expected_bound);
     if(rc!=8)$fatal(1,"bad vector row");
     @(negedge clk);while(!start_ready)@(negedge clk);start=1;
     @(negedge clk);start=0;
     for(g=0;g<B;g=g+1)begin
       repeat($urandom_range(0,2))@(negedge clk);
       x_scale=xs[g*8+:8];w_scale=ws[g*8+:8];meta_valid=1;
       while(!meta_ready)@(negedge clk);
       @(negedge clk);meta_valid=0;
     end
     for(g=0;g<B;g=g+1)begin
       for(beat=0;beat<8;beat=beat+1)begin
         repeat($urandom_range(0,2))@(negedge clk);
         x_codes=xc[(g*32+beat*4)*4+:16];w_codes=wc[(g*32+beat*4)*4+:16];in_valid=1;
         while(!in_ready)@(negedge clk);
         @(negedge clk);in_valid=0;
       end
     end
     while(!out_valid)@(negedge clk);
     // Output backpressure: all result fields must remain stable.
     repeat(3)begin
       if(out_int!==expected_t || $signed(out_exp)!=expected_e || invalid!==expected_bad[0] || out_of_contract!==expected_bound[0])
         $fatal(1,"mismatch row %0d T=%0d E=%0d expected T=%0d E=%0d",count,$signed(out_int),$signed(out_exp),$signed(expected_t),expected_e);
       @(negedge clk);
     end
     out_ready=1;@(negedge clk);out_ready=0;count=count+1;
   end
   $display("PASS transactions=%0d",count);$finish;
 end
 initial begin #100000000;$fatal(1,"timeout");end
endmodule
