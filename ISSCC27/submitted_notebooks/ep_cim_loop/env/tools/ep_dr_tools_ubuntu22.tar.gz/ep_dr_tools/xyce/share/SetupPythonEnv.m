% have to tell the python environment within matlab where to find xyce_interface 
if count(py.sys.path,'/usr/local/XyceOpenSource_7.10/share') ==0 
  insert(py.sys.path,int32(0),'/usr/local/XyceOpenSource_7.10/share')
end
if count(py.sys.path,'/opt/ep_dr_tools/xyce/share') ==0 
  insert(py.sys.path,int32(0),'/opt/ep_dr_tools/xyce/share')
end

