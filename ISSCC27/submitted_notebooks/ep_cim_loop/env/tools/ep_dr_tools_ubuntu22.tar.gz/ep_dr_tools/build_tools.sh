#!/bin/bash
# Build the prebuilt tool bundle for ep_dr_oss.ipynb on Google Colab (Ubuntu 22.04 x86_64, glibc 2.35).
# Runs as root inside a fresh ubuntu:22.04 container (Olympus: singularity --fakeroot --writable sandbox).
#   bash build_tools.sh <work dir> <out dir> [jobs]
# Builds ngspice 47 (OSDI, KLU, OpenMP), Trilinos 14.4.0 + Xyce 7.10 (serial), adds the OpenVAF 23.5.0 binary,
# copies the non-glibc shared libraries each binary needs into <tool>/lib and sets RUNPATH=$ORIGIN/../lib.
# Output: <out>/ep_dr_tools_ubuntu22.tar.gz (+ .sha256) and <out>/ep_dr_tools_sources.tar.gz (corresponding source, GPL).
set -euo pipefail
W=${1:?work dir}; OUT=${2:?out dir}; NJ=${3:-$(nproc)}
P=/opt/ep_dr_tools                     # install prefix inside the container = top folder of the bundle
TRI_V=14-4-0; XY_V=7.10.0; NG_V=47
HERE=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$W/src" "$OUT" "$P"
export DEBIAN_FRONTEND=noninteractive
t0=$(date +%s)
apt-get update -qq
apt-get install -y -qq --no-install-recommends build-essential gfortran bison flex pkg-config file curl ca-certificates \
  libopenblas-dev liblapack-dev libsuitesparse-dev libfftw3-dev libfl-dev python3-pip patchelf xz-utils > "$W/apt.log"
pip3 install -q cmake==3.27.9
echo "deps $(( $(date +%s) - t0 )) s"; cmake --version | head -1; gcc --version | head -1

get() { curl -fsSL --retry 8 --retry-delay 5 -o "$2" "$1"; [ -s "$2" ]; }
cd "$W/src"
[ -s ngspice-$NG_V.tar.gz ] || get https://sourceforge.net/projects/ngspice/files/ng-spice-rework/$NG_V/ngspice-$NG_V.tar.gz/download ngspice-$NG_V.tar.gz
[ -s trilinos-$TRI_V.tar.gz ] || get https://github.com/trilinos/Trilinos/archive/refs/tags/trilinos-release-$TRI_V.tar.gz trilinos-$TRI_V.tar.gz
[ -s xyce-$XY_V.tar.gz ] || get https://github.com/Xyce/Xyce/archive/refs/tags/Release-$XY_V.tar.gz xyce-$XY_V.tar.gz
[ -s openvaf_23_5_0_linux_amd64.tar.gz ] || get https://openva.fra1.cdn.digitaloceanspaces.com/openvaf_23_5_0_linux_amd64.tar.gz openvaf_23_5_0_linux_amd64.tar.gz
[ -s openvaf-23.5.0-src.tar.gz ] || get https://github.com/pascalkuthe/OpenVAF/archive/refs/tags/OpenVAF-v23.5.0.tar.gz openvaf-23.5.0-src.tar.gz || true
sha256sum *.tar.gz > SHA256SUMS; cat SHA256SUMS
for f in ngspice-$NG_V trilinos-$TRI_V xyce-$XY_V; do tar -xzf $f.tar.gz; done
echo "sources $(( $(date +%s) - t0 )) s"

# ---- ngspice 47: OSDI + KLU (bundled in ngspice) + OpenMP, no X, no readline
t1=$(date +%s)
mkdir -p ngspice-$NG_V/release && cd ngspice-$NG_V/release
../configure --prefix=$P/ngspice --with-x=no --with-readline=no --enable-openmp --enable-osdi --enable-klu --disable-debug \
  CFLAGS="-O2" > "$W/ngspice_cfg.log" 2>&1
make -j"$NJ" > "$W/ngspice_make.log" 2>&1
make install >> "$W/ngspice_make.log" 2>&1
cd "$W/src"; echo "ngspice $(( $(date +%s) - t1 )) s"

# ---- Trilinos 14.4 (static, serial, the package set of Xyce's cmake/trilinos/trilinos-base.cmake) + Xyce 7.10
t1=$(date +%s)
XS=$W/src/Xyce-Release-$XY_V; TS=$W/src/Trilinos-trilinos-release-$TRI_V; TI=$W/trilinos-install
mkdir -p "$W/tri_build" && cd "$W/tri_build"
cmake -G "Unix Makefiles" -DCMAKE_C_COMPILER=gcc -DCMAKE_CXX_COMPILER=g++ -DCMAKE_Fortran_COMPILER=gfortran \
  -DCMAKE_INSTALL_PREFIX="$TI" -DCMAKE_BUILD_TYPE=Release \
  -DTPL_AMD_INCLUDE_DIRS=/usr/include/suitesparse -DAMD_LIBRARY_DIRS=/usr/lib/x86_64-linux-gnu \
  -C "$XS/cmake/trilinos/trilinos-base.cmake" "$TS" > "$W/trilinos_cfg.log" 2>&1
make -j"$NJ" install > "$W/trilinos_make.log" 2>&1
echo "trilinos $(( $(date +%s) - t1 )) s"
t1=$(date +%s)
mkdir -p "$W/xy_build" && cd "$W/xy_build"
cmake -DCMAKE_C_COMPILER=gcc -DCMAKE_CXX_COMPILER=g++ -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=$P/xyce \
  -DTrilinos_ROOT="$TI" -DCMAKE_INSTALL_RPATH='$ORIGIN/../lib' -DCMAKE_BUILD_WITH_INSTALL_RPATH=ON "$XS" > "$W/xyce_cfg.log" 2>&1
make -j"$NJ" install > "$W/xyce_make.log" 2>&1
cd "$W/src"; echo "xyce $(( $(date +%s) - t1 )) s"
rm -rf $P/xyce/include $P/xyce/lib/cmake $P/xyce/share/cmake; find $P/xyce/lib -name '*.a' -delete; ls -la $P/xyce/bin $P/xyce/lib

# ---- OpenVAF 23.5.0 (public binary)
mkdir -p $P/openvaf/bin && tar -xzf openvaf_23_5_0_linux_amd64.tar.gz -C $P/openvaf/bin

# ---- make relocatable: copy every non-glibc .so into <tool>/lib, RUNPATH $ORIGIN/../lib (binaries) or $ORIGIN (libs)
SYS='^(linux-vdso|ld-linux|libc\.so|libm\.so|libdl\.so|libpthread\.so|librt\.so|libutil\.so|libresolv\.so|libstdc\+\+\.so|libgcc_s\.so)'
bundle_libs() {   # bundle_libs <tool dir> <elf ...>
  local D=$1; shift; mkdir -p "$D/lib"
  local pass
  for pass in 1 2 3 4; do          # libraries of libraries
    for e in "$@" "$D"/lib/*.so*; do
      [ -f "$e" ] || continue
      ldd "$e" 2>/dev/null | awk '$2=="=>" && $3 ~ /^\// {print $1, $3}' | while read -r n p; do
        echo "$n" | grep -Eq "$SYS" && continue
        [ -e "$D/lib/$n" ] || { cp -L "$p" "$D/lib/$n"; echo "  + $n ($p)"; }
      done
    done
  done
  for e in "$@"; do patchelf --set-rpath '$ORIGIN/../lib' "$e" || echo "  (no rpath: $e)"; done
  for l in "$D"/lib/*.so*; do [ -f "$l" ] && [ ! -L "$l" ] && patchelf --set-rpath '$ORIGIN' "$l"; done
  true
}
echo "libs for ngspice:"; bundle_libs $P/ngspice $P/ngspice/bin/ngspice $(find $P/ngspice/lib/ngspice -name '*.cm' 2>/dev/null)
# code models live in lib/ngspice: their RUNPATH must point one level higher
for c in $P/ngspice/lib/ngspice/*.cm; do [ -f "$c" ] && patchelf --set-rpath '$ORIGIN/..' "$c"; done
echo "libs for Xyce:"; bundle_libs $P/xyce $(find $P/xyce/bin -type f -perm -u+x)
echo "libs for openvaf:"; bundle_libs $P/openvaf $P/openvaf/bin/openvaf

# ngspice: real binary -> ngspice.bin; relocatable wrapper sets SPICE_LIB_DIR (spinit, code models).
# spinit's absolute code-model paths are rewritten at install time by colab_setup.sh (placeholder @NGSPICE_LIB@).
mv $P/ngspice/bin/ngspice $P/ngspice/bin/ngspice.bin
cat > $P/ngspice/bin/ngspice <<'EOS'
#!/bin/bash
D=$(cd "$(dirname "$(readlink -f "$0")")/.." && pwd)
export SPICE_LIB_DIR=${SPICE_LIB_DIR:-$D/share/ngspice} SPICE_SCRIPTS=${SPICE_SCRIPTS:-$D/share/ngspice/scripts}
exec "$D/bin/ngspice.bin" "$@"
EOS
chmod +x $P/ngspice/bin/ngspice
sed -i "s#$P/ngspice/lib/ngspice#@NGSPICE_LIB@#g" $P/ngspice/share/ngspice/scripts/spinit
grep -n codemodel $P/ngspice/share/ngspice/scripts/spinit | head -3

# ---- licenses and source notes
L=$P/LICENSES; mkdir -p $L
cp "$XS/COPYING" $L/Xyce-COPYING.txt 2>/dev/null || cp "$XS"/LICENSE* $L/ 2>/dev/null || true
cp "$TS/LICENSE" $L/Trilinos-LICENSE.txt 2>/dev/null || true; cp "$TS/Copyright.txt" $L/Trilinos-Copyright.txt 2>/dev/null || true
cp "$TS/packages/amesos/LICENSE" $L/Trilinos-Amesos-LICENSE.txt 2>/dev/null || true
cp "$W/src/ngspice-$NG_V/COPYING" $L/ngspice-COPYING.txt
for pkg in libopenblas0-pthread liblapack3 libblas3 libamd2 libsuitesparseconfig5 libfftw3-double3 libgfortran5 libquadmath0 libgomp1 libbtf1 libcolamd2 libklu1; do
  [ -f /usr/share/doc/$pkg/copyright ] && cp /usr/share/doc/$pkg/copyright $L/ubuntu-$pkg-copyright.txt
done
cp "$HERE/build_tools.sh" $P/build_tools.sh
{
echo "ep_dr_tools bundle for ep_dr_oss.ipynb (ISSCC 2027 Code-a-Chip), built $(date -u +%F) in docker://ubuntu:22.04 (x86_64, glibc 2.35, $(gcc --version | head -1))."
echo "Unpack anywhere; binaries find their shared libraries through RUNPATH \$ORIGIN/../lib. Built with build_tools.sh (included)."
echo
echo "Contents and licenses"
echo "  xyce/     Xyce 7.10.0 (Sandia), GPL-3.0-or-later (LICENSES/Xyce-COPYING.txt). Statically linked Trilinos 14.4.0"
echo "            (BSD-3 / LGPL-2.1 per package, LICENSES/Trilinos-*; Amesos KLU is LGPL-2.1)."
echo "  ngspice/  ngspice $NG_V, configured --enable-osdi --enable-klu --enable-openmp --with-x=no --with-readline=no; modified BSD-3"
echo "            (LICENSES/ngspice-COPYING.txt; some parts other permissive licenses as listed there)."
echo "  openvaf/  OpenVAF 23.5.0 official Linux binary (unchanged), GPL-3.0. Source: https://github.com/pascalkuthe/OpenVAF tag OpenVAF-v23.5.0"
echo "  */lib     Ubuntu 22.04 runtime libraries copied unchanged (OpenBLAS/LAPACK BSD-3, SuiteSparse AMD BSD-3, FFTW GPL-2+,"
echo "            libgfortran/libquadmath/libgomp GPL-3 with GCC Runtime Library Exception); copyright files in LICENSES/ubuntu-*."
echo
echo "Corresponding source (GPL-3 section 6): ep_dr_tools_sources.tar.gz, published next to this bundle, holds the exact source tarballs"
echo "and build_tools.sh. Upstream locations (sha256 below):"
echo "  https://github.com/Xyce/Xyce/archive/refs/tags/Release-$XY_V.tar.gz"
echo "  https://github.com/trilinos/Trilinos/archive/refs/tags/trilinos-release-$TRI_V.tar.gz"
echo "  https://sourceforge.net/projects/ngspice/files/ng-spice-rework/$NG_V/ngspice-$NG_V.tar.gz"
echo "  https://github.com/pascalkuthe/OpenVAF/archive/refs/tags/OpenVAF-v23.5.0.tar.gz (binary: https://openva.fra1.cdn.digitaloceanspaces.com/openvaf_23_5_0_linux_amd64.tar.gz)"
echo "  Ubuntu 22.04 library sources: apt-get source <package> (packages listed in LICENSES/ubuntu-*)."
echo
sed 's/^/  /' "$W/src/SHA256SUMS"
} > $P/NOTICE.txt

# ---- smoke test inside the build container
$P/ngspice/bin/ngspice -v | head -2
$P/xyce/bin/Xyce -v || true
$P/openvaf/bin/openvaf --version
du -sh $P/*

# ---- tar
cd /opt
tar -czf "$OUT/ep_dr_tools_ubuntu22.tar.gz" --owner=0 --group=0 ep_dr_tools
(cd "$OUT" && sha256sum ep_dr_tools_ubuntu22.tar.gz > ep_dr_tools_ubuntu22.tar.gz.sha256 && cat ep_dr_tools_ubuntu22.tar.gz.sha256)
mkdir -p "$W/srcpkg/ep_dr_tools_sources"
cp "$W/src"/*.tar.gz "$W/src/SHA256SUMS" "$HERE/build_tools.sh" $P/NOTICE.txt "$W/srcpkg/ep_dr_tools_sources/"
tar -cf "$OUT/ep_dr_tools_sources.tar" -C "$W/srcpkg" ep_dr_tools_sources
(cd "$OUT" && sha256sum ep_dr_tools_sources.tar > ep_dr_tools_sources.tar.sha256)
ls -la "$OUT"; echo "total $(( $(date +%s) - t0 )) s"
