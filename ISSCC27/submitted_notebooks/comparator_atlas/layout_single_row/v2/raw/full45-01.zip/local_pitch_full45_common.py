"""Read-only identities for the separately authorized exact-b1 full45 round."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

PRIVATE = Path(__file__).parent
ROUND = PRIVATE / "local-pitch-b1-full45-20261003"
B1 = PRIVATE / "local-pitch-20261003-b1"
ENTRY = Path.cwd() / "ISSCC27/submitted_notebooks/comparator_atlas"
RUN = Path(r"C:\Users\a-vivianhsu\AppData\Local\Temp\abf45")
AUTHORITY = Path(r"C:\Users\a-vivianhsu\.copilot\session-state\d892b0a2-ece5-4270-b902-506f89f00fc1\files\local-pitch-b1-full45-20261003-authorized-protocol.json")
AUTHORITY_SHA = "82571e069c074e71a46c4dadf9eeb79ff0cbd703ac20d8702941ab5b0ef0a381"
os.environ.update(PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1",
                  OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1")
sys.path.insert(0, str(ENTRY / "layout_nominal27"))
sys.path.insert(0, str(ENTRY))
sys.path.insert(0, str(ENTRY / "reproduction/pvt45/layout_pvt45_windows"))
import contract
import layout as layout_reader
import simulate
from comparator_atlas import spice
import windows_contract as windows
from collector_v1 import classify

ENVIRONMENT = json.loads((B1 / "simulation-environment-preflight.json").read_bytes())
BASELINE = json.loads((B1 / "baseline.json").read_bytes())
CONTROL = ENTRY / "layout_single_row/v1/native/candidate"
CANDIDATE = B1 / "native-b1"
EXE = Path(ENVIRONMENT["source_executable"])
MODELS = Path(ENVIRONMENT["source_models"])


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    contract.write_json(path, value)


def verify_authority():
    assert sha(AUTHORITY) == AUTHORITY_SHA
    p = json.loads(AUTHORITY.read_bytes())
    assert p["status"] == "USER_AUTHORIZED_FULL45_EXECUTION_NOT_YET_RUN"
    assert p["grid"]["maximum_new_transient_invocations_including_failures"] == 1440
    assert p["grid"]["steps_ps"] == [10, 5] and p["grid"]["modes"] == ["c", "rc"]
    assert p["frozen_stimulus_and_measurement"]["primary_deadline_ns"] == 2
    assert p["frozen_stimulus_and_measurement"]["helper_reporting_deadlines_ns"] == simulate.DEADLINES
    assert p["finish_boundary"]["no_adoption_or_publication_authorized"]
    return p


def native_tool_identity():
    expected = json.loads((CANDIDATE / "source-freeze.json").read_bytes())["tools"]
    script = (
        "import hashlib,json,subprocess;from pathlib import Path;"
        "p=Path('/home/a-vivianhsu/atlas-parasitic-check-5fa3/tool-work');"
        f"e={expected!r};"
        "assert len(e['seven_tool_hashes'])==7;"
        "assert all(hashlib.sha256((p/n).read_bytes()).hexdigest()==h for n,h in e['seven_tool_hashes'].items());"
        "assert all(subprocess.check_output(['git','-C',str(p/'src'/n),'rev-parse','HEAD'],text=True).strip()==h for n,h in e['source_git_pins'].items());"
        "assert hashlib.sha256((p/'src/open_pdks/sky130/sky130A/libs.tech/magic/sky130A.tcl').read_bytes()).hexdigest()==e['actual_via_script_sha256'];"
        "s={n:subprocess.check_output(['git','-C',str(p/'src'/n),'status','--porcelain','--untracked-files=no'],text=True) for n in e['source_git_pins']};"
        "assert all(v=='' for v in s.values());"
        "print(json.dumps({'pins':e,'source_git_tracked_status':s,'native_jobs':0}))"
    )
    return json.loads(subprocess.check_output(
        ["wsl", "-d", "Ubuntu-24.04", "--", "env", "PYTHONDONTWRITEBYTECODE=1",
         "python3", "-B", "-c", script], timeout=120))


def invariant_audit():
    p = verify_authority()
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == BASELINE["head"]
    assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
    assert sha(ENTRY / "entry_checksums.json") == BASELINE["entry_seal_sha256"]
    assert all(sha(ENTRY / n) == h for n, h in BASELINE["public_seal"].items())
    original = json.loads((ENTRY / "layout_single_row/v1/original-public-control-sha256.json").read_bytes())
    assert len(original) == 396 and all(sha(ENTRY / n) == h for n, h in original.items())
    packages = dict(BASELINE["private_packages"])
    packages[B1.name] = {"manifest": "round-artifact-sha256.json",
                         "manifest_sha256": p["exact_frozen_private_candidate"]["prior_round_manifest_sha256"],
                         "files": 1106}
    for folder, row in packages.items():
        root = PRIVATE / folder
        assert sha(root / row["manifest"]) == row["manifest_sha256"]
        hashes = json.loads((root / row["manifest"]).read_bytes())
        assert len(hashes) == row["files"] and all(sha(root / n) == h for n, h in hashes.items())
    assert all(sha(CONTROL / n) == h for n, h in BASELINE["control_native_sha256"].items())
    assert all(sha(ENTRY / "layout_single_row/v1/native-a1" / n) == h for n, h in BASELINE["native_source_sha256"].items())
    assert sha(CANDIDATE / "atlas.gds") == p["exact_frozen_private_candidate"]["GDS_sha256"]
    assert sha(CANDIDATE / "atlas.mag") == p["exact_frozen_private_candidate"]["MAG_sha256"]
    assert sha(CONTROL / "atlas.gds") == p["public_control"]["GDS_sha256"]
    assert sha(CONTROL / "atlas.mag") == p["public_control"]["MAG_sha256"]
    assert windows.audit_runtime(EXE) == ENVIRONMENT["runtime"]
    assert windows.audit_raw_models(MODELS) == ENVIRONMENT["models"]
    tools = native_tool_identity()
    pr = json.loads(subprocess.check_output(
        ["gh", "api", "repos/sscs-ose/sscs-ose-code-a-chip.github.io/pulls/195"]))
    assert pr["head"]["sha"] == BASELINE["head"] and pr["state"] == "open"
    assert not pr["merged"] and not pr["draft"] and pr["base"]["ref"] == "main"
    assert hashlib.sha256(pr["body"].encode()).hexdigest() == BASELINE["body_utf8_sha256"]
    return {"head": BASELINE["head"], "body_sha256": BASELINE["body_utf8_sha256"],
            "clean_tree": True, "public_seals": 790, "public_blob_closure": 791,
            "entry_seal_sha256": BASELINE["entry_seal_sha256"],
            "Notebook_sha256": BASELINE["public_seal"]["Comparator_Atlas.ipynb"],
            "original_scientific_files": 396, "old_private_packages": packages,
            "tools": tools, "runtime": ENVIRONMENT["runtime"], "models": ENVIRONMENT["models"],
            "both_native_proofs": "REUSED NOT RERUN", "native_jobs": 0,
            "old_b1_archive": {"sha256": sha(B1 / "complete-local-pitch-evidence.zip"),
                               "bytes": (B1 / "complete-local-pitch-evidence.zip").stat().st_size}}
