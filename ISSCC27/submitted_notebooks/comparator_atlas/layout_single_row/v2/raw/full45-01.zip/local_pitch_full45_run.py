"""Exact-b1 full45 paired C/RC campaign;1440 maximum, immediate stops, no reruns."""
import argparse
from dataclasses import asdict
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import traceback
from local_pitch_full45_common import *
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument("--phase", choices=("freeze", "execute"), required=True)
args = parser.parse_args()
plan = verify_authority()
assert os.name == "nt" and sys.dont_write_bytecode
grid = plan["grid"]
conditions = list(itertools.product(grid["corners"], grid["vdd_v"], grid["temperature_c"]))
keys = [(layout, mode, condition, signed) for mode, condition, signed in itertools.product(
    grid["modes"], conditions, grid["signed_input_mv"]) for layout in ("control", "candidate")]
assert len(keys) == len(set(keys)) == 720 and len(conditions) == 45
paths = {(l, m): RUN / "native" / l / f"atlas.{m}.spice"
         for l in ("control", "candidate") for m in grid["modes"]}
devices = {(l, m): contract.read_spice((CONTROL if l == "control" else CANDIDATE) / f"atlas.{m}.spice")["devices"]
           for l, m in paths}


def make_point(condition, signed, step):
    corner, vdd, temperature = condition
    return spice.Point(corner=corner, vdd_v=vdd, temperature_c=temperature,
                       differential_v=signed/1000, pair_skew=0, trim_code=0,
                       load_ff=5, max_step_ps=step, design_name="lvt_balanced_4b")


def deck(key, step):
    layout, mode, condition, signed = key
    point = make_point(condition, signed, step)
    text = simulate.make_deck(mode, point, paths[layout, mode].read_text(),
                              Path("../../model-source"), devices[layout, mode])
    command = f"tran {step:g}p 30n 19n {step:g}p\n"
    assert text.count(command) == 1 and text.count("scale=1u") == 1
    return text.replace(command, "set num_threads=1\n"
                        "echo PVT45W47_NUM_THREADS $num_threads\n"
                        "echo PVT45W47_COMPAT $ngbehavior\n"+command)


def key_dict(key):
    return {"layout": key[0], "mode": key[1], "condition": key[2], "signed_input_mv": key[3]}


def run_key(row):
    return row["layout"], row["mode"], tuple(row["condition"]), row["signed_input_mv"]


def archived_agreement(key, fresh):
    reference = archived[key[1:]]
    checks = []
    for a, b in zip(reference["measurements"], fresh):
        assert a["deadline_ns"] == b["deadline_ns"]
        exact = all(a[f] == b[f] for f in ("decision", "outcome", "reset_ok"))
        energy_ok = math.isclose(a["core_energy_fj"], b["core_energy_fj"], rel_tol=1e-12, abs_tol=1e-12)
        latency_ok = (a["decision_time_ns"] is None and b["decision_time_ns"] is None) or (
            a["decision_time_ns"] is not None and b["decision_time_ns"] is not None and
            math.isclose(a["decision_time_ns"], b["decision_time_ns"], rel_tol=1e-10, abs_tol=1e-11))
        checks.append({"deadline_ns": b["deadline_ns"], "archived": a, "fresh": b,
                       "exact_decision_outcome_reset": exact, "energy_float_agreement": energy_ok,
                       "latency_float_agreement": latency_ok, "passed": exact and energy_ok and latency_ok})
    return {**key_dict(key), "archived_adopted_a1_run_id": reference["run_id"],
            "passed": all(c["passed"] for c in checks), "checks": checks}


import math
if args.phase == "freeze":
    assert not ROUND.exists() and not RUN.exists()
    capacity = shutil.disk_usage(RUN.parent).free
    assert capacity >= 12*1024**3
    before = invariant_audit()
    ROUND.mkdir()
    RUN.mkdir()
    (RUN / "tmp").mkdir()
    (RUN / "simulations").mkdir()
    for source in (AUTHORITY, Path(__file__), PRIVATE / "local_pitch_full45_common.py"):
        shutil.copyfile(source, RUN / ("authorized-protocol.json" if source == AUTHORITY else source.name))
        shutil.copyfile(source, ROUND / ("authorized-protocol.json" if source == AUTHORITY else source.name))
    raw_models = json.loads((windows.HERE / "evidence/model-raw-sha256.json").read_bytes())
    model_root = RUN / "model-source"
    assert max(len(str(model_root/n)) for n in raw_models["files"]) <= 240
    for n in raw_models["files"]:
        target = model_root / n
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(MODELS / n, target)
    assert windows.audit_raw_models(model_root) == ENVIRONMENT["models"]
    for layout, source in (("control", CONTROL), ("candidate", CANDIDATE)):
        target = RUN / "native" / layout
        target.mkdir(parents=True)
        for n in ("atlas.mag", "atlas.gds", "atlas.ext", "atlas.res.ext", "atlas.lvs.spice",
                  "atlas.c.spice", "atlas.rc.spice"):
            shutil.copyfile(source / n, target / n)
            assert sha(target/n) == sha(source/n)
        for mode in grid["modes"]:
            save(target / f"{mode}-passive-dc-audit.json", layout_reader.extraction(source, mode))
    archived_source = ENTRY / "layout_single_row/v1/execution-index.json"
    archived_records = json.loads(archived_source.read_bytes())
    adopted = [r for r in archived_records if r["layout"] == "candidate" and r["max_step_ps"] == 5]
    assert len(adopted) == 360
    save(RUN / "archived-adopted-a1-finest.json", adopted)
    expected = set(itertools.product(grid["modes"], conditions, grid["signed_input_mv"]))
    assert {(r["mode"], (r["point"]["corner"], r["point"]["vdd_v"], r["point"]["temperature_c"]),
             r["point"]["differential_v"]*1000) for r in adopted} == expected
    planned = [{**key_dict(key), "step_ps": step,
                "deck_sha256": hashlib.sha256(deck(key, step).encode()).hexdigest()}
               for key in keys for step in (10, 5)]
    assert len(planned) == 1440
    save(RUN / "pre-data-deck-plan.json", planned)
    save(RUN / "planned-pair-keys.json", [key_dict(k) for k in keys])
    sources = {n: sha(p) for n, p in {
        "runner": Path(__file__), "common": PRIVATE/"local_pitch_full45_common.py",
        "measurement": Path(spice.__file__), "deck_helper": Path(simulate.__file__),
        "numeric_helper": Path(contract.__file__), "passive_DC_reader": Path(layout_reader.__file__),
        "runtime_helper": Path(windows.__file__),
        "classifier": ENTRY/"reproduction/pvt45/layout_pvt45_windows/collector_v1.py",
        "archived_a1_index": archived_source,
        "original_b1_round_manifest": B1/"round-artifact-sha256.json",
        "original_b1_protocol": CANDIDATE/"protocol.json",
        "original_b1_source_freeze": CANDIDATE/"source-freeze.json"}.items()}
    helpers = RUN / "published-helper-sources"
    for folder in (ENTRY/"layout_nominal27", ENTRY/"layout_preflight", ENTRY/"comparator_atlas",
                   ENTRY/"reproduction/pvt45/layout_pvt45_windows"):
        for source in folder.iterdir():
            if source.is_file():
                target = helpers / source.relative_to(ENTRY)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, target)
                assert sha(target) == BASELINE["public_seal"][source.relative_to(ENTRY).as_posix()]
    save(RUN / "input-preflight.json", before)
    save(RUN / "frozen-execution.json", {
        "authorized_plan_sha256": AUTHORITY_SHA, "protocol": plan, "sources": sources,
        "runtime": ENVIRONMENT["runtime"], "models": ENVIRONMENT["models"],
        "capacity_free_bytes": capacity, "workers": 1, "threads": 1,
        "known_nonblind": True, "native_proofs_and_extracts": "REUSED NOT RERUN",
        "native_job_invocations": 0, "control": "current-adopted-single-row-a1",
        "candidate": "exact-single-row-local-pitch-b1", "maximum_invocations": 1440,
        "expected_step_pairs": 720, "maximum_seconds": 10800,
        "primary_deadline_ns": 2, "parallel_deadline_ns": 1,
        "archived_a1_float_agreement": {"energy_relative": 1e-12, "energy_absolute_fj": 1e-12,
                                       "latency_relative": 1e-10, "latency_absolute_ns": 1e-11,
                                       "decisions_outcomes_resets_exact": True},
        "schedule": "For each mode/condition/input: control10/5, immediatequalification/archiveagreement; candidate10/5, immediatequalification/comparisonstop.",
        "planned_deck_hashes": sha(RUN/"pre-data-deck-plan.json"),
        "planned_pair_keys": sha(RUN/"planned-pair-keys.json"),
        "netlist_sha256": {f"{l}/{m}": sha(p) for (l,m),p in paths.items()}})
    save(RUN / "pre-execution-input-sha256.json",
         {p.relative_to(RUN).as_posix(): sha(p) for p in sorted(RUN.rglob("*")) if p.is_file()})
    for n in ("frozen-execution.json", "pre-execution-input-sha256.json", "input-preflight.json",
              "pre-data-deck-plan.json", "planned-pair-keys.json"):
        shutil.copyfile(RUN/n, ROUND/n)
    print("PASS exact authority/old1106+161/48/88/42 closure,720pairkeys/1440deckhashes;zero new transients", flush=True)
    sys.exit(0)

assert ROUND.exists() and RUN.exists() and not (RUN/"execution-index.json").exists()
frozen = json.loads((RUN/"frozen-execution.json").read_bytes())
assert sha(Path(__file__)) == frozen["sources"]["runner"]
assert sha(PRIVATE/"local_pitch_full45_common.py") == frozen["sources"]["common"]
assert all(sha(RUN/n) == h for n,h in json.loads((RUN/"pre-execution-input-sha256.json").read_bytes()).items())
assert invariant_audit() == json.loads((RUN/"input-preflight.json").read_bytes())
os.environ.update(TEMP=str(RUN/"tmp"), TMP=str(RUN/"tmp"))
adopted = json.loads((RUN/"archived-adopted-a1-finest.json").read_bytes())
archived = {(r["mode"], (r["point"]["corner"],r["point"]["vdd_v"],r["point"]["temperature_c"]),
             r["point"]["differential_v"]*1000):r for r in adopted}
planned = json.loads((RUN/"pre-data-deck-plan.json").read_bytes())
deck_hashes = {(r["layout"],r["mode"],tuple(r["condition"]),r["signed_input_mv"],r["step_ps"]):
               r["deck_sha256"] for r in planned}
records, numeric, comparisons, archive_checks = [], {}, [], []
start = time.monotonic()
status, failure = "incomplete", None


def execute(key, step):
    assert len(records) < 1440 and time.monotonic()-start < 10800-120
    layout, mode, condition, signed = key
    p = make_point(condition, signed, step)
    physical = asdict(p)
    physical.pop("max_step_ps")
    identity = {"layout":layout,"mode":mode,"point":physical,"netlist_sha256":sha(paths[layout,mode])}
    text = deck(key, step)
    assert hashlib.sha256(text.encode()).hexdigest() == deck_hashes[(*key,step)]
    run_id = hashlib.sha256(json.dumps({"physical":identity,"step":step,"deck_sha256":deck_hashes[(*key,step)]},
                                     sort_keys=True).encode()).hexdigest()
    folder = RUN/"simulations"/f"a{len(records)+1:04}-{run_id[:16]}"
    folder.mkdir()
    record = {**key_dict(key),"run_id":run_id,"point":asdict(p),"max_step_ps":step,
              "physical_identity":identity,"directory":folder.relative_to(RUN).as_posix(),
              "status":"reserved","charged_before_invocation":True}
    assert not any(run_key(r)==key and r["max_step_ps"]==step for r in records)
    records.append(record)
    save(RUN/"execution-index.json", records)
    try:
        (folder/"circuit.cir").write_text(text,newline="\n")
        (folder/".spiceinit").write_text(simulate.SPICE_INIT,newline="\n")
        assert sha(folder/"circuit.cir")==deck_hashes[(*key,step)]
        result = subprocess.run([str(EXE),"-b","-o","ngspice.log","circuit.cir"],
                                cwd=folder,env=dict(os.environ,HOME=str(folder),USERPROFILE=str(folder)),
                                capture_output=True,text=True,timeout=120)
        console=result.stdout+result.stderr
        (folder/"console.log").write_text(console)
        log=(folder/"ngspice.log").read_text(errors="replace")
        classification=classify(log,console)
        record.update(returncode=result.returncode,log_classification=classification,
                      executed_deck_sha256=sha(folder/"circuit.cir"))
        assert result.returncode==0 and "NOMINAL27_TRANSIENT_COMPLETE" in log
        assert not classification["warnings"] and not classification["errors"],classification
        record["startup_markers"]=windows.runtime_markers(log)
        geometry=simulate.audit_geometry(log,devices[layout,mode])
        save(folder/"actual-geometry.json",geometry)
        values=np.loadtxt(folder/"waveform.tsv",skiprows=1,ndmin=2)
        assert values.shape[1]==9
        spice.validate_waveform(values)
        trace=spice.Trace(p,values,run_id,folder,())
        measured=[asdict(spice.measure(trace,d)) for d in simulate.DEADLINES]
        assert all(m["reset_ok"] for m in measured)
        np.savez_compressed(folder/"waveform.npz",values=values)
        record.update(status="PASS",measurements=measured,geometry_count=geometry["observed_device_count"],
                      waveform_shape=list(values.shape))
    except Exception as error:
        if isinstance(error, subprocess.TimeoutExpired):
            partial = (error.stdout or b"") + (error.stderr or b"")
            if isinstance(partial, bytes):
                (folder/"console-timeout-partial.bin").write_bytes(partial)
            else:
                (folder/"console-timeout-partial.log").write_text(partial)
        record.update(status="FAIL",error=str(error),traceback=traceback.format_exc())
        raise
    finally:
        record["artifact_sha256"]={p.name:sha(p) for p in folder.iterdir() if p.is_file()}
        save(folder/"metadata.json",record)
        save(RUN/"execution-index.json",records)
    return record


try:
    for key in keys:
        history=[execute(key,step) for step in (10,5)]
        audit=contract.refinement_state(history)
        numeric[key]=audit
        save(RUN/"numerical-audits.json",[{**key_dict(k),**a} for k,a in numeric.items()])
        assert audit["qualified"],("Unqualified10/5;STOP",key,audit)
        if key[0]=="control":
            agreement=archived_agreement(key,audit["finest_measurements"])
            archive_checks.append(agreement)
            save(RUN/"fresh-control-archived-a1-agreement.json",archive_checks)
            assert agreement["passed"],("Fresh control/archive mismatch;STOP",agreement)
            continue
        old=numeric[("control",*key[1:])]["finest_measurements"]
        new=audit["finest_measurements"]
        for deadline in (1,2):
            a=next(m for m in old if m["deadline_ns"]==deadline)
            b=next(m for m in new if m["deadline_ns"]==deadline)
            dt=None if a["decision_time_ns"] is None or b["decision_time_ns"] is None else (
                b["decision_time_ns"]-a["decision_time_ns"])
            de=100*(b["core_energy_fj"]/a["core_energy_fj"]-1)
            new_bad=b["outcome"] in ("wrong","unresolved") and a["outcome"]!=b["outcome"]
            lost=a["outcome"]=="correct" and b["outcome"]!="correct"
            regressed=new_bad or lost or de>1 or (deadline==2 and dt is not None and dt>.02)
            row={"mode":key[1],"condition":key[2],"signed_input_mv":key[3],"deadline_ns":deadline,
                 "control":a,"candidate":b,"latency_delta_ns":dt,"energy_change_percent":de,
                 "new_wrong_or_unresolved":new_bad,"lost_previously_correct":lost,"regression_gate":regressed}
            comparisons.append(row)
            save(RUN/"keyed-layout-comparisons.json",comparisons)
            assert not regressed,("Pointwise regression;STOP",row)
        if len(records)%80==0:
            print(f"PASS {len(records)}/1440 charged;{len(numeric)}/720 qualified pairs",flush=True)
    status="completed"
except Exception as error:
    status="stopped"
    failure={"error":str(error),"traceback":traceback.format_exc()}
    save(RUN/"first-stop-failure.json",failure)
    raise
finally:
    after=invariant_audit()
    assert after==json.loads((RUN/"input-preflight.json").read_bytes())
    assert windows.audit_raw_models(RUN/"model-source")==ENVIRONMENT["models"]
    save(RUN/"input-post-execution.json",after)
    attempted={(*run_key(r),r["max_step_ps"]) for r in records}
    not_run=[r for r in planned if (r["layout"],r["mode"],tuple(r["condition"]),r["signed_input_mv"],r["step_ps"]) not in attempted]
    save(RUN/"execution-key-closure.json",{
        "expected":1440,"actual_charged":len(records),"successful":sum(r["status"]=="PASS" for r in records),
        "failed":sum(r["status"]=="FAIL" for r in records),"not_run":not_run,"extra":[],"duplicates":0,
        "reruns":0,"third_steps":0,"numeric_pairs_observed":len(numeric),
        "qualified_pairs":sum(n["qualified"] for n in numeric.values())})
    save(RUN/"execution-receipt.json",{
        "status":status,"failure":failure,"charged_invocations":len(records),
        "qualified_pairs":sum(n["qualified"] for n in numeric.values()),"matched_rows":len(comparisons),
        "elapsed_seconds":time.monotonic()-start,"sources":frozen["sources"],
        "native_jobs":0,"known_nonblind":True,"runtime_models_unchanged":True,
        "adoption_publication_authorized":False,
        "qualification":plan["finish_boundary"]["mandatory_caveat"]})
    save(RUN/"artifact-sha256.json",{p.relative_to(RUN).as_posix():sha(p)
         for p in sorted(RUN.rglob("*")) if p.is_file() and p.name!="artifact-sha256.json"})
    print(f"STOPPED AT BOUNDARY status={status} charged={len(records)} not_run={len(not_run)}",flush=True)
