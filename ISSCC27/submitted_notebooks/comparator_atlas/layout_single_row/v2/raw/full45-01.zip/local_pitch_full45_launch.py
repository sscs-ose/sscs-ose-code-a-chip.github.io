"""Persist exact invocation before admitting the one bounded serial full45 process."""
import os
import subprocess
from local_pitch_full45_common import *

runner = PRIVATE / "local_pitch_full45_run.py"
command = [sys.executable, "-B", str(runner), "--phase", "execute"]
frozen = json.loads((ROUND / "frozen-execution.json").read_bytes())
assert sha(runner) == frozen["sources"]["runner"]
assert not (ROUND / "actual-invocation.json").exists()
save(ROUND / "actual-invocation.json", {
    "command": command, "cwd": str(Path.cwd()), "launcher_sha256": sha(Path(__file__)),
    "runner_sha256": sha(runner), "authority_sha256": AUTHORITY_SHA,
    "frozen_execution_sha256": sha(ROUND / "frozen-execution.json"),
    "pre_execution_input_manifest_sha256": sha(ROUND / "pre-execution-input-sha256.json"),
    "workers": 1, "threads": 1, "runtime": ENVIRONMENT["runtime"],
    "no_new_native_jobs": True})
shutil = __import__("shutil")
shutil.copyfile(Path(__file__), ROUND / Path(__file__).name)
shutil.copyfile(ROUND / "actual-invocation.json", RUN / "actual-invocation.json")
with (ROUND / "execution-console.log").open("w") as console:
    result = subprocess.run(command, cwd=Path.cwd(), env=dict(os.environ),
                            stdout=console, stderr=subprocess.STDOUT)
save(ROUND / "launcher-exit.json", {"returncode": result.returncode,
                                  "execution_console_sha256": sha(ROUND / "execution-console.log")})
print("Full45 serial process exited", result.returncode, flush=True)
sys.exit(result.returncode)
