"""Persist offline/cleanup invocations and their console logs; never invokes SPICE."""
import subprocess
import shutil
from local_pitch_full45_common import *

assert (ROUND/"launcher-exit.json").exists()
shutil.copyfile(Path(__file__),ROUND/Path(__file__).name)
for phase in ("retain","close"):
    source=PRIVATE/f"local_pitch_full45_{phase}.py"
    prior=list(ROUND.glob(f"{phase}-attempt-*-receipt.json"))
    attempt=len(prior)+1
    stem=f"{phase}-attempt-{attempt:02}"
    command=[sys.executable,"-B",str(source)]
    save(ROUND/f"{stem}-invocation.json",{
        "command":command,"cwd":str(Path.cwd()),"script_sha256":sha(source),
        "native_or_SPICE_invocations":0})
    shutil.copyfile(source,ROUND/f"{stem}-source.py")
    result=subprocess.run(command,cwd=Path.cwd(),env=dict(os.environ),
                          capture_output=True,text=True)
    (ROUND/f"{stem}-console.log").write_text(result.stdout+result.stderr)
    save(ROUND/f"{stem}-receipt.json",{
        "returncode":result.returncode,"console_sha256":sha(ROUND/f"{stem}-console.log"),
        "script_sha256":sha(source),"native_or_SPICE_invocations":0})
    print(result.stdout,flush=True)
    if result.returncode:
        print(result.stderr,flush=True)
        sys.exit(result.returncode)
old_manifest=ROUND/"package-artifact-sha256.json"
assert all(sha(ROUND/n)==h for n,h in json.loads(old_manifest.read_bytes()).items())
shutil.copyfile(old_manifest,ROUND/"package-before-final-console-seal.json")
save(old_manifest,{p.relative_to(ROUND).as_posix():sha(p) for p in sorted(ROUND.rglob("*"))
                  if p.is_file() and p.name!="package-artifact-sha256.json"})
final=json.loads(old_manifest.read_bytes())
assert all(sha(ROUND/n)==h for n,h in final.items())
print("FINAL_PERSISTENT_PACKAGE",len(final),"files;SHA256",sha(old_manifest),flush=True)
