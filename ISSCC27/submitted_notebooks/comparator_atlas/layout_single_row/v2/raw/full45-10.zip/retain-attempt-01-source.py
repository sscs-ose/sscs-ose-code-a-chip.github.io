"""Separate-process saved-wave remeasurement, keyed full45 analysis and raw retention."""
from collections import Counter
from dataclasses import asdict
import csv
import itertools
import math
import shutil
import zipfile
from local_pitch_full45_common import *
import numpy as np

assert sys.dont_write_bytecode
assert (ROUND/"launcher-exit.json").exists()
assert not (ROUND/"complete-full45-evidence.zip").exists()
before=invariant_audit()
save(ROUND/"immutable-before-retention.json",before)
execution=json.loads((RUN/"execution-receipt.json").read_bytes())
records=json.loads((RUN/"execution-index.json").read_bytes())
numeric=json.loads((RUN/"numerical-audits.json").read_bytes()) if (RUN/"numerical-audits.json").exists() else []
comparisons=json.loads((RUN/"keyed-layout-comparisons.json").read_bytes()) if (RUN/"keyed-layout-comparisons.json").exists() else []
archived=json.loads((RUN/"fresh-control-archived-a1-agreement.json").read_bytes()) if (RUN/"fresh-control-archived-a1-agreement.json").exists() else []
closure=json.loads((RUN/"execution-key-closure.json").read_bytes())
manifest=json.loads((RUN/"artifact-sha256.json").read_bytes())
assert all(sha(RUN/n)==h for n,h in manifest.items())
plan=verify_authority()
conditions=list(itertools.product(plan["grid"]["corners"],plan["grid"]["vdd_v"],plan["grid"]["temperature_c"]))
expected=set(itertools.product(("control","candidate"),("c","rc"),conditions,(-10,-3,3,10),(10,5)))
planned=json.loads((RUN/"pre-data-deck-plan.json").read_bytes())
planned_keys={(r["layout"],r["mode"],tuple(r["condition"]),r["signed_input_mv"],r["step_ps"]) for r in planned}
assert planned_keys==expected and len(planned)==1440
deck_hashes={(r["layout"],r["mode"],tuple(r["condition"]),r["signed_input_mv"],r["step_ps"]):r["deck_sha256"] for r in planned}


def pair_key(row):
    return row["layout"],row["mode"],tuple(row["condition"]),row["signed_input_mv"]


observed={(*pair_key(r),r["max_step_ps"]) for r in records}
assert len(observed)==len(records) and observed<=expected
assert len(records)==closure["actual_charged"]
assert len(records)+len(closure["not_run"])==1440
assert not closure["extra"] and not closure["duplicates"] and not closure["reruns"] and not closure["third_steps"]
assert {(r["layout"],r["mode"],tuple(r["condition"]),r["signed_input_mv"],r["step_ps"])
        for r in closure["not_run"]}==expected-observed
remeasure=[]
for r in records:
    folder=RUN/r["directory"]
    assert all(sha(folder/n)==h for n,h in r["artifact_sha256"].items())
    assert sha(folder/"circuit.cir")==deck_hashes[(*pair_key(r),r["max_step_ps"])]
    if r["status"]!="PASS":
        remeasure.append({"run_id":r["run_id"],"status":"failed_original_attempt",
                          "no_fabricated_measurement":True,"original_error":r["error"]})
        continue
    assert r["returncode"]==0 and r["geometry_count"]==27
    log=(folder/"ngspice.log").read_text(errors="replace")
    console=(folder/"console.log").read_text()
    assert classify(log,console)==r["log_classification"]
    assert not r["log_classification"]["errors"] and not r["log_classification"]["warnings"]
    assert windows.runtime_markers(log)==r["startup_markers"]
    net=RUN/"native"/r["layout"]/f"atlas.{r['mode']}.spice"
    devices=contract.read_spice(net)["devices"]
    assert simulate.audit_geometry(log,devices)==json.loads((folder/"actual-geometry.json").read_bytes())
    with np.load(folder/"waveform.npz",allow_pickle=False) as saved:
        values=saved["values"]
    tsv=np.loadtxt(folder/"waveform.tsv",skiprows=1,ndmin=2)
    assert np.array_equal(values,tsv)
    spice.validate_waveform(values)
    trace=spice.Trace(spice.Point(**r["point"]),values,r["run_id"],folder,())
    fresh=[asdict(spice.measure(trace,d)) for d in simulate.DEADLINES]
    assert fresh==r["measurements"] and all(m["reset_ok"] for m in fresh)
    remeasure.append({"run_id":r["run_id"],"status":"passed","observations":fresh,
                      "TSV_NPZ_exact_equal":True,"actual27mos_si_audit":True})
    if len(remeasure)%200==0:
        print("Offline remeasured",len(remeasure),"saved waves",flush=True)
save(ROUND/"independent-offline-remeasurement.json",{
    "status":"passed_for_every_available_successful_trace",
    "actual_saved_waves_remeasured":sum(r["status"]=="passed" for r in remeasure),
    "new_SPICE_invocations":0,"unchanged_measurement_sha256":sha(Path(spice.__file__)),
    "method":"Separate process reads saved NPZ and independently parsed TSV; unchanged published measurement.",
    "not_independent_physical_qualification_or_alternative_algorithm":True,"records":remeasure})
record_by_pair={}
for r in records:
    record_by_pair.setdefault(pair_key(r),[]).append(r)
for n in numeric:
    actual=contract.refinement_state(record_by_pair[pair_key(n)])
    assert actual=={k:v for k,v in n.items() if k not in ("layout","mode","condition","signed_input_mv")}
qualified={pair_key(n):n for n in numeric if n["qualified"]}
assert len(qualified)==closure["qualified_pairs"]
adopted=json.loads((RUN/"archived-adopted-a1-finest.json").read_bytes())
adopted_by_key={(r["mode"],(r["point"]["corner"],r["point"]["vdd_v"],r["point"]["temperature_c"]),
                r["point"]["differential_v"]*1000):r for r in adopted}
for a in archived:
    n=qualified[pair_key(a)]
    reference=adopted_by_key[pair_key(a)[1:]]
    assert a["archived_adopted_a1_run_id"]==reference["run_id"]
    for d in a["checks"]:
        assert d["archived"]==next(m for m in reference["measurements"] if m["deadline_ns"]==d["deadline_ns"])
        assert d["fresh"]==next(m for m in n["finest_measurements"] if m["deadline_ns"]==d["deadline_ns"])
        exact=all(d["archived"][f]==d["fresh"][f] for f in ("decision","outcome","reset_ok"))
        energy=math.isclose(d["archived"]["core_energy_fj"],d["fresh"]["core_energy_fj"],rel_tol=1e-12,abs_tol=1e-12)
        x,y=d["archived"]["decision_time_ns"],d["fresh"]["decision_time_ns"]
        latency=(x is None and y is None) or (x is not None and y is not None and math.isclose(x,y,rel_tol=1e-10,abs_tol=1e-11))
        assert d["passed"]==(exact and energy and latency)
for r in comparisons:
    key=(r["mode"],tuple(r["condition"]),r["signed_input_mv"])
    a=next(m for m in qualified[("control",*key)]["finest_measurements"] if m["deadline_ns"]==r["deadline_ns"])
    b=next(m for m in qualified[("candidate",*key)]["finest_measurements"] if m["deadline_ns"]==r["deadline_ns"])
    assert a==r["control"] and b==r["candidate"]
    dt=None if a["decision_time_ns"] is None or b["decision_time_ns"] is None else b["decision_time_ns"]-a["decision_time_ns"]
    de=100*(b["core_energy_fj"]/a["core_energy_fj"]-1)
    assert dt==r["latency_delta_ns"] and de==r["energy_change_percent"]
    bad=b["outcome"] in ("wrong","unresolved") and a["outcome"]!=b["outcome"]
    lost=a["outcome"]=="correct" and b["outcome"]!="correct"
    assert r["regression_gate"]==(bad or lost or de>1 or (r["deadline_ns"]==2 and dt is not None and dt>.02))
complete=execution["status"]=="completed"
if complete:
    assert len(records)==1440 and len(qualified)==720 and len(comparisons)==720 and len(archived)==360
    assert all(a["passed"] for a in archived) and not any(r["regression_gate"] for r in comparisons)
    assert {(r["mode"],tuple(r["condition"]),r["signed_input_mv"],r["deadline_ns"])
            for r in comparisons}==set(itertools.product(("c","rc"),conditions,(-10,-3,3,10),(1,2)))
    assert {pair_key(a)[1:] for a in archived}==set(itertools.product(("c","rc"),conditions,(-10,-3,3,10)))
finest=[]
for key,n in qualified.items():
    for m in n["finest_measurements"]:
        if m["deadline_ns"] not in (1,2):
            continue
        finest.append({"layout":key[0],"mode":key[1],"corner":key[2][0],"vdd_v":key[2][1],
                       "temperature_c":key[2][2],"signed_input_mv":key[3],"finest_step_ps":5,
                       "run_id":n["finest_run_id"],"numerically_qualified":True,**m})
save(ROUND/"finest-point-measurements.json",finest)
save(ROUND/"all-actual-5ps-observations-including-unqualified.json",[
    {"layout":r["layout"],"mode":r["mode"],"condition":r["condition"],
     "signed_input_mv":r["signed_input_mv"],"run_id":r["run_id"],
     "numerically_qualified":pair_key(r) in qualified,"measurements":r["measurements"]}
    for r in records if r["status"]=="PASS" and r["max_step_ps"]==5])
if finest:
    with (ROUND/"finest-point-measurements.csv").open("w",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(finest[0]))
        writer.writeheader()
        writer.writerows(finest)


def physical(row):
    return {k:row[k] for k in ("layout","mode","corner","vdd_v","temperature_c","signed_input_mv")}


populations=[]
for layout,mode in itertools.product(("control","candidate"),("c","rc")):
    points=[r for r in finest if r["layout"]==layout and r["mode"]==mode and r["deadline_ns"]==2]
    first=[r for r in finest if r["layout"]==layout and r["mode"]==mode and r["deadline_ns"]==1]
    times=[r for r in points if r["decision_time_ns"] is not None]
    energy=[r["core_energy_fj"] for r in points]
    worst=max((r["decision_time_ns"] for r in times),default=None)
    max_energy=max(energy,default=None)
    populations.append({"layout":layout,"mode":mode,"actual_qualified_physical_keys":len(points),
        "expected_keys":180,"complete_population":len(points)==180,
        "1ns_counts":dict(Counter(r["outcome"] for r in first)),
        "2ns_counts":dict(Counter(r["outcome"] for r in points)),
        "1ns_wrong_or_unresolved_keys":[{**physical(r),"outcome":r["outcome"],
                                       "latency":r["decision_time_ns"]} for r in first if r["outcome"]!="correct"],
        "mean_core_energy_fj":math.fsum(energy)/len(energy) if energy else None,
        "max_core_energy_fj":max_energy,
        "max_energy_keys_exact_ties":[physical(r) for r in points if r["core_energy_fj"]==max_energy],
        "worst_recorded_2ns_latency_ns":worst,
        "min_observed_2ns_margin_ps":None if worst is None else (2-worst)*1000,
        "worst_latency_keys_exact_ties":[physical(r) for r in times if r["decision_time_ns"]==worst],
        "unrecordable_2ns_latencies":sum(r["decision_time_ns"] is None for r in points)})
if complete:
    assert all(p["actual_qualified_physical_keys"]==180 and p["2ns_counts"]=={"correct":180} for p in populations)
    control_c=next(p for p in populations if p["layout"]=="control" and p["mode"]=="c")
    control_rc=next(p for p in populations if p["layout"]=="control" and p["mode"]=="rc")
    assert control_c["1ns_counts"]=={"correct":170,"unresolved":10}
    assert control_rc["1ns_counts"]=={"correct":156,"unresolved":24}
mode_deltas=[]
for mode in ("c","rc"):
    rows=[r for r in comparisons if r["mode"]==mode and r["deadline_ns"]==2]
    if not rows:
        continue
    energy_a=math.fsum(r["control"]["core_energy_fj"] for r in rows)
    energy_b=math.fsum(r["candidate"]["core_energy_fj"] for r in rows)
    minimum_e=min(r["energy_change_percent"] for r in rows)
    maximum_e=max(r["energy_change_percent"] for r in rows)
    finite=[r for r in rows if r["latency_delta_ns"] is not None]
    minimum_t=min((r["latency_delta_ns"] for r in finite),default=None)
    maximum_t=max((r["latency_delta_ns"] for r in finite),default=None)
    mode_deltas.append({"mode":mode,"matched_keys":len(rows),
        "ratio_of_total_and_mean_energy_change_percent":100*(energy_b/energy_a-1),
        "mean_per_point_energy_change_percent":math.fsum(r["energy_change_percent"] for r in rows)/len(rows),
        "minimum_point_energy_change_percent":minimum_e,"maximum_point_energy_change_percent":maximum_e,
        "minimum_energy_delta_keys_exact_ties":[r for r in rows if r["energy_change_percent"]==minimum_e],
        "maximum_energy_delta_keys_exact_ties":[r for r in rows if r["energy_change_percent"]==maximum_e],
        "minimum_latency_delta_ps":None if minimum_t is None else minimum_t*1000,
        "maximum_latency_delta_ps":None if maximum_t is None else maximum_t*1000,
        "minimum_latency_delta_keys_exact_ties":[r for r in finite if r["latency_delta_ns"]==minimum_t],
        "maximum_latency_delta_keys_exact_ties":[r for r in finite if r["latency_delta_ns"]==maximum_t]})
transitions=[]
for mode,deadline in itertools.product(("c","rc"),(1,2)):
    rows=[r for r in comparisons if r["mode"]==mode and r["deadline_ns"]==deadline]
    counts=Counter((r["control"]["outcome"],r["candidate"]["outcome"]) for r in rows)
    transitions.append({"mode":mode,"deadline_ns":deadline,"matched_physical_keys":len(rows),
        "keyed_transitions":[{"control":a,"candidate":b,"count":n,
            "keys":[{"condition":r["condition"],"signed_input_mv":r["signed_input_mv"]} for r in rows
                    if (r["control"]["outcome"],r["candidate"]["outcome"])==(a,b)]} for (a,b),n in counts.items()],
        "lost_previously_correct":sum(r["lost_previously_correct"] for r in rows),
        "new_wrong_or_unresolved":sum(r["new_wrong_or_unresolved"] for r in rows)})
numeric_deadlines=[d for n in numeric for c in n["comparisons"] for d in c["deadlines"]]
numeric_max={
    "maximum_energy_error_percent":max((d["energy_error_percent"] for d in numeric_deadlines if d["energy_error_percent"] is not None),default=None),
    "maximum_recorded_latency_error_ps":1000*max((d["latency_error_ns"] for d in numeric_deadlines if d["latency_error_ns"] is not None),default=0)}
save(ROUND/"full45-analysis.json",{
    "status":"completed_private_full45_passed_not_adopted" if complete else "stopped_private_full45_incomplete",
    "execution":execution,"charged_invocations":len(records),
    "successful_transients":sum(r["status"]=="PASS" for r in records),
    "failed_transients":sum(r["status"]=="FAIL" for r in records),
    "not_run":len(closure["not_run"]),"qualified_step_pairs":len(qualified),
    "qualified_finest_traces":len(qualified),"finest_1_2ns_measurement_rows":len(finest),
    "numeric_pair_receipts":len(numeric),"layout_comparison_rows":len(comparisons),
    "layout_comparison_rows_each_deadline":{str(d):sum(r["deadline_ns"]==d for r in comparisons) for d in (1,2)},
    "extras":0,"duplicates":0,"reruns":0,"third_steps":0,
    "known_nonblind":True,"native_jobs":0,"both_native_proofs":"REUSED NOT RERUN",
    "populations":populations,"mode_deltas":mode_deltas,"keyed_transitions":transitions,
    "numeric_max":numeric_max,
    "fresh_control_archive_physical_keys_verified":len(archived),
    "fresh_control_archive_helper_readings":sum(len(a["checks"]) for a in archived),
    "fresh_control_archived_a1_all_available_agree":all(a["passed"] for a in archived),
    "new_wrong_unresolved_lost_correct_keys":sum(r["new_wrong_or_unresolved"] or r["lost_previously_correct"] for r in comparisons),
    "pointwise_regression_rows":sum(r["regression_gate"] for r in comparisons),
    "area_baseline_um2":2074.254,"frozen_b1_um2":1873.3,"area_reduction_percent":9.688013136288987,
    "area_measurement_not_rerun":True,"source_authority_sha256":AUTHORITY_SHA,
    "warnings":"Finite-grid maxima and observed2ns margins are not silicon worst cases. Numeric consistency is not physical fidelity or robust global PPA; unchanged inherited M3.16um margin is not a newlocal.20um claim.",
    "scope":plan["finish_boundary"]["scope"],"qualification":plan["finish_boundary"]["mandatory_caveat"],
    "adoption_publication_or_more_optimization_authorized":False})
save(ROUND/"keyed-transitions.json",transitions)
save(ROUND/"mode-delta-limiting-keys.json",mode_deltas)
raw=ROUND/"raw"
assert not raw.exists()
shutil.copytree(RUN,raw)
assert all(sha(raw/n)==h for n,h in manifest.items())
proof=ROUND/"reused-native-proof"
for label,source in (("adopted-a1",ENTRY/"layout_single_row/v1/native-a1"),("exact-b1",CANDIDATE)):
    target=proof/label
    target.mkdir(parents=True)
    for p in source.iterdir():
        if p.is_file() and p.suffix in (".json",".py",".tcl",".tsv"):
            shutil.copyfile(p,target/p.name)
shutil.copytree(B1/"pre-native-restoration",proof/"exact-b1-historical-input-restoration")
shutil.copyfile(B1/"source-freeze-member-resolution.json",proof/"b1-historical-member-resolution.json")
for n in ("local_pitch_full45_common.py","local_pitch_full45_run.py","local_pitch_full45_launch.py",
          "local_pitch_full45_retain.py"):
    source=PRIVATE/n
    if not (ROUND/n).exists():
        shutil.copyfile(source,ROUND/n)
    else:
        assert sha(source)==sha(ROUND/n)
after=invariant_audit()
assert after==before
save(ROUND/"immutable-after-retention.json",after)
members={p.relative_to(ROUND).as_posix():sha(p) for p in sorted(ROUND.rglob("*")) if p.is_file()}
archive=ROUND/"complete-full45-evidence.zip"
with zipfile.ZipFile(archive,"x",zipfile.ZIP_DEFLATED,compresslevel=6) as zipped:
    for n in members:
        zipped.write(ROUND/n,n)
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None and len(zipped.namelist())==len(members)==len(set(zipped.namelist()))
    assert set(zipped.namelist())==set(members)
    assert all(hashlib.sha256(zipped.read(n)).hexdigest()==h for n,h in members.items())
assert all(sha(ROUND/n)==h for n,h in members.items())
save(ROUND/"archive-member-sha256.json",members)
save(ROUND/"archive-retention-receipt.json",{
    "archive_sha256":sha(archive),"bytes":archive.stat().st_size,"members":len(members),
    "unique_names_CRC_every_member_SHA_verified":True,"persistent_uncompressed_bytes_verified":True,
    "raw_scratch_files":len([p for p in RUN.rglob("*") if p.is_file()]),
    "offline_remeasurement_sha256":sha(ROUND/"independent-offline-remeasurement.json"),
    "analysis_sha256":sha(ROUND/"full45-analysis.json"),"runtime_models_old_private_public_unchanged":True,
    "owned_new_Windows_root_only_cleanup_allowed":str(RUN),"no_WSL_scratch_created":True})
print("PASS offline saved waves/numerics/keyed analysis and lossless raw ZIP retention",flush=True)
print((ROUND/"archive-retention-receipt.json").read_text(),flush=True)
