"""Offline remeasurement, immutable-source checks and lossless private evidence retention."""
from collections import Counter
from dataclasses import asdict
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

PRIVATE = Path(__file__).parent
ROUND = PRIVATE / "local-pitch-20261003-b1"
RUN = Path(r"C:\Users\a-vivianhsu\AppData\Local\Temp\alp3")
ENTRY = Path.cwd() / "ISSCC27/submitted_notebooks/comparator_atlas"
NATIVE = ROUND / "native-b1"
BASELINE = json.loads((ROUND / "baseline.json").read_bytes())
PLAN = json.loads((ROUND / "authorized-plan.json").read_bytes())
os.environ.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
sys.path.insert(0, str(ENTRY / "layout_nominal27"))
sys.path.insert(0, str(ENTRY))
import numpy as np
import contract
import simulate
from comparator_atlas import spice
sys.path.insert(0, str(ENTRY / "reproduction/pvt45/layout_pvt45_windows"))
import windows_contract as windows
from collector_v1 import classify


def save(path, value):
    contract.write_json(path, value)
    return contract.sha256(path)


def invariant_audit():
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == BASELINE["head"]
    assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
    assert contract.sha256(ENTRY / "entry_checksums.json") == BASELINE["entry_seal_sha256"]
    assert len(BASELINE["public_seal"]) == 790
    assert all(contract.sha256(ENTRY / n) == h for n, h in BASELINE["public_seal"].items())
    originals = json.loads((ENTRY / "layout_single_row/v1/original-public-control-sha256.json").read_bytes())
    assert len(originals) == 396 and all(contract.sha256(ENTRY / n) == h for n, h in originals.items())
    packages = BASELINE["private_packages"]
    for folder, row in packages.items():
        root = PRIVATE / folder
        assert contract.sha256(root / row["manifest"]) == row["manifest_sha256"]
        hashes = json.loads((root / row["manifest"]).read_bytes())
        assert len(hashes) == row["files"] and all(contract.sha256(root / n) == h for n, h in hashes.items())
    control = ENTRY / "layout_single_row/v1/native/candidate"
    assert all(contract.sha256(control / n) == h for n, h in BASELINE["control_native_sha256"].items())
    adopted_sources = ENTRY / "layout_single_row/v1/native-a1"
    assert all(contract.sha256(adopted_sources / n) == h for n, h in BASELINE["native_source_sha256"].items())
    pr = json.loads(subprocess.check_output(
        ["gh", "api", "repos/sscs-ose/sscs-ose-code-a-chip.github.io/pulls/195"]))
    assert pr["head"]["sha"] == BASELINE["head"] and pr["state"] == "open"
    assert not pr["merged"] and not pr["draft"] and pr["base"]["ref"] == "main"
    assert pr["head"]["ref"] == "wlhsu0827-comparator-atlas-isscc27"
    assert hashlib.sha256(pr["body"].encode()).hexdigest() == BASELINE["body_utf8_sha256"]
    parent_plan = Path(r"C:\Users\a-vivianhsu\.copilot\session-state\d892b0a2-ece5-4270-b902-506f89f00fc1\files\next-local-pitch-round-20261003-proposed-protocol.json")
    assert contract.sha256(parent_plan) == BASELINE["authorized_plan_sha256"]
    runtime_record = json.loads((ROUND / "simulation-environment-preflight.json").read_bytes())
    assert windows.audit_runtime(Path(runtime_record["source_executable"])) == runtime_record["runtime"]
    assert windows.audit_raw_models(Path(runtime_record["source_models"])) == runtime_record["models"]
    return {"head": BASELINE["head"], "clean_tree": True, "public_seals_verified": 790,
            "public_blob_closure": 791, "entry_seal": BASELINE["entry_seal_sha256"],
            "Notebook": BASELINE["public_seal"]["Comparator_Atlas.ipynb"],
            "body_utf8_sha256": BASELINE["body_utf8_sha256"], "state": "open_non_draft_unmerged_main",
            "original_scientific_assets_verified": 396, "private_packages_verified": packages,
            "all_public_native_and_raw_sources_byte_identical": True,
            "control_native_proof": "REUSED NOT RERUN", "runtime_models_unchanged": True,
            "authorized_parent_plan_unchanged": True}


if "--verify-immutable-only" in sys.argv:
    save(ROUND / "immutable-after-cleanup.json", invariant_audit())
    print("PASS immutable public/native/control/scientific/private/model closure after cleanup")
    sys.exit(0)

assert sys.dont_write_bytecode and RUN.is_dir()
before = invariant_audit()
save(ROUND / "immutable-before-archive.json", before)
for root in (RUN, NATIVE):
    manifest = json.loads((root / "artifact-sha256.json").read_bytes())
    assert all(contract.sha256(root / n) == h for n, h in manifest.items())
records = json.loads((RUN / "execution-index.json").read_bytes())
summary = json.loads((RUN / "comparison-summary.json").read_bytes())
numerics = json.loads((RUN / "numerical-audits.json").read_bytes())
structural = json.loads((NATIVE / "structural-receipt.json").read_bytes())
execution = json.loads((RUN / "execution-receipt.json").read_bytes())
key_closure = json.loads((RUN / "execution-key-closure.json").read_bytes())
assert summary["status"] == execution["status"] == "completed"
assert summary["limited_diagnostic_gate_passed"] and summary["regression_rows"] == 0
assert len(records) == execution["charged_transients"] == execution["successful_transients"] == 64
assert len(numerics) == 32 and all(n["qualified"] and n["finest_max_step_ps"] == 5 for n in numerics)
assert key_closure["actual_charged_invocations"] == 64 and not key_closure["not_run"]
assert not key_closure["extra"] and key_closure["duplicates"] == key_closure["reruns"] == key_closure["third_steps"] == 0
assert structural["qualified"] and structural["native_drc_attempts"] == 1
assert len(structural["checks"]) == 14 and all(c["status"] == "PASS" for c in structural["checks"])
area = contract.gds_bounds(NATIVE / "atlas.gds")
assert area == structural["checks"][0]["detail"]["actual_material_bbox"]
assert area["bbox_area_um2"] <= 1970.5413
remeasured = []
for row in records:
    directory = RUN / row["directory"]
    assert row["status"] == "PASS" and row["returncode"] == 0 and row["geometry_count"] == 27
    assert all(contract.sha256(directory / n) == h for n, h in row["artifact_sha256"].items())
    log = (directory / "ngspice.log").read_text(errors="replace")
    console = (directory / "console.log").read_text()
    assert classify(log, console) == row["log_classification"]
    assert not row["log_classification"]["errors"] and not row["log_classification"]["warnings"]
    assert windows.runtime_markers(log) == row["startup_markers"]
    net = RUN / "native" / row["layout"] / f"atlas.{row['mode']}.spice"
    devices = contract.DEVICES if row["mode"] == "schematic" else contract.read_spice(net)["devices"]
    geometry = simulate.audit_geometry(log, devices)
    assert geometry == json.loads((directory / "actual-geometry.json").read_bytes())
    with np.load(directory / "waveform.npz", allow_pickle=False) as raw:
        values = raw["values"]
    tsv = np.loadtxt(directory / "waveform.tsv", skiprows=1, ndmin=2)
    assert np.array_equal(values, tsv)
    spice.validate_waveform(values)
    trace = spice.Trace(spice.Point(**row["point"]), values, row["run_id"], directory, ())
    fresh = [asdict(spice.measure(trace, deadline)) for deadline in simulate.DEADLINES]
    assert fresh == row["measurements"] and all(r["reset_ok"] for r in fresh)
    remeasured.append({"run_id": row["run_id"], "measurements": fresh,
                       "TSV_NPZ_exact_equal": True, "actual_27mos_si_audit": True})
save(ROUND / "independent-offline-remeasurement.json", {
    "status": "passed", "waves_remeasured": 64, "deadline_readings": 384,
    "new_simulations": 0, "measurement_helper_unchanged": contract.sha256(Path(spice.__file__)),
    "reader": "Separate offline process from actual saved NPZ and independent TSV; published measurement function.",
    "not_independent_physical_validation_or_alternative_measurement_algorithm": True,
    "observations": remeasured})
frozen = json.loads((NATIVE / "source-freeze.json").read_bytes())
for name, h in frozen["pre_native_files"].items():
    source = ROUND / "pre-native-restoration/atlas.mag" if name == "atlas.mag" else NATIVE / name
    assert contract.sha256(source) == h, name
save(ROUND / "source-freeze-member-resolution.json", {
    "all_frozen_input_hashes_verified": len(frozen["pre_native_files"]),
    "atlas.mag_pre_native_resolves_to": "pre-native-restoration/atlas.mag",
    "reason": "Native routing normal save replaced original atlas.mag; exact frozen input restored without native execution.",
    "post_native_atlas.mag_resolves_to": "native-b1/atlas.mag"})
retained_run = ROUND / "diagnostic-raw"
assert not retained_run.exists()
shutil.copytree(RUN, retained_run)
run_manifest = json.loads((RUN / "artifact-sha256.json").read_bytes())
assert all(contract.sha256(retained_run / n) == h for n, h in run_manifest.items())
helpers = ROUND / "published-helper-sources"
assert not helpers.exists()
for folder in (ENTRY / "layout_nominal27", ENTRY / "layout_preflight",
               ENTRY / "comparator_atlas", ENTRY / "reproduction/pvt45/layout_pvt45_windows"):
    for source in folder.iterdir():
        if source.is_file():
            target = helpers / source.relative_to(ENTRY)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            assert contract.sha256(target) == BASELINE["public_seal"][source.relative_to(ENTRY).as_posix()]
for name in ("local_pitch_baseline.py", "local_pitch_native.py", "local_pitch_crossmask.py",
             "local_pitch_runtime.py", "local_pitch_simulate.py", "local_pitch_restore_input.py",
             "local_pitch_retain.py"):
    shutil.copyfile(PRIVATE / name, ROUND / name)
counts = []
for layout in ("control", "candidate"):
    for mode in simulate.MODES:
        for deadline in (1, 2):
            outcomes = [r[layout]["outcome"] for r in summary["matched_comparisons"]
                        if r["mode"] == mode and r["deadline_ns"] == deadline]
            assert len(outcomes) == 4
            counts.append({"layout": layout, "mode": mode, "deadline_ns": deadline, "physical_keys": 4,
                           **{name: outcomes.count(name) for name in ("correct", "wrong", "unresolved")}})
assert all(c["correct"] == 4 for c in counts if c["deadline_ns"] == 2)
same_key = lambda r: (r["layout"], r["mode"], tuple(r["condition"]), r["signed_input_mv"])
for n in numerics:
    history = [r for r in records if same_key(r) == same_key(n)]
    assert contract.refinement_state(history) == {k: v for k, v in n.items()
                                                 if k not in ("layout", "mode", "condition", "signed_input_mv")}
comparisons = summary["matched_comparisons"]
save(ROUND / "measured-local-pitch-deltas.json", comparisons)
serial_rows = []
for r in comparisons:
    a, b = r["control"], r["candidate"]
    d = r["candidate_minus_control_latency_ns"]
    assert d is None or math.isclose(d, b["decision_time_ns"]-a["decision_time_ns"], abs_tol=1e-15)
    energy = 100*(b["core_energy_fj"]/a["core_energy_fj"]-1)
    assert energy == r["candidate_energy_change_percent"] and not r["regression_gate"]
    serial_rows.append({"mode": r["mode"], "condition": r["condition"],
                        "signed_input_mv": r["signed_input_mv"], "deadline_ns": r["deadline_ns"],
                        "control_outcome": a["outcome"], "candidate_outcome": b["outcome"],
                        "control_latency_ns": a["decision_time_ns"], "candidate_latency_ns": b["decision_time_ns"],
                        "latency_delta_ps": None if d is None else d*1000,
                        "control_energy_fj": a["core_energy_fj"], "candidate_energy_fj": b["core_energy_fj"],
                        "energy_delta_percent": energy})
save(ROUND / "pointwise-outcome-delta-table.json", serial_rows)
save(ROUND / "final-scientific-receipt.json", {
    "status": "private_native_area_and_limited_diagnostic_passed_not_adopted",
    "candidate": PLAN["candidate_id"], "baseline": "adopted-single-row-a1",
    "actual_all_material_bbox": area, "baseline_um2": 2074.254,
    "incremental_reduction_um2": 2074.254-area["bbox_area_um2"],
    "incremental_reduction_percent": 100*(1-area["bbox_area_um2"]/2074.254),
    "target_um2": 1970.5413, "target_satisfied": True,
    "area_definition": "Actual all nonempty material GDS bbox, including wells/body/guards/shields; TEXT only excluded.",
    "native_checks_passed": 14, "actual_candidate_full_DRC_attempts": 1,
    "candidate_architectures": 1, "optional_second_DRC_not_used": True,
    "pre_native_implementation_failures_in_this_round": [],
    "input_retention_note": "Pre-route MAG overwritten by normal native save; exact frozen SHA-identical bytes restored offline, with explicit recovery receipt.",
    "control_proof": "REUSED NOT RERUN; unchanged adopted candidate GDS/MAG/native LVS/C/RC and a1 generator/protocol.",
    "source_freeze": contract.sha256(NATIVE / "source-freeze.json"),
    "native_manifest": contract.sha256(NATIVE / "artifact-sha256.json"),
    "gds_sha256": contract.sha256(NATIVE / "atlas.gds"),
    "mag_sha256": contract.sha256(NATIVE / "atlas.mag"),
    "authorized_plan_sha256": contract.sha256(ROUND / "authorized-plan.json"),
    "fresh_control_and_candidate_transients": 64, "actual_successful_transients": 64,
    "qualified_10_5_pairs": 32, "expected_pairs": 32, "not_run_transients": 0,
    "diagnostic_point_keys_per_layout_mode": 4, "primary_deadline_ns": 2,
    "parallel_reporting_deadline_ns": 1, "helper_deadlines_ns": simulate.DEADLINES,
    "actual_27mos_si_audits_and_reset_checks": 64, "offline_waves_remeasured": 64,
    "reruns_or_third_steps_or_extra_experiments": 0, "regression_rows": 0,
    "outcomes": counts, "pointwise_changes": serial_rows,
    "largest_numeric_energy_error_percent": max(d["energy_error_percent"] for n in numerics for c in n["comparisons"] for d in c["deadlines"]),
    "largest_numeric_latency_error_ps": 1000*max(d["latency_error_ns"] for n in numerics for c in n["comparisons"] for d in c["deadlines"] if d["latency_error_ns"] is not None),
    "scope": "TT1.8V27C and FS1.62V-40C x signed+-3mV x SC/LVS/C/RC, both a1/b1,10/5ps only; not45PVT/calibrated49.",
    "limits": "All within-band changes/nulls retained; numeric acceptance bands are not physical uncertainty. Small energy/timing decreases are not robust PPA. Not noise/mismatch/MC/silicon/signoff or independently qualified PEX.",
    "qualification": PLAN["end_of_round"]["mandatory_caveat"],
    "public_changes_commit_push_PR_body_comments_CI_jobs_installs_downloads": 0,
    "publication_adoption_full45_authorized": False, "public": before,
    "inherited_tracks": "Unchanged global M3 strip gap0.46um/rule0.30/margin0.16. New-local interval planning margin>=0.20 verified; not a global0.20claim.",
    "simulation_environment": {"runtime": execution["runtime"], "models": execution["models"],
                               "elapsed_seconds": execution["elapsed_seconds"]}})
after = invariant_audit()
assert after == before
save(ROUND / "immutable-after-archive-inputs.json", after)
archive = ROUND / "complete-local-pitch-evidence.zip"
assert not archive.exists()
members = {p.relative_to(ROUND).as_posix(): contract.sha256(p) for p in sorted(ROUND.rglob("*")) if p.is_file()}
with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
    for name in members:
        zipped.write(ROUND / name, name)
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    assert len(zipped.namelist()) == len(members) == len(set(zipped.namelist()))
    assert set(zipped.namelist()) == set(members)
    assert all(hashlib.sha256(zipped.read(n)).hexdigest() == h for n, h in members.items())
save(ROUND / "archive-member-sha256.json", members)
save(ROUND / "archive-retention-receipt.json", {
    "complete_archive_sha256": contract.sha256(archive), "bytes": archive.stat().st_size,
    "members": len(members), "zip_crc_all_members_passed": True,
    "every_member_names_bytes_sha256_verified": True, "persistent_uncompressed_copy_verified": True,
    "Windows_scratch_member_files": len(run_manifest)+1, "native_scratch_member_files": 85,
    "public_and_all_old_packages_models_verified_before_and_after": True,
    "cleanup_permitted_for_only_owned_named_roots": True,
    "scientific_receipt_sha256": contract.sha256(ROUND / "final-scientific-receipt.json")})
print("PASS64 offline waves,790seals,396 originals,161/48/88/42 packages; lossless ZIP CRC/all-member SHA verified")
print(json.dumps(json.loads((ROUND / "archive-retention-receipt.json").read_bytes()), indent=2))
