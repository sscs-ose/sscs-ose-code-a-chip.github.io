"""Close the bounded round: stable final ZIP, exact owned cleanup, persistent final seal."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import zipfile

PRIVATE = Path(__file__).parent
ROUND = PRIVATE / "local-pitch-20261003-b1"
RUN = Path(r"C:\Users\a-vivianhsu\AppData\Local\Temp\alp3")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (ROUND / name).write_text(json.dumps(value, indent=2, allow_nan=False)+"\n", encoding="utf-8")


assert sys.dont_write_bytecode and not RUN.is_symlink() and RUN.resolve() == RUN
initial = json.loads((ROUND / "archive-retention-receipt.json").read_bytes())
archive = ROUND / "complete-local-pitch-evidence.zip"
assert sha(archive) == initial["complete_archive_sha256"]
# Preserve the first packaging snapshot, including its contemporaneous receipts.
archive.rename(ROUND / "initial-retention-snapshot.zip")
(ROUND / "archive-retention-receipt.json").rename(ROUND / "initial-retention-receipt.json")
(ROUND / "archive-member-sha256.json").rename(ROUND / "initial-retention-member-sha256.json")
for name in ("local_pitch_cleanup_native.py", "local_pitch_close.py"):
    shutil.copyfile(PRIVATE / name, ROUND / name)
members = {p.relative_to(ROUND).as_posix(): sha(p) for p in sorted(ROUND.rglob("*")) if p.is_file()}
with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
    for name in members:
        zipped.write(ROUND / name, name)
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None and len(zipped.namelist()) == len(members)
    assert set(zipped.namelist()) == set(members)
    assert all(hashlib.sha256(zipped.read(n)).hexdigest() == h for n, h in members.items())
assert all(sha(ROUND / n) == h for n, h in members.items())
save("archive-member-sha256.json", members)
save("archive-retention-receipt.json", {
    **initial, "complete_archive_sha256": sha(archive), "bytes": archive.stat().st_size,
    "members": len(members), "stable_completed_console_snapshot": True,
    "first_packaging_snapshot_retained": sha(ROUND / "initial-retention-snapshot.zip"),
    "every_persistent_uncompressed_snapshot_member_reverified": True})
run_hashes = json.loads((RUN / "artifact-sha256.json").read_bytes())
assert all(sha(RUN / n) == sha(ROUND / "diagnostic-raw" / n) == h for n, h in run_hashes.items())
assert sha(RUN / "artifact-sha256.json") == sha(ROUND / "diagnostic-raw/artifact-sha256.json")
readonly = []
for p in RUN.rglob("*"):
    if p.is_file() and not p.stat().st_mode & stat.S_IWRITE:
        readonly.append(p.relative_to(RUN).as_posix())
        p.chmod(p.stat().st_mode | stat.S_IWRITE)
assert len([p for p in RUN.rglob("*") if p.is_file()]) == 931
shutil.rmtree(RUN)
assert not RUN.exists()
command = ["wsl", "-d", "Ubuntu-24.04", "--", "env", "PYTHONDONTWRITEBYTECODE=1",
           "python3", "-B", "/mnt/c/Users/a-vivianhsu/.copilot/session-state/b7269072-a451-43a4-91a8-83b8d5c075d9/files/local_pitch_cleanup_native.py"]
native_cleanup = subprocess.run(command, capture_output=True, text=True, check=True, timeout=120)
(ROUND / "native-cleanup-console.log").write_text(native_cleanup.stdout+native_cleanup.stderr)
subprocess.run([sys.executable, "-B", str(PRIVATE / "local_pitch_retain.py"),
                "--verify-immutable-only"], check=True, timeout=180)
save("cleanup-receipt.json", {
    "Windows_owned_scratch_removed": str(RUN), "Windows_removed_files": 931,
    "WSL_owned_scratch_removed": "/home/a-vivianhsu/atlas-local-pitch-20261003-b1",
    "WSL_removed_files": 85, "native_cleanup_receipt_sha256": sha(ROUND / "native-cleanup-receipt.json"),
    "archive_crc_member_names_all_sha_verified_before_both_cleanups": True,
    "readonly_Windows_file_scope_fixes": readonly, "cleanup_failures": [],
    "public_and_all_old_packages_models_unchanged_after_cleanup": True,
    "no_other_paths_deleted": True})
save("final-handoff-receipt.json", {
    "status": "private_local_pitch_b1_native_area_and_64_diagnostic_passed_NOT_ADOPTED",
    "scientific_receipt_sha256": sha(ROUND / "final-scientific-receipt.json"),
    "raw_archive_sha256": sha(archive), "raw_archive_bytes": archive.stat().st_size,
    "raw_archive_members": len(members), "member_manifest_sha256": sha(ROUND / "archive-member-sha256.json"),
    "offline_remeasurement_sha256": sha(ROUND / "independent-offline-remeasurement.json"),
    "cleanup_sha256": sha(ROUND / "cleanup-receipt.json"),
    "immutable_after_cleanup_sha256": sha(ROUND / "immutable-after-cleanup.json"),
    "no_authority_for_adoption_full45_or_publication": True,
    "qualification": "Archived RC-deck outcomes; model physical fidelity not yet qualified"})
save("round-artifact-sha256.json", {
    p.relative_to(ROUND).as_posix(): sha(p) for p in sorted(ROUND.rglob("*"))
    if p.is_file() and p.name != "round-artifact-sha256.json"})
print((ROUND / "final-handoff-receipt.json").read_text())
print("round_manifest_sha256", sha(ROUND / "round-artifact-sha256.json"))
