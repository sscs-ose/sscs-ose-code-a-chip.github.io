"""Read-only existing Windows47/runtime/model capacity gate; no simulations."""
import json
import os
from pathlib import Path
import shutil
import sys

PRIVATE = Path(__file__).parent
ROUND = PRIVATE / "local-pitch-20261003-b1"
ENTRY = Path.cwd() / "ISSCC27/submitted_notebooks/comparator_atlas"
ROOT = Path(r"C:\Users\a-vivianhsu\OneDrive - Microsoft\Desktop\IEEE SSCS Code-a-chip")
EXE = ROOT / ".tools/ngspice/Spice64/bin/ngspice_con.exe"
MODELS = ROOT / ".deps/sky130_fd_pr"
sys.path.insert(0, str(ENTRY / "reproduction/pvt45/layout_pvt45_windows"))
import windows_contract as windows

assert os.environ["PYTHONDONTWRITEBYTECODE"] == "1"
assert not Path(r"C:\Users\a-vivianhsu\AppData\Local\Temp\alp3").exists()
assert shutil.disk_usage(ROUND).free >= 8*1024**3
runtime = windows.audit_runtime(EXE)
models = windows.audit_raw_models(MODELS)
assert runtime["python_version"] == "3.12.10"
record = {"runtime": runtime, "models": models, "source_models": str(MODELS),
          "source_executable": str(EXE), "source_python": sys.executable,
          "windows_free_bytes": shutil.disk_usage(ROUND).free,
          "parallel_workers": 1, "native_transients_executed": 0,
          "no_installs_downloads_normalization": True}
target = ROUND / "simulation-environment-preflight.json"
assert not target.exists()
target.write_text(json.dumps(record, indent=2) + "\n")
print("PASS all existing Windows47/Python3.12.10/NumPy2.2.6 components and400raw model bytes")
