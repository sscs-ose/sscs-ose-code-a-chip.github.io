"""Recover exact frozen pre-route MAG bytes overwritten by Magic's normal save."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys

entry = Path(sys.argv[1])
private = Path(__file__).parent
round_root = private / "local-pitch-20261003-b1"
source = round_root / "native-b1"
target = round_root / "pre-native-restoration"
assert not target.exists()
sys.path.insert(0, str(entry / "layout_nominal27"))
import layout

freeze = json.loads((source / "source-freeze.json").read_bytes())
placement = json.loads((source / "placement.json").read_bytes())
material = defaultdict(list)
for device in layout.DEVICES:
    name = device["name"]
    pcell = source / f"pcell_{name.lower()}.mag"
    assert layout.sha256(pcell) == placement[name]["pcell_sha256"]
    for layer, rectangles in layout.inspect_mag(pcell)["rectangles"].items():
        material[layer].extend(layout.transform_rect(rect, placement[name]) for rect in rectangles)
lines = ["magic", "tech sky130A", "magscale 1 2", "timestamp 0"]
for layer, rectangles in sorted(material.items()):
    lines.append(f"<< {layer} >>")
    lines.extend("rect " + " ".join(map(str, rectangle)) for rectangle in rectangles)
lines.extend(["<< end >>", ""])
recovered = "\n".join(lines).encode()
actual = hashlib.sha256(recovered).hexdigest()
assert actual == freeze["pre_native_files"]["atlas.mag"]
assert actual == json.loads((source / "source-freeze-initial.json").read_bytes())["pre_native_files"]["atlas.mag"]
target.mkdir()
(target / "atlas.mag").write_bytes(recovered)
layout.write_json(target / "recovery-receipt.json", {
    "status": "exact_sha256_identity_verified_against_both_pre_native_freezes",
    "why": "Magic normal routing save overwrote atlas.mag; only frozen input bytes were recovered.",
    "method": "Unchanged original deterministic rectangle serializer, exact retained PCells and frozen placements.",
    "sha256": actual, "native_tool_invocations": 0, "transients": 0,
    "new_geometry_or_search": False, "initial_pre_route_MAG_not_separately_copied": True,
    "source_freeze_sha256": layout.sha256(source / "source-freeze.json"),
    "original_serializer_sha256": layout.sha256(entry / "layout_nominal27/layout.py")})
print("PASS exact original pre-native MAG restored", actual)
