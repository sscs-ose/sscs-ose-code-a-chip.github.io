"""Verify the authorized private round and immutable adopted control."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

PRIVATE = Path(__file__).parent
ROUND = PRIVATE / "local-pitch-20261003-b1"
ENTRY = Path.cwd() / "ISSCC27/submitted_notebooks/comparator_atlas"
PLAN = Path(r"C:\Users\a-vivianhsu\.copilot\session-state\d892b0a2-ece5-4270-b902-506f89f00fc1\files\next-local-pitch-round-20261003-proposed-protocol.json")
PLAN_HASH = "f5fda331cff71e78d09860247420b562d613515ff928a463a3d8aae164e1d87d"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert digest(PLAN) == PLAN_HASH
plan = json.loads(PLAN.read_bytes())
assert plan["status"] == "USER_AUTHORIZED_BOUNDED_EXECUTION_NOT_YET_RUN"
assert plan["limited_matched_simulation"]["maximum_new_transient_invocations_including_failures"] == 64
assert not plan["end_of_round"]["publication_or_adoption_authorized"]
assert not ROUND.exists()
assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == plan["baseline"]["public_commit"]
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
seal = json.loads((ENTRY / "entry_checksums.json").read_bytes())
assert len(seal) == 790 and all(digest(ENTRY / n) == h for n, h in seal.items())
assert digest(ENTRY / "entry_checksums.json") == plan["baseline"]["entry_seal_sha256"]
packages = {}
for folder, manifest, expected in (
    ("single-row-20261003", "round-artifact-sha256.json",
     "647c0f612265a30891ba3eaac1b5b7d2643d6bdcc9bc92809c4343425b2e9606"),
    ("singlerow-full45-20261003", "package-artifact-sha256.json",
     "3cfe50f9b58c8a669370af6b20c8561ed63bb6d6208400f6e5456b6e0377c85e"),
    ("area-two-row-20261003-r1", "artifact-sha256.json",
     "faf8ff62a9e5c982f1803985b34d1eaadac7d1ced30a5888200b234361c486c6"),
    ("area-two-row-20261003-r2", "artifact-sha256.json",
     "6e804e327bf646c29864726b52558772c4c6ce8f9622f447dca0bad30fd5be20"),
):
    root = PRIVATE / folder
    assert digest(root / manifest) == expected
    hashes = json.loads((root / manifest).read_bytes())
    assert all(digest(root / n) == h for n, h in hashes.items()), folder
    packages[folder] = {"manifest": manifest, "manifest_sha256": expected, "files": len(hashes)}
old = json.loads((ENTRY / "layout_single_row/v1/original-public-control-sha256.json").read_bytes())
assert len(old) == 396 and all(digest(ENTRY / n) == h for n, h in old.items())
native = ENTRY / "layout_single_row/v1/native-a1"
assert digest(native / "area_single_row.py") == plan["baseline"]["original_generator_sha256"]
assert digest(native / "protocol.json") == plan["baseline"]["original_protocol_sha256"]
pr = json.loads(subprocess.check_output(
    ["gh", "api", "repos/sscs-ose/sscs-ose-code-a-chip.github.io/pulls/195"]))
assert pr["head"]["sha"] == plan["baseline"]["public_commit"]
assert pr["state"] == "open" and not pr["merged"] and not pr["draft"] and pr["base"]["ref"] == "main"
assert hashlib.sha256(pr["body"].encode()).hexdigest() == (
    "f13b9d7e57fccf225b54293229e1816d918e007912973d4506d4c6c816ca2847")
ROUND.mkdir()
shutil.copyfile(PLAN, ROUND / "authorized-plan.json")
shutil.copyfile(Path(__file__), ROUND / Path(__file__).name)
baseline = {
    "head": pr["head"]["sha"], "body_utf8_sha256": hashlib.sha256(pr["body"].encode()).hexdigest(),
    "authorized_plan_sha256": PLAN_HASH, "public_seal": seal,
    "entry_seal_sha256": digest(ENTRY / "entry_checksums.json"), "private_packages": packages,
    "original_scientific_files_verified": len(old), "public_files": len(seal)+1,
    "control_proof_reused_not_rerun": True,
    "control_native_sha256": {p.name: digest(p) for p in (ENTRY / "layout_single_row/v1/native/candidate").iterdir()
                              if p.is_file()},
    "native_source_sha256": {p.relative_to(native).as_posix(): digest(p)
                             for p in native.rglob("*") if p.is_file()},
    "no_public_edits_or_uploads_authorized": True,
    "owned_windows_scratch": r"C:\Users\a-vivianhsu\AppData\Local\Temp\alp3",
    "owned_wsl_scratch": "/home/a-vivianhsu/atlas-local-pitch-20261003-b1",
}
(ROUND / "baseline.json").write_text(json.dumps(baseline, indent=2) + "\n")
print("PASS authorized plan,790 public seals,396 originals, private packages161/48/88/42; control=a1")
