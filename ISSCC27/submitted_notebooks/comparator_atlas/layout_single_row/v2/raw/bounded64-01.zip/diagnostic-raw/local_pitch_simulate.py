"""Only64 fresh a1/b1 matched transients; stop immediately on numeric/comparison failure."""
from dataclasses import asdict
import hashlib
import itertools
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

PRIVATE = Path(__file__).parent
ROUND = PRIVATE / "local-pitch-20261003-b1"
ENTRY = Path.cwd() / "ISSCC27/submitted_notebooks/comparator_atlas"
NATIVE = ROUND / "native-b1"
CONTROL = ENTRY / "layout_single_row/v1/native/candidate"
OUT = Path(r"C:\Users\a-vivianhsu\AppData\Local\Temp\alp3")
env_record = json.loads((ROUND / "simulation-environment-preflight.json").read_bytes())
EXE, MODELS = Path(env_record["source_executable"]), Path(env_record["source_models"])
plan = json.loads((ROUND / "authorized-plan.json").read_bytes())
sys.path.insert(0, str(ENTRY / "layout_nominal27"))
sys.path.insert(0, str(ENTRY))
os.environ.update(PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1",
                  OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1")
import numpy as np
import contract
import simulate as native_simulator
from comparator_atlas import spice
sys.path.insert(0, str(ENTRY / "reproduction/pvt45/layout_pvt45_windows"))
import windows_contract as windows
from collector_v1 import classify

assert os.name == "nt" and sys.dont_write_bytecode
assert not OUT.exists() and shutil.disk_usage(OUT.parent).free >= 8*1024**3
assert json.loads((NATIVE / "structural-receipt.json").read_bytes())["qualified"]
assert hashlib.sha256((ROUND / "authorized-plan.json").read_bytes()).hexdigest() == (
    "f5fda331cff71e78d09860247420b562d613515ff928a463a3d8aae164e1d87d")
runtime, models = windows.audit_runtime(EXE), windows.audit_raw_models(MODELS)
assert runtime == env_record["runtime"] and models == env_record["models"]
assert runtime["ngspice_console_sha256"] == plan["execution_environment"]["ngspice_sha256"]
for n, h in json.loads((NATIVE / "artifact-sha256.json").read_bytes()).items():
    assert contract.sha256(NATIVE / n) == h
baseline = json.loads((ROUND / "baseline.json").read_bytes())
assert all(contract.sha256(ENTRY / n) == h for n, h in baseline["public_seal"].items())
assert subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip() == baseline["head"]
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
science = plan["limited_matched_simulation"]
assert science["primary_deadline_ns"] == 2 and science["expected_step_pairs"] == 32
assert science["helper_reporting_deadlines_ns"] == native_simulator.DEADLINES
assert science["steps_ps"] == [10, 5]
assert science["maximum_new_transient_invocations_including_failures"] == 64
assert spice.SPICE_INIT == native_simulator.SPICE_INIT
OUT.mkdir()
(OUT / "tmp").mkdir()
(OUT / "simulations").mkdir()
for key in ("TEMP", "TMP"):
    os.environ[key] = str(OUT / "tmp")
os.environ.update(PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1",
                  OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1")
shutil.copyfile(Path(__file__), OUT / Path(__file__).name)
shutil.copyfile(ROUND / "authorized-plan.json", OUT / "authorized-plan.json")
raw_manifest = json.loads((windows.HERE / "evidence/model-raw-sha256.json").read_bytes())
model_root = OUT / "model-source"
assert max(len(str(model_root / n)) for n in raw_manifest["files"]) <= 240
for name in raw_manifest["files"]:
    target = model_root / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(MODELS / name, target)
assert windows.audit_raw_models(model_root) == models
paths, devices = {}, {}
for layout, source in (("control", CONTROL), ("candidate", NATIVE)):
    folder = OUT / "native" / layout
    folder.mkdir(parents=True)
    for mode in native_simulator.MODES:
        original = ENTRY / "results/study/selected_circuit.spice" if mode == "schematic" else source / f"atlas.{mode}.spice"
        target = folder / f"atlas.{mode}.spice"
        shutil.copyfile(original, target)
        paths[layout, mode] = target
        devices[layout, mode] = contract.DEVICES if mode == "schematic" else contract.read_spice(target)["devices"]
        if mode != "schematic":
            contract.check_netlist(contract.read_spice(target), rc=mode == "rc")
assert contract.sha256(paths["control", "schematic"]) == contract.sha256(paths["candidate", "schematic"])
assert all(contract.sha256(paths["control", mode]) == baseline["control_native_sha256"][f"atlas.{mode}.spice"]
           for mode in native_simulator.MODES[1:])
sources = {
    "runner": contract.sha256(Path(__file__)), "authorized_plan": contract.sha256(ROUND / "authorized-plan.json"),
    "measurement": contract.sha256(Path(spice.__file__)),
    "deck_helper": contract.sha256(Path(native_simulator.__file__)),
    "numeric_helper": contract.sha256(Path(contract.__file__)),
    "runtime_helper": contract.sha256(Path(windows.__file__)),
    "log_classifier": contract.sha256(ENTRY / "reproduction/pvt45/layout_pvt45_windows/collector_v1.py"),
    "candidate_native_manifest": contract.sha256(NATIVE / "artifact-sha256.json"),
    "candidate_protocol": contract.sha256(NATIVE / "protocol.json"),
    "native_source_freeze": contract.sha256(NATIVE / "source-freeze.json"),
}
conditions = [tuple(c) for c in science["conditions"]]
physical_keys = list(itertools.product(native_simulator.MODES, conditions, science["signed_input_mv"]))
# Schedule each complete a1 pair immediately before its matched b1 pair.
keys = [(layout, mode, condition, signed) for mode, condition, signed in physical_keys
        for layout in ("control", "candidate")]
assert len(keys) == 32 and len(set(keys)) == 32


def point(condition, signed, step):
    corner, vdd, temperature = condition
    return spice.Point(corner=corner, vdd_v=vdd, temperature_c=temperature,
                       differential_v=signed/1000, pair_skew=0, trim_code=0,
                       load_ff=5, max_step_ps=step, design_name="lvt_balanced_4b")


def deck(layout, mode, p):
    text = native_simulator.make_deck(mode, p, paths[layout, mode].read_text(),
                                      Path("../../model-source"), devices[layout, mode])
    command = f"tran {p.max_step_ps:.12g}p 30n 19n {p.max_step_ps:.12g}p\n"
    assert text.count(command) == 1 and text.count("scale=1u") == 1
    return text.replace(command, "set num_threads=1\n"
                        "echo PVT45W47_NUM_THREADS $num_threads\n"
                        "echo PVT45W47_COMPAT $ngbehavior\n" + command)


planned = [{"layout": layout, "mode": mode, "condition": condition, "signed_input_mv": signed,
            "step_ps": step, "deck_sha256": hashlib.sha256(deck(
                layout, mode, point(condition, signed, step)).encode()).hexdigest()}
           for layout, mode, condition, signed in keys for step in (10, 5)]
contract.write_json(OUT / "pre-data-deck-plan.json", planned)
contract.write_json(OUT / "frozen-execution.json", {
    "candidate": plan["candidate_id"], "control": "adopted-single-row-a1",
    "protocol": science, "runtime": runtime, "models": models, "sources": sources,
    "primary_deadline_ns": 2, "old_inherited_1ns_stimulus_not_primary_policy": True,
    "max_invocations": 64, "workers": 1, "threads": 1,
    "netlist_sha256": {f"{l}/{m}": contract.sha256(p) for (l, m), p in paths.items()},
    "scheduled_order": "Each a1 10/5 pair followed by matched b1 10/5; immediate qualification and stop.",
    "no_further_step_or_rerun": True})
records, numerics, comparisons = [], {}, []
status, failure = "incomplete", None
start = time.monotonic()


def key_record(k):
    return {"layout": k[0], "mode": k[1], "condition": k[2], "signed_input_mv": k[3]}


def persist_numeric():
    contract.write_json(OUT / "numerical-audits.json",
                        [{**key_record(k), **a} for k, a in numerics.items()])


def run(key, step):
    assert len(records) < 64 and time.monotonic()-start < 900
    layout, mode, condition, signed = key
    p = point(condition, signed, step)
    physical = asdict(p)
    physical.pop("max_step_ps")
    identity = {"layout": layout, "mode": mode, "point": physical,
                "netlist_sha256": contract.sha256(paths[layout, mode]), "runtime": runtime, "models": models}
    text = deck(layout, mode, p)
    run_id = hashlib.sha256(json.dumps({"physical": identity, "step": step,
                                      "deck_sha256": hashlib.sha256(text.encode()).hexdigest()},
                                     sort_keys=True).encode()).hexdigest()
    folder = OUT / "simulations" / f"a{len(records)+1:03}-{run_id[:16]}"
    folder.mkdir()
    record = {**key_record(key), "run_id": run_id, "point": asdict(p), "max_step_ps": step,
              "physical_identity": identity, "directory": folder.relative_to(OUT).as_posix(),
              "status": "reserved", "charged_before_invocation": True}
    assert not any(r["layout"] == layout and r["mode"] == mode and r["condition"] == condition
                   and r["signed_input_mv"] == signed and r["max_step_ps"] == step for r in records)
    records.append(record)
    contract.write_json(OUT / "execution-index.json", records)
    try:
        (folder / "circuit.cir").write_text(text, newline="\n")
        (folder / ".spiceinit").write_text(native_simulator.SPICE_INIT, newline="\n")
        expected = next(row for row in planned if row["layout"] == layout and row["mode"] == mode
                        and row["condition"] == condition and row["signed_input_mv"] == signed and row["step_ps"] == step)
        assert contract.sha256(folder / "circuit.cir") == expected["deck_sha256"]
        env = dict(os.environ, HOME=str(folder), USERPROFILE=str(folder))
        result = subprocess.run([str(EXE), "-b", "-o", "ngspice.log", "circuit.cir"],
                                cwd=folder, env=env, capture_output=True, text=True, timeout=120)
        console = result.stdout + result.stderr
        (folder / "console.log").write_text(console)
        log = (folder / "ngspice.log").read_text(errors="replace")
        classification = classify(log, console)
        record.update(returncode=result.returncode, log_classification=classification)
        assert result.returncode == 0 and "NOMINAL27_TRANSIENT_COMPLETE" in log
        assert not classification["warnings"] and not classification["errors"], classification
        record["startup_markers"] = windows.runtime_markers(log)
        actual = native_simulator.audit_geometry(log, devices[layout, mode])
        contract.write_json(folder / "actual-geometry.json", actual)
        values = np.loadtxt(folder / "waveform.tsv", skiprows=1, ndmin=2)
        assert values.shape[1] == 9
        spice.validate_waveform(values)
        trace = spice.Trace(p, values, run_id, folder, ())
        measured = [asdict(spice.measure(trace, deadline)) for deadline in native_simulator.DEADLINES]
        assert all(m["reset_ok"] for m in measured)
        np.savez_compressed(folder / "waveform.npz", values=values)
        record.update(status="PASS", measurements=measured, geometry_count=actual["observed_device_count"],
                      waveform_shape=list(values.shape))
    except Exception as error:
        record.update(status="FAIL", error=str(error), traceback=traceback.format_exc())
        raise
    finally:
        record["artifact_sha256"] = {p.name: contract.sha256(p) for p in folder.iterdir() if p.is_file()}
        contract.write_json(folder / "metadata.json", record)
        contract.write_json(OUT / "execution-index.json", records)
    print(f"PASS {len(records)}/64 {layout} {mode} {condition} {signed:+}mV {step}ps", flush=True)
    return record


try:
    for key in keys:
        history = [run(key, step) for step in (10, 5)]
        numerics[key] = contract.refinement_state(history)
        persist_numeric()
        assert numerics[key]["qualified"], ("Unqualified pair; stop", key, numerics[key])
        if key[0] != "candidate":
            continue
        control = numerics[("control", *key[1:])]
        candidate = numerics[key]
        for deadline in (1, 2):
            a = next(m for m in control["finest_measurements"] if m["deadline_ns"] == deadline)
            b = next(m for m in candidate["finest_measurements"] if m["deadline_ns"] == deadline)
            delta = None if a["decision_time_ns"] is None or b["decision_time_ns"] is None else (
                b["decision_time_ns"]-a["decision_time_ns"])
            energy = 100*(b["core_energy_fj"]/a["core_energy_fj"]-1)
            new_failure = (b["outcome"] in ("wrong", "unresolved") and b["outcome"] != a["outcome"])
            lost_correct = a["outcome"] == "correct" and b["outcome"] != "correct"
            regressed = new_failure or lost_correct or energy > 1 or (
                deadline == 2 and delta is not None and delta > .02)
            comparisons.append({"mode": key[1], "condition": key[2], "signed_input_mv": key[3],
                "deadline_ns": deadline, "control": a, "candidate": b,
                "control_finest_step_ps": 5, "candidate_finest_step_ps": 5,
                "candidate_minus_control_latency_ns": delta, "candidate_energy_change_percent": energy,
                "new_failure": new_failure, "lost_previously_correct": lost_correct,
                "regression_gate": regressed})
            contract.write_json(OUT / "matched-comparisons.json", comparisons)
            assert not regressed, ("Comparison stop/reject", comparisons[-1])
    status = "completed"
except Exception as error:
    status = "stopped_failed_or_regressed"
    failure = {"error": str(error), "traceback": traceback.format_exc()}
    contract.write_json(OUT / "first-stop-failure.json", failure)
    raise
finally:
    assert windows.audit_runtime(EXE) == runtime
    assert windows.audit_raw_models(MODELS) == windows.audit_raw_models(model_root) == models
    attempted = {(r["layout"], r["mode"], tuple(r["condition"]), r["signed_input_mv"], r["max_step_ps"])
                 for r in records}
    not_run = [row for row in planned if (row["layout"], row["mode"], tuple(row["condition"]),
                                        row["signed_input_mv"], row["step_ps"]) not in attempted]
    contract.write_json(OUT / "execution-key-closure.json", {
        "planned_invocations": 64, "actual_charged_invocations": len(records),
        "not_run": not_run, "extra": [], "duplicates": 0, "reruns": 0, "third_steps": 0})
    summary = {"status": status, "transients": len(records),
               "successful_transients": sum(r["status"] == "PASS" for r in records),
               "numerically_qualified_pairs": sum(n["qualified"] for n in numerics.values()),
               "expected_pairs": 32, "not_run": len(not_run), "matched_comparisons": comparisons,
               "regression_rows": sum(r["regression_gate"] for r in comparisons),
               "limited_diagnostic_gate_passed": status == "completed",
               "adopted_or_published": False, "failure": failure,
               "qualification": plan["end_of_round"]["mandatory_caveat"]}
    contract.write_json(OUT / "comparison-summary.json", summary)
    persist_numeric()
    contract.write_json(OUT / "execution-receipt.json", {
        "status": status, "charged_transients": len(records),
        "successful_transients": sum(r["status"] == "PASS" for r in records),
        "elapsed_seconds": time.monotonic()-start, "runtime_models_unchanged": True,
        "sources": sources, "runtime": runtime, "models": models,
        "no_installs_downloads_or_finer_steps": True})
    contract.write_json(OUT / "artifact-sha256.json", {
        p.relative_to(OUT).as_posix(): contract.sha256(p) for p in sorted(OUT.rglob("*")) if p.is_file()
        and p.name != "artifact-sha256.json"})
