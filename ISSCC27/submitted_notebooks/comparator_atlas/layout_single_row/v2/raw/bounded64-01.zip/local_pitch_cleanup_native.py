"""Delete only this round's exact owned WSL scratch after persisted verification."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

PRIVATE = Path(__file__).parent
ROUND = PRIVATE / "local-pitch-20261003-b1"
OUT = Path("/home/a-vivianhsu/atlas-local-pitch-20261003-b1")
ENTRY = Path("/mnt/c/Users/a-vivianhsu/.copilot/repos/copilot-worktrees/official/wlhsu0827-sturdy-adventure/ISSCC27/submitted_notebooks/comparator_atlas")
TOOLS = Path("/home/a-vivianhsu/atlas-parasitic-check-5fa3/tool-work")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tools():
    args = ["python3", "-B", str(PRIVATE / "local_pitch_native.py"), "--entry", str(ENTRY),
            "--private", str(PRIVATE), "--phase", "verify-tools"]
    return json.loads(subprocess.check_output(args))


assert OUT.resolve() == OUT and not OUT.is_symlink()
assert (ROUND / "archive-retention-receipt.json").exists()
archive = json.loads((ROUND / "archive-retention-receipt.json").read_bytes())
assert sha(ROUND / "complete-local-pitch-evidence.zip") == archive["complete_archive_sha256"]
manifest = json.loads((OUT / "artifact-sha256.json").read_bytes())
assert all(sha(OUT / n) == sha(ROUND / "native-b1" / n) == h for n, h in manifest.items())
assert sha(OUT / "artifact-sha256.json") == sha(ROUND / "native-b1/artifact-sha256.json")
expected = json.loads((ROUND / "native-b1/source-freeze.json").read_bytes())["tools"]
before = tools()
assert before == expected
git_before = {name: subprocess.check_output(
    ["git", "-C", str(TOOLS / "src" / name), "status", "--porcelain", "--untracked-files=no"],
    text=True) for name in ("magic", "netgen", "open_pdks")}
files = [str(p.relative_to(OUT)) for p in sorted(OUT.rglob("*")) if p.is_file()]
assert len(files) == 85
shutil.rmtree(OUT)
assert not OUT.exists()
after = tools()
assert after == before
git_after = {name: subprocess.check_output(
    ["git", "-C", str(TOOLS / "src" / name), "status", "--porcelain", "--untracked-files=no"],
    text=True) for name in ("magic", "netgen", "open_pdks")}
assert git_before == git_after
receipt = {"owned_root": str(OUT), "removed_files": files, "owned_root_absent": True,
           "persistent_native_and_archive_verified_before_cleanup": True,
           "tool_pins_before": before, "tool_pins_after": after,
           "source_git_tracked_status_before": git_before, "source_git_tracked_status_after": git_after,
           "existing_tools_sources_unmodified": True, "readonly_file_scope_fixes": [],
           "cleanup_failures": []}
(ROUND / "native-cleanup-receipt.json").write_text(json.dumps(receipt, indent=2)+"\n")
print("PASS exact85-file owned WSL scratch removed;7tool/sourcepins unchanged")
