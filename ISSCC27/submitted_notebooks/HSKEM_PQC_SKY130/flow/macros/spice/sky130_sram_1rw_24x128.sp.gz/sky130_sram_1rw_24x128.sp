**************************************************
* OpenRAM generated memory.
* Words: 128
* Data bits: 24
* Banks: 1
* Column mux: 8:1
* Trimmed: False
* LVS: False
**************************************************
* Copyright 2020 The SkyWater PDK Authors
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     https://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*
* SPDX-License-Identifier: Apache-2.0

* SPICE3 file created from sky130_fd_bd_sram__openram_dff.ext - technology: EFS8A

.subckt sky130_fd_bd_sram__openram_dff D Q CLK VDD GND
X1000 a_511_725# a_n8_115# VDD VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1001 a_353_115# CLK a_11_624# GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X1002 a_353_725# a_203_89# a_11_624# VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1003 a_11_624# a_203_89# a_161_115# GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X1004 a_11_624# CLK a_161_725# VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1005 GND Q a_703_115# GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X1006 VDD Q a_703_725# VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1007 a_203_89# CLK GND GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X1008 a_203_89# CLK VDD VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1009 a_161_115# D GND GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X1010 a_161_725# D VDD VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1011 GND a_11_624# a_n8_115# GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X1012 a_703_115# a_203_89# ON GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X1013 VDD a_11_624# a_n8_115# VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1014 a_703_725# CLK ON VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1015 Q ON VDD VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1016 Q ON GND GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X1017 ON a_203_89# a_511_725# VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1018 ON CLK a_511_115# GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X1019 GND a_n8_115# a_353_115# GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X1020 VDD a_n8_115# a_353_725# VDD sky130_fd_pr__pfet_01v8 W=3 L=0.15
X1021 a_511_115# a_n8_115# GND GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
.ends

.SUBCKT sky130_sram_1rw_24x128_row_addr_dff
+ din_0 din_1 din_2 din_3 din_4 dout_0 dout_1 dout_2 dout_3 dout_4 clk
+ vdd gnd
* INPUT : din_0 
* INPUT : din_1 
* INPUT : din_2 
* INPUT : din_3 
* INPUT : din_4 
* OUTPUT: dout_0 
* OUTPUT: dout_1 
* OUTPUT: dout_2 
* OUTPUT: dout_3 
* OUTPUT: dout_4 
* INPUT : clk 
* POWER : vdd 
* GROUND: gnd 
* rows: 5 cols: 1
Xdff_r0_c0
+ din_0 dout_0 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r1_c0
+ din_1 dout_1 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r2_c0
+ din_2 dout_2 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r3_c0
+ din_3 dout_3 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r4_c0
+ din_4 dout_4 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
.ENDS sky130_sram_1rw_24x128_row_addr_dff

.SUBCKT sky130_sram_1rw_24x128_spare_wen_dff
+ din_0 dout_0 clk vdd gnd
* INPUT : din_0 
* OUTPUT: dout_0 
* INPUT : clk 
* POWER : vdd 
* GROUND: gnd 
* rows: 1 cols: 1
Xdff_r0_c0
+ din_0 dout_0 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
.ENDS sky130_sram_1rw_24x128_spare_wen_dff

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=14 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=14 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

.SUBCKT sky130_sram_1rw_24x128_pinv_13
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 25
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=14 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=14 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
.ENDS sky130_sram_1rw_24x128_pinv_13

.SUBCKT sky130_sram_1rw_24x128_pdriver_5
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* sizes: [25]
Xbuf_inv1
+ A Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_13
.ENDS sky130_sram_1rw_24x128_pdriver_5

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u

.SUBCKT sky130_sram_1rw_24x128_pnand3
+ A B C Z vdd gnd
* INPUT : A 
* INPUT : B 
* INPUT : C 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpnand3_pmos1 vdd A Z vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpnand3_pmos2 Z B vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpnand3_pmos3 Z C vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpnand3_nmos1 Z C net1 gnd sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
Xpnand3_nmos2 net1 B net2 gnd sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
Xpnand3_nmos3 net2 A gnd gnd sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
.ENDS sky130_sram_1rw_24x128_pnand3

.SUBCKT sky130_sram_1rw_24x128_pand3_1
+ A B C Z vdd gnd
* INPUT : A 
* INPUT : B 
* INPUT : C 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 25
Xpand3_nand
+ A B C zb_int vdd gnd
+ sky130_sram_1rw_24x128_pnand3
Xpand3_inv
+ zb_int Z vdd gnd
+ sky130_sram_1rw_24x128_pdriver_5
.ENDS sky130_sram_1rw_24x128_pand3_1

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=3 w=1.68 l=0.15 pd=3.66 ps=3.66 as=0.63u ad=0.63u

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=3 w=1.68 l=0.15 pd=3.66 ps=3.66 as=0.63u ad=0.63u

.SUBCKT sky130_sram_1rw_24x128_pinv_3
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 4
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=3 w=1.68 l=0.15 pd=3.66 ps=3.66 as=0.63u ad=0.63u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=3 w=1.68 l=0.15 pd=3.66 ps=3.66 as=0.63u ad=0.63u
.ENDS sky130_sram_1rw_24x128_pinv_3

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=2 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=2 w=1.26 l=0.15 pd=2.82 ps=2.82 as=0.47u ad=0.47u

.SUBCKT sky130_sram_1rw_24x128_pinv_2
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 2
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=2 w=1.26 l=0.15 pd=2.82 ps=2.82 as=0.47u ad=0.47u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=2 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
.ENDS sky130_sram_1rw_24x128_pinv_2

.SUBCKT sky130_sram_1rw_24x128_dff_buf_0
+ D Q Qb clk vdd gnd
* INPUT : D 
* OUTPUT: Q 
* OUTPUT: Qb 
* INPUT : clk 
* POWER : vdd 
* GROUND: gnd 
* inv1: 2 inv2: 4
Xdff_buf_dff
+ D qint clk vdd gnd
+ sky130_fd_bd_sram__openram_dff
Xdff_buf_inv1
+ qint Qb vdd gnd
+ sky130_sram_1rw_24x128_pinv_2
Xdff_buf_inv2
+ Qb Q vdd gnd
+ sky130_sram_1rw_24x128_pinv_3
.ENDS sky130_sram_1rw_24x128_dff_buf_0

.SUBCKT sky130_sram_1rw_24x128_dff_buf_array
+ din_0 din_1 dout_0 dout_bar_0 dout_1 dout_bar_1 clk vdd gnd
* INPUT : din_0 
* INPUT : din_1 
* OUTPUT: dout_0 
* OUTPUT: dout_bar_0 
* OUTPUT: dout_1 
* OUTPUT: dout_bar_1 
* INPUT : clk 
* POWER : vdd 
* GROUND: gnd 
* rows: 2 cols: 1
* inv1: 2 inv2: 4
Xdff_r0_c0
+ din_0 dout_0 dout_bar_0 clk vdd gnd
+ sky130_sram_1rw_24x128_dff_buf_0
Xdff_r1_c0
+ din_1 dout_1 dout_bar_1 clk vdd gnd
+ sky130_sram_1rw_24x128_dff_buf_0
.ENDS sky130_sram_1rw_24x128_dff_buf_array

.SUBCKT sky130_sram_1rw_24x128_pnand2_1
+ A B Z vdd gnd
* INPUT : A 
* INPUT : B 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpnand2_pmos1 vdd A Z vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpnand2_pmos2 Z B vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpnand2_nmos1 Z B net1 gnd sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
Xpnand2_nmos2 net1 A gnd gnd sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
.ENDS sky130_sram_1rw_24x128_pnand2_1

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=3 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=3 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

.SUBCKT sky130_sram_1rw_24x128_pinv_11
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 5
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=3 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=3 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
.ENDS sky130_sram_1rw_24x128_pinv_11

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=1 w=0.36 l=0.15 pd=1.02 ps=1.02 as=0.14u ad=0.14u

.SUBCKT sky130_sram_1rw_24x128_pinv_0
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=1 w=0.36 l=0.15 pd=1.02 ps=1.02 as=0.14u ad=0.14u
.ENDS sky130_sram_1rw_24x128_pinv_0

.SUBCKT sky130_sram_1rw_24x128_pdriver_3
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* sizes: [1, 5]
Xbuf_inv1
+ A Zb1_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_0
Xbuf_inv2
+ Zb1_int Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_11
.ENDS sky130_sram_1rw_24x128_pdriver_3

.SUBCKT sky130_sram_1rw_24x128_pnand2_0
+ A B Z vdd gnd
* INPUT : A 
* INPUT : B 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpnand2_pmos1 vdd A Z vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpnand2_pmos2 Z B vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpnand2_nmos1 Z B net1 gnd sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
Xpnand2_nmos2 net1 A gnd gnd sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
.ENDS sky130_sram_1rw_24x128_pnand2_0

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=7 w=1.68 l=0.15 pd=3.66 ps=3.66 as=0.63u ad=0.63u

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=7 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

.SUBCKT sky130_sram_1rw_24x128_pinv_4
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 12
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=7 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=7 w=1.68 l=0.15 pd=3.66 ps=3.66 as=0.63u ad=0.63u
.ENDS sky130_sram_1rw_24x128_pinv_4

.SUBCKT sky130_sram_1rw_24x128_pdriver_1
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* sizes: [12]
Xbuf_inv1
+ A Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_4
.ENDS sky130_sram_1rw_24x128_pdriver_1

.SUBCKT sky130_sram_1rw_24x128_pand2_0
+ A B Z vdd gnd
* INPUT : A 
* INPUT : B 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 12
Xpand2_nand
+ A B zb_int vdd gnd
+ sky130_sram_1rw_24x128_pnand2_0
Xpand2_inv
+ zb_int Z vdd gnd
+ sky130_sram_1rw_24x128_pdriver_1
.ENDS sky130_sram_1rw_24x128_pand2_0

.SUBCKT sky130_sram_1rw_24x128_pinv_1
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=1 w=0.36 l=0.15 pd=1.02 ps=1.02 as=0.14u ad=0.14u
.ENDS sky130_sram_1rw_24x128_pinv_1

.SUBCKT sky130_sram_1rw_24x128_pinv_15
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=1 w=0.36 l=0.15 pd=1.02 ps=1.02 as=0.14u ad=0.14u
.ENDS sky130_sram_1rw_24x128_pinv_15

.SUBCKT sky130_sram_1rw_24x128_delay_chain
+ in out vdd gnd
* INPUT : in 
* OUTPUT: out 
* POWER : vdd 
* GROUND: gnd 
* fanouts: [4, 4, 4, 4, 4, 4, 4, 4, 4]
Xdinv0
+ in dout_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_0_0
+ dout_1 n_0_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_0_1
+ dout_1 n_0_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_0_2
+ dout_1 n_0_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_0_3
+ dout_1 n_0_3 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdinv1
+ dout_1 dout_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_1_0
+ dout_2 n_1_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_1_1
+ dout_2 n_1_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_1_2
+ dout_2 n_1_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_1_3
+ dout_2 n_1_3 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdinv2
+ dout_2 dout_3 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_2_0
+ dout_3 n_2_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_2_1
+ dout_3 n_2_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_2_2
+ dout_3 n_2_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_2_3
+ dout_3 n_2_3 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdinv3
+ dout_3 dout_4 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_3_0
+ dout_4 n_3_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_3_1
+ dout_4 n_3_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_3_2
+ dout_4 n_3_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_3_3
+ dout_4 n_3_3 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdinv4
+ dout_4 dout_5 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_4_0
+ dout_5 n_4_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_4_1
+ dout_5 n_4_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_4_2
+ dout_5 n_4_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_4_3
+ dout_5 n_4_3 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdinv5
+ dout_5 dout_6 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_5_0
+ dout_6 n_5_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_5_1
+ dout_6 n_5_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_5_2
+ dout_6 n_5_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_5_3
+ dout_6 n_5_3 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdinv6
+ dout_6 dout_7 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_6_0
+ dout_7 n_6_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_6_1
+ dout_7 n_6_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_6_2
+ dout_7 n_6_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_6_3
+ dout_7 n_6_3 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdinv7
+ dout_7 dout_8 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_7_0
+ dout_8 n_7_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_7_1
+ dout_8 n_7_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_7_2
+ dout_8 n_7_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_7_3
+ dout_8 n_7_3 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdinv8
+ dout_8 out vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_8_0
+ out n_8_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_8_1
+ out n_8_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_8_2
+ out n_8_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
Xdload_8_3
+ out n_8_3 vdd gnd
+ sky130_sram_1rw_24x128_pinv_15
.ENDS sky130_sram_1rw_24x128_delay_chain

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=18 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=18 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

.SUBCKT sky130_sram_1rw_24x128_pinv_12
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 32
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=18 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=18 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
.ENDS sky130_sram_1rw_24x128_pinv_12

.SUBCKT sky130_sram_1rw_24x128_pdriver_4
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* sizes: [32]
Xbuf_inv1
+ A Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_12
.ENDS sky130_sram_1rw_24x128_pdriver_4

.SUBCKT sky130_sram_1rw_24x128_pand3_0
+ A B C Z vdd gnd
* INPUT : A 
* INPUT : B 
* INPUT : C 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 32
Xpand3_nand
+ A B C zb_int vdd gnd
+ sky130_sram_1rw_24x128_pnand3
Xpand3_inv
+ zb_int Z vdd gnd
+ sky130_sram_1rw_24x128_pdriver_4
.ENDS sky130_sram_1rw_24x128_pand3_0

.SUBCKT sky130_sram_1rw_24x128_pinv_7
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 2
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=2 w=1.26 l=0.15 pd=2.82 ps=2.82 as=0.47u ad=0.47u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=2 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
.ENDS sky130_sram_1rw_24x128_pinv_7

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=4 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=4 w=1.26 l=0.15 pd=2.82 ps=2.82 as=0.47u ad=0.47u

.SUBCKT sky130_sram_1rw_24x128_pinv_8
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 7
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=4 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=4 w=1.26 l=0.15 pd=2.82 ps=2.82 as=0.47u ad=0.47u
.ENDS sky130_sram_1rw_24x128_pinv_8

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=35 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=35 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

.SUBCKT sky130_sram_1rw_24x128_pinv_14
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 64
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=35 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=35 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
.ENDS sky130_sram_1rw_24x128_pinv_14

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=12 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=12 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u

.SUBCKT sky130_sram_1rw_24x128_pinv_9
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 21
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=12 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=12 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
.ENDS sky130_sram_1rw_24x128_pinv_9

.SUBCKT sky130_sram_1rw_24x128_pdriver_6
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* sizes: [1, 1, 2, 7, 21, 64]
Xbuf_inv1
+ A Zb1_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_0
Xbuf_inv2
+ Zb1_int Zb2_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_0
Xbuf_inv3
+ Zb2_int Zb3_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_7
Xbuf_inv4
+ Zb3_int Zb4_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_8
Xbuf_inv5
+ Zb4_int Zb5_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_9
Xbuf_inv6
+ Zb5_int Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_14
.ENDS sky130_sram_1rw_24x128_pdriver_6

.SUBCKT sky130_sram_1rw_24x128_pinv_10
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 63
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=35 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=35 w=2.0 l=0.15 pd=4.30 ps=4.30 as=0.75u ad=0.75u
.ENDS sky130_sram_1rw_24x128_pinv_10

.SUBCKT sky130_sram_1rw_24x128_pdriver_2
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* sizes: [1, 1, 2, 7, 21, 63]
Xbuf_inv1
+ A Zb1_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_0
Xbuf_inv2
+ Zb1_int Zb2_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_0
Xbuf_inv3
+ Zb2_int Zb3_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_7
Xbuf_inv4
+ Zb3_int Zb4_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_8
Xbuf_inv5
+ Zb4_int Zb5_int vdd gnd
+ sky130_sram_1rw_24x128_pinv_9
Xbuf_inv6
+ Zb5_int Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_10
.ENDS sky130_sram_1rw_24x128_pdriver_2

.SUBCKT sky130_sram_1rw_24x128_control_logic_rw
+ csb web clk rbl_bl s_en w_en p_en_bar wl_en clk_buf vdd gnd
* INPUT : csb 
* INPUT : web 
* INPUT : clk 
* INPUT : rbl_bl 
* OUTPUT: s_en 
* OUTPUT: w_en 
* OUTPUT: p_en_bar 
* OUTPUT: wl_en 
* OUTPUT: clk_buf 
* POWER : vdd 
* GROUND: gnd 
* num_rows: 17
* words_per_row: 8
* word_size 24
Xctrl_dffs
+ csb web cs_bar cs we_bar we clk_buf vdd gnd
+ sky130_sram_1rw_24x128_dff_buf_array
Xclkbuf
+ clk clk_buf vdd gnd
+ sky130_sram_1rw_24x128_pdriver_2
Xinv_clk_bar
+ clk_buf clk_bar vdd gnd
+ sky130_sram_1rw_24x128_pinv_1
Xand2_gated_clk_bar
+ clk_bar cs gated_clk_bar vdd gnd
+ sky130_sram_1rw_24x128_pand2_0
Xand2_gated_clk_buf
+ clk_buf cs gated_clk_buf vdd gnd
+ sky130_sram_1rw_24x128_pand2_0
Xbuf_wl_en
+ gated_clk_bar wl_en vdd gnd
+ sky130_sram_1rw_24x128_pdriver_3
Xrbl_bl_delay_inv
+ rbl_bl_delay rbl_bl_delay_bar vdd gnd
+ sky130_sram_1rw_24x128_pinv_1
Xw_en_and
+ we rbl_bl_delay_bar gated_clk_bar w_en vdd gnd
+ sky130_sram_1rw_24x128_pand3_0
Xbuf_s_en_and
+ rbl_bl_delay gated_clk_bar we_bar s_en vdd gnd
+ sky130_sram_1rw_24x128_pand3_1
Xdelay_chain
+ rbl_bl rbl_bl_delay vdd gnd
+ sky130_sram_1rw_24x128_delay_chain
Xnand_p_en_bar
+ gated_clk_buf rbl_bl_delay p_en_bar_unbuf vdd gnd
+ sky130_sram_1rw_24x128_pnand2_1
Xbuf_p_en_bar
+ p_en_bar_unbuf p_en_bar vdd gnd
+ sky130_sram_1rw_24x128_pdriver_6
.ENDS sky130_sram_1rw_24x128_control_logic_rw

.SUBCKT sky130_sram_1rw_24x128_pdriver_0
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* sizes: [1]
Xbuf_inv1
+ A Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_0
.ENDS sky130_sram_1rw_24x128_pdriver_0

.SUBCKT sky130_sram_1rw_24x128_pand3
+ A B C Z vdd gnd
* INPUT : A 
* INPUT : B 
* INPUT : C 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpand3_nand
+ A B C zb_int vdd gnd
+ sky130_sram_1rw_24x128_pnand3
Xpand3_inv
+ zb_int Z vdd gnd
+ sky130_sram_1rw_24x128_pdriver_0
.ENDS sky130_sram_1rw_24x128_pand3

.SUBCKT sky130_sram_1rw_24x128_hierarchical_predecode3x8_0
+ in_0 in_1 in_2 out_0 out_1 out_2 out_3 out_4 out_5 out_6 out_7 vdd gnd
* INPUT : in_0 
* INPUT : in_1 
* INPUT : in_2 
* OUTPUT: out_0 
* OUTPUT: out_1 
* OUTPUT: out_2 
* OUTPUT: out_3 
* OUTPUT: out_4 
* OUTPUT: out_5 
* OUTPUT: out_6 
* OUTPUT: out_7 
* POWER : vdd 
* GROUND: gnd 
Xpre_inv_0
+ in_0 inbar_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_1
Xpre_inv_1
+ in_1 inbar_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_1
Xpre_inv_2
+ in_2 inbar_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_1
XXpre3x8_and_0
+ inbar_0 inbar_1 inbar_2 out_0 vdd gnd
+ sky130_sram_1rw_24x128_pand3
XXpre3x8_and_1
+ in_0 inbar_1 inbar_2 out_1 vdd gnd
+ sky130_sram_1rw_24x128_pand3
XXpre3x8_and_2
+ inbar_0 in_1 inbar_2 out_2 vdd gnd
+ sky130_sram_1rw_24x128_pand3
XXpre3x8_and_3
+ in_0 in_1 inbar_2 out_3 vdd gnd
+ sky130_sram_1rw_24x128_pand3
XXpre3x8_and_4
+ inbar_0 inbar_1 in_2 out_4 vdd gnd
+ sky130_sram_1rw_24x128_pand3
XXpre3x8_and_5
+ in_0 inbar_1 in_2 out_5 vdd gnd
+ sky130_sram_1rw_24x128_pand3
XXpre3x8_and_6
+ inbar_0 in_1 in_2 out_6 vdd gnd
+ sky130_sram_1rw_24x128_pand3
XXpre3x8_and_7
+ in_0 in_1 in_2 out_7 vdd gnd
+ sky130_sram_1rw_24x128_pand3
.ENDS sky130_sram_1rw_24x128_hierarchical_predecode3x8_0

.SUBCKT sky130_sram_1rw_24x128_column_decoder
+ in_0 in_1 in_2 out_0 out_1 out_2 out_3 out_4 out_5 out_6 out_7 vdd gnd
* INPUT : in_0 
* INPUT : in_1 
* INPUT : in_2 
* OUTPUT: out_0 
* OUTPUT: out_1 
* OUTPUT: out_2 
* OUTPUT: out_3 
* OUTPUT: out_4 
* OUTPUT: out_5 
* OUTPUT: out_6 
* OUTPUT: out_7 
* POWER : vdd 
* GROUND: gnd 
Xcolumn_decoder
+ in_0 in_1 in_2 out_0 out_1 out_2 out_3 out_4 out_5 out_6 out_7 vdd gnd
+ sky130_sram_1rw_24x128_hierarchical_predecode3x8_0
.ENDS sky130_sram_1rw_24x128_column_decoder
* Copyright 2020 The SkyWater PDK Authors
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     https://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*
* SPDX-License-Identifier: Apache-2.0

*********************** "sky130_fd_bd_sram__openram_sense_amp" ******************************

.SUBCKT sky130_fd_bd_sram__openram_sense_amp BL BR DOUT EN VDD GND
X1000 GND EN a_56_432# GND sky130_fd_pr__nfet_01v8 W=0.65 L=0.15
X1001 a_56_432# dint_bar dint GND sky130_fd_pr__nfet_01v8 W=0.65 L=0.15
X1002 dint_bar dint a_56_432# GND sky130_fd_pr__nfet_01v8 W=0.65 L=0.15

X1003 VDD dint_bar dint VDD sky130_fd_pr__pfet_01v8 W=1.26 L=0.15
X1004 dint_bar dint VDD VDD sky130_fd_pr__pfet_01v8 W=1.26 L=0.15

X1005 BL EN dint VDD sky130_fd_pr__pfet_01v8 W=2 L=0.15
X1006 dint_bar EN BR VDD sky130_fd_pr__pfet_01v8 W=2 L=0.15

X1007 VDD dint_bar DOUT VDD sky130_fd_pr__pfet_01v8 W=1.26 L=0.15
X1008 DOUT dint_bar GND GND sky130_fd_pr__nfet_01v8 W=0.65 L=0.15

.ENDS sky130_fd_bd_sram__openram_sense_amp

.SUBCKT sky130_sram_1rw_24x128_sense_amp_array
+ data_0 bl_0 br_0 data_1 bl_1 br_1 data_2 bl_2 br_2 data_3 bl_3 br_3
+ data_4 bl_4 br_4 data_5 bl_5 br_5 data_6 bl_6 br_6 data_7 bl_7 br_7
+ data_8 bl_8 br_8 data_9 bl_9 br_9 data_10 bl_10 br_10 data_11 bl_11
+ br_11 data_12 bl_12 br_12 data_13 bl_13 br_13 data_14 bl_14 br_14
+ data_15 bl_15 br_15 data_16 bl_16 br_16 data_17 bl_17 br_17 data_18
+ bl_18 br_18 data_19 bl_19 br_19 data_20 bl_20 br_20 data_21 bl_21
+ br_21 data_22 bl_22 br_22 data_23 bl_23 br_23 data_24 bl_24 br_24 en
+ vdd gnd
* OUTPUT: data_0 
* INPUT : bl_0 
* INPUT : br_0 
* OUTPUT: data_1 
* INPUT : bl_1 
* INPUT : br_1 
* OUTPUT: data_2 
* INPUT : bl_2 
* INPUT : br_2 
* OUTPUT: data_3 
* INPUT : bl_3 
* INPUT : br_3 
* OUTPUT: data_4 
* INPUT : bl_4 
* INPUT : br_4 
* OUTPUT: data_5 
* INPUT : bl_5 
* INPUT : br_5 
* OUTPUT: data_6 
* INPUT : bl_6 
* INPUT : br_6 
* OUTPUT: data_7 
* INPUT : bl_7 
* INPUT : br_7 
* OUTPUT: data_8 
* INPUT : bl_8 
* INPUT : br_8 
* OUTPUT: data_9 
* INPUT : bl_9 
* INPUT : br_9 
* OUTPUT: data_10 
* INPUT : bl_10 
* INPUT : br_10 
* OUTPUT: data_11 
* INPUT : bl_11 
* INPUT : br_11 
* OUTPUT: data_12 
* INPUT : bl_12 
* INPUT : br_12 
* OUTPUT: data_13 
* INPUT : bl_13 
* INPUT : br_13 
* OUTPUT: data_14 
* INPUT : bl_14 
* INPUT : br_14 
* OUTPUT: data_15 
* INPUT : bl_15 
* INPUT : br_15 
* OUTPUT: data_16 
* INPUT : bl_16 
* INPUT : br_16 
* OUTPUT: data_17 
* INPUT : bl_17 
* INPUT : br_17 
* OUTPUT: data_18 
* INPUT : bl_18 
* INPUT : br_18 
* OUTPUT: data_19 
* INPUT : bl_19 
* INPUT : br_19 
* OUTPUT: data_20 
* INPUT : bl_20 
* INPUT : br_20 
* OUTPUT: data_21 
* INPUT : bl_21 
* INPUT : br_21 
* OUTPUT: data_22 
* INPUT : bl_22 
* INPUT : br_22 
* OUTPUT: data_23 
* INPUT : bl_23 
* INPUT : br_23 
* OUTPUT: data_24 
* INPUT : bl_24 
* INPUT : br_24 
* INPUT : en 
* POWER : vdd 
* GROUND: gnd 
* word_size 24
* words_per_row: 8
Xsa_d0
+ bl_0 br_0 data_0 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d1
+ bl_1 br_1 data_1 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d2
+ bl_2 br_2 data_2 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d3
+ bl_3 br_3 data_3 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d4
+ bl_4 br_4 data_4 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d5
+ bl_5 br_5 data_5 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d6
+ bl_6 br_6 data_6 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d7
+ bl_7 br_7 data_7 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d8
+ bl_8 br_8 data_8 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d9
+ bl_9 br_9 data_9 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d10
+ bl_10 br_10 data_10 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d11
+ bl_11 br_11 data_11 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d12
+ bl_12 br_12 data_12 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d13
+ bl_13 br_13 data_13 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d14
+ bl_14 br_14 data_14 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d15
+ bl_15 br_15 data_15 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d16
+ bl_16 br_16 data_16 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d17
+ bl_17 br_17 data_17 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d18
+ bl_18 br_18 data_18 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d19
+ bl_19 br_19 data_19 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d20
+ bl_20 br_20 data_20 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d21
+ bl_21 br_21 data_21 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d22
+ bl_22 br_22 data_22 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d23
+ bl_23 br_23 data_23 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
Xsa_d24
+ bl_24 br_24 data_24 en vdd gnd
+ sky130_fd_bd_sram__openram_sense_amp
.ENDS sky130_sram_1rw_24x128_sense_amp_array
* Copyright 2020 The SkyWater PDK Authors
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     https://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*
* SPDX-License-Identifier: Apache-2.0

*********************** "sky130_fd_bd_sram__openram_write_driver" ******************************

.SUBCKT sky130_fd_bd_sram__openram_write_driver DIN BL BR EN VDD GND

**** Inverter to conver Data_in to data_in_bar ******
* din_bar = inv(DIN)
X_1 din_bar DIN GND GND sky130_fd_pr__nfet_01v8 W=0.36 L=0.15
X_2 din_bar DIN VDD VDD sky130_fd_pr__pfet_01v8 W=0.55 L=0.15

**** 2input nand gate follwed by inverter to drive BL ******
* din_bar_gated = nand(EN, DIN)
X_3 din_bar_gated EN net_7 GND sky130_fd_pr__nfet_01v8 W=0.55 L=0.15
X_4 net_7 DIN GND GND sky130_fd_pr__nfet_01v8 W=0.55 L=0.15
X_5 din_bar_gated EN VDD VDD sky130_fd_pr__pfet_01v8 W=0.55 L=0.15
X_6 din_bar_gated DIN VDD VDD sky130_fd_pr__pfet_01v8 W=0.55 L=0.15
* din_bar_gated_bar = inv(din_bar_gated)
X_7 din_bar_gated_bar din_bar_gated VDD VDD sky130_fd_pr__pfet_01v8 W=0.55 L=0.15
X_8 din_bar_gated_bar din_bar_gated GND GND sky130_fd_pr__nfet_01v8 W=0.36 L=0.15

**** 2input nand gate follwed by inverter to drive BR******
* din_gated = nand(EN, din_bar)
X_9 din_gated EN VDD VDD sky130_fd_pr__pfet_01v8 W=0.55 L=0.15
X_10 din_gated EN net_8 GND sky130_fd_pr__nfet_01v8 W=0.55 L=0.15
X_11 net_8 din_bar GND GND sky130_fd_pr__nfet_01v8 W=0.55 L=0.15
X_12 din_gated din_bar VDD VDD sky130_fd_pr__pfet_01v8 W=0.55 L=0.15
* din_gated_bar = inv(din_gated)
X_13 din_gated_bar din_gated VDD VDD sky130_fd_pr__pfet_01v8 W=0.55 L=0.15
X_14 din_gated_bar din_gated GND GND sky130_fd_pr__nfet_01v8 W=0.36 L=0.15

************************************************
* pull down with EN enable
X_15 BL din_gated_bar GND GND sky130_fd_pr__nfet_01v8 W=1 L=0.15
X_16 BR din_bar_gated_bar GND GND sky130_fd_pr__nfet_01v8 W=1 L=0.15

.ENDS sky130_fd_bd_sram__openram_write_driver

.SUBCKT sky130_sram_1rw_24x128_write_driver_array
+ data_0 data_1 data_2 data_3 data_4 data_5 data_6 data_7 data_8 data_9
+ data_10 data_11 data_12 data_13 data_14 data_15 data_16 data_17
+ data_18 data_19 data_20 data_21 data_22 data_23 data_24 bl_0 br_0 bl_1
+ br_1 bl_2 br_2 bl_3 br_3 bl_4 br_4 bl_5 br_5 bl_6 br_6 bl_7 br_7 bl_8
+ br_8 bl_9 br_9 bl_10 br_10 bl_11 br_11 bl_12 br_12 bl_13 br_13 bl_14
+ br_14 bl_15 br_15 bl_16 br_16 bl_17 br_17 bl_18 br_18 bl_19 br_19
+ bl_20 br_20 bl_21 br_21 bl_22 br_22 bl_23 br_23 bl_24 br_24 en_0 en_1
+ en_2 en_3 vdd gnd
* INPUT : data_0 
* INPUT : data_1 
* INPUT : data_2 
* INPUT : data_3 
* INPUT : data_4 
* INPUT : data_5 
* INPUT : data_6 
* INPUT : data_7 
* INPUT : data_8 
* INPUT : data_9 
* INPUT : data_10 
* INPUT : data_11 
* INPUT : data_12 
* INPUT : data_13 
* INPUT : data_14 
* INPUT : data_15 
* INPUT : data_16 
* INPUT : data_17 
* INPUT : data_18 
* INPUT : data_19 
* INPUT : data_20 
* INPUT : data_21 
* INPUT : data_22 
* INPUT : data_23 
* INPUT : data_24 
* OUTPUT: bl_0 
* OUTPUT: br_0 
* OUTPUT: bl_1 
* OUTPUT: br_1 
* OUTPUT: bl_2 
* OUTPUT: br_2 
* OUTPUT: bl_3 
* OUTPUT: br_3 
* OUTPUT: bl_4 
* OUTPUT: br_4 
* OUTPUT: bl_5 
* OUTPUT: br_5 
* OUTPUT: bl_6 
* OUTPUT: br_6 
* OUTPUT: bl_7 
* OUTPUT: br_7 
* OUTPUT: bl_8 
* OUTPUT: br_8 
* OUTPUT: bl_9 
* OUTPUT: br_9 
* OUTPUT: bl_10 
* OUTPUT: br_10 
* OUTPUT: bl_11 
* OUTPUT: br_11 
* OUTPUT: bl_12 
* OUTPUT: br_12 
* OUTPUT: bl_13 
* OUTPUT: br_13 
* OUTPUT: bl_14 
* OUTPUT: br_14 
* OUTPUT: bl_15 
* OUTPUT: br_15 
* OUTPUT: bl_16 
* OUTPUT: br_16 
* OUTPUT: bl_17 
* OUTPUT: br_17 
* OUTPUT: bl_18 
* OUTPUT: br_18 
* OUTPUT: bl_19 
* OUTPUT: br_19 
* OUTPUT: bl_20 
* OUTPUT: br_20 
* OUTPUT: bl_21 
* OUTPUT: br_21 
* OUTPUT: bl_22 
* OUTPUT: br_22 
* OUTPUT: bl_23 
* OUTPUT: br_23 
* OUTPUT: bl_24 
* OUTPUT: br_24 
* INPUT : en_0 
* INPUT : en_1 
* INPUT : en_2 
* INPUT : en_3 
* POWER : vdd 
* GROUND: gnd 
* columns: 192
* word_size 24
Xwrite_driver0
+ data_0 bl_0 br_0 en_0 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver8
+ data_1 bl_1 br_1 en_0 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver16
+ data_2 bl_2 br_2 en_0 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver24
+ data_3 bl_3 br_3 en_0 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver32
+ data_4 bl_4 br_4 en_0 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver40
+ data_5 bl_5 br_5 en_0 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver48
+ data_6 bl_6 br_6 en_0 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver56
+ data_7 bl_7 br_7 en_0 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver64
+ data_8 bl_8 br_8 en_1 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver72
+ data_9 bl_9 br_9 en_1 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver80
+ data_10 bl_10 br_10 en_1 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver88
+ data_11 bl_11 br_11 en_1 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver96
+ data_12 bl_12 br_12 en_1 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver104
+ data_13 bl_13 br_13 en_1 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver112
+ data_14 bl_14 br_14 en_1 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver120
+ data_15 bl_15 br_15 en_1 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver128
+ data_16 bl_16 br_16 en_2 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver136
+ data_17 bl_17 br_17 en_2 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver144
+ data_18 bl_18 br_18 en_2 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver152
+ data_19 bl_19 br_19 en_2 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver160
+ data_20 bl_20 br_20 en_2 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver168
+ data_21 bl_21 br_21 en_2 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver176
+ data_22 bl_22 br_22 en_2 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver184
+ data_23 bl_23 br_23 en_2 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
Xwrite_driver192
+ data_24 bl_24 br_24 en_3 vdd gnd
+ sky130_fd_bd_sram__openram_write_driver
.ENDS sky130_sram_1rw_24x128_write_driver_array

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=1 w=0.55 l=0.15 pd=1.40 ps=1.40 as=0.21u ad=0.21u

.SUBCKT sky130_sram_1rw_24x128_precharge_0
+ bl br en_bar vdd
* OUTPUT: bl 
* OUTPUT: br 
* INPUT : en_bar 
* POWER : vdd 
Xlower_pmos bl en_bar br vdd sky130_fd_pr__pfet_01v8 m=1 w=0.55 l=0.15 pd=1.40 ps=1.40 as=0.21u ad=0.21u
Xupper_pmos1 bl en_bar vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=0.55 l=0.15 pd=1.40 ps=1.40 as=0.21u ad=0.21u
Xupper_pmos2 br en_bar vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=0.55 l=0.15 pd=1.40 ps=1.40 as=0.21u ad=0.21u
.ENDS sky130_sram_1rw_24x128_precharge_0

.SUBCKT sky130_sram_1rw_24x128_precharge_array
+ bl_0 br_0 bl_1 br_1 bl_2 br_2 bl_3 br_3 bl_4 br_4 bl_5 br_5 bl_6 br_6
+ bl_7 br_7 bl_8 br_8 bl_9 br_9 bl_10 br_10 bl_11 br_11 bl_12 br_12
+ bl_13 br_13 bl_14 br_14 bl_15 br_15 bl_16 br_16 bl_17 br_17 bl_18
+ br_18 bl_19 br_19 bl_20 br_20 bl_21 br_21 bl_22 br_22 bl_23 br_23
+ bl_24 br_24 bl_25 br_25 bl_26 br_26 bl_27 br_27 bl_28 br_28 bl_29
+ br_29 bl_30 br_30 bl_31 br_31 bl_32 br_32 bl_33 br_33 bl_34 br_34
+ bl_35 br_35 bl_36 br_36 bl_37 br_37 bl_38 br_38 bl_39 br_39 bl_40
+ br_40 bl_41 br_41 bl_42 br_42 bl_43 br_43 bl_44 br_44 bl_45 br_45
+ bl_46 br_46 bl_47 br_47 bl_48 br_48 bl_49 br_49 bl_50 br_50 bl_51
+ br_51 bl_52 br_52 bl_53 br_53 bl_54 br_54 bl_55 br_55 bl_56 br_56
+ bl_57 br_57 bl_58 br_58 bl_59 br_59 bl_60 br_60 bl_61 br_61 bl_62
+ br_62 bl_63 br_63 bl_64 br_64 bl_65 br_65 bl_66 br_66 bl_67 br_67
+ bl_68 br_68 bl_69 br_69 bl_70 br_70 bl_71 br_71 bl_72 br_72 bl_73
+ br_73 bl_74 br_74 bl_75 br_75 bl_76 br_76 bl_77 br_77 bl_78 br_78
+ bl_79 br_79 bl_80 br_80 bl_81 br_81 bl_82 br_82 bl_83 br_83 bl_84
+ br_84 bl_85 br_85 bl_86 br_86 bl_87 br_87 bl_88 br_88 bl_89 br_89
+ bl_90 br_90 bl_91 br_91 bl_92 br_92 bl_93 br_93 bl_94 br_94 bl_95
+ br_95 bl_96 br_96 bl_97 br_97 bl_98 br_98 bl_99 br_99 bl_100 br_100
+ bl_101 br_101 bl_102 br_102 bl_103 br_103 bl_104 br_104 bl_105 br_105
+ bl_106 br_106 bl_107 br_107 bl_108 br_108 bl_109 br_109 bl_110 br_110
+ bl_111 br_111 bl_112 br_112 bl_113 br_113 bl_114 br_114 bl_115 br_115
+ bl_116 br_116 bl_117 br_117 bl_118 br_118 bl_119 br_119 bl_120 br_120
+ bl_121 br_121 bl_122 br_122 bl_123 br_123 bl_124 br_124 bl_125 br_125
+ bl_126 br_126 bl_127 br_127 bl_128 br_128 bl_129 br_129 bl_130 br_130
+ bl_131 br_131 bl_132 br_132 bl_133 br_133 bl_134 br_134 bl_135 br_135
+ bl_136 br_136 bl_137 br_137 bl_138 br_138 bl_139 br_139 bl_140 br_140
+ bl_141 br_141 bl_142 br_142 bl_143 br_143 bl_144 br_144 bl_145 br_145
+ bl_146 br_146 bl_147 br_147 bl_148 br_148 bl_149 br_149 bl_150 br_150
+ bl_151 br_151 bl_152 br_152 bl_153 br_153 bl_154 br_154 bl_155 br_155
+ bl_156 br_156 bl_157 br_157 bl_158 br_158 bl_159 br_159 bl_160 br_160
+ bl_161 br_161 bl_162 br_162 bl_163 br_163 bl_164 br_164 bl_165 br_165
+ bl_166 br_166 bl_167 br_167 bl_168 br_168 bl_169 br_169 bl_170 br_170
+ bl_171 br_171 bl_172 br_172 bl_173 br_173 bl_174 br_174 bl_175 br_175
+ bl_176 br_176 bl_177 br_177 bl_178 br_178 bl_179 br_179 bl_180 br_180
+ bl_181 br_181 bl_182 br_182 bl_183 br_183 bl_184 br_184 bl_185 br_185
+ bl_186 br_186 bl_187 br_187 bl_188 br_188 bl_189 br_189 bl_190 br_190
+ bl_191 br_191 bl_192 br_192 bl_193 br_193 en_bar vdd
* OUTPUT: bl_0 
* OUTPUT: br_0 
* OUTPUT: bl_1 
* OUTPUT: br_1 
* OUTPUT: bl_2 
* OUTPUT: br_2 
* OUTPUT: bl_3 
* OUTPUT: br_3 
* OUTPUT: bl_4 
* OUTPUT: br_4 
* OUTPUT: bl_5 
* OUTPUT: br_5 
* OUTPUT: bl_6 
* OUTPUT: br_6 
* OUTPUT: bl_7 
* OUTPUT: br_7 
* OUTPUT: bl_8 
* OUTPUT: br_8 
* OUTPUT: bl_9 
* OUTPUT: br_9 
* OUTPUT: bl_10 
* OUTPUT: br_10 
* OUTPUT: bl_11 
* OUTPUT: br_11 
* OUTPUT: bl_12 
* OUTPUT: br_12 
* OUTPUT: bl_13 
* OUTPUT: br_13 
* OUTPUT: bl_14 
* OUTPUT: br_14 
* OUTPUT: bl_15 
* OUTPUT: br_15 
* OUTPUT: bl_16 
* OUTPUT: br_16 
* OUTPUT: bl_17 
* OUTPUT: br_17 
* OUTPUT: bl_18 
* OUTPUT: br_18 
* OUTPUT: bl_19 
* OUTPUT: br_19 
* OUTPUT: bl_20 
* OUTPUT: br_20 
* OUTPUT: bl_21 
* OUTPUT: br_21 
* OUTPUT: bl_22 
* OUTPUT: br_22 
* OUTPUT: bl_23 
* OUTPUT: br_23 
* OUTPUT: bl_24 
* OUTPUT: br_24 
* OUTPUT: bl_25 
* OUTPUT: br_25 
* OUTPUT: bl_26 
* OUTPUT: br_26 
* OUTPUT: bl_27 
* OUTPUT: br_27 
* OUTPUT: bl_28 
* OUTPUT: br_28 
* OUTPUT: bl_29 
* OUTPUT: br_29 
* OUTPUT: bl_30 
* OUTPUT: br_30 
* OUTPUT: bl_31 
* OUTPUT: br_31 
* OUTPUT: bl_32 
* OUTPUT: br_32 
* OUTPUT: bl_33 
* OUTPUT: br_33 
* OUTPUT: bl_34 
* OUTPUT: br_34 
* OUTPUT: bl_35 
* OUTPUT: br_35 
* OUTPUT: bl_36 
* OUTPUT: br_36 
* OUTPUT: bl_37 
* OUTPUT: br_37 
* OUTPUT: bl_38 
* OUTPUT: br_38 
* OUTPUT: bl_39 
* OUTPUT: br_39 
* OUTPUT: bl_40 
* OUTPUT: br_40 
* OUTPUT: bl_41 
* OUTPUT: br_41 
* OUTPUT: bl_42 
* OUTPUT: br_42 
* OUTPUT: bl_43 
* OUTPUT: br_43 
* OUTPUT: bl_44 
* OUTPUT: br_44 
* OUTPUT: bl_45 
* OUTPUT: br_45 
* OUTPUT: bl_46 
* OUTPUT: br_46 
* OUTPUT: bl_47 
* OUTPUT: br_47 
* OUTPUT: bl_48 
* OUTPUT: br_48 
* OUTPUT: bl_49 
* OUTPUT: br_49 
* OUTPUT: bl_50 
* OUTPUT: br_50 
* OUTPUT: bl_51 
* OUTPUT: br_51 
* OUTPUT: bl_52 
* OUTPUT: br_52 
* OUTPUT: bl_53 
* OUTPUT: br_53 
* OUTPUT: bl_54 
* OUTPUT: br_54 
* OUTPUT: bl_55 
* OUTPUT: br_55 
* OUTPUT: bl_56 
* OUTPUT: br_56 
* OUTPUT: bl_57 
* OUTPUT: br_57 
* OUTPUT: bl_58 
* OUTPUT: br_58 
* OUTPUT: bl_59 
* OUTPUT: br_59 
* OUTPUT: bl_60 
* OUTPUT: br_60 
* OUTPUT: bl_61 
* OUTPUT: br_61 
* OUTPUT: bl_62 
* OUTPUT: br_62 
* OUTPUT: bl_63 
* OUTPUT: br_63 
* OUTPUT: bl_64 
* OUTPUT: br_64 
* OUTPUT: bl_65 
* OUTPUT: br_65 
* OUTPUT: bl_66 
* OUTPUT: br_66 
* OUTPUT: bl_67 
* OUTPUT: br_67 
* OUTPUT: bl_68 
* OUTPUT: br_68 
* OUTPUT: bl_69 
* OUTPUT: br_69 
* OUTPUT: bl_70 
* OUTPUT: br_70 
* OUTPUT: bl_71 
* OUTPUT: br_71 
* OUTPUT: bl_72 
* OUTPUT: br_72 
* OUTPUT: bl_73 
* OUTPUT: br_73 
* OUTPUT: bl_74 
* OUTPUT: br_74 
* OUTPUT: bl_75 
* OUTPUT: br_75 
* OUTPUT: bl_76 
* OUTPUT: br_76 
* OUTPUT: bl_77 
* OUTPUT: br_77 
* OUTPUT: bl_78 
* OUTPUT: br_78 
* OUTPUT: bl_79 
* OUTPUT: br_79 
* OUTPUT: bl_80 
* OUTPUT: br_80 
* OUTPUT: bl_81 
* OUTPUT: br_81 
* OUTPUT: bl_82 
* OUTPUT: br_82 
* OUTPUT: bl_83 
* OUTPUT: br_83 
* OUTPUT: bl_84 
* OUTPUT: br_84 
* OUTPUT: bl_85 
* OUTPUT: br_85 
* OUTPUT: bl_86 
* OUTPUT: br_86 
* OUTPUT: bl_87 
* OUTPUT: br_87 
* OUTPUT: bl_88 
* OUTPUT: br_88 
* OUTPUT: bl_89 
* OUTPUT: br_89 
* OUTPUT: bl_90 
* OUTPUT: br_90 
* OUTPUT: bl_91 
* OUTPUT: br_91 
* OUTPUT: bl_92 
* OUTPUT: br_92 
* OUTPUT: bl_93 
* OUTPUT: br_93 
* OUTPUT: bl_94 
* OUTPUT: br_94 
* OUTPUT: bl_95 
* OUTPUT: br_95 
* OUTPUT: bl_96 
* OUTPUT: br_96 
* OUTPUT: bl_97 
* OUTPUT: br_97 
* OUTPUT: bl_98 
* OUTPUT: br_98 
* OUTPUT: bl_99 
* OUTPUT: br_99 
* OUTPUT: bl_100 
* OUTPUT: br_100 
* OUTPUT: bl_101 
* OUTPUT: br_101 
* OUTPUT: bl_102 
* OUTPUT: br_102 
* OUTPUT: bl_103 
* OUTPUT: br_103 
* OUTPUT: bl_104 
* OUTPUT: br_104 
* OUTPUT: bl_105 
* OUTPUT: br_105 
* OUTPUT: bl_106 
* OUTPUT: br_106 
* OUTPUT: bl_107 
* OUTPUT: br_107 
* OUTPUT: bl_108 
* OUTPUT: br_108 
* OUTPUT: bl_109 
* OUTPUT: br_109 
* OUTPUT: bl_110 
* OUTPUT: br_110 
* OUTPUT: bl_111 
* OUTPUT: br_111 
* OUTPUT: bl_112 
* OUTPUT: br_112 
* OUTPUT: bl_113 
* OUTPUT: br_113 
* OUTPUT: bl_114 
* OUTPUT: br_114 
* OUTPUT: bl_115 
* OUTPUT: br_115 
* OUTPUT: bl_116 
* OUTPUT: br_116 
* OUTPUT: bl_117 
* OUTPUT: br_117 
* OUTPUT: bl_118 
* OUTPUT: br_118 
* OUTPUT: bl_119 
* OUTPUT: br_119 
* OUTPUT: bl_120 
* OUTPUT: br_120 
* OUTPUT: bl_121 
* OUTPUT: br_121 
* OUTPUT: bl_122 
* OUTPUT: br_122 
* OUTPUT: bl_123 
* OUTPUT: br_123 
* OUTPUT: bl_124 
* OUTPUT: br_124 
* OUTPUT: bl_125 
* OUTPUT: br_125 
* OUTPUT: bl_126 
* OUTPUT: br_126 
* OUTPUT: bl_127 
* OUTPUT: br_127 
* OUTPUT: bl_128 
* OUTPUT: br_128 
* OUTPUT: bl_129 
* OUTPUT: br_129 
* OUTPUT: bl_130 
* OUTPUT: br_130 
* OUTPUT: bl_131 
* OUTPUT: br_131 
* OUTPUT: bl_132 
* OUTPUT: br_132 
* OUTPUT: bl_133 
* OUTPUT: br_133 
* OUTPUT: bl_134 
* OUTPUT: br_134 
* OUTPUT: bl_135 
* OUTPUT: br_135 
* OUTPUT: bl_136 
* OUTPUT: br_136 
* OUTPUT: bl_137 
* OUTPUT: br_137 
* OUTPUT: bl_138 
* OUTPUT: br_138 
* OUTPUT: bl_139 
* OUTPUT: br_139 
* OUTPUT: bl_140 
* OUTPUT: br_140 
* OUTPUT: bl_141 
* OUTPUT: br_141 
* OUTPUT: bl_142 
* OUTPUT: br_142 
* OUTPUT: bl_143 
* OUTPUT: br_143 
* OUTPUT: bl_144 
* OUTPUT: br_144 
* OUTPUT: bl_145 
* OUTPUT: br_145 
* OUTPUT: bl_146 
* OUTPUT: br_146 
* OUTPUT: bl_147 
* OUTPUT: br_147 
* OUTPUT: bl_148 
* OUTPUT: br_148 
* OUTPUT: bl_149 
* OUTPUT: br_149 
* OUTPUT: bl_150 
* OUTPUT: br_150 
* OUTPUT: bl_151 
* OUTPUT: br_151 
* OUTPUT: bl_152 
* OUTPUT: br_152 
* OUTPUT: bl_153 
* OUTPUT: br_153 
* OUTPUT: bl_154 
* OUTPUT: br_154 
* OUTPUT: bl_155 
* OUTPUT: br_155 
* OUTPUT: bl_156 
* OUTPUT: br_156 
* OUTPUT: bl_157 
* OUTPUT: br_157 
* OUTPUT: bl_158 
* OUTPUT: br_158 
* OUTPUT: bl_159 
* OUTPUT: br_159 
* OUTPUT: bl_160 
* OUTPUT: br_160 
* OUTPUT: bl_161 
* OUTPUT: br_161 
* OUTPUT: bl_162 
* OUTPUT: br_162 
* OUTPUT: bl_163 
* OUTPUT: br_163 
* OUTPUT: bl_164 
* OUTPUT: br_164 
* OUTPUT: bl_165 
* OUTPUT: br_165 
* OUTPUT: bl_166 
* OUTPUT: br_166 
* OUTPUT: bl_167 
* OUTPUT: br_167 
* OUTPUT: bl_168 
* OUTPUT: br_168 
* OUTPUT: bl_169 
* OUTPUT: br_169 
* OUTPUT: bl_170 
* OUTPUT: br_170 
* OUTPUT: bl_171 
* OUTPUT: br_171 
* OUTPUT: bl_172 
* OUTPUT: br_172 
* OUTPUT: bl_173 
* OUTPUT: br_173 
* OUTPUT: bl_174 
* OUTPUT: br_174 
* OUTPUT: bl_175 
* OUTPUT: br_175 
* OUTPUT: bl_176 
* OUTPUT: br_176 
* OUTPUT: bl_177 
* OUTPUT: br_177 
* OUTPUT: bl_178 
* OUTPUT: br_178 
* OUTPUT: bl_179 
* OUTPUT: br_179 
* OUTPUT: bl_180 
* OUTPUT: br_180 
* OUTPUT: bl_181 
* OUTPUT: br_181 
* OUTPUT: bl_182 
* OUTPUT: br_182 
* OUTPUT: bl_183 
* OUTPUT: br_183 
* OUTPUT: bl_184 
* OUTPUT: br_184 
* OUTPUT: bl_185 
* OUTPUT: br_185 
* OUTPUT: bl_186 
* OUTPUT: br_186 
* OUTPUT: bl_187 
* OUTPUT: br_187 
* OUTPUT: bl_188 
* OUTPUT: br_188 
* OUTPUT: bl_189 
* OUTPUT: br_189 
* OUTPUT: bl_190 
* OUTPUT: br_190 
* OUTPUT: bl_191 
* OUTPUT: br_191 
* OUTPUT: bl_192 
* OUTPUT: br_192 
* OUTPUT: bl_193 
* OUTPUT: br_193 
* INPUT : en_bar 
* POWER : vdd 
* cols: 194 size: 1 bl: bl br: br
Xpre_column_0
+ bl_0 br_0 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_1
+ bl_1 br_1 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_2
+ bl_2 br_2 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_3
+ bl_3 br_3 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_4
+ bl_4 br_4 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_5
+ bl_5 br_5 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_6
+ bl_6 br_6 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_7
+ bl_7 br_7 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_8
+ bl_8 br_8 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_9
+ bl_9 br_9 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_10
+ bl_10 br_10 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_11
+ bl_11 br_11 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_12
+ bl_12 br_12 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_13
+ bl_13 br_13 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_14
+ bl_14 br_14 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_15
+ bl_15 br_15 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_16
+ bl_16 br_16 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_17
+ bl_17 br_17 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_18
+ bl_18 br_18 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_19
+ bl_19 br_19 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_20
+ bl_20 br_20 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_21
+ bl_21 br_21 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_22
+ bl_22 br_22 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_23
+ bl_23 br_23 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_24
+ bl_24 br_24 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_25
+ bl_25 br_25 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_26
+ bl_26 br_26 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_27
+ bl_27 br_27 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_28
+ bl_28 br_28 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_29
+ bl_29 br_29 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_30
+ bl_30 br_30 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_31
+ bl_31 br_31 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_32
+ bl_32 br_32 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_33
+ bl_33 br_33 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_34
+ bl_34 br_34 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_35
+ bl_35 br_35 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_36
+ bl_36 br_36 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_37
+ bl_37 br_37 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_38
+ bl_38 br_38 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_39
+ bl_39 br_39 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_40
+ bl_40 br_40 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_41
+ bl_41 br_41 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_42
+ bl_42 br_42 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_43
+ bl_43 br_43 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_44
+ bl_44 br_44 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_45
+ bl_45 br_45 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_46
+ bl_46 br_46 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_47
+ bl_47 br_47 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_48
+ bl_48 br_48 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_49
+ bl_49 br_49 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_50
+ bl_50 br_50 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_51
+ bl_51 br_51 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_52
+ bl_52 br_52 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_53
+ bl_53 br_53 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_54
+ bl_54 br_54 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_55
+ bl_55 br_55 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_56
+ bl_56 br_56 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_57
+ bl_57 br_57 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_58
+ bl_58 br_58 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_59
+ bl_59 br_59 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_60
+ bl_60 br_60 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_61
+ bl_61 br_61 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_62
+ bl_62 br_62 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_63
+ bl_63 br_63 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_64
+ bl_64 br_64 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_65
+ bl_65 br_65 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_66
+ bl_66 br_66 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_67
+ bl_67 br_67 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_68
+ bl_68 br_68 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_69
+ bl_69 br_69 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_70
+ bl_70 br_70 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_71
+ bl_71 br_71 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_72
+ bl_72 br_72 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_73
+ bl_73 br_73 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_74
+ bl_74 br_74 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_75
+ bl_75 br_75 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_76
+ bl_76 br_76 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_77
+ bl_77 br_77 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_78
+ bl_78 br_78 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_79
+ bl_79 br_79 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_80
+ bl_80 br_80 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_81
+ bl_81 br_81 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_82
+ bl_82 br_82 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_83
+ bl_83 br_83 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_84
+ bl_84 br_84 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_85
+ bl_85 br_85 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_86
+ bl_86 br_86 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_87
+ bl_87 br_87 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_88
+ bl_88 br_88 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_89
+ bl_89 br_89 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_90
+ bl_90 br_90 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_91
+ bl_91 br_91 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_92
+ bl_92 br_92 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_93
+ bl_93 br_93 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_94
+ bl_94 br_94 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_95
+ bl_95 br_95 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_96
+ bl_96 br_96 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_97
+ bl_97 br_97 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_98
+ bl_98 br_98 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_99
+ bl_99 br_99 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_100
+ bl_100 br_100 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_101
+ bl_101 br_101 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_102
+ bl_102 br_102 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_103
+ bl_103 br_103 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_104
+ bl_104 br_104 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_105
+ bl_105 br_105 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_106
+ bl_106 br_106 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_107
+ bl_107 br_107 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_108
+ bl_108 br_108 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_109
+ bl_109 br_109 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_110
+ bl_110 br_110 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_111
+ bl_111 br_111 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_112
+ bl_112 br_112 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_113
+ bl_113 br_113 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_114
+ bl_114 br_114 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_115
+ bl_115 br_115 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_116
+ bl_116 br_116 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_117
+ bl_117 br_117 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_118
+ bl_118 br_118 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_119
+ bl_119 br_119 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_120
+ bl_120 br_120 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_121
+ bl_121 br_121 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_122
+ bl_122 br_122 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_123
+ bl_123 br_123 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_124
+ bl_124 br_124 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_125
+ bl_125 br_125 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_126
+ bl_126 br_126 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_127
+ bl_127 br_127 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_128
+ bl_128 br_128 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_129
+ bl_129 br_129 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_130
+ bl_130 br_130 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_131
+ bl_131 br_131 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_132
+ bl_132 br_132 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_133
+ bl_133 br_133 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_134
+ bl_134 br_134 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_135
+ bl_135 br_135 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_136
+ bl_136 br_136 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_137
+ bl_137 br_137 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_138
+ bl_138 br_138 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_139
+ bl_139 br_139 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_140
+ bl_140 br_140 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_141
+ bl_141 br_141 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_142
+ bl_142 br_142 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_143
+ bl_143 br_143 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_144
+ bl_144 br_144 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_145
+ bl_145 br_145 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_146
+ bl_146 br_146 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_147
+ bl_147 br_147 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_148
+ bl_148 br_148 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_149
+ bl_149 br_149 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_150
+ bl_150 br_150 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_151
+ bl_151 br_151 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_152
+ bl_152 br_152 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_153
+ bl_153 br_153 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_154
+ bl_154 br_154 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_155
+ bl_155 br_155 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_156
+ bl_156 br_156 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_157
+ bl_157 br_157 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_158
+ bl_158 br_158 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_159
+ bl_159 br_159 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_160
+ bl_160 br_160 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_161
+ bl_161 br_161 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_162
+ bl_162 br_162 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_163
+ bl_163 br_163 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_164
+ bl_164 br_164 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_165
+ bl_165 br_165 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_166
+ bl_166 br_166 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_167
+ bl_167 br_167 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_168
+ bl_168 br_168 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_169
+ bl_169 br_169 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_170
+ bl_170 br_170 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_171
+ bl_171 br_171 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_172
+ bl_172 br_172 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_173
+ bl_173 br_173 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_174
+ bl_174 br_174 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_175
+ bl_175 br_175 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_176
+ bl_176 br_176 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_177
+ bl_177 br_177 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_178
+ bl_178 br_178 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_179
+ bl_179 br_179 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_180
+ bl_180 br_180 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_181
+ bl_181 br_181 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_182
+ bl_182 br_182 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_183
+ bl_183 br_183 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_184
+ bl_184 br_184 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_185
+ bl_185 br_185 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_186
+ bl_186 br_186 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_187
+ bl_187 br_187 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_188
+ bl_188 br_188 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_189
+ bl_189 br_189 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_190
+ bl_190 br_190 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_191
+ bl_191 br_191 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_192
+ bl_192 br_192 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
Xpre_column_193
+ bl_193 br_193 en_bar vdd
+ sky130_sram_1rw_24x128_precharge_0
.ENDS sky130_sram_1rw_24x128_precharge_array

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=1 w=2.88 l=0.15 pd=6.06 ps=6.06 as=1.08u ad=1.08u

.SUBCKT sky130_sram_1rw_24x128_column_mux
+ bl br bl_out br_out sel gnd
* INOUT : bl 
* INOUT : br 
* INOUT : bl_out 
* INOUT : br_out 
* INOUT : sel 
* INOUT : gnd 
Xmux_tx1 bl sel bl_out gnd sky130_fd_pr__nfet_01v8 m=1 w=2.88 l=0.15 pd=6.06 ps=6.06 as=1.08u ad=1.08u
Xmux_tx2 br sel br_out gnd sky130_fd_pr__nfet_01v8 m=1 w=2.88 l=0.15 pd=6.06 ps=6.06 as=1.08u ad=1.08u
.ENDS sky130_sram_1rw_24x128_column_mux

.SUBCKT sky130_sram_1rw_24x128_column_mux_array
+ bl_0 br_0 bl_1 br_1 bl_2 br_2 bl_3 br_3 bl_4 br_4 bl_5 br_5 bl_6 br_6
+ bl_7 br_7 bl_8 br_8 bl_9 br_9 bl_10 br_10 bl_11 br_11 bl_12 br_12
+ bl_13 br_13 bl_14 br_14 bl_15 br_15 bl_16 br_16 bl_17 br_17 bl_18
+ br_18 bl_19 br_19 bl_20 br_20 bl_21 br_21 bl_22 br_22 bl_23 br_23
+ bl_24 br_24 bl_25 br_25 bl_26 br_26 bl_27 br_27 bl_28 br_28 bl_29
+ br_29 bl_30 br_30 bl_31 br_31 bl_32 br_32 bl_33 br_33 bl_34 br_34
+ bl_35 br_35 bl_36 br_36 bl_37 br_37 bl_38 br_38 bl_39 br_39 bl_40
+ br_40 bl_41 br_41 bl_42 br_42 bl_43 br_43 bl_44 br_44 bl_45 br_45
+ bl_46 br_46 bl_47 br_47 bl_48 br_48 bl_49 br_49 bl_50 br_50 bl_51
+ br_51 bl_52 br_52 bl_53 br_53 bl_54 br_54 bl_55 br_55 bl_56 br_56
+ bl_57 br_57 bl_58 br_58 bl_59 br_59 bl_60 br_60 bl_61 br_61 bl_62
+ br_62 bl_63 br_63 bl_64 br_64 bl_65 br_65 bl_66 br_66 bl_67 br_67
+ bl_68 br_68 bl_69 br_69 bl_70 br_70 bl_71 br_71 bl_72 br_72 bl_73
+ br_73 bl_74 br_74 bl_75 br_75 bl_76 br_76 bl_77 br_77 bl_78 br_78
+ bl_79 br_79 bl_80 br_80 bl_81 br_81 bl_82 br_82 bl_83 br_83 bl_84
+ br_84 bl_85 br_85 bl_86 br_86 bl_87 br_87 bl_88 br_88 bl_89 br_89
+ bl_90 br_90 bl_91 br_91 bl_92 br_92 bl_93 br_93 bl_94 br_94 bl_95
+ br_95 bl_96 br_96 bl_97 br_97 bl_98 br_98 bl_99 br_99 bl_100 br_100
+ bl_101 br_101 bl_102 br_102 bl_103 br_103 bl_104 br_104 bl_105 br_105
+ bl_106 br_106 bl_107 br_107 bl_108 br_108 bl_109 br_109 bl_110 br_110
+ bl_111 br_111 bl_112 br_112 bl_113 br_113 bl_114 br_114 bl_115 br_115
+ bl_116 br_116 bl_117 br_117 bl_118 br_118 bl_119 br_119 bl_120 br_120
+ bl_121 br_121 bl_122 br_122 bl_123 br_123 bl_124 br_124 bl_125 br_125
+ bl_126 br_126 bl_127 br_127 bl_128 br_128 bl_129 br_129 bl_130 br_130
+ bl_131 br_131 bl_132 br_132 bl_133 br_133 bl_134 br_134 bl_135 br_135
+ bl_136 br_136 bl_137 br_137 bl_138 br_138 bl_139 br_139 bl_140 br_140
+ bl_141 br_141 bl_142 br_142 bl_143 br_143 bl_144 br_144 bl_145 br_145
+ bl_146 br_146 bl_147 br_147 bl_148 br_148 bl_149 br_149 bl_150 br_150
+ bl_151 br_151 bl_152 br_152 bl_153 br_153 bl_154 br_154 bl_155 br_155
+ bl_156 br_156 bl_157 br_157 bl_158 br_158 bl_159 br_159 bl_160 br_160
+ bl_161 br_161 bl_162 br_162 bl_163 br_163 bl_164 br_164 bl_165 br_165
+ bl_166 br_166 bl_167 br_167 bl_168 br_168 bl_169 br_169 bl_170 br_170
+ bl_171 br_171 bl_172 br_172 bl_173 br_173 bl_174 br_174 bl_175 br_175
+ bl_176 br_176 bl_177 br_177 bl_178 br_178 bl_179 br_179 bl_180 br_180
+ bl_181 br_181 bl_182 br_182 bl_183 br_183 bl_184 br_184 bl_185 br_185
+ bl_186 br_186 bl_187 br_187 bl_188 br_188 bl_189 br_189 bl_190 br_190
+ bl_191 br_191 sel_0 sel_1 sel_2 sel_3 sel_4 sel_5 sel_6 sel_7 bl_out_0
+ br_out_0 bl_out_1 br_out_1 bl_out_2 br_out_2 bl_out_3 br_out_3
+ bl_out_4 br_out_4 bl_out_5 br_out_5 bl_out_6 br_out_6 bl_out_7
+ br_out_7 bl_out_8 br_out_8 bl_out_9 br_out_9 bl_out_10 br_out_10
+ bl_out_11 br_out_11 bl_out_12 br_out_12 bl_out_13 br_out_13 bl_out_14
+ br_out_14 bl_out_15 br_out_15 bl_out_16 br_out_16 bl_out_17 br_out_17
+ bl_out_18 br_out_18 bl_out_19 br_out_19 bl_out_20 br_out_20 bl_out_21
+ br_out_21 bl_out_22 br_out_22 bl_out_23 br_out_23 gnd
* INOUT : bl_0 
* INOUT : br_0 
* INOUT : bl_1 
* INOUT : br_1 
* INOUT : bl_2 
* INOUT : br_2 
* INOUT : bl_3 
* INOUT : br_3 
* INOUT : bl_4 
* INOUT : br_4 
* INOUT : bl_5 
* INOUT : br_5 
* INOUT : bl_6 
* INOUT : br_6 
* INOUT : bl_7 
* INOUT : br_7 
* INOUT : bl_8 
* INOUT : br_8 
* INOUT : bl_9 
* INOUT : br_9 
* INOUT : bl_10 
* INOUT : br_10 
* INOUT : bl_11 
* INOUT : br_11 
* INOUT : bl_12 
* INOUT : br_12 
* INOUT : bl_13 
* INOUT : br_13 
* INOUT : bl_14 
* INOUT : br_14 
* INOUT : bl_15 
* INOUT : br_15 
* INOUT : bl_16 
* INOUT : br_16 
* INOUT : bl_17 
* INOUT : br_17 
* INOUT : bl_18 
* INOUT : br_18 
* INOUT : bl_19 
* INOUT : br_19 
* INOUT : bl_20 
* INOUT : br_20 
* INOUT : bl_21 
* INOUT : br_21 
* INOUT : bl_22 
* INOUT : br_22 
* INOUT : bl_23 
* INOUT : br_23 
* INOUT : bl_24 
* INOUT : br_24 
* INOUT : bl_25 
* INOUT : br_25 
* INOUT : bl_26 
* INOUT : br_26 
* INOUT : bl_27 
* INOUT : br_27 
* INOUT : bl_28 
* INOUT : br_28 
* INOUT : bl_29 
* INOUT : br_29 
* INOUT : bl_30 
* INOUT : br_30 
* INOUT : bl_31 
* INOUT : br_31 
* INOUT : bl_32 
* INOUT : br_32 
* INOUT : bl_33 
* INOUT : br_33 
* INOUT : bl_34 
* INOUT : br_34 
* INOUT : bl_35 
* INOUT : br_35 
* INOUT : bl_36 
* INOUT : br_36 
* INOUT : bl_37 
* INOUT : br_37 
* INOUT : bl_38 
* INOUT : br_38 
* INOUT : bl_39 
* INOUT : br_39 
* INOUT : bl_40 
* INOUT : br_40 
* INOUT : bl_41 
* INOUT : br_41 
* INOUT : bl_42 
* INOUT : br_42 
* INOUT : bl_43 
* INOUT : br_43 
* INOUT : bl_44 
* INOUT : br_44 
* INOUT : bl_45 
* INOUT : br_45 
* INOUT : bl_46 
* INOUT : br_46 
* INOUT : bl_47 
* INOUT : br_47 
* INOUT : bl_48 
* INOUT : br_48 
* INOUT : bl_49 
* INOUT : br_49 
* INOUT : bl_50 
* INOUT : br_50 
* INOUT : bl_51 
* INOUT : br_51 
* INOUT : bl_52 
* INOUT : br_52 
* INOUT : bl_53 
* INOUT : br_53 
* INOUT : bl_54 
* INOUT : br_54 
* INOUT : bl_55 
* INOUT : br_55 
* INOUT : bl_56 
* INOUT : br_56 
* INOUT : bl_57 
* INOUT : br_57 
* INOUT : bl_58 
* INOUT : br_58 
* INOUT : bl_59 
* INOUT : br_59 
* INOUT : bl_60 
* INOUT : br_60 
* INOUT : bl_61 
* INOUT : br_61 
* INOUT : bl_62 
* INOUT : br_62 
* INOUT : bl_63 
* INOUT : br_63 
* INOUT : bl_64 
* INOUT : br_64 
* INOUT : bl_65 
* INOUT : br_65 
* INOUT : bl_66 
* INOUT : br_66 
* INOUT : bl_67 
* INOUT : br_67 
* INOUT : bl_68 
* INOUT : br_68 
* INOUT : bl_69 
* INOUT : br_69 
* INOUT : bl_70 
* INOUT : br_70 
* INOUT : bl_71 
* INOUT : br_71 
* INOUT : bl_72 
* INOUT : br_72 
* INOUT : bl_73 
* INOUT : br_73 
* INOUT : bl_74 
* INOUT : br_74 
* INOUT : bl_75 
* INOUT : br_75 
* INOUT : bl_76 
* INOUT : br_76 
* INOUT : bl_77 
* INOUT : br_77 
* INOUT : bl_78 
* INOUT : br_78 
* INOUT : bl_79 
* INOUT : br_79 
* INOUT : bl_80 
* INOUT : br_80 
* INOUT : bl_81 
* INOUT : br_81 
* INOUT : bl_82 
* INOUT : br_82 
* INOUT : bl_83 
* INOUT : br_83 
* INOUT : bl_84 
* INOUT : br_84 
* INOUT : bl_85 
* INOUT : br_85 
* INOUT : bl_86 
* INOUT : br_86 
* INOUT : bl_87 
* INOUT : br_87 
* INOUT : bl_88 
* INOUT : br_88 
* INOUT : bl_89 
* INOUT : br_89 
* INOUT : bl_90 
* INOUT : br_90 
* INOUT : bl_91 
* INOUT : br_91 
* INOUT : bl_92 
* INOUT : br_92 
* INOUT : bl_93 
* INOUT : br_93 
* INOUT : bl_94 
* INOUT : br_94 
* INOUT : bl_95 
* INOUT : br_95 
* INOUT : bl_96 
* INOUT : br_96 
* INOUT : bl_97 
* INOUT : br_97 
* INOUT : bl_98 
* INOUT : br_98 
* INOUT : bl_99 
* INOUT : br_99 
* INOUT : bl_100 
* INOUT : br_100 
* INOUT : bl_101 
* INOUT : br_101 
* INOUT : bl_102 
* INOUT : br_102 
* INOUT : bl_103 
* INOUT : br_103 
* INOUT : bl_104 
* INOUT : br_104 
* INOUT : bl_105 
* INOUT : br_105 
* INOUT : bl_106 
* INOUT : br_106 
* INOUT : bl_107 
* INOUT : br_107 
* INOUT : bl_108 
* INOUT : br_108 
* INOUT : bl_109 
* INOUT : br_109 
* INOUT : bl_110 
* INOUT : br_110 
* INOUT : bl_111 
* INOUT : br_111 
* INOUT : bl_112 
* INOUT : br_112 
* INOUT : bl_113 
* INOUT : br_113 
* INOUT : bl_114 
* INOUT : br_114 
* INOUT : bl_115 
* INOUT : br_115 
* INOUT : bl_116 
* INOUT : br_116 
* INOUT : bl_117 
* INOUT : br_117 
* INOUT : bl_118 
* INOUT : br_118 
* INOUT : bl_119 
* INOUT : br_119 
* INOUT : bl_120 
* INOUT : br_120 
* INOUT : bl_121 
* INOUT : br_121 
* INOUT : bl_122 
* INOUT : br_122 
* INOUT : bl_123 
* INOUT : br_123 
* INOUT : bl_124 
* INOUT : br_124 
* INOUT : bl_125 
* INOUT : br_125 
* INOUT : bl_126 
* INOUT : br_126 
* INOUT : bl_127 
* INOUT : br_127 
* INOUT : bl_128 
* INOUT : br_128 
* INOUT : bl_129 
* INOUT : br_129 
* INOUT : bl_130 
* INOUT : br_130 
* INOUT : bl_131 
* INOUT : br_131 
* INOUT : bl_132 
* INOUT : br_132 
* INOUT : bl_133 
* INOUT : br_133 
* INOUT : bl_134 
* INOUT : br_134 
* INOUT : bl_135 
* INOUT : br_135 
* INOUT : bl_136 
* INOUT : br_136 
* INOUT : bl_137 
* INOUT : br_137 
* INOUT : bl_138 
* INOUT : br_138 
* INOUT : bl_139 
* INOUT : br_139 
* INOUT : bl_140 
* INOUT : br_140 
* INOUT : bl_141 
* INOUT : br_141 
* INOUT : bl_142 
* INOUT : br_142 
* INOUT : bl_143 
* INOUT : br_143 
* INOUT : bl_144 
* INOUT : br_144 
* INOUT : bl_145 
* INOUT : br_145 
* INOUT : bl_146 
* INOUT : br_146 
* INOUT : bl_147 
* INOUT : br_147 
* INOUT : bl_148 
* INOUT : br_148 
* INOUT : bl_149 
* INOUT : br_149 
* INOUT : bl_150 
* INOUT : br_150 
* INOUT : bl_151 
* INOUT : br_151 
* INOUT : bl_152 
* INOUT : br_152 
* INOUT : bl_153 
* INOUT : br_153 
* INOUT : bl_154 
* INOUT : br_154 
* INOUT : bl_155 
* INOUT : br_155 
* INOUT : bl_156 
* INOUT : br_156 
* INOUT : bl_157 
* INOUT : br_157 
* INOUT : bl_158 
* INOUT : br_158 
* INOUT : bl_159 
* INOUT : br_159 
* INOUT : bl_160 
* INOUT : br_160 
* INOUT : bl_161 
* INOUT : br_161 
* INOUT : bl_162 
* INOUT : br_162 
* INOUT : bl_163 
* INOUT : br_163 
* INOUT : bl_164 
* INOUT : br_164 
* INOUT : bl_165 
* INOUT : br_165 
* INOUT : bl_166 
* INOUT : br_166 
* INOUT : bl_167 
* INOUT : br_167 
* INOUT : bl_168 
* INOUT : br_168 
* INOUT : bl_169 
* INOUT : br_169 
* INOUT : bl_170 
* INOUT : br_170 
* INOUT : bl_171 
* INOUT : br_171 
* INOUT : bl_172 
* INOUT : br_172 
* INOUT : bl_173 
* INOUT : br_173 
* INOUT : bl_174 
* INOUT : br_174 
* INOUT : bl_175 
* INOUT : br_175 
* INOUT : bl_176 
* INOUT : br_176 
* INOUT : bl_177 
* INOUT : br_177 
* INOUT : bl_178 
* INOUT : br_178 
* INOUT : bl_179 
* INOUT : br_179 
* INOUT : bl_180 
* INOUT : br_180 
* INOUT : bl_181 
* INOUT : br_181 
* INOUT : bl_182 
* INOUT : br_182 
* INOUT : bl_183 
* INOUT : br_183 
* INOUT : bl_184 
* INOUT : br_184 
* INOUT : bl_185 
* INOUT : br_185 
* INOUT : bl_186 
* INOUT : br_186 
* INOUT : bl_187 
* INOUT : br_187 
* INOUT : bl_188 
* INOUT : br_188 
* INOUT : bl_189 
* INOUT : br_189 
* INOUT : bl_190 
* INOUT : br_190 
* INOUT : bl_191 
* INOUT : br_191 
* INOUT : sel_0 
* INOUT : sel_1 
* INOUT : sel_2 
* INOUT : sel_3 
* INOUT : sel_4 
* INOUT : sel_5 
* INOUT : sel_6 
* INOUT : sel_7 
* INOUT : bl_out_0 
* INOUT : br_out_0 
* INOUT : bl_out_1 
* INOUT : br_out_1 
* INOUT : bl_out_2 
* INOUT : br_out_2 
* INOUT : bl_out_3 
* INOUT : br_out_3 
* INOUT : bl_out_4 
* INOUT : br_out_4 
* INOUT : bl_out_5 
* INOUT : br_out_5 
* INOUT : bl_out_6 
* INOUT : br_out_6 
* INOUT : bl_out_7 
* INOUT : br_out_7 
* INOUT : bl_out_8 
* INOUT : br_out_8 
* INOUT : bl_out_9 
* INOUT : br_out_9 
* INOUT : bl_out_10 
* INOUT : br_out_10 
* INOUT : bl_out_11 
* INOUT : br_out_11 
* INOUT : bl_out_12 
* INOUT : br_out_12 
* INOUT : bl_out_13 
* INOUT : br_out_13 
* INOUT : bl_out_14 
* INOUT : br_out_14 
* INOUT : bl_out_15 
* INOUT : br_out_15 
* INOUT : bl_out_16 
* INOUT : br_out_16 
* INOUT : bl_out_17 
* INOUT : br_out_17 
* INOUT : bl_out_18 
* INOUT : br_out_18 
* INOUT : bl_out_19 
* INOUT : br_out_19 
* INOUT : bl_out_20 
* INOUT : br_out_20 
* INOUT : bl_out_21 
* INOUT : br_out_21 
* INOUT : bl_out_22 
* INOUT : br_out_22 
* INOUT : bl_out_23 
* INOUT : br_out_23 
* INOUT : gnd 
* cols: 192 word_size: 24 bl: bl br: br
XXMUX0
+ bl_0 br_0 bl_out_0 br_out_0 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX1
+ bl_1 br_1 bl_out_0 br_out_0 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX2
+ bl_2 br_2 bl_out_0 br_out_0 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX3
+ bl_3 br_3 bl_out_0 br_out_0 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX4
+ bl_4 br_4 bl_out_0 br_out_0 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX5
+ bl_5 br_5 bl_out_0 br_out_0 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX6
+ bl_6 br_6 bl_out_0 br_out_0 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX7
+ bl_7 br_7 bl_out_0 br_out_0 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX8
+ bl_8 br_8 bl_out_1 br_out_1 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX9
+ bl_9 br_9 bl_out_1 br_out_1 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX10
+ bl_10 br_10 bl_out_1 br_out_1 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX11
+ bl_11 br_11 bl_out_1 br_out_1 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX12
+ bl_12 br_12 bl_out_1 br_out_1 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX13
+ bl_13 br_13 bl_out_1 br_out_1 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX14
+ bl_14 br_14 bl_out_1 br_out_1 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX15
+ bl_15 br_15 bl_out_1 br_out_1 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX16
+ bl_16 br_16 bl_out_2 br_out_2 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX17
+ bl_17 br_17 bl_out_2 br_out_2 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX18
+ bl_18 br_18 bl_out_2 br_out_2 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX19
+ bl_19 br_19 bl_out_2 br_out_2 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX20
+ bl_20 br_20 bl_out_2 br_out_2 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX21
+ bl_21 br_21 bl_out_2 br_out_2 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX22
+ bl_22 br_22 bl_out_2 br_out_2 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX23
+ bl_23 br_23 bl_out_2 br_out_2 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX24
+ bl_24 br_24 bl_out_3 br_out_3 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX25
+ bl_25 br_25 bl_out_3 br_out_3 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX26
+ bl_26 br_26 bl_out_3 br_out_3 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX27
+ bl_27 br_27 bl_out_3 br_out_3 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX28
+ bl_28 br_28 bl_out_3 br_out_3 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX29
+ bl_29 br_29 bl_out_3 br_out_3 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX30
+ bl_30 br_30 bl_out_3 br_out_3 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX31
+ bl_31 br_31 bl_out_3 br_out_3 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX32
+ bl_32 br_32 bl_out_4 br_out_4 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX33
+ bl_33 br_33 bl_out_4 br_out_4 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX34
+ bl_34 br_34 bl_out_4 br_out_4 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX35
+ bl_35 br_35 bl_out_4 br_out_4 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX36
+ bl_36 br_36 bl_out_4 br_out_4 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX37
+ bl_37 br_37 bl_out_4 br_out_4 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX38
+ bl_38 br_38 bl_out_4 br_out_4 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX39
+ bl_39 br_39 bl_out_4 br_out_4 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX40
+ bl_40 br_40 bl_out_5 br_out_5 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX41
+ bl_41 br_41 bl_out_5 br_out_5 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX42
+ bl_42 br_42 bl_out_5 br_out_5 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX43
+ bl_43 br_43 bl_out_5 br_out_5 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX44
+ bl_44 br_44 bl_out_5 br_out_5 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX45
+ bl_45 br_45 bl_out_5 br_out_5 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX46
+ bl_46 br_46 bl_out_5 br_out_5 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX47
+ bl_47 br_47 bl_out_5 br_out_5 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX48
+ bl_48 br_48 bl_out_6 br_out_6 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX49
+ bl_49 br_49 bl_out_6 br_out_6 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX50
+ bl_50 br_50 bl_out_6 br_out_6 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX51
+ bl_51 br_51 bl_out_6 br_out_6 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX52
+ bl_52 br_52 bl_out_6 br_out_6 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX53
+ bl_53 br_53 bl_out_6 br_out_6 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX54
+ bl_54 br_54 bl_out_6 br_out_6 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX55
+ bl_55 br_55 bl_out_6 br_out_6 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX56
+ bl_56 br_56 bl_out_7 br_out_7 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX57
+ bl_57 br_57 bl_out_7 br_out_7 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX58
+ bl_58 br_58 bl_out_7 br_out_7 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX59
+ bl_59 br_59 bl_out_7 br_out_7 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX60
+ bl_60 br_60 bl_out_7 br_out_7 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX61
+ bl_61 br_61 bl_out_7 br_out_7 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX62
+ bl_62 br_62 bl_out_7 br_out_7 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX63
+ bl_63 br_63 bl_out_7 br_out_7 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX64
+ bl_64 br_64 bl_out_8 br_out_8 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX65
+ bl_65 br_65 bl_out_8 br_out_8 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX66
+ bl_66 br_66 bl_out_8 br_out_8 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX67
+ bl_67 br_67 bl_out_8 br_out_8 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX68
+ bl_68 br_68 bl_out_8 br_out_8 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX69
+ bl_69 br_69 bl_out_8 br_out_8 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX70
+ bl_70 br_70 bl_out_8 br_out_8 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX71
+ bl_71 br_71 bl_out_8 br_out_8 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX72
+ bl_72 br_72 bl_out_9 br_out_9 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX73
+ bl_73 br_73 bl_out_9 br_out_9 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX74
+ bl_74 br_74 bl_out_9 br_out_9 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX75
+ bl_75 br_75 bl_out_9 br_out_9 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX76
+ bl_76 br_76 bl_out_9 br_out_9 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX77
+ bl_77 br_77 bl_out_9 br_out_9 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX78
+ bl_78 br_78 bl_out_9 br_out_9 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX79
+ bl_79 br_79 bl_out_9 br_out_9 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX80
+ bl_80 br_80 bl_out_10 br_out_10 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX81
+ bl_81 br_81 bl_out_10 br_out_10 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX82
+ bl_82 br_82 bl_out_10 br_out_10 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX83
+ bl_83 br_83 bl_out_10 br_out_10 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX84
+ bl_84 br_84 bl_out_10 br_out_10 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX85
+ bl_85 br_85 bl_out_10 br_out_10 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX86
+ bl_86 br_86 bl_out_10 br_out_10 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX87
+ bl_87 br_87 bl_out_10 br_out_10 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX88
+ bl_88 br_88 bl_out_11 br_out_11 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX89
+ bl_89 br_89 bl_out_11 br_out_11 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX90
+ bl_90 br_90 bl_out_11 br_out_11 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX91
+ bl_91 br_91 bl_out_11 br_out_11 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX92
+ bl_92 br_92 bl_out_11 br_out_11 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX93
+ bl_93 br_93 bl_out_11 br_out_11 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX94
+ bl_94 br_94 bl_out_11 br_out_11 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX95
+ bl_95 br_95 bl_out_11 br_out_11 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX96
+ bl_96 br_96 bl_out_12 br_out_12 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX97
+ bl_97 br_97 bl_out_12 br_out_12 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX98
+ bl_98 br_98 bl_out_12 br_out_12 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX99
+ bl_99 br_99 bl_out_12 br_out_12 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX100
+ bl_100 br_100 bl_out_12 br_out_12 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX101
+ bl_101 br_101 bl_out_12 br_out_12 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX102
+ bl_102 br_102 bl_out_12 br_out_12 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX103
+ bl_103 br_103 bl_out_12 br_out_12 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX104
+ bl_104 br_104 bl_out_13 br_out_13 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX105
+ bl_105 br_105 bl_out_13 br_out_13 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX106
+ bl_106 br_106 bl_out_13 br_out_13 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX107
+ bl_107 br_107 bl_out_13 br_out_13 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX108
+ bl_108 br_108 bl_out_13 br_out_13 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX109
+ bl_109 br_109 bl_out_13 br_out_13 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX110
+ bl_110 br_110 bl_out_13 br_out_13 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX111
+ bl_111 br_111 bl_out_13 br_out_13 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX112
+ bl_112 br_112 bl_out_14 br_out_14 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX113
+ bl_113 br_113 bl_out_14 br_out_14 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX114
+ bl_114 br_114 bl_out_14 br_out_14 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX115
+ bl_115 br_115 bl_out_14 br_out_14 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX116
+ bl_116 br_116 bl_out_14 br_out_14 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX117
+ bl_117 br_117 bl_out_14 br_out_14 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX118
+ bl_118 br_118 bl_out_14 br_out_14 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX119
+ bl_119 br_119 bl_out_14 br_out_14 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX120
+ bl_120 br_120 bl_out_15 br_out_15 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX121
+ bl_121 br_121 bl_out_15 br_out_15 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX122
+ bl_122 br_122 bl_out_15 br_out_15 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX123
+ bl_123 br_123 bl_out_15 br_out_15 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX124
+ bl_124 br_124 bl_out_15 br_out_15 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX125
+ bl_125 br_125 bl_out_15 br_out_15 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX126
+ bl_126 br_126 bl_out_15 br_out_15 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX127
+ bl_127 br_127 bl_out_15 br_out_15 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX128
+ bl_128 br_128 bl_out_16 br_out_16 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX129
+ bl_129 br_129 bl_out_16 br_out_16 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX130
+ bl_130 br_130 bl_out_16 br_out_16 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX131
+ bl_131 br_131 bl_out_16 br_out_16 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX132
+ bl_132 br_132 bl_out_16 br_out_16 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX133
+ bl_133 br_133 bl_out_16 br_out_16 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX134
+ bl_134 br_134 bl_out_16 br_out_16 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX135
+ bl_135 br_135 bl_out_16 br_out_16 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX136
+ bl_136 br_136 bl_out_17 br_out_17 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX137
+ bl_137 br_137 bl_out_17 br_out_17 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX138
+ bl_138 br_138 bl_out_17 br_out_17 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX139
+ bl_139 br_139 bl_out_17 br_out_17 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX140
+ bl_140 br_140 bl_out_17 br_out_17 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX141
+ bl_141 br_141 bl_out_17 br_out_17 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX142
+ bl_142 br_142 bl_out_17 br_out_17 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX143
+ bl_143 br_143 bl_out_17 br_out_17 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX144
+ bl_144 br_144 bl_out_18 br_out_18 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX145
+ bl_145 br_145 bl_out_18 br_out_18 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX146
+ bl_146 br_146 bl_out_18 br_out_18 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX147
+ bl_147 br_147 bl_out_18 br_out_18 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX148
+ bl_148 br_148 bl_out_18 br_out_18 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX149
+ bl_149 br_149 bl_out_18 br_out_18 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX150
+ bl_150 br_150 bl_out_18 br_out_18 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX151
+ bl_151 br_151 bl_out_18 br_out_18 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX152
+ bl_152 br_152 bl_out_19 br_out_19 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX153
+ bl_153 br_153 bl_out_19 br_out_19 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX154
+ bl_154 br_154 bl_out_19 br_out_19 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX155
+ bl_155 br_155 bl_out_19 br_out_19 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX156
+ bl_156 br_156 bl_out_19 br_out_19 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX157
+ bl_157 br_157 bl_out_19 br_out_19 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX158
+ bl_158 br_158 bl_out_19 br_out_19 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX159
+ bl_159 br_159 bl_out_19 br_out_19 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX160
+ bl_160 br_160 bl_out_20 br_out_20 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX161
+ bl_161 br_161 bl_out_20 br_out_20 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX162
+ bl_162 br_162 bl_out_20 br_out_20 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX163
+ bl_163 br_163 bl_out_20 br_out_20 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX164
+ bl_164 br_164 bl_out_20 br_out_20 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX165
+ bl_165 br_165 bl_out_20 br_out_20 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX166
+ bl_166 br_166 bl_out_20 br_out_20 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX167
+ bl_167 br_167 bl_out_20 br_out_20 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX168
+ bl_168 br_168 bl_out_21 br_out_21 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX169
+ bl_169 br_169 bl_out_21 br_out_21 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX170
+ bl_170 br_170 bl_out_21 br_out_21 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX171
+ bl_171 br_171 bl_out_21 br_out_21 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX172
+ bl_172 br_172 bl_out_21 br_out_21 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX173
+ bl_173 br_173 bl_out_21 br_out_21 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX174
+ bl_174 br_174 bl_out_21 br_out_21 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX175
+ bl_175 br_175 bl_out_21 br_out_21 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX176
+ bl_176 br_176 bl_out_22 br_out_22 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX177
+ bl_177 br_177 bl_out_22 br_out_22 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX178
+ bl_178 br_178 bl_out_22 br_out_22 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX179
+ bl_179 br_179 bl_out_22 br_out_22 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX180
+ bl_180 br_180 bl_out_22 br_out_22 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX181
+ bl_181 br_181 bl_out_22 br_out_22 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX182
+ bl_182 br_182 bl_out_22 br_out_22 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX183
+ bl_183 br_183 bl_out_22 br_out_22 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX184
+ bl_184 br_184 bl_out_23 br_out_23 sel_0 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX185
+ bl_185 br_185 bl_out_23 br_out_23 sel_1 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX186
+ bl_186 br_186 bl_out_23 br_out_23 sel_2 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX187
+ bl_187 br_187 bl_out_23 br_out_23 sel_3 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX188
+ bl_188 br_188 bl_out_23 br_out_23 sel_4 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX189
+ bl_189 br_189 bl_out_23 br_out_23 sel_5 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX190
+ bl_190 br_190 bl_out_23 br_out_23 sel_6 gnd
+ sky130_sram_1rw_24x128_column_mux
XXMUX191
+ bl_191 br_191 bl_out_23 br_out_23 sel_7 gnd
+ sky130_sram_1rw_24x128_column_mux
.ENDS sky130_sram_1rw_24x128_column_mux_array

.SUBCKT sky130_sram_1rw_24x128_pnand2
+ A B Z vdd gnd
* INPUT : A 
* INPUT : B 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpnand2_pmos1 vdd A Z vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpnand2_pmos2 Z B vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpnand2_nmos1 Z B net1 gnd sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
Xpnand2_nmos2 net1 A gnd gnd sky130_fd_pr__nfet_01v8 m=1 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
.ENDS sky130_sram_1rw_24x128_pnand2

.SUBCKT sky130_sram_1rw_24x128_pinv
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 2.0
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=2 w=1.26 l=0.15 pd=2.82 ps=2.82 as=0.47u ad=0.47u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=2 w=0.74 l=0.15 pd=1.78 ps=1.78 as=0.28u ad=0.28u
.ENDS sky130_sram_1rw_24x128_pinv

.SUBCKT sky130_sram_1rw_24x128_pdriver
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* sizes: [2.0]
Xbuf_inv1
+ A Z vdd gnd
+ sky130_sram_1rw_24x128_pinv
.ENDS sky130_sram_1rw_24x128_pdriver

.SUBCKT sky130_sram_1rw_24x128_pand2
+ A B Z vdd gnd
* INPUT : A 
* INPUT : B 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 2.0
Xpand2_nand
+ A B zb_int vdd gnd
+ sky130_sram_1rw_24x128_pnand2
Xpand2_inv
+ zb_int Z vdd gnd
+ sky130_sram_1rw_24x128_pdriver
.ENDS sky130_sram_1rw_24x128_pand2

.SUBCKT sky130_sram_1rw_24x128_write_mask_and_array
+ wmask_in_0 wmask_in_1 wmask_in_2 en wmask_out_0 wmask_out_1
+ wmask_out_2 vdd gnd
* INPUT : wmask_in_0 
* INPUT : wmask_in_1 
* INPUT : wmask_in_2 
* INPUT : en 
* OUTPUT: wmask_out_0 
* OUTPUT: wmask_out_1 
* OUTPUT: wmask_out_2 
* POWER : vdd 
* GROUND: gnd 
* columns: 192
* word_size 24
* write_size 8
Xand2_0
+ wmask_in_0 en wmask_out_0 vdd gnd
+ sky130_sram_1rw_24x128_pand2
Xand2_1
+ wmask_in_1 en wmask_out_1 vdd gnd
+ sky130_sram_1rw_24x128_pand2
Xand2_2
+ wmask_in_2 en wmask_out_2 vdd gnd
+ sky130_sram_1rw_24x128_pand2
.ENDS sky130_sram_1rw_24x128_write_mask_and_array

.SUBCKT sky130_sram_1rw_24x128_port_data
+ rbl_bl rbl_br bl_0 br_0 bl_1 br_1 bl_2 br_2 bl_3 br_3 bl_4 br_4 bl_5
+ br_5 bl_6 br_6 bl_7 br_7 bl_8 br_8 bl_9 br_9 bl_10 br_10 bl_11 br_11
+ bl_12 br_12 bl_13 br_13 bl_14 br_14 bl_15 br_15 bl_16 br_16 bl_17
+ br_17 bl_18 br_18 bl_19 br_19 bl_20 br_20 bl_21 br_21 bl_22 br_22
+ bl_23 br_23 bl_24 br_24 bl_25 br_25 bl_26 br_26 bl_27 br_27 bl_28
+ br_28 bl_29 br_29 bl_30 br_30 bl_31 br_31 bl_32 br_32 bl_33 br_33
+ bl_34 br_34 bl_35 br_35 bl_36 br_36 bl_37 br_37 bl_38 br_38 bl_39
+ br_39 bl_40 br_40 bl_41 br_41 bl_42 br_42 bl_43 br_43 bl_44 br_44
+ bl_45 br_45 bl_46 br_46 bl_47 br_47 bl_48 br_48 bl_49 br_49 bl_50
+ br_50 bl_51 br_51 bl_52 br_52 bl_53 br_53 bl_54 br_54 bl_55 br_55
+ bl_56 br_56 bl_57 br_57 bl_58 br_58 bl_59 br_59 bl_60 br_60 bl_61
+ br_61 bl_62 br_62 bl_63 br_63 bl_64 br_64 bl_65 br_65 bl_66 br_66
+ bl_67 br_67 bl_68 br_68 bl_69 br_69 bl_70 br_70 bl_71 br_71 bl_72
+ br_72 bl_73 br_73 bl_74 br_74 bl_75 br_75 bl_76 br_76 bl_77 br_77
+ bl_78 br_78 bl_79 br_79 bl_80 br_80 bl_81 br_81 bl_82 br_82 bl_83
+ br_83 bl_84 br_84 bl_85 br_85 bl_86 br_86 bl_87 br_87 bl_88 br_88
+ bl_89 br_89 bl_90 br_90 bl_91 br_91 bl_92 br_92 bl_93 br_93 bl_94
+ br_94 bl_95 br_95 bl_96 br_96 bl_97 br_97 bl_98 br_98 bl_99 br_99
+ bl_100 br_100 bl_101 br_101 bl_102 br_102 bl_103 br_103 bl_104 br_104
+ bl_105 br_105 bl_106 br_106 bl_107 br_107 bl_108 br_108 bl_109 br_109
+ bl_110 br_110 bl_111 br_111 bl_112 br_112 bl_113 br_113 bl_114 br_114
+ bl_115 br_115 bl_116 br_116 bl_117 br_117 bl_118 br_118 bl_119 br_119
+ bl_120 br_120 bl_121 br_121 bl_122 br_122 bl_123 br_123 bl_124 br_124
+ bl_125 br_125 bl_126 br_126 bl_127 br_127 bl_128 br_128 bl_129 br_129
+ bl_130 br_130 bl_131 br_131 bl_132 br_132 bl_133 br_133 bl_134 br_134
+ bl_135 br_135 bl_136 br_136 bl_137 br_137 bl_138 br_138 bl_139 br_139
+ bl_140 br_140 bl_141 br_141 bl_142 br_142 bl_143 br_143 bl_144 br_144
+ bl_145 br_145 bl_146 br_146 bl_147 br_147 bl_148 br_148 bl_149 br_149
+ bl_150 br_150 bl_151 br_151 bl_152 br_152 bl_153 br_153 bl_154 br_154
+ bl_155 br_155 bl_156 br_156 bl_157 br_157 bl_158 br_158 bl_159 br_159
+ bl_160 br_160 bl_161 br_161 bl_162 br_162 bl_163 br_163 bl_164 br_164
+ bl_165 br_165 bl_166 br_166 bl_167 br_167 bl_168 br_168 bl_169 br_169
+ bl_170 br_170 bl_171 br_171 bl_172 br_172 bl_173 br_173 bl_174 br_174
+ bl_175 br_175 bl_176 br_176 bl_177 br_177 bl_178 br_178 bl_179 br_179
+ bl_180 br_180 bl_181 br_181 bl_182 br_182 bl_183 br_183 bl_184 br_184
+ bl_185 br_185 bl_186 br_186 bl_187 br_187 bl_188 br_188 bl_189 br_189
+ bl_190 br_190 bl_191 br_191 sparebl_0 sparebr_0 dout_0 dout_1 dout_2
+ dout_3 dout_4 dout_5 dout_6 dout_7 dout_8 dout_9 dout_10 dout_11
+ dout_12 dout_13 dout_14 dout_15 dout_16 dout_17 dout_18 dout_19
+ dout_20 dout_21 dout_22 dout_23 dout_24 din_0 din_1 din_2 din_3 din_4
+ din_5 din_6 din_7 din_8 din_9 din_10 din_11 din_12 din_13 din_14
+ din_15 din_16 din_17 din_18 din_19 din_20 din_21 din_22 din_23 din_24
+ sel_0 sel_1 sel_2 sel_3 sel_4 sel_5 sel_6 sel_7 s_en p_en_bar w_en
+ bank_wmask_0 bank_wmask_1 bank_wmask_2 bank_spare_wen0 vdd gnd
* INOUT : rbl_bl 
* INOUT : rbl_br 
* INOUT : bl_0 
* INOUT : br_0 
* INOUT : bl_1 
* INOUT : br_1 
* INOUT : bl_2 
* INOUT : br_2 
* INOUT : bl_3 
* INOUT : br_3 
* INOUT : bl_4 
* INOUT : br_4 
* INOUT : bl_5 
* INOUT : br_5 
* INOUT : bl_6 
* INOUT : br_6 
* INOUT : bl_7 
* INOUT : br_7 
* INOUT : bl_8 
* INOUT : br_8 
* INOUT : bl_9 
* INOUT : br_9 
* INOUT : bl_10 
* INOUT : br_10 
* INOUT : bl_11 
* INOUT : br_11 
* INOUT : bl_12 
* INOUT : br_12 
* INOUT : bl_13 
* INOUT : br_13 
* INOUT : bl_14 
* INOUT : br_14 
* INOUT : bl_15 
* INOUT : br_15 
* INOUT : bl_16 
* INOUT : br_16 
* INOUT : bl_17 
* INOUT : br_17 
* INOUT : bl_18 
* INOUT : br_18 
* INOUT : bl_19 
* INOUT : br_19 
* INOUT : bl_20 
* INOUT : br_20 
* INOUT : bl_21 
* INOUT : br_21 
* INOUT : bl_22 
* INOUT : br_22 
* INOUT : bl_23 
* INOUT : br_23 
* INOUT : bl_24 
* INOUT : br_24 
* INOUT : bl_25 
* INOUT : br_25 
* INOUT : bl_26 
* INOUT : br_26 
* INOUT : bl_27 
* INOUT : br_27 
* INOUT : bl_28 
* INOUT : br_28 
* INOUT : bl_29 
* INOUT : br_29 
* INOUT : bl_30 
* INOUT : br_30 
* INOUT : bl_31 
* INOUT : br_31 
* INOUT : bl_32 
* INOUT : br_32 
* INOUT : bl_33 
* INOUT : br_33 
* INOUT : bl_34 
* INOUT : br_34 
* INOUT : bl_35 
* INOUT : br_35 
* INOUT : bl_36 
* INOUT : br_36 
* INOUT : bl_37 
* INOUT : br_37 
* INOUT : bl_38 
* INOUT : br_38 
* INOUT : bl_39 
* INOUT : br_39 
* INOUT : bl_40 
* INOUT : br_40 
* INOUT : bl_41 
* INOUT : br_41 
* INOUT : bl_42 
* INOUT : br_42 
* INOUT : bl_43 
* INOUT : br_43 
* INOUT : bl_44 
* INOUT : br_44 
* INOUT : bl_45 
* INOUT : br_45 
* INOUT : bl_46 
* INOUT : br_46 
* INOUT : bl_47 
* INOUT : br_47 
* INOUT : bl_48 
* INOUT : br_48 
* INOUT : bl_49 
* INOUT : br_49 
* INOUT : bl_50 
* INOUT : br_50 
* INOUT : bl_51 
* INOUT : br_51 
* INOUT : bl_52 
* INOUT : br_52 
* INOUT : bl_53 
* INOUT : br_53 
* INOUT : bl_54 
* INOUT : br_54 
* INOUT : bl_55 
* INOUT : br_55 
* INOUT : bl_56 
* INOUT : br_56 
* INOUT : bl_57 
* INOUT : br_57 
* INOUT : bl_58 
* INOUT : br_58 
* INOUT : bl_59 
* INOUT : br_59 
* INOUT : bl_60 
* INOUT : br_60 
* INOUT : bl_61 
* INOUT : br_61 
* INOUT : bl_62 
* INOUT : br_62 
* INOUT : bl_63 
* INOUT : br_63 
* INOUT : bl_64 
* INOUT : br_64 
* INOUT : bl_65 
* INOUT : br_65 
* INOUT : bl_66 
* INOUT : br_66 
* INOUT : bl_67 
* INOUT : br_67 
* INOUT : bl_68 
* INOUT : br_68 
* INOUT : bl_69 
* INOUT : br_69 
* INOUT : bl_70 
* INOUT : br_70 
* INOUT : bl_71 
* INOUT : br_71 
* INOUT : bl_72 
* INOUT : br_72 
* INOUT : bl_73 
* INOUT : br_73 
* INOUT : bl_74 
* INOUT : br_74 
* INOUT : bl_75 
* INOUT : br_75 
* INOUT : bl_76 
* INOUT : br_76 
* INOUT : bl_77 
* INOUT : br_77 
* INOUT : bl_78 
* INOUT : br_78 
* INOUT : bl_79 
* INOUT : br_79 
* INOUT : bl_80 
* INOUT : br_80 
* INOUT : bl_81 
* INOUT : br_81 
* INOUT : bl_82 
* INOUT : br_82 
* INOUT : bl_83 
* INOUT : br_83 
* INOUT : bl_84 
* INOUT : br_84 
* INOUT : bl_85 
* INOUT : br_85 
* INOUT : bl_86 
* INOUT : br_86 
* INOUT : bl_87 
* INOUT : br_87 
* INOUT : bl_88 
* INOUT : br_88 
* INOUT : bl_89 
* INOUT : br_89 
* INOUT : bl_90 
* INOUT : br_90 
* INOUT : bl_91 
* INOUT : br_91 
* INOUT : bl_92 
* INOUT : br_92 
* INOUT : bl_93 
* INOUT : br_93 
* INOUT : bl_94 
* INOUT : br_94 
* INOUT : bl_95 
* INOUT : br_95 
* INOUT : bl_96 
* INOUT : br_96 
* INOUT : bl_97 
* INOUT : br_97 
* INOUT : bl_98 
* INOUT : br_98 
* INOUT : bl_99 
* INOUT : br_99 
* INOUT : bl_100 
* INOUT : br_100 
* INOUT : bl_101 
* INOUT : br_101 
* INOUT : bl_102 
* INOUT : br_102 
* INOUT : bl_103 
* INOUT : br_103 
* INOUT : bl_104 
* INOUT : br_104 
* INOUT : bl_105 
* INOUT : br_105 
* INOUT : bl_106 
* INOUT : br_106 
* INOUT : bl_107 
* INOUT : br_107 
* INOUT : bl_108 
* INOUT : br_108 
* INOUT : bl_109 
* INOUT : br_109 
* INOUT : bl_110 
* INOUT : br_110 
* INOUT : bl_111 
* INOUT : br_111 
* INOUT : bl_112 
* INOUT : br_112 
* INOUT : bl_113 
* INOUT : br_113 
* INOUT : bl_114 
* INOUT : br_114 
* INOUT : bl_115 
* INOUT : br_115 
* INOUT : bl_116 
* INOUT : br_116 
* INOUT : bl_117 
* INOUT : br_117 
* INOUT : bl_118 
* INOUT : br_118 
* INOUT : bl_119 
* INOUT : br_119 
* INOUT : bl_120 
* INOUT : br_120 
* INOUT : bl_121 
* INOUT : br_121 
* INOUT : bl_122 
* INOUT : br_122 
* INOUT : bl_123 
* INOUT : br_123 
* INOUT : bl_124 
* INOUT : br_124 
* INOUT : bl_125 
* INOUT : br_125 
* INOUT : bl_126 
* INOUT : br_126 
* INOUT : bl_127 
* INOUT : br_127 
* INOUT : bl_128 
* INOUT : br_128 
* INOUT : bl_129 
* INOUT : br_129 
* INOUT : bl_130 
* INOUT : br_130 
* INOUT : bl_131 
* INOUT : br_131 
* INOUT : bl_132 
* INOUT : br_132 
* INOUT : bl_133 
* INOUT : br_133 
* INOUT : bl_134 
* INOUT : br_134 
* INOUT : bl_135 
* INOUT : br_135 
* INOUT : bl_136 
* INOUT : br_136 
* INOUT : bl_137 
* INOUT : br_137 
* INOUT : bl_138 
* INOUT : br_138 
* INOUT : bl_139 
* INOUT : br_139 
* INOUT : bl_140 
* INOUT : br_140 
* INOUT : bl_141 
* INOUT : br_141 
* INOUT : bl_142 
* INOUT : br_142 
* INOUT : bl_143 
* INOUT : br_143 
* INOUT : bl_144 
* INOUT : br_144 
* INOUT : bl_145 
* INOUT : br_145 
* INOUT : bl_146 
* INOUT : br_146 
* INOUT : bl_147 
* INOUT : br_147 
* INOUT : bl_148 
* INOUT : br_148 
* INOUT : bl_149 
* INOUT : br_149 
* INOUT : bl_150 
* INOUT : br_150 
* INOUT : bl_151 
* INOUT : br_151 
* INOUT : bl_152 
* INOUT : br_152 
* INOUT : bl_153 
* INOUT : br_153 
* INOUT : bl_154 
* INOUT : br_154 
* INOUT : bl_155 
* INOUT : br_155 
* INOUT : bl_156 
* INOUT : br_156 
* INOUT : bl_157 
* INOUT : br_157 
* INOUT : bl_158 
* INOUT : br_158 
* INOUT : bl_159 
* INOUT : br_159 
* INOUT : bl_160 
* INOUT : br_160 
* INOUT : bl_161 
* INOUT : br_161 
* INOUT : bl_162 
* INOUT : br_162 
* INOUT : bl_163 
* INOUT : br_163 
* INOUT : bl_164 
* INOUT : br_164 
* INOUT : bl_165 
* INOUT : br_165 
* INOUT : bl_166 
* INOUT : br_166 
* INOUT : bl_167 
* INOUT : br_167 
* INOUT : bl_168 
* INOUT : br_168 
* INOUT : bl_169 
* INOUT : br_169 
* INOUT : bl_170 
* INOUT : br_170 
* INOUT : bl_171 
* INOUT : br_171 
* INOUT : bl_172 
* INOUT : br_172 
* INOUT : bl_173 
* INOUT : br_173 
* INOUT : bl_174 
* INOUT : br_174 
* INOUT : bl_175 
* INOUT : br_175 
* INOUT : bl_176 
* INOUT : br_176 
* INOUT : bl_177 
* INOUT : br_177 
* INOUT : bl_178 
* INOUT : br_178 
* INOUT : bl_179 
* INOUT : br_179 
* INOUT : bl_180 
* INOUT : br_180 
* INOUT : bl_181 
* INOUT : br_181 
* INOUT : bl_182 
* INOUT : br_182 
* INOUT : bl_183 
* INOUT : br_183 
* INOUT : bl_184 
* INOUT : br_184 
* INOUT : bl_185 
* INOUT : br_185 
* INOUT : bl_186 
* INOUT : br_186 
* INOUT : bl_187 
* INOUT : br_187 
* INOUT : bl_188 
* INOUT : br_188 
* INOUT : bl_189 
* INOUT : br_189 
* INOUT : bl_190 
* INOUT : br_190 
* INOUT : bl_191 
* INOUT : br_191 
* INOUT : sparebl_0 
* INOUT : sparebr_0 
* OUTPUT: dout_0 
* OUTPUT: dout_1 
* OUTPUT: dout_2 
* OUTPUT: dout_3 
* OUTPUT: dout_4 
* OUTPUT: dout_5 
* OUTPUT: dout_6 
* OUTPUT: dout_7 
* OUTPUT: dout_8 
* OUTPUT: dout_9 
* OUTPUT: dout_10 
* OUTPUT: dout_11 
* OUTPUT: dout_12 
* OUTPUT: dout_13 
* OUTPUT: dout_14 
* OUTPUT: dout_15 
* OUTPUT: dout_16 
* OUTPUT: dout_17 
* OUTPUT: dout_18 
* OUTPUT: dout_19 
* OUTPUT: dout_20 
* OUTPUT: dout_21 
* OUTPUT: dout_22 
* OUTPUT: dout_23 
* OUTPUT: dout_24 
* INPUT : din_0 
* INPUT : din_1 
* INPUT : din_2 
* INPUT : din_3 
* INPUT : din_4 
* INPUT : din_5 
* INPUT : din_6 
* INPUT : din_7 
* INPUT : din_8 
* INPUT : din_9 
* INPUT : din_10 
* INPUT : din_11 
* INPUT : din_12 
* INPUT : din_13 
* INPUT : din_14 
* INPUT : din_15 
* INPUT : din_16 
* INPUT : din_17 
* INPUT : din_18 
* INPUT : din_19 
* INPUT : din_20 
* INPUT : din_21 
* INPUT : din_22 
* INPUT : din_23 
* INPUT : din_24 
* INPUT : sel_0 
* INPUT : sel_1 
* INPUT : sel_2 
* INPUT : sel_3 
* INPUT : sel_4 
* INPUT : sel_5 
* INPUT : sel_6 
* INPUT : sel_7 
* INPUT : s_en 
* INPUT : p_en_bar 
* INPUT : w_en 
* INPUT : bank_wmask_0 
* INPUT : bank_wmask_1 
* INPUT : bank_wmask_2 
* INPUT : bank_spare_wen0 
* POWER : vdd 
* GROUND: gnd 
Xprecharge_array0
+ rbl_bl rbl_br bl_0 br_0 bl_1 br_1 bl_2 br_2 bl_3 br_3 bl_4 br_4 bl_5
+ br_5 bl_6 br_6 bl_7 br_7 bl_8 br_8 bl_9 br_9 bl_10 br_10 bl_11 br_11
+ bl_12 br_12 bl_13 br_13 bl_14 br_14 bl_15 br_15 bl_16 br_16 bl_17
+ br_17 bl_18 br_18 bl_19 br_19 bl_20 br_20 bl_21 br_21 bl_22 br_22
+ bl_23 br_23 bl_24 br_24 bl_25 br_25 bl_26 br_26 bl_27 br_27 bl_28
+ br_28 bl_29 br_29 bl_30 br_30 bl_31 br_31 bl_32 br_32 bl_33 br_33
+ bl_34 br_34 bl_35 br_35 bl_36 br_36 bl_37 br_37 bl_38 br_38 bl_39
+ br_39 bl_40 br_40 bl_41 br_41 bl_42 br_42 bl_43 br_43 bl_44 br_44
+ bl_45 br_45 bl_46 br_46 bl_47 br_47 bl_48 br_48 bl_49 br_49 bl_50
+ br_50 bl_51 br_51 bl_52 br_52 bl_53 br_53 bl_54 br_54 bl_55 br_55
+ bl_56 br_56 bl_57 br_57 bl_58 br_58 bl_59 br_59 bl_60 br_60 bl_61
+ br_61 bl_62 br_62 bl_63 br_63 bl_64 br_64 bl_65 br_65 bl_66 br_66
+ bl_67 br_67 bl_68 br_68 bl_69 br_69 bl_70 br_70 bl_71 br_71 bl_72
+ br_72 bl_73 br_73 bl_74 br_74 bl_75 br_75 bl_76 br_76 bl_77 br_77
+ bl_78 br_78 bl_79 br_79 bl_80 br_80 bl_81 br_81 bl_82 br_82 bl_83
+ br_83 bl_84 br_84 bl_85 br_85 bl_86 br_86 bl_87 br_87 bl_88 br_88
+ bl_89 br_89 bl_90 br_90 bl_91 br_91 bl_92 br_92 bl_93 br_93 bl_94
+ br_94 bl_95 br_95 bl_96 br_96 bl_97 br_97 bl_98 br_98 bl_99 br_99
+ bl_100 br_100 bl_101 br_101 bl_102 br_102 bl_103 br_103 bl_104 br_104
+ bl_105 br_105 bl_106 br_106 bl_107 br_107 bl_108 br_108 bl_109 br_109
+ bl_110 br_110 bl_111 br_111 bl_112 br_112 bl_113 br_113 bl_114 br_114
+ bl_115 br_115 bl_116 br_116 bl_117 br_117 bl_118 br_118 bl_119 br_119
+ bl_120 br_120 bl_121 br_121 bl_122 br_122 bl_123 br_123 bl_124 br_124
+ bl_125 br_125 bl_126 br_126 bl_127 br_127 bl_128 br_128 bl_129 br_129
+ bl_130 br_130 bl_131 br_131 bl_132 br_132 bl_133 br_133 bl_134 br_134
+ bl_135 br_135 bl_136 br_136 bl_137 br_137 bl_138 br_138 bl_139 br_139
+ bl_140 br_140 bl_141 br_141 bl_142 br_142 bl_143 br_143 bl_144 br_144
+ bl_145 br_145 bl_146 br_146 bl_147 br_147 bl_148 br_148 bl_149 br_149
+ bl_150 br_150 bl_151 br_151 bl_152 br_152 bl_153 br_153 bl_154 br_154
+ bl_155 br_155 bl_156 br_156 bl_157 br_157 bl_158 br_158 bl_159 br_159
+ bl_160 br_160 bl_161 br_161 bl_162 br_162 bl_163 br_163 bl_164 br_164
+ bl_165 br_165 bl_166 br_166 bl_167 br_167 bl_168 br_168 bl_169 br_169
+ bl_170 br_170 bl_171 br_171 bl_172 br_172 bl_173 br_173 bl_174 br_174
+ bl_175 br_175 bl_176 br_176 bl_177 br_177 bl_178 br_178 bl_179 br_179
+ bl_180 br_180 bl_181 br_181 bl_182 br_182 bl_183 br_183 bl_184 br_184
+ bl_185 br_185 bl_186 br_186 bl_187 br_187 bl_188 br_188 bl_189 br_189
+ bl_190 br_190 bl_191 br_191 sparebl_0 sparebr_0 p_en_bar vdd
+ sky130_sram_1rw_24x128_precharge_array
Xsense_amp_array0
+ dout_0 bl_out_0 br_out_0 dout_1 bl_out_1 br_out_1 dout_2 bl_out_2
+ br_out_2 dout_3 bl_out_3 br_out_3 dout_4 bl_out_4 br_out_4 dout_5
+ bl_out_5 br_out_5 dout_6 bl_out_6 br_out_6 dout_7 bl_out_7 br_out_7
+ dout_8 bl_out_8 br_out_8 dout_9 bl_out_9 br_out_9 dout_10 bl_out_10
+ br_out_10 dout_11 bl_out_11 br_out_11 dout_12 bl_out_12 br_out_12
+ dout_13 bl_out_13 br_out_13 dout_14 bl_out_14 br_out_14 dout_15
+ bl_out_15 br_out_15 dout_16 bl_out_16 br_out_16 dout_17 bl_out_17
+ br_out_17 dout_18 bl_out_18 br_out_18 dout_19 bl_out_19 br_out_19
+ dout_20 bl_out_20 br_out_20 dout_21 bl_out_21 br_out_21 dout_22
+ bl_out_22 br_out_22 dout_23 bl_out_23 br_out_23 dout_24 sparebl_0
+ sparebr_0 s_en vdd gnd
+ sky130_sram_1rw_24x128_sense_amp_array
Xwrite_driver_array0
+ din_0 din_1 din_2 din_3 din_4 din_5 din_6 din_7 din_8 din_9 din_10
+ din_11 din_12 din_13 din_14 din_15 din_16 din_17 din_18 din_19 din_20
+ din_21 din_22 din_23 din_24 bl_out_0 br_out_0 bl_out_1 br_out_1
+ bl_out_2 br_out_2 bl_out_3 br_out_3 bl_out_4 br_out_4 bl_out_5
+ br_out_5 bl_out_6 br_out_6 bl_out_7 br_out_7 bl_out_8 br_out_8
+ bl_out_9 br_out_9 bl_out_10 br_out_10 bl_out_11 br_out_11 bl_out_12
+ br_out_12 bl_out_13 br_out_13 bl_out_14 br_out_14 bl_out_15 br_out_15
+ bl_out_16 br_out_16 bl_out_17 br_out_17 bl_out_18 br_out_18 bl_out_19
+ br_out_19 bl_out_20 br_out_20 bl_out_21 br_out_21 bl_out_22 br_out_22
+ bl_out_23 br_out_23 sparebl_0 sparebr_0 wdriver_sel_0 wdriver_sel_1
+ wdriver_sel_2 bank_spare_wen0 vdd gnd
+ sky130_sram_1rw_24x128_write_driver_array
Xwrite_mask_and_array0
+ bank_wmask_0 bank_wmask_1 bank_wmask_2 w_en wdriver_sel_0
+ wdriver_sel_1 wdriver_sel_2 vdd gnd
+ sky130_sram_1rw_24x128_write_mask_and_array
Xcolumn_mux_array0
+ bl_0 br_0 bl_1 br_1 bl_2 br_2 bl_3 br_3 bl_4 br_4 bl_5 br_5 bl_6 br_6
+ bl_7 br_7 bl_8 br_8 bl_9 br_9 bl_10 br_10 bl_11 br_11 bl_12 br_12
+ bl_13 br_13 bl_14 br_14 bl_15 br_15 bl_16 br_16 bl_17 br_17 bl_18
+ br_18 bl_19 br_19 bl_20 br_20 bl_21 br_21 bl_22 br_22 bl_23 br_23
+ bl_24 br_24 bl_25 br_25 bl_26 br_26 bl_27 br_27 bl_28 br_28 bl_29
+ br_29 bl_30 br_30 bl_31 br_31 bl_32 br_32 bl_33 br_33 bl_34 br_34
+ bl_35 br_35 bl_36 br_36 bl_37 br_37 bl_38 br_38 bl_39 br_39 bl_40
+ br_40 bl_41 br_41 bl_42 br_42 bl_43 br_43 bl_44 br_44 bl_45 br_45
+ bl_46 br_46 bl_47 br_47 bl_48 br_48 bl_49 br_49 bl_50 br_50 bl_51
+ br_51 bl_52 br_52 bl_53 br_53 bl_54 br_54 bl_55 br_55 bl_56 br_56
+ bl_57 br_57 bl_58 br_58 bl_59 br_59 bl_60 br_60 bl_61 br_61 bl_62
+ br_62 bl_63 br_63 bl_64 br_64 bl_65 br_65 bl_66 br_66 bl_67 br_67
+ bl_68 br_68 bl_69 br_69 bl_70 br_70 bl_71 br_71 bl_72 br_72 bl_73
+ br_73 bl_74 br_74 bl_75 br_75 bl_76 br_76 bl_77 br_77 bl_78 br_78
+ bl_79 br_79 bl_80 br_80 bl_81 br_81 bl_82 br_82 bl_83 br_83 bl_84
+ br_84 bl_85 br_85 bl_86 br_86 bl_87 br_87 bl_88 br_88 bl_89 br_89
+ bl_90 br_90 bl_91 br_91 bl_92 br_92 bl_93 br_93 bl_94 br_94 bl_95
+ br_95 bl_96 br_96 bl_97 br_97 bl_98 br_98 bl_99 br_99 bl_100 br_100
+ bl_101 br_101 bl_102 br_102 bl_103 br_103 bl_104 br_104 bl_105 br_105
+ bl_106 br_106 bl_107 br_107 bl_108 br_108 bl_109 br_109 bl_110 br_110
+ bl_111 br_111 bl_112 br_112 bl_113 br_113 bl_114 br_114 bl_115 br_115
+ bl_116 br_116 bl_117 br_117 bl_118 br_118 bl_119 br_119 bl_120 br_120
+ bl_121 br_121 bl_122 br_122 bl_123 br_123 bl_124 br_124 bl_125 br_125
+ bl_126 br_126 bl_127 br_127 bl_128 br_128 bl_129 br_129 bl_130 br_130
+ bl_131 br_131 bl_132 br_132 bl_133 br_133 bl_134 br_134 bl_135 br_135
+ bl_136 br_136 bl_137 br_137 bl_138 br_138 bl_139 br_139 bl_140 br_140
+ bl_141 br_141 bl_142 br_142 bl_143 br_143 bl_144 br_144 bl_145 br_145
+ bl_146 br_146 bl_147 br_147 bl_148 br_148 bl_149 br_149 bl_150 br_150
+ bl_151 br_151 bl_152 br_152 bl_153 br_153 bl_154 br_154 bl_155 br_155
+ bl_156 br_156 bl_157 br_157 bl_158 br_158 bl_159 br_159 bl_160 br_160
+ bl_161 br_161 bl_162 br_162 bl_163 br_163 bl_164 br_164 bl_165 br_165
+ bl_166 br_166 bl_167 br_167 bl_168 br_168 bl_169 br_169 bl_170 br_170
+ bl_171 br_171 bl_172 br_172 bl_173 br_173 bl_174 br_174 bl_175 br_175
+ bl_176 br_176 bl_177 br_177 bl_178 br_178 bl_179 br_179 bl_180 br_180
+ bl_181 br_181 bl_182 br_182 bl_183 br_183 bl_184 br_184 bl_185 br_185
+ bl_186 br_186 bl_187 br_187 bl_188 br_188 bl_189 br_189 bl_190 br_190
+ bl_191 br_191 sel_0 sel_1 sel_2 sel_3 sel_4 sel_5 sel_6 sel_7 bl_out_0
+ br_out_0 bl_out_1 br_out_1 bl_out_2 br_out_2 bl_out_3 br_out_3
+ bl_out_4 br_out_4 bl_out_5 br_out_5 bl_out_6 br_out_6 bl_out_7
+ br_out_7 bl_out_8 br_out_8 bl_out_9 br_out_9 bl_out_10 br_out_10
+ bl_out_11 br_out_11 bl_out_12 br_out_12 bl_out_13 br_out_13 bl_out_14
+ br_out_14 bl_out_15 br_out_15 bl_out_16 br_out_16 bl_out_17 br_out_17
+ bl_out_18 br_out_18 bl_out_19 br_out_19 bl_out_20 br_out_20 bl_out_21
+ br_out_21 bl_out_22 br_out_22 bl_out_23 br_out_23 gnd
+ sky130_sram_1rw_24x128_column_mux_array
.ENDS sky130_sram_1rw_24x128_port_data
* SPICE3 file created from sky130_custom_dummy.ext - technology: sky130A

.subckt sky130_custom_dummy BL BR WL VPWR VGND
X0 a_290_377# a_30_347# VPWR VPWR sky130_fd_pr__pfet_01v8 ad=0.1218p pd=1.42u as=0.0882p ps=0.84u w=0.42u l=0.15u
X1 a_56_159# WL BR VGND sky130_fd_pr__nfet_01v8 ad=0.0777p pd=0.79u as=0.1218p ps=1.42u w=0.42u l=0.15u
X2 a_56_377# a_30_347# VGND VGND sky130_fd_pr__nfet_01v8 ad=0.0756p pd=0.78u as=0.09795p ps=0.915u w=0.42u l=0.15u
X3 VPWR a_30_233# a_290_176# VPWR sky130_fd_pr__pfet_01v8 ad=0.0882p pd=0.84u as=0.1197p ps=1.41u w=0.42u l=0.15u
X4 VGND a_30_233# a_56_159# VGND sky130_fd_pr__nfet_01v8 ad=0.09795p pd=0.915u as=0.0777p ps=0.79u w=0.42u l=0.15u
X5 BL WL a_56_377# VGND sky130_fd_pr__nfet_01v8 ad=0.1428p pd=1.52u as=0.0756p ps=0.78u w=0.42u l=0.15u
.ends

.SUBCKT sky130_sram_1rw_24x128_dummy_array_2
+ bl_0_0 br_0_0 wl_0_0 wl_0_1 wl_0_2 wl_0_3 wl_0_4 wl_0_5 wl_0_6 wl_0_7
+ wl_0_8 wl_0_9 wl_0_10 wl_0_11 wl_0_12 wl_0_13 wl_0_14 wl_0_15 wl_0_16
+ wl_0_17 wl_0_18 wl_0_19 vdd gnd
* INOUT : bl_0_0 
* INOUT : br_0_0 
* INPUT : wl_0_0 
* INPUT : wl_0_1 
* INPUT : wl_0_2 
* INPUT : wl_0_3 
* INPUT : wl_0_4 
* INPUT : wl_0_5 
* INPUT : wl_0_6 
* INPUT : wl_0_7 
* INPUT : wl_0_8 
* INPUT : wl_0_9 
* INPUT : wl_0_10 
* INPUT : wl_0_11 
* INPUT : wl_0_12 
* INPUT : wl_0_13 
* INPUT : wl_0_14 
* INPUT : wl_0_15 
* INPUT : wl_0_16 
* INPUT : wl_0_17 
* INPUT : wl_0_18 
* INPUT : wl_0_19 
* POWER : vdd 
* GROUND: gnd 
Xbit_r0_c0
+ bl_0_0 br_0_0 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r1_c0
+ bl_0_0 br_0_0 wl_0_1 vdd gnd
+ sky130_custom_dummy
Xbit_r2_c0
+ bl_0_0 br_0_0 wl_0_2 vdd gnd
+ sky130_custom_dummy
Xbit_r3_c0
+ bl_0_0 br_0_0 wl_0_3 vdd gnd
+ sky130_custom_dummy
Xbit_r4_c0
+ bl_0_0 br_0_0 wl_0_4 vdd gnd
+ sky130_custom_dummy
Xbit_r5_c0
+ bl_0_0 br_0_0 wl_0_5 vdd gnd
+ sky130_custom_dummy
Xbit_r6_c0
+ bl_0_0 br_0_0 wl_0_6 vdd gnd
+ sky130_custom_dummy
Xbit_r7_c0
+ bl_0_0 br_0_0 wl_0_7 vdd gnd
+ sky130_custom_dummy
Xbit_r8_c0
+ bl_0_0 br_0_0 wl_0_8 vdd gnd
+ sky130_custom_dummy
Xbit_r9_c0
+ bl_0_0 br_0_0 wl_0_9 vdd gnd
+ sky130_custom_dummy
Xbit_r10_c0
+ bl_0_0 br_0_0 wl_0_10 vdd gnd
+ sky130_custom_dummy
Xbit_r11_c0
+ bl_0_0 br_0_0 wl_0_11 vdd gnd
+ sky130_custom_dummy
Xbit_r12_c0
+ bl_0_0 br_0_0 wl_0_12 vdd gnd
+ sky130_custom_dummy
Xbit_r13_c0
+ bl_0_0 br_0_0 wl_0_13 vdd gnd
+ sky130_custom_dummy
Xbit_r14_c0
+ bl_0_0 br_0_0 wl_0_14 vdd gnd
+ sky130_custom_dummy
Xbit_r15_c0
+ bl_0_0 br_0_0 wl_0_15 vdd gnd
+ sky130_custom_dummy
Xbit_r16_c0
+ bl_0_0 br_0_0 wl_0_16 vdd gnd
+ sky130_custom_dummy
Xbit_r17_c0
+ bl_0_0 br_0_0 wl_0_17 vdd gnd
+ sky130_custom_dummy
Xbit_r18_c0
+ bl_0_0 br_0_0 wl_0_18 vdd gnd
+ sky130_custom_dummy
Xbit_r19_c0
+ bl_0_0 br_0_0 wl_0_19 vdd gnd
+ sky130_custom_dummy
.ENDS sky130_sram_1rw_24x128_dummy_array_2
* SPICE3 file created from sky130_custom_replica.ext - technology: sky130A

.subckt sky130_custom_replica BL BR WL VPWR VGND
X0 BL WL Q VGND sky130_fd_pr__nfet_01v8 ad=0.1428p pd=1.52u as=0.0756p ps=0.78u w=0.42u l=0.15u
X1 VGND Q VPWR VGND sky130_fd_pr__nfet_01v8 ad=0.09795p pd=0.915u as=0.0777p ps=0.79u w=0.42u l=0.15u
X2 VPWR WL BR VGND sky130_fd_pr__nfet_01v8 ad=0.0777p pd=0.79u as=0.1218p ps=1.42u w=0.42u l=0.15u
X3 VPWR Q VPWR VPWR sky130_fd_pr__pfet_01v8 ad=0.0882p pd=0.84u as=0.2961p ps=3.09u w=0.42u l=0.15u
X4 Q VPWR VPWR VPWR sky130_fd_pr__pfet_01v8 ad=0.1218p pd=1.42u as=0.0882p ps=0.84u w=0.42u l=0.15u
X5 Q VPWR VGND VGND sky130_fd_pr__nfet_01v8 ad=0.0756p pd=0.78u as=0.09795p ps=0.915u w=0.42u l=0.15u
.ends

.SUBCKT sky130_sram_1rw_24x128_replica_column
+ bl_0_0 br_0_0 wl_0_0 wl_0_1 wl_0_2 wl_0_3 wl_0_4 wl_0_5 wl_0_6 wl_0_7
+ wl_0_8 wl_0_9 wl_0_10 wl_0_11 wl_0_12 wl_0_13 wl_0_14 wl_0_15 wl_0_16
+ wl_0_17 vdd gnd
* OUTPUT: bl_0_0 
* OUTPUT: br_0_0 
* INPUT : wl_0_0 
* INPUT : wl_0_1 
* INPUT : wl_0_2 
* INPUT : wl_0_3 
* INPUT : wl_0_4 
* INPUT : wl_0_5 
* INPUT : wl_0_6 
* INPUT : wl_0_7 
* INPUT : wl_0_8 
* INPUT : wl_0_9 
* INPUT : wl_0_10 
* INPUT : wl_0_11 
* INPUT : wl_0_12 
* INPUT : wl_0_13 
* INPUT : wl_0_14 
* INPUT : wl_0_15 
* INPUT : wl_0_16 
* INPUT : wl_0_17 
* POWER : vdd 
* GROUND: gnd 
Xrbc_r0_c0
+ bl_0_0 br_0_0 wl_0_0 vdd gnd
+ sky130_custom_replica
Xrbc_r1_c0
+ bl_0_0 br_0_0 wl_0_1 vdd gnd
+ sky130_custom_replica
Xrbc_r2_c0
+ bl_0_0 br_0_0 wl_0_2 vdd gnd
+ sky130_custom_replica
Xrbc_r3_c0
+ bl_0_0 br_0_0 wl_0_3 vdd gnd
+ sky130_custom_replica
Xrbc_r4_c0
+ bl_0_0 br_0_0 wl_0_4 vdd gnd
+ sky130_custom_replica
Xrbc_r5_c0
+ bl_0_0 br_0_0 wl_0_5 vdd gnd
+ sky130_custom_replica
Xrbc_r6_c0
+ bl_0_0 br_0_0 wl_0_6 vdd gnd
+ sky130_custom_replica
Xrbc_r7_c0
+ bl_0_0 br_0_0 wl_0_7 vdd gnd
+ sky130_custom_replica
Xrbc_r8_c0
+ bl_0_0 br_0_0 wl_0_8 vdd gnd
+ sky130_custom_replica
Xrbc_r9_c0
+ bl_0_0 br_0_0 wl_0_9 vdd gnd
+ sky130_custom_replica
Xrbc_r10_c0
+ bl_0_0 br_0_0 wl_0_10 vdd gnd
+ sky130_custom_replica
Xrbc_r11_c0
+ bl_0_0 br_0_0 wl_0_11 vdd gnd
+ sky130_custom_replica
Xrbc_r12_c0
+ bl_0_0 br_0_0 wl_0_12 vdd gnd
+ sky130_custom_replica
Xrbc_r13_c0
+ bl_0_0 br_0_0 wl_0_13 vdd gnd
+ sky130_custom_replica
Xrbc_r14_c0
+ bl_0_0 br_0_0 wl_0_14 vdd gnd
+ sky130_custom_replica
Xrbc_r15_c0
+ bl_0_0 br_0_0 wl_0_15 vdd gnd
+ sky130_custom_replica
Xrbc_r16_c0
+ bl_0_0 br_0_0 wl_0_16 vdd gnd
+ sky130_custom_replica
Xrbc_r17_c0
+ bl_0_0 br_0_0 wl_0_17 vdd gnd
+ sky130_custom_replica
.ENDS sky130_sram_1rw_24x128_replica_column

.SUBCKT sky130_sram_1rw_24x128_dummy_array
+ bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3 br_0_3 bl_0_4 br_0_4
+ bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8 br_0_8 bl_0_9 br_0_9
+ bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12 bl_0_13 br_0_13
+ bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16 bl_0_17 br_0_17
+ bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20 bl_0_21 br_0_21
+ bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24 bl_0_25 br_0_25
+ bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28 bl_0_29 br_0_29
+ bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32 bl_0_33 br_0_33
+ bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36 bl_0_37 br_0_37
+ bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40 bl_0_41 br_0_41
+ bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44 bl_0_45 br_0_45
+ bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48 bl_0_49 br_0_49
+ bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52 bl_0_53 br_0_53
+ bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56 bl_0_57 br_0_57
+ bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60 bl_0_61 br_0_61
+ bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64 bl_0_65 br_0_65
+ bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68 bl_0_69 br_0_69
+ bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72 bl_0_73 br_0_73
+ bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76 bl_0_77 br_0_77
+ bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80 bl_0_81 br_0_81
+ bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84 bl_0_85 br_0_85
+ bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88 bl_0_89 br_0_89
+ bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92 bl_0_93 br_0_93
+ bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96 bl_0_97 br_0_97
+ bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100 bl_0_101 br_0_101
+ bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104 br_0_104 bl_0_105
+ br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107 bl_0_108 br_0_108
+ bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111 br_0_111 bl_0_112
+ br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114 bl_0_115 br_0_115
+ bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118 br_0_118 bl_0_119
+ br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121 bl_0_122 br_0_122
+ bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125 br_0_125 bl_0_126
+ br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128 bl_0_129 br_0_129
+ bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132 br_0_132 bl_0_133
+ br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135 bl_0_136 br_0_136
+ bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139 br_0_139 bl_0_140
+ br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142 bl_0_143 br_0_143
+ bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146 br_0_146 bl_0_147
+ br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149 bl_0_150 br_0_150
+ bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153 br_0_153 bl_0_154
+ br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156 bl_0_157 br_0_157
+ bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160 br_0_160 bl_0_161
+ br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163 bl_0_164 br_0_164
+ bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167 br_0_167 bl_0_168
+ br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170 bl_0_171 br_0_171
+ bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174 br_0_174 bl_0_175
+ br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177 bl_0_178 br_0_178
+ bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181 br_0_181 bl_0_182
+ br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184 bl_0_185 br_0_185
+ bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188 br_0_188 bl_0_189
+ br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191 bl_0_192 br_0_192 wl_0_0
+ vdd gnd
* INOUT : bl_0_0 
* INOUT : br_0_0 
* INOUT : bl_0_1 
* INOUT : br_0_1 
* INOUT : bl_0_2 
* INOUT : br_0_2 
* INOUT : bl_0_3 
* INOUT : br_0_3 
* INOUT : bl_0_4 
* INOUT : br_0_4 
* INOUT : bl_0_5 
* INOUT : br_0_5 
* INOUT : bl_0_6 
* INOUT : br_0_6 
* INOUT : bl_0_7 
* INOUT : br_0_7 
* INOUT : bl_0_8 
* INOUT : br_0_8 
* INOUT : bl_0_9 
* INOUT : br_0_9 
* INOUT : bl_0_10 
* INOUT : br_0_10 
* INOUT : bl_0_11 
* INOUT : br_0_11 
* INOUT : bl_0_12 
* INOUT : br_0_12 
* INOUT : bl_0_13 
* INOUT : br_0_13 
* INOUT : bl_0_14 
* INOUT : br_0_14 
* INOUT : bl_0_15 
* INOUT : br_0_15 
* INOUT : bl_0_16 
* INOUT : br_0_16 
* INOUT : bl_0_17 
* INOUT : br_0_17 
* INOUT : bl_0_18 
* INOUT : br_0_18 
* INOUT : bl_0_19 
* INOUT : br_0_19 
* INOUT : bl_0_20 
* INOUT : br_0_20 
* INOUT : bl_0_21 
* INOUT : br_0_21 
* INOUT : bl_0_22 
* INOUT : br_0_22 
* INOUT : bl_0_23 
* INOUT : br_0_23 
* INOUT : bl_0_24 
* INOUT : br_0_24 
* INOUT : bl_0_25 
* INOUT : br_0_25 
* INOUT : bl_0_26 
* INOUT : br_0_26 
* INOUT : bl_0_27 
* INOUT : br_0_27 
* INOUT : bl_0_28 
* INOUT : br_0_28 
* INOUT : bl_0_29 
* INOUT : br_0_29 
* INOUT : bl_0_30 
* INOUT : br_0_30 
* INOUT : bl_0_31 
* INOUT : br_0_31 
* INOUT : bl_0_32 
* INOUT : br_0_32 
* INOUT : bl_0_33 
* INOUT : br_0_33 
* INOUT : bl_0_34 
* INOUT : br_0_34 
* INOUT : bl_0_35 
* INOUT : br_0_35 
* INOUT : bl_0_36 
* INOUT : br_0_36 
* INOUT : bl_0_37 
* INOUT : br_0_37 
* INOUT : bl_0_38 
* INOUT : br_0_38 
* INOUT : bl_0_39 
* INOUT : br_0_39 
* INOUT : bl_0_40 
* INOUT : br_0_40 
* INOUT : bl_0_41 
* INOUT : br_0_41 
* INOUT : bl_0_42 
* INOUT : br_0_42 
* INOUT : bl_0_43 
* INOUT : br_0_43 
* INOUT : bl_0_44 
* INOUT : br_0_44 
* INOUT : bl_0_45 
* INOUT : br_0_45 
* INOUT : bl_0_46 
* INOUT : br_0_46 
* INOUT : bl_0_47 
* INOUT : br_0_47 
* INOUT : bl_0_48 
* INOUT : br_0_48 
* INOUT : bl_0_49 
* INOUT : br_0_49 
* INOUT : bl_0_50 
* INOUT : br_0_50 
* INOUT : bl_0_51 
* INOUT : br_0_51 
* INOUT : bl_0_52 
* INOUT : br_0_52 
* INOUT : bl_0_53 
* INOUT : br_0_53 
* INOUT : bl_0_54 
* INOUT : br_0_54 
* INOUT : bl_0_55 
* INOUT : br_0_55 
* INOUT : bl_0_56 
* INOUT : br_0_56 
* INOUT : bl_0_57 
* INOUT : br_0_57 
* INOUT : bl_0_58 
* INOUT : br_0_58 
* INOUT : bl_0_59 
* INOUT : br_0_59 
* INOUT : bl_0_60 
* INOUT : br_0_60 
* INOUT : bl_0_61 
* INOUT : br_0_61 
* INOUT : bl_0_62 
* INOUT : br_0_62 
* INOUT : bl_0_63 
* INOUT : br_0_63 
* INOUT : bl_0_64 
* INOUT : br_0_64 
* INOUT : bl_0_65 
* INOUT : br_0_65 
* INOUT : bl_0_66 
* INOUT : br_0_66 
* INOUT : bl_0_67 
* INOUT : br_0_67 
* INOUT : bl_0_68 
* INOUT : br_0_68 
* INOUT : bl_0_69 
* INOUT : br_0_69 
* INOUT : bl_0_70 
* INOUT : br_0_70 
* INOUT : bl_0_71 
* INOUT : br_0_71 
* INOUT : bl_0_72 
* INOUT : br_0_72 
* INOUT : bl_0_73 
* INOUT : br_0_73 
* INOUT : bl_0_74 
* INOUT : br_0_74 
* INOUT : bl_0_75 
* INOUT : br_0_75 
* INOUT : bl_0_76 
* INOUT : br_0_76 
* INOUT : bl_0_77 
* INOUT : br_0_77 
* INOUT : bl_0_78 
* INOUT : br_0_78 
* INOUT : bl_0_79 
* INOUT : br_0_79 
* INOUT : bl_0_80 
* INOUT : br_0_80 
* INOUT : bl_0_81 
* INOUT : br_0_81 
* INOUT : bl_0_82 
* INOUT : br_0_82 
* INOUT : bl_0_83 
* INOUT : br_0_83 
* INOUT : bl_0_84 
* INOUT : br_0_84 
* INOUT : bl_0_85 
* INOUT : br_0_85 
* INOUT : bl_0_86 
* INOUT : br_0_86 
* INOUT : bl_0_87 
* INOUT : br_0_87 
* INOUT : bl_0_88 
* INOUT : br_0_88 
* INOUT : bl_0_89 
* INOUT : br_0_89 
* INOUT : bl_0_90 
* INOUT : br_0_90 
* INOUT : bl_0_91 
* INOUT : br_0_91 
* INOUT : bl_0_92 
* INOUT : br_0_92 
* INOUT : bl_0_93 
* INOUT : br_0_93 
* INOUT : bl_0_94 
* INOUT : br_0_94 
* INOUT : bl_0_95 
* INOUT : br_0_95 
* INOUT : bl_0_96 
* INOUT : br_0_96 
* INOUT : bl_0_97 
* INOUT : br_0_97 
* INOUT : bl_0_98 
* INOUT : br_0_98 
* INOUT : bl_0_99 
* INOUT : br_0_99 
* INOUT : bl_0_100 
* INOUT : br_0_100 
* INOUT : bl_0_101 
* INOUT : br_0_101 
* INOUT : bl_0_102 
* INOUT : br_0_102 
* INOUT : bl_0_103 
* INOUT : br_0_103 
* INOUT : bl_0_104 
* INOUT : br_0_104 
* INOUT : bl_0_105 
* INOUT : br_0_105 
* INOUT : bl_0_106 
* INOUT : br_0_106 
* INOUT : bl_0_107 
* INOUT : br_0_107 
* INOUT : bl_0_108 
* INOUT : br_0_108 
* INOUT : bl_0_109 
* INOUT : br_0_109 
* INOUT : bl_0_110 
* INOUT : br_0_110 
* INOUT : bl_0_111 
* INOUT : br_0_111 
* INOUT : bl_0_112 
* INOUT : br_0_112 
* INOUT : bl_0_113 
* INOUT : br_0_113 
* INOUT : bl_0_114 
* INOUT : br_0_114 
* INOUT : bl_0_115 
* INOUT : br_0_115 
* INOUT : bl_0_116 
* INOUT : br_0_116 
* INOUT : bl_0_117 
* INOUT : br_0_117 
* INOUT : bl_0_118 
* INOUT : br_0_118 
* INOUT : bl_0_119 
* INOUT : br_0_119 
* INOUT : bl_0_120 
* INOUT : br_0_120 
* INOUT : bl_0_121 
* INOUT : br_0_121 
* INOUT : bl_0_122 
* INOUT : br_0_122 
* INOUT : bl_0_123 
* INOUT : br_0_123 
* INOUT : bl_0_124 
* INOUT : br_0_124 
* INOUT : bl_0_125 
* INOUT : br_0_125 
* INOUT : bl_0_126 
* INOUT : br_0_126 
* INOUT : bl_0_127 
* INOUT : br_0_127 
* INOUT : bl_0_128 
* INOUT : br_0_128 
* INOUT : bl_0_129 
* INOUT : br_0_129 
* INOUT : bl_0_130 
* INOUT : br_0_130 
* INOUT : bl_0_131 
* INOUT : br_0_131 
* INOUT : bl_0_132 
* INOUT : br_0_132 
* INOUT : bl_0_133 
* INOUT : br_0_133 
* INOUT : bl_0_134 
* INOUT : br_0_134 
* INOUT : bl_0_135 
* INOUT : br_0_135 
* INOUT : bl_0_136 
* INOUT : br_0_136 
* INOUT : bl_0_137 
* INOUT : br_0_137 
* INOUT : bl_0_138 
* INOUT : br_0_138 
* INOUT : bl_0_139 
* INOUT : br_0_139 
* INOUT : bl_0_140 
* INOUT : br_0_140 
* INOUT : bl_0_141 
* INOUT : br_0_141 
* INOUT : bl_0_142 
* INOUT : br_0_142 
* INOUT : bl_0_143 
* INOUT : br_0_143 
* INOUT : bl_0_144 
* INOUT : br_0_144 
* INOUT : bl_0_145 
* INOUT : br_0_145 
* INOUT : bl_0_146 
* INOUT : br_0_146 
* INOUT : bl_0_147 
* INOUT : br_0_147 
* INOUT : bl_0_148 
* INOUT : br_0_148 
* INOUT : bl_0_149 
* INOUT : br_0_149 
* INOUT : bl_0_150 
* INOUT : br_0_150 
* INOUT : bl_0_151 
* INOUT : br_0_151 
* INOUT : bl_0_152 
* INOUT : br_0_152 
* INOUT : bl_0_153 
* INOUT : br_0_153 
* INOUT : bl_0_154 
* INOUT : br_0_154 
* INOUT : bl_0_155 
* INOUT : br_0_155 
* INOUT : bl_0_156 
* INOUT : br_0_156 
* INOUT : bl_0_157 
* INOUT : br_0_157 
* INOUT : bl_0_158 
* INOUT : br_0_158 
* INOUT : bl_0_159 
* INOUT : br_0_159 
* INOUT : bl_0_160 
* INOUT : br_0_160 
* INOUT : bl_0_161 
* INOUT : br_0_161 
* INOUT : bl_0_162 
* INOUT : br_0_162 
* INOUT : bl_0_163 
* INOUT : br_0_163 
* INOUT : bl_0_164 
* INOUT : br_0_164 
* INOUT : bl_0_165 
* INOUT : br_0_165 
* INOUT : bl_0_166 
* INOUT : br_0_166 
* INOUT : bl_0_167 
* INOUT : br_0_167 
* INOUT : bl_0_168 
* INOUT : br_0_168 
* INOUT : bl_0_169 
* INOUT : br_0_169 
* INOUT : bl_0_170 
* INOUT : br_0_170 
* INOUT : bl_0_171 
* INOUT : br_0_171 
* INOUT : bl_0_172 
* INOUT : br_0_172 
* INOUT : bl_0_173 
* INOUT : br_0_173 
* INOUT : bl_0_174 
* INOUT : br_0_174 
* INOUT : bl_0_175 
* INOUT : br_0_175 
* INOUT : bl_0_176 
* INOUT : br_0_176 
* INOUT : bl_0_177 
* INOUT : br_0_177 
* INOUT : bl_0_178 
* INOUT : br_0_178 
* INOUT : bl_0_179 
* INOUT : br_0_179 
* INOUT : bl_0_180 
* INOUT : br_0_180 
* INOUT : bl_0_181 
* INOUT : br_0_181 
* INOUT : bl_0_182 
* INOUT : br_0_182 
* INOUT : bl_0_183 
* INOUT : br_0_183 
* INOUT : bl_0_184 
* INOUT : br_0_184 
* INOUT : bl_0_185 
* INOUT : br_0_185 
* INOUT : bl_0_186 
* INOUT : br_0_186 
* INOUT : bl_0_187 
* INOUT : br_0_187 
* INOUT : bl_0_188 
* INOUT : br_0_188 
* INOUT : bl_0_189 
* INOUT : br_0_189 
* INOUT : bl_0_190 
* INOUT : br_0_190 
* INOUT : bl_0_191 
* INOUT : br_0_191 
* INOUT : bl_0_192 
* INOUT : br_0_192 
* INPUT : wl_0_0 
* POWER : vdd 
* GROUND: gnd 
Xbit_r0_c0
+ bl_0_0 br_0_0 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c1
+ bl_0_1 br_0_1 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c2
+ bl_0_2 br_0_2 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c3
+ bl_0_3 br_0_3 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c4
+ bl_0_4 br_0_4 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c5
+ bl_0_5 br_0_5 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c6
+ bl_0_6 br_0_6 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c7
+ bl_0_7 br_0_7 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c8
+ bl_0_8 br_0_8 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c9
+ bl_0_9 br_0_9 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c10
+ bl_0_10 br_0_10 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c11
+ bl_0_11 br_0_11 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c12
+ bl_0_12 br_0_12 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c13
+ bl_0_13 br_0_13 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c14
+ bl_0_14 br_0_14 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c15
+ bl_0_15 br_0_15 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c16
+ bl_0_16 br_0_16 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c17
+ bl_0_17 br_0_17 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c18
+ bl_0_18 br_0_18 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c19
+ bl_0_19 br_0_19 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c20
+ bl_0_20 br_0_20 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c21
+ bl_0_21 br_0_21 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c22
+ bl_0_22 br_0_22 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c23
+ bl_0_23 br_0_23 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c24
+ bl_0_24 br_0_24 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c25
+ bl_0_25 br_0_25 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c26
+ bl_0_26 br_0_26 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c27
+ bl_0_27 br_0_27 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c28
+ bl_0_28 br_0_28 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c29
+ bl_0_29 br_0_29 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c30
+ bl_0_30 br_0_30 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c31
+ bl_0_31 br_0_31 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c32
+ bl_0_32 br_0_32 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c33
+ bl_0_33 br_0_33 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c34
+ bl_0_34 br_0_34 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c35
+ bl_0_35 br_0_35 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c36
+ bl_0_36 br_0_36 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c37
+ bl_0_37 br_0_37 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c38
+ bl_0_38 br_0_38 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c39
+ bl_0_39 br_0_39 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c40
+ bl_0_40 br_0_40 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c41
+ bl_0_41 br_0_41 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c42
+ bl_0_42 br_0_42 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c43
+ bl_0_43 br_0_43 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c44
+ bl_0_44 br_0_44 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c45
+ bl_0_45 br_0_45 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c46
+ bl_0_46 br_0_46 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c47
+ bl_0_47 br_0_47 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c48
+ bl_0_48 br_0_48 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c49
+ bl_0_49 br_0_49 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c50
+ bl_0_50 br_0_50 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c51
+ bl_0_51 br_0_51 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c52
+ bl_0_52 br_0_52 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c53
+ bl_0_53 br_0_53 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c54
+ bl_0_54 br_0_54 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c55
+ bl_0_55 br_0_55 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c56
+ bl_0_56 br_0_56 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c57
+ bl_0_57 br_0_57 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c58
+ bl_0_58 br_0_58 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c59
+ bl_0_59 br_0_59 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c60
+ bl_0_60 br_0_60 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c61
+ bl_0_61 br_0_61 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c62
+ bl_0_62 br_0_62 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c63
+ bl_0_63 br_0_63 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c64
+ bl_0_64 br_0_64 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c65
+ bl_0_65 br_0_65 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c66
+ bl_0_66 br_0_66 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c67
+ bl_0_67 br_0_67 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c68
+ bl_0_68 br_0_68 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c69
+ bl_0_69 br_0_69 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c70
+ bl_0_70 br_0_70 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c71
+ bl_0_71 br_0_71 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c72
+ bl_0_72 br_0_72 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c73
+ bl_0_73 br_0_73 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c74
+ bl_0_74 br_0_74 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c75
+ bl_0_75 br_0_75 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c76
+ bl_0_76 br_0_76 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c77
+ bl_0_77 br_0_77 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c78
+ bl_0_78 br_0_78 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c79
+ bl_0_79 br_0_79 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c80
+ bl_0_80 br_0_80 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c81
+ bl_0_81 br_0_81 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c82
+ bl_0_82 br_0_82 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c83
+ bl_0_83 br_0_83 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c84
+ bl_0_84 br_0_84 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c85
+ bl_0_85 br_0_85 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c86
+ bl_0_86 br_0_86 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c87
+ bl_0_87 br_0_87 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c88
+ bl_0_88 br_0_88 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c89
+ bl_0_89 br_0_89 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c90
+ bl_0_90 br_0_90 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c91
+ bl_0_91 br_0_91 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c92
+ bl_0_92 br_0_92 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c93
+ bl_0_93 br_0_93 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c94
+ bl_0_94 br_0_94 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c95
+ bl_0_95 br_0_95 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c96
+ bl_0_96 br_0_96 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c97
+ bl_0_97 br_0_97 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c98
+ bl_0_98 br_0_98 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c99
+ bl_0_99 br_0_99 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c100
+ bl_0_100 br_0_100 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c101
+ bl_0_101 br_0_101 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c102
+ bl_0_102 br_0_102 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c103
+ bl_0_103 br_0_103 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c104
+ bl_0_104 br_0_104 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c105
+ bl_0_105 br_0_105 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c106
+ bl_0_106 br_0_106 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c107
+ bl_0_107 br_0_107 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c108
+ bl_0_108 br_0_108 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c109
+ bl_0_109 br_0_109 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c110
+ bl_0_110 br_0_110 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c111
+ bl_0_111 br_0_111 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c112
+ bl_0_112 br_0_112 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c113
+ bl_0_113 br_0_113 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c114
+ bl_0_114 br_0_114 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c115
+ bl_0_115 br_0_115 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c116
+ bl_0_116 br_0_116 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c117
+ bl_0_117 br_0_117 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c118
+ bl_0_118 br_0_118 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c119
+ bl_0_119 br_0_119 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c120
+ bl_0_120 br_0_120 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c121
+ bl_0_121 br_0_121 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c122
+ bl_0_122 br_0_122 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c123
+ bl_0_123 br_0_123 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c124
+ bl_0_124 br_0_124 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c125
+ bl_0_125 br_0_125 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c126
+ bl_0_126 br_0_126 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c127
+ bl_0_127 br_0_127 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c128
+ bl_0_128 br_0_128 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c129
+ bl_0_129 br_0_129 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c130
+ bl_0_130 br_0_130 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c131
+ bl_0_131 br_0_131 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c132
+ bl_0_132 br_0_132 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c133
+ bl_0_133 br_0_133 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c134
+ bl_0_134 br_0_134 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c135
+ bl_0_135 br_0_135 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c136
+ bl_0_136 br_0_136 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c137
+ bl_0_137 br_0_137 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c138
+ bl_0_138 br_0_138 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c139
+ bl_0_139 br_0_139 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c140
+ bl_0_140 br_0_140 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c141
+ bl_0_141 br_0_141 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c142
+ bl_0_142 br_0_142 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c143
+ bl_0_143 br_0_143 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c144
+ bl_0_144 br_0_144 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c145
+ bl_0_145 br_0_145 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c146
+ bl_0_146 br_0_146 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c147
+ bl_0_147 br_0_147 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c148
+ bl_0_148 br_0_148 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c149
+ bl_0_149 br_0_149 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c150
+ bl_0_150 br_0_150 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c151
+ bl_0_151 br_0_151 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c152
+ bl_0_152 br_0_152 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c153
+ bl_0_153 br_0_153 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c154
+ bl_0_154 br_0_154 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c155
+ bl_0_155 br_0_155 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c156
+ bl_0_156 br_0_156 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c157
+ bl_0_157 br_0_157 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c158
+ bl_0_158 br_0_158 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c159
+ bl_0_159 br_0_159 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c160
+ bl_0_160 br_0_160 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c161
+ bl_0_161 br_0_161 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c162
+ bl_0_162 br_0_162 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c163
+ bl_0_163 br_0_163 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c164
+ bl_0_164 br_0_164 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c165
+ bl_0_165 br_0_165 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c166
+ bl_0_166 br_0_166 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c167
+ bl_0_167 br_0_167 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c168
+ bl_0_168 br_0_168 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c169
+ bl_0_169 br_0_169 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c170
+ bl_0_170 br_0_170 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c171
+ bl_0_171 br_0_171 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c172
+ bl_0_172 br_0_172 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c173
+ bl_0_173 br_0_173 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c174
+ bl_0_174 br_0_174 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c175
+ bl_0_175 br_0_175 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c176
+ bl_0_176 br_0_176 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c177
+ bl_0_177 br_0_177 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c178
+ bl_0_178 br_0_178 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c179
+ bl_0_179 br_0_179 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c180
+ bl_0_180 br_0_180 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c181
+ bl_0_181 br_0_181 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c182
+ bl_0_182 br_0_182 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c183
+ bl_0_183 br_0_183 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c184
+ bl_0_184 br_0_184 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c185
+ bl_0_185 br_0_185 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c186
+ bl_0_186 br_0_186 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c187
+ bl_0_187 br_0_187 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c188
+ bl_0_188 br_0_188 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c189
+ bl_0_189 br_0_189 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c190
+ bl_0_190 br_0_190 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c191
+ bl_0_191 br_0_191 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c192
+ bl_0_192 br_0_192 wl_0_0 vdd gnd
+ sky130_custom_dummy
.ENDS sky130_sram_1rw_24x128_dummy_array
* SPICE3 file created from sky130_custom_cell.ext - technology: sky130A

.subckt sky130_custom_cell BL BR WL VPWR VGND
X1 VGND Q Qbar VGND sky130_fd_pr__nfet_01v8 ad=0.09795p pd=0.915u as=0.0777p ps=0.79u w=0.42u l=0.15u
X3 VPWR Q Qbar VPWR sky130_fd_pr__pfet_01v8 ad=0.0882p pd=0.84u as=0.1197p ps=1.41u w=0.42u l=0.15u
X4 Q Qbar VPWR VPWR sky130_fd_pr__pfet_01v8 ad=0.1218p pd=1.42u as=0.0882p ps=0.84u w=0.42u l=0.15u
X5 Q Qbar VGND VGND sky130_fd_pr__nfet_01v8 ad=0.0756p pd=0.78u as=0.09795p ps=0.915u w=0.42u l=0.15u

X0 BL WL Q VGND sky130_fd_pr__nfet_01v8 ad=0.1428p pd=1.52u as=0.0756p ps=0.78u w=0.42u l=0.15u
X2 Qbar WL BR VGND sky130_fd_pr__nfet_01v8 ad=0.0777p pd=0.79u as=0.1218p ps=1.42u w=0.42u l=0.15u

.ends

.SUBCKT sky130_sram_1rw_24x128_bitcell_array
+ bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3 br_0_3 bl_0_4 br_0_4
+ bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8 br_0_8 bl_0_9 br_0_9
+ bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12 bl_0_13 br_0_13
+ bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16 bl_0_17 br_0_17
+ bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20 bl_0_21 br_0_21
+ bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24 bl_0_25 br_0_25
+ bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28 bl_0_29 br_0_29
+ bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32 bl_0_33 br_0_33
+ bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36 bl_0_37 br_0_37
+ bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40 bl_0_41 br_0_41
+ bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44 bl_0_45 br_0_45
+ bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48 bl_0_49 br_0_49
+ bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52 bl_0_53 br_0_53
+ bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56 bl_0_57 br_0_57
+ bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60 bl_0_61 br_0_61
+ bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64 bl_0_65 br_0_65
+ bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68 bl_0_69 br_0_69
+ bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72 bl_0_73 br_0_73
+ bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76 bl_0_77 br_0_77
+ bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80 bl_0_81 br_0_81
+ bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84 bl_0_85 br_0_85
+ bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88 bl_0_89 br_0_89
+ bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92 bl_0_93 br_0_93
+ bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96 bl_0_97 br_0_97
+ bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100 bl_0_101 br_0_101
+ bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104 br_0_104 bl_0_105
+ br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107 bl_0_108 br_0_108
+ bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111 br_0_111 bl_0_112
+ br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114 bl_0_115 br_0_115
+ bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118 br_0_118 bl_0_119
+ br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121 bl_0_122 br_0_122
+ bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125 br_0_125 bl_0_126
+ br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128 bl_0_129 br_0_129
+ bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132 br_0_132 bl_0_133
+ br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135 bl_0_136 br_0_136
+ bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139 br_0_139 bl_0_140
+ br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142 bl_0_143 br_0_143
+ bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146 br_0_146 bl_0_147
+ br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149 bl_0_150 br_0_150
+ bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153 br_0_153 bl_0_154
+ br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156 bl_0_157 br_0_157
+ bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160 br_0_160 bl_0_161
+ br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163 bl_0_164 br_0_164
+ bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167 br_0_167 bl_0_168
+ br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170 bl_0_171 br_0_171
+ bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174 br_0_174 bl_0_175
+ br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177 bl_0_178 br_0_178
+ bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181 br_0_181 bl_0_182
+ br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184 bl_0_185 br_0_185
+ bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188 br_0_188 bl_0_189
+ br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191 bl_0_192 br_0_192 wl_0_0
+ wl_0_1 wl_0_2 wl_0_3 wl_0_4 wl_0_5 wl_0_6 wl_0_7 wl_0_8 wl_0_9 wl_0_10
+ wl_0_11 wl_0_12 wl_0_13 wl_0_14 wl_0_15 wl_0_16 vdd gnd
* INOUT : bl_0_0 
* INOUT : br_0_0 
* INOUT : bl_0_1 
* INOUT : br_0_1 
* INOUT : bl_0_2 
* INOUT : br_0_2 
* INOUT : bl_0_3 
* INOUT : br_0_3 
* INOUT : bl_0_4 
* INOUT : br_0_4 
* INOUT : bl_0_5 
* INOUT : br_0_5 
* INOUT : bl_0_6 
* INOUT : br_0_6 
* INOUT : bl_0_7 
* INOUT : br_0_7 
* INOUT : bl_0_8 
* INOUT : br_0_8 
* INOUT : bl_0_9 
* INOUT : br_0_9 
* INOUT : bl_0_10 
* INOUT : br_0_10 
* INOUT : bl_0_11 
* INOUT : br_0_11 
* INOUT : bl_0_12 
* INOUT : br_0_12 
* INOUT : bl_0_13 
* INOUT : br_0_13 
* INOUT : bl_0_14 
* INOUT : br_0_14 
* INOUT : bl_0_15 
* INOUT : br_0_15 
* INOUT : bl_0_16 
* INOUT : br_0_16 
* INOUT : bl_0_17 
* INOUT : br_0_17 
* INOUT : bl_0_18 
* INOUT : br_0_18 
* INOUT : bl_0_19 
* INOUT : br_0_19 
* INOUT : bl_0_20 
* INOUT : br_0_20 
* INOUT : bl_0_21 
* INOUT : br_0_21 
* INOUT : bl_0_22 
* INOUT : br_0_22 
* INOUT : bl_0_23 
* INOUT : br_0_23 
* INOUT : bl_0_24 
* INOUT : br_0_24 
* INOUT : bl_0_25 
* INOUT : br_0_25 
* INOUT : bl_0_26 
* INOUT : br_0_26 
* INOUT : bl_0_27 
* INOUT : br_0_27 
* INOUT : bl_0_28 
* INOUT : br_0_28 
* INOUT : bl_0_29 
* INOUT : br_0_29 
* INOUT : bl_0_30 
* INOUT : br_0_30 
* INOUT : bl_0_31 
* INOUT : br_0_31 
* INOUT : bl_0_32 
* INOUT : br_0_32 
* INOUT : bl_0_33 
* INOUT : br_0_33 
* INOUT : bl_0_34 
* INOUT : br_0_34 
* INOUT : bl_0_35 
* INOUT : br_0_35 
* INOUT : bl_0_36 
* INOUT : br_0_36 
* INOUT : bl_0_37 
* INOUT : br_0_37 
* INOUT : bl_0_38 
* INOUT : br_0_38 
* INOUT : bl_0_39 
* INOUT : br_0_39 
* INOUT : bl_0_40 
* INOUT : br_0_40 
* INOUT : bl_0_41 
* INOUT : br_0_41 
* INOUT : bl_0_42 
* INOUT : br_0_42 
* INOUT : bl_0_43 
* INOUT : br_0_43 
* INOUT : bl_0_44 
* INOUT : br_0_44 
* INOUT : bl_0_45 
* INOUT : br_0_45 
* INOUT : bl_0_46 
* INOUT : br_0_46 
* INOUT : bl_0_47 
* INOUT : br_0_47 
* INOUT : bl_0_48 
* INOUT : br_0_48 
* INOUT : bl_0_49 
* INOUT : br_0_49 
* INOUT : bl_0_50 
* INOUT : br_0_50 
* INOUT : bl_0_51 
* INOUT : br_0_51 
* INOUT : bl_0_52 
* INOUT : br_0_52 
* INOUT : bl_0_53 
* INOUT : br_0_53 
* INOUT : bl_0_54 
* INOUT : br_0_54 
* INOUT : bl_0_55 
* INOUT : br_0_55 
* INOUT : bl_0_56 
* INOUT : br_0_56 
* INOUT : bl_0_57 
* INOUT : br_0_57 
* INOUT : bl_0_58 
* INOUT : br_0_58 
* INOUT : bl_0_59 
* INOUT : br_0_59 
* INOUT : bl_0_60 
* INOUT : br_0_60 
* INOUT : bl_0_61 
* INOUT : br_0_61 
* INOUT : bl_0_62 
* INOUT : br_0_62 
* INOUT : bl_0_63 
* INOUT : br_0_63 
* INOUT : bl_0_64 
* INOUT : br_0_64 
* INOUT : bl_0_65 
* INOUT : br_0_65 
* INOUT : bl_0_66 
* INOUT : br_0_66 
* INOUT : bl_0_67 
* INOUT : br_0_67 
* INOUT : bl_0_68 
* INOUT : br_0_68 
* INOUT : bl_0_69 
* INOUT : br_0_69 
* INOUT : bl_0_70 
* INOUT : br_0_70 
* INOUT : bl_0_71 
* INOUT : br_0_71 
* INOUT : bl_0_72 
* INOUT : br_0_72 
* INOUT : bl_0_73 
* INOUT : br_0_73 
* INOUT : bl_0_74 
* INOUT : br_0_74 
* INOUT : bl_0_75 
* INOUT : br_0_75 
* INOUT : bl_0_76 
* INOUT : br_0_76 
* INOUT : bl_0_77 
* INOUT : br_0_77 
* INOUT : bl_0_78 
* INOUT : br_0_78 
* INOUT : bl_0_79 
* INOUT : br_0_79 
* INOUT : bl_0_80 
* INOUT : br_0_80 
* INOUT : bl_0_81 
* INOUT : br_0_81 
* INOUT : bl_0_82 
* INOUT : br_0_82 
* INOUT : bl_0_83 
* INOUT : br_0_83 
* INOUT : bl_0_84 
* INOUT : br_0_84 
* INOUT : bl_0_85 
* INOUT : br_0_85 
* INOUT : bl_0_86 
* INOUT : br_0_86 
* INOUT : bl_0_87 
* INOUT : br_0_87 
* INOUT : bl_0_88 
* INOUT : br_0_88 
* INOUT : bl_0_89 
* INOUT : br_0_89 
* INOUT : bl_0_90 
* INOUT : br_0_90 
* INOUT : bl_0_91 
* INOUT : br_0_91 
* INOUT : bl_0_92 
* INOUT : br_0_92 
* INOUT : bl_0_93 
* INOUT : br_0_93 
* INOUT : bl_0_94 
* INOUT : br_0_94 
* INOUT : bl_0_95 
* INOUT : br_0_95 
* INOUT : bl_0_96 
* INOUT : br_0_96 
* INOUT : bl_0_97 
* INOUT : br_0_97 
* INOUT : bl_0_98 
* INOUT : br_0_98 
* INOUT : bl_0_99 
* INOUT : br_0_99 
* INOUT : bl_0_100 
* INOUT : br_0_100 
* INOUT : bl_0_101 
* INOUT : br_0_101 
* INOUT : bl_0_102 
* INOUT : br_0_102 
* INOUT : bl_0_103 
* INOUT : br_0_103 
* INOUT : bl_0_104 
* INOUT : br_0_104 
* INOUT : bl_0_105 
* INOUT : br_0_105 
* INOUT : bl_0_106 
* INOUT : br_0_106 
* INOUT : bl_0_107 
* INOUT : br_0_107 
* INOUT : bl_0_108 
* INOUT : br_0_108 
* INOUT : bl_0_109 
* INOUT : br_0_109 
* INOUT : bl_0_110 
* INOUT : br_0_110 
* INOUT : bl_0_111 
* INOUT : br_0_111 
* INOUT : bl_0_112 
* INOUT : br_0_112 
* INOUT : bl_0_113 
* INOUT : br_0_113 
* INOUT : bl_0_114 
* INOUT : br_0_114 
* INOUT : bl_0_115 
* INOUT : br_0_115 
* INOUT : bl_0_116 
* INOUT : br_0_116 
* INOUT : bl_0_117 
* INOUT : br_0_117 
* INOUT : bl_0_118 
* INOUT : br_0_118 
* INOUT : bl_0_119 
* INOUT : br_0_119 
* INOUT : bl_0_120 
* INOUT : br_0_120 
* INOUT : bl_0_121 
* INOUT : br_0_121 
* INOUT : bl_0_122 
* INOUT : br_0_122 
* INOUT : bl_0_123 
* INOUT : br_0_123 
* INOUT : bl_0_124 
* INOUT : br_0_124 
* INOUT : bl_0_125 
* INOUT : br_0_125 
* INOUT : bl_0_126 
* INOUT : br_0_126 
* INOUT : bl_0_127 
* INOUT : br_0_127 
* INOUT : bl_0_128 
* INOUT : br_0_128 
* INOUT : bl_0_129 
* INOUT : br_0_129 
* INOUT : bl_0_130 
* INOUT : br_0_130 
* INOUT : bl_0_131 
* INOUT : br_0_131 
* INOUT : bl_0_132 
* INOUT : br_0_132 
* INOUT : bl_0_133 
* INOUT : br_0_133 
* INOUT : bl_0_134 
* INOUT : br_0_134 
* INOUT : bl_0_135 
* INOUT : br_0_135 
* INOUT : bl_0_136 
* INOUT : br_0_136 
* INOUT : bl_0_137 
* INOUT : br_0_137 
* INOUT : bl_0_138 
* INOUT : br_0_138 
* INOUT : bl_0_139 
* INOUT : br_0_139 
* INOUT : bl_0_140 
* INOUT : br_0_140 
* INOUT : bl_0_141 
* INOUT : br_0_141 
* INOUT : bl_0_142 
* INOUT : br_0_142 
* INOUT : bl_0_143 
* INOUT : br_0_143 
* INOUT : bl_0_144 
* INOUT : br_0_144 
* INOUT : bl_0_145 
* INOUT : br_0_145 
* INOUT : bl_0_146 
* INOUT : br_0_146 
* INOUT : bl_0_147 
* INOUT : br_0_147 
* INOUT : bl_0_148 
* INOUT : br_0_148 
* INOUT : bl_0_149 
* INOUT : br_0_149 
* INOUT : bl_0_150 
* INOUT : br_0_150 
* INOUT : bl_0_151 
* INOUT : br_0_151 
* INOUT : bl_0_152 
* INOUT : br_0_152 
* INOUT : bl_0_153 
* INOUT : br_0_153 
* INOUT : bl_0_154 
* INOUT : br_0_154 
* INOUT : bl_0_155 
* INOUT : br_0_155 
* INOUT : bl_0_156 
* INOUT : br_0_156 
* INOUT : bl_0_157 
* INOUT : br_0_157 
* INOUT : bl_0_158 
* INOUT : br_0_158 
* INOUT : bl_0_159 
* INOUT : br_0_159 
* INOUT : bl_0_160 
* INOUT : br_0_160 
* INOUT : bl_0_161 
* INOUT : br_0_161 
* INOUT : bl_0_162 
* INOUT : br_0_162 
* INOUT : bl_0_163 
* INOUT : br_0_163 
* INOUT : bl_0_164 
* INOUT : br_0_164 
* INOUT : bl_0_165 
* INOUT : br_0_165 
* INOUT : bl_0_166 
* INOUT : br_0_166 
* INOUT : bl_0_167 
* INOUT : br_0_167 
* INOUT : bl_0_168 
* INOUT : br_0_168 
* INOUT : bl_0_169 
* INOUT : br_0_169 
* INOUT : bl_0_170 
* INOUT : br_0_170 
* INOUT : bl_0_171 
* INOUT : br_0_171 
* INOUT : bl_0_172 
* INOUT : br_0_172 
* INOUT : bl_0_173 
* INOUT : br_0_173 
* INOUT : bl_0_174 
* INOUT : br_0_174 
* INOUT : bl_0_175 
* INOUT : br_0_175 
* INOUT : bl_0_176 
* INOUT : br_0_176 
* INOUT : bl_0_177 
* INOUT : br_0_177 
* INOUT : bl_0_178 
* INOUT : br_0_178 
* INOUT : bl_0_179 
* INOUT : br_0_179 
* INOUT : bl_0_180 
* INOUT : br_0_180 
* INOUT : bl_0_181 
* INOUT : br_0_181 
* INOUT : bl_0_182 
* INOUT : br_0_182 
* INOUT : bl_0_183 
* INOUT : br_0_183 
* INOUT : bl_0_184 
* INOUT : br_0_184 
* INOUT : bl_0_185 
* INOUT : br_0_185 
* INOUT : bl_0_186 
* INOUT : br_0_186 
* INOUT : bl_0_187 
* INOUT : br_0_187 
* INOUT : bl_0_188 
* INOUT : br_0_188 
* INOUT : bl_0_189 
* INOUT : br_0_189 
* INOUT : bl_0_190 
* INOUT : br_0_190 
* INOUT : bl_0_191 
* INOUT : br_0_191 
* INOUT : bl_0_192 
* INOUT : br_0_192 
* INPUT : wl_0_0 
* INPUT : wl_0_1 
* INPUT : wl_0_2 
* INPUT : wl_0_3 
* INPUT : wl_0_4 
* INPUT : wl_0_5 
* INPUT : wl_0_6 
* INPUT : wl_0_7 
* INPUT : wl_0_8 
* INPUT : wl_0_9 
* INPUT : wl_0_10 
* INPUT : wl_0_11 
* INPUT : wl_0_12 
* INPUT : wl_0_13 
* INPUT : wl_0_14 
* INPUT : wl_0_15 
* INPUT : wl_0_16 
* POWER : vdd 
* GROUND: gnd 
* rows: 17 cols: 193
Xbit_r0_c0
+ bl_0_0 br_0_0 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c1
+ bl_0_1 br_0_1 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c0
+ bl_0_0 br_0_0 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c1
+ bl_0_1 br_0_1 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c2
+ bl_0_2 br_0_2 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c3
+ bl_0_3 br_0_3 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c2
+ bl_0_2 br_0_2 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c3
+ bl_0_3 br_0_3 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c4
+ bl_0_4 br_0_4 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c5
+ bl_0_5 br_0_5 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c4
+ bl_0_4 br_0_4 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c5
+ bl_0_5 br_0_5 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c6
+ bl_0_6 br_0_6 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c7
+ bl_0_7 br_0_7 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c6
+ bl_0_6 br_0_6 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c7
+ bl_0_7 br_0_7 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c8
+ bl_0_8 br_0_8 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c9
+ bl_0_9 br_0_9 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c8
+ bl_0_8 br_0_8 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c9
+ bl_0_9 br_0_9 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c10
+ bl_0_10 br_0_10 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c11
+ bl_0_11 br_0_11 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c10
+ bl_0_10 br_0_10 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c11
+ bl_0_11 br_0_11 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c12
+ bl_0_12 br_0_12 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c13
+ bl_0_13 br_0_13 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c12
+ bl_0_12 br_0_12 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c13
+ bl_0_13 br_0_13 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c14
+ bl_0_14 br_0_14 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c15
+ bl_0_15 br_0_15 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c14
+ bl_0_14 br_0_14 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c15
+ bl_0_15 br_0_15 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c16
+ bl_0_16 br_0_16 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c17
+ bl_0_17 br_0_17 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c16
+ bl_0_16 br_0_16 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c17
+ bl_0_17 br_0_17 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c18
+ bl_0_18 br_0_18 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c19
+ bl_0_19 br_0_19 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c18
+ bl_0_18 br_0_18 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c19
+ bl_0_19 br_0_19 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c20
+ bl_0_20 br_0_20 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c21
+ bl_0_21 br_0_21 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c20
+ bl_0_20 br_0_20 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c21
+ bl_0_21 br_0_21 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c22
+ bl_0_22 br_0_22 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c23
+ bl_0_23 br_0_23 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c22
+ bl_0_22 br_0_22 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c23
+ bl_0_23 br_0_23 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c24
+ bl_0_24 br_0_24 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c25
+ bl_0_25 br_0_25 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c24
+ bl_0_24 br_0_24 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c25
+ bl_0_25 br_0_25 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c26
+ bl_0_26 br_0_26 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c27
+ bl_0_27 br_0_27 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c26
+ bl_0_26 br_0_26 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c27
+ bl_0_27 br_0_27 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c28
+ bl_0_28 br_0_28 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c29
+ bl_0_29 br_0_29 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c28
+ bl_0_28 br_0_28 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c29
+ bl_0_29 br_0_29 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c30
+ bl_0_30 br_0_30 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c31
+ bl_0_31 br_0_31 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c30
+ bl_0_30 br_0_30 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c31
+ bl_0_31 br_0_31 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c32
+ bl_0_32 br_0_32 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c33
+ bl_0_33 br_0_33 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c32
+ bl_0_32 br_0_32 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c33
+ bl_0_33 br_0_33 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c34
+ bl_0_34 br_0_34 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c35
+ bl_0_35 br_0_35 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c34
+ bl_0_34 br_0_34 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c35
+ bl_0_35 br_0_35 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c36
+ bl_0_36 br_0_36 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c37
+ bl_0_37 br_0_37 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c36
+ bl_0_36 br_0_36 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c37
+ bl_0_37 br_0_37 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c38
+ bl_0_38 br_0_38 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c39
+ bl_0_39 br_0_39 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c38
+ bl_0_38 br_0_38 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c39
+ bl_0_39 br_0_39 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c40
+ bl_0_40 br_0_40 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c41
+ bl_0_41 br_0_41 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c40
+ bl_0_40 br_0_40 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c41
+ bl_0_41 br_0_41 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c42
+ bl_0_42 br_0_42 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c43
+ bl_0_43 br_0_43 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c42
+ bl_0_42 br_0_42 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c43
+ bl_0_43 br_0_43 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c44
+ bl_0_44 br_0_44 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c45
+ bl_0_45 br_0_45 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c44
+ bl_0_44 br_0_44 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c45
+ bl_0_45 br_0_45 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c46
+ bl_0_46 br_0_46 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c47
+ bl_0_47 br_0_47 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c46
+ bl_0_46 br_0_46 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c47
+ bl_0_47 br_0_47 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c48
+ bl_0_48 br_0_48 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c49
+ bl_0_49 br_0_49 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c48
+ bl_0_48 br_0_48 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c49
+ bl_0_49 br_0_49 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c50
+ bl_0_50 br_0_50 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c51
+ bl_0_51 br_0_51 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c50
+ bl_0_50 br_0_50 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c51
+ bl_0_51 br_0_51 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c52
+ bl_0_52 br_0_52 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c53
+ bl_0_53 br_0_53 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c52
+ bl_0_52 br_0_52 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c53
+ bl_0_53 br_0_53 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c54
+ bl_0_54 br_0_54 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c55
+ bl_0_55 br_0_55 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c54
+ bl_0_54 br_0_54 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c55
+ bl_0_55 br_0_55 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c56
+ bl_0_56 br_0_56 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c57
+ bl_0_57 br_0_57 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c56
+ bl_0_56 br_0_56 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c57
+ bl_0_57 br_0_57 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c58
+ bl_0_58 br_0_58 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c59
+ bl_0_59 br_0_59 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c58
+ bl_0_58 br_0_58 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c59
+ bl_0_59 br_0_59 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c60
+ bl_0_60 br_0_60 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c61
+ bl_0_61 br_0_61 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c60
+ bl_0_60 br_0_60 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c61
+ bl_0_61 br_0_61 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c62
+ bl_0_62 br_0_62 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c63
+ bl_0_63 br_0_63 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c62
+ bl_0_62 br_0_62 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c63
+ bl_0_63 br_0_63 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c64
+ bl_0_64 br_0_64 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c65
+ bl_0_65 br_0_65 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c64
+ bl_0_64 br_0_64 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c65
+ bl_0_65 br_0_65 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c66
+ bl_0_66 br_0_66 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c67
+ bl_0_67 br_0_67 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c66
+ bl_0_66 br_0_66 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c67
+ bl_0_67 br_0_67 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c68
+ bl_0_68 br_0_68 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c69
+ bl_0_69 br_0_69 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c68
+ bl_0_68 br_0_68 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c69
+ bl_0_69 br_0_69 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c70
+ bl_0_70 br_0_70 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c71
+ bl_0_71 br_0_71 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c70
+ bl_0_70 br_0_70 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c71
+ bl_0_71 br_0_71 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c72
+ bl_0_72 br_0_72 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c73
+ bl_0_73 br_0_73 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c72
+ bl_0_72 br_0_72 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c73
+ bl_0_73 br_0_73 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c74
+ bl_0_74 br_0_74 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c75
+ bl_0_75 br_0_75 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c74
+ bl_0_74 br_0_74 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c75
+ bl_0_75 br_0_75 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c76
+ bl_0_76 br_0_76 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c77
+ bl_0_77 br_0_77 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c76
+ bl_0_76 br_0_76 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c77
+ bl_0_77 br_0_77 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c78
+ bl_0_78 br_0_78 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c79
+ bl_0_79 br_0_79 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c78
+ bl_0_78 br_0_78 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c79
+ bl_0_79 br_0_79 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c80
+ bl_0_80 br_0_80 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c81
+ bl_0_81 br_0_81 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c80
+ bl_0_80 br_0_80 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c81
+ bl_0_81 br_0_81 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c82
+ bl_0_82 br_0_82 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c83
+ bl_0_83 br_0_83 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c82
+ bl_0_82 br_0_82 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c83
+ bl_0_83 br_0_83 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c84
+ bl_0_84 br_0_84 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c85
+ bl_0_85 br_0_85 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c84
+ bl_0_84 br_0_84 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c85
+ bl_0_85 br_0_85 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c86
+ bl_0_86 br_0_86 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c87
+ bl_0_87 br_0_87 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c86
+ bl_0_86 br_0_86 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c87
+ bl_0_87 br_0_87 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c88
+ bl_0_88 br_0_88 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c89
+ bl_0_89 br_0_89 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c88
+ bl_0_88 br_0_88 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c89
+ bl_0_89 br_0_89 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c90
+ bl_0_90 br_0_90 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c91
+ bl_0_91 br_0_91 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c90
+ bl_0_90 br_0_90 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c91
+ bl_0_91 br_0_91 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c92
+ bl_0_92 br_0_92 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c93
+ bl_0_93 br_0_93 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c92
+ bl_0_92 br_0_92 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c93
+ bl_0_93 br_0_93 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c94
+ bl_0_94 br_0_94 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c95
+ bl_0_95 br_0_95 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c94
+ bl_0_94 br_0_94 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c95
+ bl_0_95 br_0_95 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c96
+ bl_0_96 br_0_96 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c97
+ bl_0_97 br_0_97 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c96
+ bl_0_96 br_0_96 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c97
+ bl_0_97 br_0_97 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c98
+ bl_0_98 br_0_98 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c99
+ bl_0_99 br_0_99 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c98
+ bl_0_98 br_0_98 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c99
+ bl_0_99 br_0_99 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c100
+ bl_0_100 br_0_100 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c101
+ bl_0_101 br_0_101 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c100
+ bl_0_100 br_0_100 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c101
+ bl_0_101 br_0_101 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c102
+ bl_0_102 br_0_102 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c103
+ bl_0_103 br_0_103 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c102
+ bl_0_102 br_0_102 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c103
+ bl_0_103 br_0_103 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c104
+ bl_0_104 br_0_104 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c105
+ bl_0_105 br_0_105 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c104
+ bl_0_104 br_0_104 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c105
+ bl_0_105 br_0_105 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c106
+ bl_0_106 br_0_106 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c107
+ bl_0_107 br_0_107 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c106
+ bl_0_106 br_0_106 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c107
+ bl_0_107 br_0_107 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c108
+ bl_0_108 br_0_108 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c109
+ bl_0_109 br_0_109 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c108
+ bl_0_108 br_0_108 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c109
+ bl_0_109 br_0_109 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c110
+ bl_0_110 br_0_110 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c111
+ bl_0_111 br_0_111 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c110
+ bl_0_110 br_0_110 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c111
+ bl_0_111 br_0_111 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c112
+ bl_0_112 br_0_112 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c113
+ bl_0_113 br_0_113 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c112
+ bl_0_112 br_0_112 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c113
+ bl_0_113 br_0_113 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c114
+ bl_0_114 br_0_114 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c115
+ bl_0_115 br_0_115 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c114
+ bl_0_114 br_0_114 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c115
+ bl_0_115 br_0_115 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c116
+ bl_0_116 br_0_116 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c117
+ bl_0_117 br_0_117 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c116
+ bl_0_116 br_0_116 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c117
+ bl_0_117 br_0_117 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c118
+ bl_0_118 br_0_118 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c119
+ bl_0_119 br_0_119 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c118
+ bl_0_118 br_0_118 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c119
+ bl_0_119 br_0_119 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c120
+ bl_0_120 br_0_120 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c121
+ bl_0_121 br_0_121 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c120
+ bl_0_120 br_0_120 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c121
+ bl_0_121 br_0_121 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c122
+ bl_0_122 br_0_122 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c123
+ bl_0_123 br_0_123 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c122
+ bl_0_122 br_0_122 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c123
+ bl_0_123 br_0_123 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c124
+ bl_0_124 br_0_124 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c125
+ bl_0_125 br_0_125 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c124
+ bl_0_124 br_0_124 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c125
+ bl_0_125 br_0_125 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c126
+ bl_0_126 br_0_126 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c127
+ bl_0_127 br_0_127 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c126
+ bl_0_126 br_0_126 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c127
+ bl_0_127 br_0_127 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c128
+ bl_0_128 br_0_128 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c129
+ bl_0_129 br_0_129 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c128
+ bl_0_128 br_0_128 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c129
+ bl_0_129 br_0_129 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c130
+ bl_0_130 br_0_130 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c131
+ bl_0_131 br_0_131 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c130
+ bl_0_130 br_0_130 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c131
+ bl_0_131 br_0_131 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c132
+ bl_0_132 br_0_132 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c133
+ bl_0_133 br_0_133 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c132
+ bl_0_132 br_0_132 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c133
+ bl_0_133 br_0_133 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c134
+ bl_0_134 br_0_134 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c135
+ bl_0_135 br_0_135 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c134
+ bl_0_134 br_0_134 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c135
+ bl_0_135 br_0_135 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c136
+ bl_0_136 br_0_136 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c137
+ bl_0_137 br_0_137 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c136
+ bl_0_136 br_0_136 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c137
+ bl_0_137 br_0_137 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c138
+ bl_0_138 br_0_138 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c139
+ bl_0_139 br_0_139 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c138
+ bl_0_138 br_0_138 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c139
+ bl_0_139 br_0_139 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c140
+ bl_0_140 br_0_140 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c141
+ bl_0_141 br_0_141 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c140
+ bl_0_140 br_0_140 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c141
+ bl_0_141 br_0_141 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c142
+ bl_0_142 br_0_142 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c143
+ bl_0_143 br_0_143 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c142
+ bl_0_142 br_0_142 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c143
+ bl_0_143 br_0_143 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c144
+ bl_0_144 br_0_144 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c145
+ bl_0_145 br_0_145 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c144
+ bl_0_144 br_0_144 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c145
+ bl_0_145 br_0_145 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c146
+ bl_0_146 br_0_146 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c147
+ bl_0_147 br_0_147 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c146
+ bl_0_146 br_0_146 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c147
+ bl_0_147 br_0_147 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c148
+ bl_0_148 br_0_148 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c149
+ bl_0_149 br_0_149 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c148
+ bl_0_148 br_0_148 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c149
+ bl_0_149 br_0_149 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c150
+ bl_0_150 br_0_150 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c151
+ bl_0_151 br_0_151 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c150
+ bl_0_150 br_0_150 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c151
+ bl_0_151 br_0_151 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c152
+ bl_0_152 br_0_152 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c153
+ bl_0_153 br_0_153 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c152
+ bl_0_152 br_0_152 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c153
+ bl_0_153 br_0_153 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c154
+ bl_0_154 br_0_154 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c155
+ bl_0_155 br_0_155 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c154
+ bl_0_154 br_0_154 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c155
+ bl_0_155 br_0_155 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c156
+ bl_0_156 br_0_156 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c157
+ bl_0_157 br_0_157 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c156
+ bl_0_156 br_0_156 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c157
+ bl_0_157 br_0_157 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c158
+ bl_0_158 br_0_158 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c159
+ bl_0_159 br_0_159 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c158
+ bl_0_158 br_0_158 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c159
+ bl_0_159 br_0_159 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c160
+ bl_0_160 br_0_160 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c161
+ bl_0_161 br_0_161 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c160
+ bl_0_160 br_0_160 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c161
+ bl_0_161 br_0_161 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c162
+ bl_0_162 br_0_162 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c163
+ bl_0_163 br_0_163 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c162
+ bl_0_162 br_0_162 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c163
+ bl_0_163 br_0_163 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c164
+ bl_0_164 br_0_164 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c165
+ bl_0_165 br_0_165 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c164
+ bl_0_164 br_0_164 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c165
+ bl_0_165 br_0_165 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c166
+ bl_0_166 br_0_166 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c167
+ bl_0_167 br_0_167 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c166
+ bl_0_166 br_0_166 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c167
+ bl_0_167 br_0_167 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c168
+ bl_0_168 br_0_168 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c169
+ bl_0_169 br_0_169 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c168
+ bl_0_168 br_0_168 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c169
+ bl_0_169 br_0_169 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c170
+ bl_0_170 br_0_170 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c171
+ bl_0_171 br_0_171 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c170
+ bl_0_170 br_0_170 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c171
+ bl_0_171 br_0_171 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c172
+ bl_0_172 br_0_172 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c173
+ bl_0_173 br_0_173 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c172
+ bl_0_172 br_0_172 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c173
+ bl_0_173 br_0_173 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c174
+ bl_0_174 br_0_174 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c175
+ bl_0_175 br_0_175 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c174
+ bl_0_174 br_0_174 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c175
+ bl_0_175 br_0_175 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c176
+ bl_0_176 br_0_176 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c177
+ bl_0_177 br_0_177 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c176
+ bl_0_176 br_0_176 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c177
+ bl_0_177 br_0_177 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c178
+ bl_0_178 br_0_178 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c179
+ bl_0_179 br_0_179 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c178
+ bl_0_178 br_0_178 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c179
+ bl_0_179 br_0_179 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c180
+ bl_0_180 br_0_180 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c181
+ bl_0_181 br_0_181 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c180
+ bl_0_180 br_0_180 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c181
+ bl_0_181 br_0_181 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c182
+ bl_0_182 br_0_182 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c183
+ bl_0_183 br_0_183 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c182
+ bl_0_182 br_0_182 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c183
+ bl_0_183 br_0_183 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c184
+ bl_0_184 br_0_184 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c185
+ bl_0_185 br_0_185 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c184
+ bl_0_184 br_0_184 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c185
+ bl_0_185 br_0_185 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c186
+ bl_0_186 br_0_186 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c187
+ bl_0_187 br_0_187 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c186
+ bl_0_186 br_0_186 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c187
+ bl_0_187 br_0_187 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c188
+ bl_0_188 br_0_188 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c189
+ bl_0_189 br_0_189 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c188
+ bl_0_188 br_0_188 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c189
+ bl_0_189 br_0_189 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c190
+ bl_0_190 br_0_190 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r0_c191
+ bl_0_191 br_0_191 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c190
+ bl_0_190 br_0_190 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r1_c191
+ bl_0_191 br_0_191 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r0_c192
+ bl_0_192 br_0_192 wl_0_0 vdd gnd
+ sky130_custom_cell
Xbit_r1_c192
+ bl_0_192 br_0_192 wl_0_1 vdd gnd
+ sky130_custom_cell
Xbit_r2_c0
+ bl_0_0 br_0_0 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c1
+ bl_0_1 br_0_1 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c0
+ bl_0_0 br_0_0 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c1
+ bl_0_1 br_0_1 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c2
+ bl_0_2 br_0_2 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c3
+ bl_0_3 br_0_3 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c2
+ bl_0_2 br_0_2 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c3
+ bl_0_3 br_0_3 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c4
+ bl_0_4 br_0_4 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c5
+ bl_0_5 br_0_5 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c4
+ bl_0_4 br_0_4 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c5
+ bl_0_5 br_0_5 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c6
+ bl_0_6 br_0_6 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c7
+ bl_0_7 br_0_7 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c6
+ bl_0_6 br_0_6 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c7
+ bl_0_7 br_0_7 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c8
+ bl_0_8 br_0_8 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c9
+ bl_0_9 br_0_9 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c8
+ bl_0_8 br_0_8 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c9
+ bl_0_9 br_0_9 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c10
+ bl_0_10 br_0_10 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c11
+ bl_0_11 br_0_11 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c10
+ bl_0_10 br_0_10 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c11
+ bl_0_11 br_0_11 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c12
+ bl_0_12 br_0_12 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c13
+ bl_0_13 br_0_13 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c12
+ bl_0_12 br_0_12 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c13
+ bl_0_13 br_0_13 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c14
+ bl_0_14 br_0_14 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c15
+ bl_0_15 br_0_15 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c14
+ bl_0_14 br_0_14 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c15
+ bl_0_15 br_0_15 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c16
+ bl_0_16 br_0_16 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c17
+ bl_0_17 br_0_17 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c16
+ bl_0_16 br_0_16 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c17
+ bl_0_17 br_0_17 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c18
+ bl_0_18 br_0_18 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c19
+ bl_0_19 br_0_19 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c18
+ bl_0_18 br_0_18 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c19
+ bl_0_19 br_0_19 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c20
+ bl_0_20 br_0_20 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c21
+ bl_0_21 br_0_21 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c20
+ bl_0_20 br_0_20 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c21
+ bl_0_21 br_0_21 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c22
+ bl_0_22 br_0_22 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c23
+ bl_0_23 br_0_23 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c22
+ bl_0_22 br_0_22 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c23
+ bl_0_23 br_0_23 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c24
+ bl_0_24 br_0_24 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c25
+ bl_0_25 br_0_25 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c24
+ bl_0_24 br_0_24 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c25
+ bl_0_25 br_0_25 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c26
+ bl_0_26 br_0_26 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c27
+ bl_0_27 br_0_27 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c26
+ bl_0_26 br_0_26 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c27
+ bl_0_27 br_0_27 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c28
+ bl_0_28 br_0_28 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c29
+ bl_0_29 br_0_29 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c28
+ bl_0_28 br_0_28 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c29
+ bl_0_29 br_0_29 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c30
+ bl_0_30 br_0_30 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c31
+ bl_0_31 br_0_31 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c30
+ bl_0_30 br_0_30 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c31
+ bl_0_31 br_0_31 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c32
+ bl_0_32 br_0_32 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c33
+ bl_0_33 br_0_33 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c32
+ bl_0_32 br_0_32 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c33
+ bl_0_33 br_0_33 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c34
+ bl_0_34 br_0_34 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c35
+ bl_0_35 br_0_35 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c34
+ bl_0_34 br_0_34 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c35
+ bl_0_35 br_0_35 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c36
+ bl_0_36 br_0_36 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c37
+ bl_0_37 br_0_37 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c36
+ bl_0_36 br_0_36 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c37
+ bl_0_37 br_0_37 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c38
+ bl_0_38 br_0_38 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c39
+ bl_0_39 br_0_39 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c38
+ bl_0_38 br_0_38 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c39
+ bl_0_39 br_0_39 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c40
+ bl_0_40 br_0_40 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c41
+ bl_0_41 br_0_41 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c40
+ bl_0_40 br_0_40 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c41
+ bl_0_41 br_0_41 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c42
+ bl_0_42 br_0_42 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c43
+ bl_0_43 br_0_43 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c42
+ bl_0_42 br_0_42 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c43
+ bl_0_43 br_0_43 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c44
+ bl_0_44 br_0_44 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c45
+ bl_0_45 br_0_45 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c44
+ bl_0_44 br_0_44 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c45
+ bl_0_45 br_0_45 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c46
+ bl_0_46 br_0_46 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c47
+ bl_0_47 br_0_47 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c46
+ bl_0_46 br_0_46 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c47
+ bl_0_47 br_0_47 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c48
+ bl_0_48 br_0_48 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c49
+ bl_0_49 br_0_49 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c48
+ bl_0_48 br_0_48 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c49
+ bl_0_49 br_0_49 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c50
+ bl_0_50 br_0_50 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c51
+ bl_0_51 br_0_51 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c50
+ bl_0_50 br_0_50 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c51
+ bl_0_51 br_0_51 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c52
+ bl_0_52 br_0_52 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c53
+ bl_0_53 br_0_53 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c52
+ bl_0_52 br_0_52 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c53
+ bl_0_53 br_0_53 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c54
+ bl_0_54 br_0_54 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c55
+ bl_0_55 br_0_55 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c54
+ bl_0_54 br_0_54 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c55
+ bl_0_55 br_0_55 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c56
+ bl_0_56 br_0_56 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c57
+ bl_0_57 br_0_57 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c56
+ bl_0_56 br_0_56 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c57
+ bl_0_57 br_0_57 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c58
+ bl_0_58 br_0_58 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c59
+ bl_0_59 br_0_59 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c58
+ bl_0_58 br_0_58 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c59
+ bl_0_59 br_0_59 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c60
+ bl_0_60 br_0_60 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c61
+ bl_0_61 br_0_61 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c60
+ bl_0_60 br_0_60 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c61
+ bl_0_61 br_0_61 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c62
+ bl_0_62 br_0_62 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c63
+ bl_0_63 br_0_63 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c62
+ bl_0_62 br_0_62 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c63
+ bl_0_63 br_0_63 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c64
+ bl_0_64 br_0_64 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c65
+ bl_0_65 br_0_65 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c64
+ bl_0_64 br_0_64 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c65
+ bl_0_65 br_0_65 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c66
+ bl_0_66 br_0_66 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c67
+ bl_0_67 br_0_67 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c66
+ bl_0_66 br_0_66 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c67
+ bl_0_67 br_0_67 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c68
+ bl_0_68 br_0_68 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c69
+ bl_0_69 br_0_69 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c68
+ bl_0_68 br_0_68 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c69
+ bl_0_69 br_0_69 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c70
+ bl_0_70 br_0_70 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c71
+ bl_0_71 br_0_71 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c70
+ bl_0_70 br_0_70 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c71
+ bl_0_71 br_0_71 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c72
+ bl_0_72 br_0_72 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c73
+ bl_0_73 br_0_73 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c72
+ bl_0_72 br_0_72 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c73
+ bl_0_73 br_0_73 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c74
+ bl_0_74 br_0_74 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c75
+ bl_0_75 br_0_75 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c74
+ bl_0_74 br_0_74 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c75
+ bl_0_75 br_0_75 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c76
+ bl_0_76 br_0_76 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c77
+ bl_0_77 br_0_77 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c76
+ bl_0_76 br_0_76 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c77
+ bl_0_77 br_0_77 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c78
+ bl_0_78 br_0_78 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c79
+ bl_0_79 br_0_79 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c78
+ bl_0_78 br_0_78 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c79
+ bl_0_79 br_0_79 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c80
+ bl_0_80 br_0_80 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c81
+ bl_0_81 br_0_81 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c80
+ bl_0_80 br_0_80 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c81
+ bl_0_81 br_0_81 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c82
+ bl_0_82 br_0_82 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c83
+ bl_0_83 br_0_83 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c82
+ bl_0_82 br_0_82 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c83
+ bl_0_83 br_0_83 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c84
+ bl_0_84 br_0_84 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c85
+ bl_0_85 br_0_85 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c84
+ bl_0_84 br_0_84 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c85
+ bl_0_85 br_0_85 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c86
+ bl_0_86 br_0_86 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c87
+ bl_0_87 br_0_87 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c86
+ bl_0_86 br_0_86 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c87
+ bl_0_87 br_0_87 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c88
+ bl_0_88 br_0_88 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c89
+ bl_0_89 br_0_89 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c88
+ bl_0_88 br_0_88 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c89
+ bl_0_89 br_0_89 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c90
+ bl_0_90 br_0_90 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c91
+ bl_0_91 br_0_91 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c90
+ bl_0_90 br_0_90 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c91
+ bl_0_91 br_0_91 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c92
+ bl_0_92 br_0_92 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c93
+ bl_0_93 br_0_93 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c92
+ bl_0_92 br_0_92 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c93
+ bl_0_93 br_0_93 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c94
+ bl_0_94 br_0_94 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c95
+ bl_0_95 br_0_95 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c94
+ bl_0_94 br_0_94 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c95
+ bl_0_95 br_0_95 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c96
+ bl_0_96 br_0_96 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c97
+ bl_0_97 br_0_97 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c96
+ bl_0_96 br_0_96 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c97
+ bl_0_97 br_0_97 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c98
+ bl_0_98 br_0_98 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c99
+ bl_0_99 br_0_99 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c98
+ bl_0_98 br_0_98 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c99
+ bl_0_99 br_0_99 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c100
+ bl_0_100 br_0_100 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c101
+ bl_0_101 br_0_101 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c100
+ bl_0_100 br_0_100 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c101
+ bl_0_101 br_0_101 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c102
+ bl_0_102 br_0_102 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c103
+ bl_0_103 br_0_103 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c102
+ bl_0_102 br_0_102 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c103
+ bl_0_103 br_0_103 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c104
+ bl_0_104 br_0_104 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c105
+ bl_0_105 br_0_105 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c104
+ bl_0_104 br_0_104 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c105
+ bl_0_105 br_0_105 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c106
+ bl_0_106 br_0_106 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c107
+ bl_0_107 br_0_107 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c106
+ bl_0_106 br_0_106 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c107
+ bl_0_107 br_0_107 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c108
+ bl_0_108 br_0_108 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c109
+ bl_0_109 br_0_109 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c108
+ bl_0_108 br_0_108 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c109
+ bl_0_109 br_0_109 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c110
+ bl_0_110 br_0_110 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c111
+ bl_0_111 br_0_111 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c110
+ bl_0_110 br_0_110 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c111
+ bl_0_111 br_0_111 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c112
+ bl_0_112 br_0_112 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c113
+ bl_0_113 br_0_113 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c112
+ bl_0_112 br_0_112 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c113
+ bl_0_113 br_0_113 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c114
+ bl_0_114 br_0_114 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c115
+ bl_0_115 br_0_115 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c114
+ bl_0_114 br_0_114 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c115
+ bl_0_115 br_0_115 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c116
+ bl_0_116 br_0_116 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c117
+ bl_0_117 br_0_117 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c116
+ bl_0_116 br_0_116 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c117
+ bl_0_117 br_0_117 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c118
+ bl_0_118 br_0_118 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c119
+ bl_0_119 br_0_119 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c118
+ bl_0_118 br_0_118 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c119
+ bl_0_119 br_0_119 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c120
+ bl_0_120 br_0_120 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c121
+ bl_0_121 br_0_121 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c120
+ bl_0_120 br_0_120 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c121
+ bl_0_121 br_0_121 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c122
+ bl_0_122 br_0_122 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c123
+ bl_0_123 br_0_123 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c122
+ bl_0_122 br_0_122 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c123
+ bl_0_123 br_0_123 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c124
+ bl_0_124 br_0_124 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c125
+ bl_0_125 br_0_125 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c124
+ bl_0_124 br_0_124 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c125
+ bl_0_125 br_0_125 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c126
+ bl_0_126 br_0_126 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c127
+ bl_0_127 br_0_127 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c126
+ bl_0_126 br_0_126 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c127
+ bl_0_127 br_0_127 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c128
+ bl_0_128 br_0_128 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c129
+ bl_0_129 br_0_129 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c128
+ bl_0_128 br_0_128 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c129
+ bl_0_129 br_0_129 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c130
+ bl_0_130 br_0_130 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c131
+ bl_0_131 br_0_131 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c130
+ bl_0_130 br_0_130 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c131
+ bl_0_131 br_0_131 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c132
+ bl_0_132 br_0_132 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c133
+ bl_0_133 br_0_133 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c132
+ bl_0_132 br_0_132 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c133
+ bl_0_133 br_0_133 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c134
+ bl_0_134 br_0_134 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c135
+ bl_0_135 br_0_135 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c134
+ bl_0_134 br_0_134 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c135
+ bl_0_135 br_0_135 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c136
+ bl_0_136 br_0_136 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c137
+ bl_0_137 br_0_137 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c136
+ bl_0_136 br_0_136 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c137
+ bl_0_137 br_0_137 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c138
+ bl_0_138 br_0_138 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c139
+ bl_0_139 br_0_139 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c138
+ bl_0_138 br_0_138 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c139
+ bl_0_139 br_0_139 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c140
+ bl_0_140 br_0_140 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c141
+ bl_0_141 br_0_141 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c140
+ bl_0_140 br_0_140 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c141
+ bl_0_141 br_0_141 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c142
+ bl_0_142 br_0_142 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c143
+ bl_0_143 br_0_143 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c142
+ bl_0_142 br_0_142 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c143
+ bl_0_143 br_0_143 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c144
+ bl_0_144 br_0_144 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c145
+ bl_0_145 br_0_145 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c144
+ bl_0_144 br_0_144 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c145
+ bl_0_145 br_0_145 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c146
+ bl_0_146 br_0_146 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c147
+ bl_0_147 br_0_147 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c146
+ bl_0_146 br_0_146 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c147
+ bl_0_147 br_0_147 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c148
+ bl_0_148 br_0_148 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c149
+ bl_0_149 br_0_149 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c148
+ bl_0_148 br_0_148 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c149
+ bl_0_149 br_0_149 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c150
+ bl_0_150 br_0_150 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c151
+ bl_0_151 br_0_151 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c150
+ bl_0_150 br_0_150 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c151
+ bl_0_151 br_0_151 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c152
+ bl_0_152 br_0_152 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c153
+ bl_0_153 br_0_153 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c152
+ bl_0_152 br_0_152 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c153
+ bl_0_153 br_0_153 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c154
+ bl_0_154 br_0_154 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c155
+ bl_0_155 br_0_155 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c154
+ bl_0_154 br_0_154 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c155
+ bl_0_155 br_0_155 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c156
+ bl_0_156 br_0_156 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c157
+ bl_0_157 br_0_157 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c156
+ bl_0_156 br_0_156 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c157
+ bl_0_157 br_0_157 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c158
+ bl_0_158 br_0_158 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c159
+ bl_0_159 br_0_159 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c158
+ bl_0_158 br_0_158 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c159
+ bl_0_159 br_0_159 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c160
+ bl_0_160 br_0_160 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c161
+ bl_0_161 br_0_161 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c160
+ bl_0_160 br_0_160 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c161
+ bl_0_161 br_0_161 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c162
+ bl_0_162 br_0_162 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c163
+ bl_0_163 br_0_163 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c162
+ bl_0_162 br_0_162 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c163
+ bl_0_163 br_0_163 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c164
+ bl_0_164 br_0_164 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c165
+ bl_0_165 br_0_165 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c164
+ bl_0_164 br_0_164 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c165
+ bl_0_165 br_0_165 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c166
+ bl_0_166 br_0_166 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c167
+ bl_0_167 br_0_167 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c166
+ bl_0_166 br_0_166 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c167
+ bl_0_167 br_0_167 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c168
+ bl_0_168 br_0_168 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c169
+ bl_0_169 br_0_169 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c168
+ bl_0_168 br_0_168 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c169
+ bl_0_169 br_0_169 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c170
+ bl_0_170 br_0_170 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c171
+ bl_0_171 br_0_171 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c170
+ bl_0_170 br_0_170 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c171
+ bl_0_171 br_0_171 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c172
+ bl_0_172 br_0_172 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c173
+ bl_0_173 br_0_173 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c172
+ bl_0_172 br_0_172 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c173
+ bl_0_173 br_0_173 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c174
+ bl_0_174 br_0_174 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c175
+ bl_0_175 br_0_175 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c174
+ bl_0_174 br_0_174 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c175
+ bl_0_175 br_0_175 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c176
+ bl_0_176 br_0_176 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c177
+ bl_0_177 br_0_177 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c176
+ bl_0_176 br_0_176 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c177
+ bl_0_177 br_0_177 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c178
+ bl_0_178 br_0_178 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c179
+ bl_0_179 br_0_179 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c178
+ bl_0_178 br_0_178 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c179
+ bl_0_179 br_0_179 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c180
+ bl_0_180 br_0_180 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c181
+ bl_0_181 br_0_181 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c180
+ bl_0_180 br_0_180 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c181
+ bl_0_181 br_0_181 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c182
+ bl_0_182 br_0_182 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c183
+ bl_0_183 br_0_183 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c182
+ bl_0_182 br_0_182 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c183
+ bl_0_183 br_0_183 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c184
+ bl_0_184 br_0_184 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c185
+ bl_0_185 br_0_185 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c184
+ bl_0_184 br_0_184 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c185
+ bl_0_185 br_0_185 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c186
+ bl_0_186 br_0_186 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c187
+ bl_0_187 br_0_187 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c186
+ bl_0_186 br_0_186 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c187
+ bl_0_187 br_0_187 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c188
+ bl_0_188 br_0_188 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c189
+ bl_0_189 br_0_189 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c188
+ bl_0_188 br_0_188 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c189
+ bl_0_189 br_0_189 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c190
+ bl_0_190 br_0_190 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r2_c191
+ bl_0_191 br_0_191 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c190
+ bl_0_190 br_0_190 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r3_c191
+ bl_0_191 br_0_191 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r2_c192
+ bl_0_192 br_0_192 wl_0_2 vdd gnd
+ sky130_custom_cell
Xbit_r3_c192
+ bl_0_192 br_0_192 wl_0_3 vdd gnd
+ sky130_custom_cell
Xbit_r4_c0
+ bl_0_0 br_0_0 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c1
+ bl_0_1 br_0_1 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c0
+ bl_0_0 br_0_0 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c1
+ bl_0_1 br_0_1 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c2
+ bl_0_2 br_0_2 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c3
+ bl_0_3 br_0_3 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c2
+ bl_0_2 br_0_2 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c3
+ bl_0_3 br_0_3 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c4
+ bl_0_4 br_0_4 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c5
+ bl_0_5 br_0_5 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c4
+ bl_0_4 br_0_4 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c5
+ bl_0_5 br_0_5 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c6
+ bl_0_6 br_0_6 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c7
+ bl_0_7 br_0_7 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c6
+ bl_0_6 br_0_6 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c7
+ bl_0_7 br_0_7 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c8
+ bl_0_8 br_0_8 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c9
+ bl_0_9 br_0_9 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c8
+ bl_0_8 br_0_8 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c9
+ bl_0_9 br_0_9 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c10
+ bl_0_10 br_0_10 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c11
+ bl_0_11 br_0_11 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c10
+ bl_0_10 br_0_10 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c11
+ bl_0_11 br_0_11 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c12
+ bl_0_12 br_0_12 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c13
+ bl_0_13 br_0_13 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c12
+ bl_0_12 br_0_12 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c13
+ bl_0_13 br_0_13 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c14
+ bl_0_14 br_0_14 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c15
+ bl_0_15 br_0_15 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c14
+ bl_0_14 br_0_14 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c15
+ bl_0_15 br_0_15 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c16
+ bl_0_16 br_0_16 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c17
+ bl_0_17 br_0_17 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c16
+ bl_0_16 br_0_16 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c17
+ bl_0_17 br_0_17 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c18
+ bl_0_18 br_0_18 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c19
+ bl_0_19 br_0_19 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c18
+ bl_0_18 br_0_18 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c19
+ bl_0_19 br_0_19 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c20
+ bl_0_20 br_0_20 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c21
+ bl_0_21 br_0_21 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c20
+ bl_0_20 br_0_20 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c21
+ bl_0_21 br_0_21 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c22
+ bl_0_22 br_0_22 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c23
+ bl_0_23 br_0_23 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c22
+ bl_0_22 br_0_22 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c23
+ bl_0_23 br_0_23 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c24
+ bl_0_24 br_0_24 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c25
+ bl_0_25 br_0_25 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c24
+ bl_0_24 br_0_24 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c25
+ bl_0_25 br_0_25 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c26
+ bl_0_26 br_0_26 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c27
+ bl_0_27 br_0_27 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c26
+ bl_0_26 br_0_26 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c27
+ bl_0_27 br_0_27 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c28
+ bl_0_28 br_0_28 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c29
+ bl_0_29 br_0_29 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c28
+ bl_0_28 br_0_28 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c29
+ bl_0_29 br_0_29 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c30
+ bl_0_30 br_0_30 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c31
+ bl_0_31 br_0_31 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c30
+ bl_0_30 br_0_30 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c31
+ bl_0_31 br_0_31 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c32
+ bl_0_32 br_0_32 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c33
+ bl_0_33 br_0_33 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c32
+ bl_0_32 br_0_32 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c33
+ bl_0_33 br_0_33 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c34
+ bl_0_34 br_0_34 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c35
+ bl_0_35 br_0_35 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c34
+ bl_0_34 br_0_34 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c35
+ bl_0_35 br_0_35 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c36
+ bl_0_36 br_0_36 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c37
+ bl_0_37 br_0_37 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c36
+ bl_0_36 br_0_36 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c37
+ bl_0_37 br_0_37 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c38
+ bl_0_38 br_0_38 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c39
+ bl_0_39 br_0_39 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c38
+ bl_0_38 br_0_38 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c39
+ bl_0_39 br_0_39 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c40
+ bl_0_40 br_0_40 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c41
+ bl_0_41 br_0_41 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c40
+ bl_0_40 br_0_40 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c41
+ bl_0_41 br_0_41 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c42
+ bl_0_42 br_0_42 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c43
+ bl_0_43 br_0_43 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c42
+ bl_0_42 br_0_42 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c43
+ bl_0_43 br_0_43 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c44
+ bl_0_44 br_0_44 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c45
+ bl_0_45 br_0_45 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c44
+ bl_0_44 br_0_44 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c45
+ bl_0_45 br_0_45 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c46
+ bl_0_46 br_0_46 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c47
+ bl_0_47 br_0_47 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c46
+ bl_0_46 br_0_46 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c47
+ bl_0_47 br_0_47 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c48
+ bl_0_48 br_0_48 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c49
+ bl_0_49 br_0_49 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c48
+ bl_0_48 br_0_48 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c49
+ bl_0_49 br_0_49 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c50
+ bl_0_50 br_0_50 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c51
+ bl_0_51 br_0_51 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c50
+ bl_0_50 br_0_50 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c51
+ bl_0_51 br_0_51 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c52
+ bl_0_52 br_0_52 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c53
+ bl_0_53 br_0_53 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c52
+ bl_0_52 br_0_52 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c53
+ bl_0_53 br_0_53 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c54
+ bl_0_54 br_0_54 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c55
+ bl_0_55 br_0_55 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c54
+ bl_0_54 br_0_54 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c55
+ bl_0_55 br_0_55 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c56
+ bl_0_56 br_0_56 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c57
+ bl_0_57 br_0_57 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c56
+ bl_0_56 br_0_56 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c57
+ bl_0_57 br_0_57 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c58
+ bl_0_58 br_0_58 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c59
+ bl_0_59 br_0_59 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c58
+ bl_0_58 br_0_58 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c59
+ bl_0_59 br_0_59 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c60
+ bl_0_60 br_0_60 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c61
+ bl_0_61 br_0_61 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c60
+ bl_0_60 br_0_60 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c61
+ bl_0_61 br_0_61 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c62
+ bl_0_62 br_0_62 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c63
+ bl_0_63 br_0_63 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c62
+ bl_0_62 br_0_62 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c63
+ bl_0_63 br_0_63 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c64
+ bl_0_64 br_0_64 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c65
+ bl_0_65 br_0_65 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c64
+ bl_0_64 br_0_64 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c65
+ bl_0_65 br_0_65 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c66
+ bl_0_66 br_0_66 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c67
+ bl_0_67 br_0_67 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c66
+ bl_0_66 br_0_66 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c67
+ bl_0_67 br_0_67 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c68
+ bl_0_68 br_0_68 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c69
+ bl_0_69 br_0_69 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c68
+ bl_0_68 br_0_68 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c69
+ bl_0_69 br_0_69 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c70
+ bl_0_70 br_0_70 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c71
+ bl_0_71 br_0_71 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c70
+ bl_0_70 br_0_70 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c71
+ bl_0_71 br_0_71 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c72
+ bl_0_72 br_0_72 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c73
+ bl_0_73 br_0_73 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c72
+ bl_0_72 br_0_72 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c73
+ bl_0_73 br_0_73 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c74
+ bl_0_74 br_0_74 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c75
+ bl_0_75 br_0_75 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c74
+ bl_0_74 br_0_74 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c75
+ bl_0_75 br_0_75 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c76
+ bl_0_76 br_0_76 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c77
+ bl_0_77 br_0_77 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c76
+ bl_0_76 br_0_76 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c77
+ bl_0_77 br_0_77 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c78
+ bl_0_78 br_0_78 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c79
+ bl_0_79 br_0_79 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c78
+ bl_0_78 br_0_78 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c79
+ bl_0_79 br_0_79 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c80
+ bl_0_80 br_0_80 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c81
+ bl_0_81 br_0_81 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c80
+ bl_0_80 br_0_80 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c81
+ bl_0_81 br_0_81 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c82
+ bl_0_82 br_0_82 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c83
+ bl_0_83 br_0_83 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c82
+ bl_0_82 br_0_82 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c83
+ bl_0_83 br_0_83 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c84
+ bl_0_84 br_0_84 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c85
+ bl_0_85 br_0_85 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c84
+ bl_0_84 br_0_84 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c85
+ bl_0_85 br_0_85 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c86
+ bl_0_86 br_0_86 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c87
+ bl_0_87 br_0_87 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c86
+ bl_0_86 br_0_86 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c87
+ bl_0_87 br_0_87 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c88
+ bl_0_88 br_0_88 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c89
+ bl_0_89 br_0_89 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c88
+ bl_0_88 br_0_88 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c89
+ bl_0_89 br_0_89 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c90
+ bl_0_90 br_0_90 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c91
+ bl_0_91 br_0_91 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c90
+ bl_0_90 br_0_90 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c91
+ bl_0_91 br_0_91 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c92
+ bl_0_92 br_0_92 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c93
+ bl_0_93 br_0_93 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c92
+ bl_0_92 br_0_92 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c93
+ bl_0_93 br_0_93 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c94
+ bl_0_94 br_0_94 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c95
+ bl_0_95 br_0_95 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c94
+ bl_0_94 br_0_94 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c95
+ bl_0_95 br_0_95 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c96
+ bl_0_96 br_0_96 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c97
+ bl_0_97 br_0_97 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c96
+ bl_0_96 br_0_96 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c97
+ bl_0_97 br_0_97 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c98
+ bl_0_98 br_0_98 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c99
+ bl_0_99 br_0_99 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c98
+ bl_0_98 br_0_98 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c99
+ bl_0_99 br_0_99 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c100
+ bl_0_100 br_0_100 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c101
+ bl_0_101 br_0_101 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c100
+ bl_0_100 br_0_100 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c101
+ bl_0_101 br_0_101 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c102
+ bl_0_102 br_0_102 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c103
+ bl_0_103 br_0_103 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c102
+ bl_0_102 br_0_102 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c103
+ bl_0_103 br_0_103 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c104
+ bl_0_104 br_0_104 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c105
+ bl_0_105 br_0_105 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c104
+ bl_0_104 br_0_104 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c105
+ bl_0_105 br_0_105 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c106
+ bl_0_106 br_0_106 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c107
+ bl_0_107 br_0_107 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c106
+ bl_0_106 br_0_106 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c107
+ bl_0_107 br_0_107 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c108
+ bl_0_108 br_0_108 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c109
+ bl_0_109 br_0_109 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c108
+ bl_0_108 br_0_108 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c109
+ bl_0_109 br_0_109 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c110
+ bl_0_110 br_0_110 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c111
+ bl_0_111 br_0_111 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c110
+ bl_0_110 br_0_110 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c111
+ bl_0_111 br_0_111 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c112
+ bl_0_112 br_0_112 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c113
+ bl_0_113 br_0_113 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c112
+ bl_0_112 br_0_112 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c113
+ bl_0_113 br_0_113 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c114
+ bl_0_114 br_0_114 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c115
+ bl_0_115 br_0_115 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c114
+ bl_0_114 br_0_114 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c115
+ bl_0_115 br_0_115 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c116
+ bl_0_116 br_0_116 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c117
+ bl_0_117 br_0_117 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c116
+ bl_0_116 br_0_116 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c117
+ bl_0_117 br_0_117 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c118
+ bl_0_118 br_0_118 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c119
+ bl_0_119 br_0_119 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c118
+ bl_0_118 br_0_118 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c119
+ bl_0_119 br_0_119 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c120
+ bl_0_120 br_0_120 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c121
+ bl_0_121 br_0_121 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c120
+ bl_0_120 br_0_120 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c121
+ bl_0_121 br_0_121 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c122
+ bl_0_122 br_0_122 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c123
+ bl_0_123 br_0_123 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c122
+ bl_0_122 br_0_122 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c123
+ bl_0_123 br_0_123 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c124
+ bl_0_124 br_0_124 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c125
+ bl_0_125 br_0_125 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c124
+ bl_0_124 br_0_124 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c125
+ bl_0_125 br_0_125 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c126
+ bl_0_126 br_0_126 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c127
+ bl_0_127 br_0_127 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c126
+ bl_0_126 br_0_126 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c127
+ bl_0_127 br_0_127 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c128
+ bl_0_128 br_0_128 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c129
+ bl_0_129 br_0_129 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c128
+ bl_0_128 br_0_128 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c129
+ bl_0_129 br_0_129 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c130
+ bl_0_130 br_0_130 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c131
+ bl_0_131 br_0_131 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c130
+ bl_0_130 br_0_130 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c131
+ bl_0_131 br_0_131 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c132
+ bl_0_132 br_0_132 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c133
+ bl_0_133 br_0_133 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c132
+ bl_0_132 br_0_132 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c133
+ bl_0_133 br_0_133 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c134
+ bl_0_134 br_0_134 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c135
+ bl_0_135 br_0_135 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c134
+ bl_0_134 br_0_134 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c135
+ bl_0_135 br_0_135 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c136
+ bl_0_136 br_0_136 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c137
+ bl_0_137 br_0_137 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c136
+ bl_0_136 br_0_136 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c137
+ bl_0_137 br_0_137 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c138
+ bl_0_138 br_0_138 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c139
+ bl_0_139 br_0_139 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c138
+ bl_0_138 br_0_138 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c139
+ bl_0_139 br_0_139 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c140
+ bl_0_140 br_0_140 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c141
+ bl_0_141 br_0_141 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c140
+ bl_0_140 br_0_140 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c141
+ bl_0_141 br_0_141 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c142
+ bl_0_142 br_0_142 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c143
+ bl_0_143 br_0_143 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c142
+ bl_0_142 br_0_142 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c143
+ bl_0_143 br_0_143 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c144
+ bl_0_144 br_0_144 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c145
+ bl_0_145 br_0_145 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c144
+ bl_0_144 br_0_144 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c145
+ bl_0_145 br_0_145 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c146
+ bl_0_146 br_0_146 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c147
+ bl_0_147 br_0_147 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c146
+ bl_0_146 br_0_146 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c147
+ bl_0_147 br_0_147 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c148
+ bl_0_148 br_0_148 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c149
+ bl_0_149 br_0_149 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c148
+ bl_0_148 br_0_148 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c149
+ bl_0_149 br_0_149 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c150
+ bl_0_150 br_0_150 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c151
+ bl_0_151 br_0_151 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c150
+ bl_0_150 br_0_150 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c151
+ bl_0_151 br_0_151 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c152
+ bl_0_152 br_0_152 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c153
+ bl_0_153 br_0_153 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c152
+ bl_0_152 br_0_152 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c153
+ bl_0_153 br_0_153 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c154
+ bl_0_154 br_0_154 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c155
+ bl_0_155 br_0_155 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c154
+ bl_0_154 br_0_154 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c155
+ bl_0_155 br_0_155 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c156
+ bl_0_156 br_0_156 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c157
+ bl_0_157 br_0_157 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c156
+ bl_0_156 br_0_156 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c157
+ bl_0_157 br_0_157 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c158
+ bl_0_158 br_0_158 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c159
+ bl_0_159 br_0_159 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c158
+ bl_0_158 br_0_158 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c159
+ bl_0_159 br_0_159 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c160
+ bl_0_160 br_0_160 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c161
+ bl_0_161 br_0_161 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c160
+ bl_0_160 br_0_160 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c161
+ bl_0_161 br_0_161 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c162
+ bl_0_162 br_0_162 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c163
+ bl_0_163 br_0_163 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c162
+ bl_0_162 br_0_162 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c163
+ bl_0_163 br_0_163 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c164
+ bl_0_164 br_0_164 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c165
+ bl_0_165 br_0_165 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c164
+ bl_0_164 br_0_164 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c165
+ bl_0_165 br_0_165 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c166
+ bl_0_166 br_0_166 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c167
+ bl_0_167 br_0_167 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c166
+ bl_0_166 br_0_166 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c167
+ bl_0_167 br_0_167 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c168
+ bl_0_168 br_0_168 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c169
+ bl_0_169 br_0_169 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c168
+ bl_0_168 br_0_168 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c169
+ bl_0_169 br_0_169 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c170
+ bl_0_170 br_0_170 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c171
+ bl_0_171 br_0_171 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c170
+ bl_0_170 br_0_170 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c171
+ bl_0_171 br_0_171 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c172
+ bl_0_172 br_0_172 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c173
+ bl_0_173 br_0_173 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c172
+ bl_0_172 br_0_172 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c173
+ bl_0_173 br_0_173 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c174
+ bl_0_174 br_0_174 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c175
+ bl_0_175 br_0_175 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c174
+ bl_0_174 br_0_174 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c175
+ bl_0_175 br_0_175 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c176
+ bl_0_176 br_0_176 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c177
+ bl_0_177 br_0_177 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c176
+ bl_0_176 br_0_176 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c177
+ bl_0_177 br_0_177 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c178
+ bl_0_178 br_0_178 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c179
+ bl_0_179 br_0_179 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c178
+ bl_0_178 br_0_178 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c179
+ bl_0_179 br_0_179 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c180
+ bl_0_180 br_0_180 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c181
+ bl_0_181 br_0_181 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c180
+ bl_0_180 br_0_180 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c181
+ bl_0_181 br_0_181 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c182
+ bl_0_182 br_0_182 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c183
+ bl_0_183 br_0_183 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c182
+ bl_0_182 br_0_182 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c183
+ bl_0_183 br_0_183 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c184
+ bl_0_184 br_0_184 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c185
+ bl_0_185 br_0_185 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c184
+ bl_0_184 br_0_184 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c185
+ bl_0_185 br_0_185 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c186
+ bl_0_186 br_0_186 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c187
+ bl_0_187 br_0_187 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c186
+ bl_0_186 br_0_186 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c187
+ bl_0_187 br_0_187 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c188
+ bl_0_188 br_0_188 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c189
+ bl_0_189 br_0_189 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c188
+ bl_0_188 br_0_188 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c189
+ bl_0_189 br_0_189 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c190
+ bl_0_190 br_0_190 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r4_c191
+ bl_0_191 br_0_191 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c190
+ bl_0_190 br_0_190 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r5_c191
+ bl_0_191 br_0_191 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r4_c192
+ bl_0_192 br_0_192 wl_0_4 vdd gnd
+ sky130_custom_cell
Xbit_r5_c192
+ bl_0_192 br_0_192 wl_0_5 vdd gnd
+ sky130_custom_cell
Xbit_r6_c0
+ bl_0_0 br_0_0 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c1
+ bl_0_1 br_0_1 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c0
+ bl_0_0 br_0_0 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c1
+ bl_0_1 br_0_1 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c2
+ bl_0_2 br_0_2 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c3
+ bl_0_3 br_0_3 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c2
+ bl_0_2 br_0_2 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c3
+ bl_0_3 br_0_3 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c4
+ bl_0_4 br_0_4 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c5
+ bl_0_5 br_0_5 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c4
+ bl_0_4 br_0_4 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c5
+ bl_0_5 br_0_5 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c6
+ bl_0_6 br_0_6 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c7
+ bl_0_7 br_0_7 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c6
+ bl_0_6 br_0_6 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c7
+ bl_0_7 br_0_7 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c8
+ bl_0_8 br_0_8 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c9
+ bl_0_9 br_0_9 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c8
+ bl_0_8 br_0_8 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c9
+ bl_0_9 br_0_9 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c10
+ bl_0_10 br_0_10 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c11
+ bl_0_11 br_0_11 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c10
+ bl_0_10 br_0_10 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c11
+ bl_0_11 br_0_11 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c12
+ bl_0_12 br_0_12 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c13
+ bl_0_13 br_0_13 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c12
+ bl_0_12 br_0_12 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c13
+ bl_0_13 br_0_13 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c14
+ bl_0_14 br_0_14 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c15
+ bl_0_15 br_0_15 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c14
+ bl_0_14 br_0_14 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c15
+ bl_0_15 br_0_15 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c16
+ bl_0_16 br_0_16 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c17
+ bl_0_17 br_0_17 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c16
+ bl_0_16 br_0_16 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c17
+ bl_0_17 br_0_17 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c18
+ bl_0_18 br_0_18 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c19
+ bl_0_19 br_0_19 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c18
+ bl_0_18 br_0_18 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c19
+ bl_0_19 br_0_19 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c20
+ bl_0_20 br_0_20 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c21
+ bl_0_21 br_0_21 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c20
+ bl_0_20 br_0_20 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c21
+ bl_0_21 br_0_21 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c22
+ bl_0_22 br_0_22 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c23
+ bl_0_23 br_0_23 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c22
+ bl_0_22 br_0_22 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c23
+ bl_0_23 br_0_23 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c24
+ bl_0_24 br_0_24 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c25
+ bl_0_25 br_0_25 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c24
+ bl_0_24 br_0_24 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c25
+ bl_0_25 br_0_25 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c26
+ bl_0_26 br_0_26 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c27
+ bl_0_27 br_0_27 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c26
+ bl_0_26 br_0_26 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c27
+ bl_0_27 br_0_27 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c28
+ bl_0_28 br_0_28 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c29
+ bl_0_29 br_0_29 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c28
+ bl_0_28 br_0_28 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c29
+ bl_0_29 br_0_29 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c30
+ bl_0_30 br_0_30 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c31
+ bl_0_31 br_0_31 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c30
+ bl_0_30 br_0_30 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c31
+ bl_0_31 br_0_31 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c32
+ bl_0_32 br_0_32 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c33
+ bl_0_33 br_0_33 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c32
+ bl_0_32 br_0_32 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c33
+ bl_0_33 br_0_33 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c34
+ bl_0_34 br_0_34 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c35
+ bl_0_35 br_0_35 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c34
+ bl_0_34 br_0_34 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c35
+ bl_0_35 br_0_35 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c36
+ bl_0_36 br_0_36 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c37
+ bl_0_37 br_0_37 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c36
+ bl_0_36 br_0_36 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c37
+ bl_0_37 br_0_37 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c38
+ bl_0_38 br_0_38 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c39
+ bl_0_39 br_0_39 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c38
+ bl_0_38 br_0_38 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c39
+ bl_0_39 br_0_39 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c40
+ bl_0_40 br_0_40 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c41
+ bl_0_41 br_0_41 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c40
+ bl_0_40 br_0_40 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c41
+ bl_0_41 br_0_41 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c42
+ bl_0_42 br_0_42 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c43
+ bl_0_43 br_0_43 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c42
+ bl_0_42 br_0_42 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c43
+ bl_0_43 br_0_43 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c44
+ bl_0_44 br_0_44 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c45
+ bl_0_45 br_0_45 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c44
+ bl_0_44 br_0_44 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c45
+ bl_0_45 br_0_45 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c46
+ bl_0_46 br_0_46 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c47
+ bl_0_47 br_0_47 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c46
+ bl_0_46 br_0_46 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c47
+ bl_0_47 br_0_47 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c48
+ bl_0_48 br_0_48 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c49
+ bl_0_49 br_0_49 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c48
+ bl_0_48 br_0_48 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c49
+ bl_0_49 br_0_49 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c50
+ bl_0_50 br_0_50 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c51
+ bl_0_51 br_0_51 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c50
+ bl_0_50 br_0_50 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c51
+ bl_0_51 br_0_51 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c52
+ bl_0_52 br_0_52 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c53
+ bl_0_53 br_0_53 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c52
+ bl_0_52 br_0_52 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c53
+ bl_0_53 br_0_53 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c54
+ bl_0_54 br_0_54 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c55
+ bl_0_55 br_0_55 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c54
+ bl_0_54 br_0_54 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c55
+ bl_0_55 br_0_55 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c56
+ bl_0_56 br_0_56 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c57
+ bl_0_57 br_0_57 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c56
+ bl_0_56 br_0_56 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c57
+ bl_0_57 br_0_57 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c58
+ bl_0_58 br_0_58 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c59
+ bl_0_59 br_0_59 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c58
+ bl_0_58 br_0_58 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c59
+ bl_0_59 br_0_59 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c60
+ bl_0_60 br_0_60 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c61
+ bl_0_61 br_0_61 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c60
+ bl_0_60 br_0_60 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c61
+ bl_0_61 br_0_61 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c62
+ bl_0_62 br_0_62 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c63
+ bl_0_63 br_0_63 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c62
+ bl_0_62 br_0_62 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c63
+ bl_0_63 br_0_63 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c64
+ bl_0_64 br_0_64 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c65
+ bl_0_65 br_0_65 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c64
+ bl_0_64 br_0_64 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c65
+ bl_0_65 br_0_65 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c66
+ bl_0_66 br_0_66 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c67
+ bl_0_67 br_0_67 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c66
+ bl_0_66 br_0_66 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c67
+ bl_0_67 br_0_67 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c68
+ bl_0_68 br_0_68 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c69
+ bl_0_69 br_0_69 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c68
+ bl_0_68 br_0_68 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c69
+ bl_0_69 br_0_69 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c70
+ bl_0_70 br_0_70 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c71
+ bl_0_71 br_0_71 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c70
+ bl_0_70 br_0_70 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c71
+ bl_0_71 br_0_71 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c72
+ bl_0_72 br_0_72 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c73
+ bl_0_73 br_0_73 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c72
+ bl_0_72 br_0_72 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c73
+ bl_0_73 br_0_73 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c74
+ bl_0_74 br_0_74 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c75
+ bl_0_75 br_0_75 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c74
+ bl_0_74 br_0_74 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c75
+ bl_0_75 br_0_75 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c76
+ bl_0_76 br_0_76 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c77
+ bl_0_77 br_0_77 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c76
+ bl_0_76 br_0_76 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c77
+ bl_0_77 br_0_77 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c78
+ bl_0_78 br_0_78 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c79
+ bl_0_79 br_0_79 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c78
+ bl_0_78 br_0_78 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c79
+ bl_0_79 br_0_79 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c80
+ bl_0_80 br_0_80 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c81
+ bl_0_81 br_0_81 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c80
+ bl_0_80 br_0_80 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c81
+ bl_0_81 br_0_81 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c82
+ bl_0_82 br_0_82 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c83
+ bl_0_83 br_0_83 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c82
+ bl_0_82 br_0_82 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c83
+ bl_0_83 br_0_83 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c84
+ bl_0_84 br_0_84 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c85
+ bl_0_85 br_0_85 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c84
+ bl_0_84 br_0_84 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c85
+ bl_0_85 br_0_85 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c86
+ bl_0_86 br_0_86 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c87
+ bl_0_87 br_0_87 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c86
+ bl_0_86 br_0_86 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c87
+ bl_0_87 br_0_87 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c88
+ bl_0_88 br_0_88 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c89
+ bl_0_89 br_0_89 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c88
+ bl_0_88 br_0_88 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c89
+ bl_0_89 br_0_89 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c90
+ bl_0_90 br_0_90 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c91
+ bl_0_91 br_0_91 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c90
+ bl_0_90 br_0_90 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c91
+ bl_0_91 br_0_91 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c92
+ bl_0_92 br_0_92 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c93
+ bl_0_93 br_0_93 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c92
+ bl_0_92 br_0_92 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c93
+ bl_0_93 br_0_93 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c94
+ bl_0_94 br_0_94 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c95
+ bl_0_95 br_0_95 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c94
+ bl_0_94 br_0_94 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c95
+ bl_0_95 br_0_95 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c96
+ bl_0_96 br_0_96 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c97
+ bl_0_97 br_0_97 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c96
+ bl_0_96 br_0_96 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c97
+ bl_0_97 br_0_97 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c98
+ bl_0_98 br_0_98 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c99
+ bl_0_99 br_0_99 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c98
+ bl_0_98 br_0_98 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c99
+ bl_0_99 br_0_99 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c100
+ bl_0_100 br_0_100 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c101
+ bl_0_101 br_0_101 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c100
+ bl_0_100 br_0_100 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c101
+ bl_0_101 br_0_101 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c102
+ bl_0_102 br_0_102 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c103
+ bl_0_103 br_0_103 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c102
+ bl_0_102 br_0_102 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c103
+ bl_0_103 br_0_103 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c104
+ bl_0_104 br_0_104 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c105
+ bl_0_105 br_0_105 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c104
+ bl_0_104 br_0_104 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c105
+ bl_0_105 br_0_105 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c106
+ bl_0_106 br_0_106 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c107
+ bl_0_107 br_0_107 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c106
+ bl_0_106 br_0_106 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c107
+ bl_0_107 br_0_107 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c108
+ bl_0_108 br_0_108 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c109
+ bl_0_109 br_0_109 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c108
+ bl_0_108 br_0_108 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c109
+ bl_0_109 br_0_109 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c110
+ bl_0_110 br_0_110 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c111
+ bl_0_111 br_0_111 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c110
+ bl_0_110 br_0_110 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c111
+ bl_0_111 br_0_111 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c112
+ bl_0_112 br_0_112 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c113
+ bl_0_113 br_0_113 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c112
+ bl_0_112 br_0_112 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c113
+ bl_0_113 br_0_113 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c114
+ bl_0_114 br_0_114 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c115
+ bl_0_115 br_0_115 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c114
+ bl_0_114 br_0_114 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c115
+ bl_0_115 br_0_115 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c116
+ bl_0_116 br_0_116 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c117
+ bl_0_117 br_0_117 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c116
+ bl_0_116 br_0_116 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c117
+ bl_0_117 br_0_117 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c118
+ bl_0_118 br_0_118 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c119
+ bl_0_119 br_0_119 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c118
+ bl_0_118 br_0_118 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c119
+ bl_0_119 br_0_119 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c120
+ bl_0_120 br_0_120 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c121
+ bl_0_121 br_0_121 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c120
+ bl_0_120 br_0_120 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c121
+ bl_0_121 br_0_121 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c122
+ bl_0_122 br_0_122 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c123
+ bl_0_123 br_0_123 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c122
+ bl_0_122 br_0_122 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c123
+ bl_0_123 br_0_123 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c124
+ bl_0_124 br_0_124 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c125
+ bl_0_125 br_0_125 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c124
+ bl_0_124 br_0_124 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c125
+ bl_0_125 br_0_125 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c126
+ bl_0_126 br_0_126 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c127
+ bl_0_127 br_0_127 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c126
+ bl_0_126 br_0_126 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c127
+ bl_0_127 br_0_127 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c128
+ bl_0_128 br_0_128 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c129
+ bl_0_129 br_0_129 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c128
+ bl_0_128 br_0_128 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c129
+ bl_0_129 br_0_129 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c130
+ bl_0_130 br_0_130 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c131
+ bl_0_131 br_0_131 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c130
+ bl_0_130 br_0_130 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c131
+ bl_0_131 br_0_131 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c132
+ bl_0_132 br_0_132 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c133
+ bl_0_133 br_0_133 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c132
+ bl_0_132 br_0_132 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c133
+ bl_0_133 br_0_133 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c134
+ bl_0_134 br_0_134 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c135
+ bl_0_135 br_0_135 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c134
+ bl_0_134 br_0_134 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c135
+ bl_0_135 br_0_135 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c136
+ bl_0_136 br_0_136 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c137
+ bl_0_137 br_0_137 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c136
+ bl_0_136 br_0_136 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c137
+ bl_0_137 br_0_137 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c138
+ bl_0_138 br_0_138 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c139
+ bl_0_139 br_0_139 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c138
+ bl_0_138 br_0_138 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c139
+ bl_0_139 br_0_139 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c140
+ bl_0_140 br_0_140 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c141
+ bl_0_141 br_0_141 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c140
+ bl_0_140 br_0_140 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c141
+ bl_0_141 br_0_141 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c142
+ bl_0_142 br_0_142 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c143
+ bl_0_143 br_0_143 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c142
+ bl_0_142 br_0_142 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c143
+ bl_0_143 br_0_143 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c144
+ bl_0_144 br_0_144 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c145
+ bl_0_145 br_0_145 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c144
+ bl_0_144 br_0_144 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c145
+ bl_0_145 br_0_145 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c146
+ bl_0_146 br_0_146 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c147
+ bl_0_147 br_0_147 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c146
+ bl_0_146 br_0_146 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c147
+ bl_0_147 br_0_147 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c148
+ bl_0_148 br_0_148 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c149
+ bl_0_149 br_0_149 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c148
+ bl_0_148 br_0_148 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c149
+ bl_0_149 br_0_149 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c150
+ bl_0_150 br_0_150 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c151
+ bl_0_151 br_0_151 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c150
+ bl_0_150 br_0_150 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c151
+ bl_0_151 br_0_151 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c152
+ bl_0_152 br_0_152 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c153
+ bl_0_153 br_0_153 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c152
+ bl_0_152 br_0_152 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c153
+ bl_0_153 br_0_153 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c154
+ bl_0_154 br_0_154 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c155
+ bl_0_155 br_0_155 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c154
+ bl_0_154 br_0_154 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c155
+ bl_0_155 br_0_155 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c156
+ bl_0_156 br_0_156 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c157
+ bl_0_157 br_0_157 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c156
+ bl_0_156 br_0_156 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c157
+ bl_0_157 br_0_157 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c158
+ bl_0_158 br_0_158 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c159
+ bl_0_159 br_0_159 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c158
+ bl_0_158 br_0_158 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c159
+ bl_0_159 br_0_159 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c160
+ bl_0_160 br_0_160 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c161
+ bl_0_161 br_0_161 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c160
+ bl_0_160 br_0_160 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c161
+ bl_0_161 br_0_161 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c162
+ bl_0_162 br_0_162 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c163
+ bl_0_163 br_0_163 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c162
+ bl_0_162 br_0_162 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c163
+ bl_0_163 br_0_163 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c164
+ bl_0_164 br_0_164 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c165
+ bl_0_165 br_0_165 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c164
+ bl_0_164 br_0_164 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c165
+ bl_0_165 br_0_165 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c166
+ bl_0_166 br_0_166 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c167
+ bl_0_167 br_0_167 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c166
+ bl_0_166 br_0_166 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c167
+ bl_0_167 br_0_167 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c168
+ bl_0_168 br_0_168 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c169
+ bl_0_169 br_0_169 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c168
+ bl_0_168 br_0_168 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c169
+ bl_0_169 br_0_169 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c170
+ bl_0_170 br_0_170 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c171
+ bl_0_171 br_0_171 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c170
+ bl_0_170 br_0_170 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c171
+ bl_0_171 br_0_171 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c172
+ bl_0_172 br_0_172 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c173
+ bl_0_173 br_0_173 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c172
+ bl_0_172 br_0_172 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c173
+ bl_0_173 br_0_173 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c174
+ bl_0_174 br_0_174 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c175
+ bl_0_175 br_0_175 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c174
+ bl_0_174 br_0_174 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c175
+ bl_0_175 br_0_175 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c176
+ bl_0_176 br_0_176 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c177
+ bl_0_177 br_0_177 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c176
+ bl_0_176 br_0_176 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c177
+ bl_0_177 br_0_177 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c178
+ bl_0_178 br_0_178 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c179
+ bl_0_179 br_0_179 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c178
+ bl_0_178 br_0_178 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c179
+ bl_0_179 br_0_179 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c180
+ bl_0_180 br_0_180 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c181
+ bl_0_181 br_0_181 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c180
+ bl_0_180 br_0_180 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c181
+ bl_0_181 br_0_181 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c182
+ bl_0_182 br_0_182 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c183
+ bl_0_183 br_0_183 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c182
+ bl_0_182 br_0_182 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c183
+ bl_0_183 br_0_183 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c184
+ bl_0_184 br_0_184 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c185
+ bl_0_185 br_0_185 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c184
+ bl_0_184 br_0_184 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c185
+ bl_0_185 br_0_185 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c186
+ bl_0_186 br_0_186 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c187
+ bl_0_187 br_0_187 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c186
+ bl_0_186 br_0_186 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c187
+ bl_0_187 br_0_187 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c188
+ bl_0_188 br_0_188 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c189
+ bl_0_189 br_0_189 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c188
+ bl_0_188 br_0_188 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c189
+ bl_0_189 br_0_189 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c190
+ bl_0_190 br_0_190 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r6_c191
+ bl_0_191 br_0_191 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c190
+ bl_0_190 br_0_190 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r7_c191
+ bl_0_191 br_0_191 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r6_c192
+ bl_0_192 br_0_192 wl_0_6 vdd gnd
+ sky130_custom_cell
Xbit_r7_c192
+ bl_0_192 br_0_192 wl_0_7 vdd gnd
+ sky130_custom_cell
Xbit_r8_c0
+ bl_0_0 br_0_0 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c1
+ bl_0_1 br_0_1 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c0
+ bl_0_0 br_0_0 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c1
+ bl_0_1 br_0_1 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c2
+ bl_0_2 br_0_2 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c3
+ bl_0_3 br_0_3 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c2
+ bl_0_2 br_0_2 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c3
+ bl_0_3 br_0_3 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c4
+ bl_0_4 br_0_4 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c5
+ bl_0_5 br_0_5 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c4
+ bl_0_4 br_0_4 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c5
+ bl_0_5 br_0_5 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c6
+ bl_0_6 br_0_6 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c7
+ bl_0_7 br_0_7 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c6
+ bl_0_6 br_0_6 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c7
+ bl_0_7 br_0_7 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c8
+ bl_0_8 br_0_8 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c9
+ bl_0_9 br_0_9 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c8
+ bl_0_8 br_0_8 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c9
+ bl_0_9 br_0_9 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c10
+ bl_0_10 br_0_10 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c11
+ bl_0_11 br_0_11 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c10
+ bl_0_10 br_0_10 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c11
+ bl_0_11 br_0_11 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c12
+ bl_0_12 br_0_12 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c13
+ bl_0_13 br_0_13 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c12
+ bl_0_12 br_0_12 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c13
+ bl_0_13 br_0_13 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c14
+ bl_0_14 br_0_14 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c15
+ bl_0_15 br_0_15 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c14
+ bl_0_14 br_0_14 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c15
+ bl_0_15 br_0_15 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c16
+ bl_0_16 br_0_16 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c17
+ bl_0_17 br_0_17 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c16
+ bl_0_16 br_0_16 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c17
+ bl_0_17 br_0_17 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c18
+ bl_0_18 br_0_18 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c19
+ bl_0_19 br_0_19 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c18
+ bl_0_18 br_0_18 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c19
+ bl_0_19 br_0_19 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c20
+ bl_0_20 br_0_20 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c21
+ bl_0_21 br_0_21 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c20
+ bl_0_20 br_0_20 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c21
+ bl_0_21 br_0_21 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c22
+ bl_0_22 br_0_22 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c23
+ bl_0_23 br_0_23 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c22
+ bl_0_22 br_0_22 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c23
+ bl_0_23 br_0_23 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c24
+ bl_0_24 br_0_24 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c25
+ bl_0_25 br_0_25 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c24
+ bl_0_24 br_0_24 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c25
+ bl_0_25 br_0_25 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c26
+ bl_0_26 br_0_26 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c27
+ bl_0_27 br_0_27 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c26
+ bl_0_26 br_0_26 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c27
+ bl_0_27 br_0_27 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c28
+ bl_0_28 br_0_28 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c29
+ bl_0_29 br_0_29 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c28
+ bl_0_28 br_0_28 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c29
+ bl_0_29 br_0_29 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c30
+ bl_0_30 br_0_30 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c31
+ bl_0_31 br_0_31 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c30
+ bl_0_30 br_0_30 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c31
+ bl_0_31 br_0_31 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c32
+ bl_0_32 br_0_32 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c33
+ bl_0_33 br_0_33 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c32
+ bl_0_32 br_0_32 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c33
+ bl_0_33 br_0_33 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c34
+ bl_0_34 br_0_34 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c35
+ bl_0_35 br_0_35 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c34
+ bl_0_34 br_0_34 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c35
+ bl_0_35 br_0_35 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c36
+ bl_0_36 br_0_36 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c37
+ bl_0_37 br_0_37 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c36
+ bl_0_36 br_0_36 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c37
+ bl_0_37 br_0_37 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c38
+ bl_0_38 br_0_38 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c39
+ bl_0_39 br_0_39 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c38
+ bl_0_38 br_0_38 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c39
+ bl_0_39 br_0_39 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c40
+ bl_0_40 br_0_40 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c41
+ bl_0_41 br_0_41 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c40
+ bl_0_40 br_0_40 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c41
+ bl_0_41 br_0_41 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c42
+ bl_0_42 br_0_42 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c43
+ bl_0_43 br_0_43 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c42
+ bl_0_42 br_0_42 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c43
+ bl_0_43 br_0_43 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c44
+ bl_0_44 br_0_44 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c45
+ bl_0_45 br_0_45 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c44
+ bl_0_44 br_0_44 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c45
+ bl_0_45 br_0_45 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c46
+ bl_0_46 br_0_46 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c47
+ bl_0_47 br_0_47 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c46
+ bl_0_46 br_0_46 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c47
+ bl_0_47 br_0_47 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c48
+ bl_0_48 br_0_48 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c49
+ bl_0_49 br_0_49 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c48
+ bl_0_48 br_0_48 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c49
+ bl_0_49 br_0_49 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c50
+ bl_0_50 br_0_50 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c51
+ bl_0_51 br_0_51 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c50
+ bl_0_50 br_0_50 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c51
+ bl_0_51 br_0_51 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c52
+ bl_0_52 br_0_52 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c53
+ bl_0_53 br_0_53 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c52
+ bl_0_52 br_0_52 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c53
+ bl_0_53 br_0_53 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c54
+ bl_0_54 br_0_54 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c55
+ bl_0_55 br_0_55 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c54
+ bl_0_54 br_0_54 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c55
+ bl_0_55 br_0_55 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c56
+ bl_0_56 br_0_56 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c57
+ bl_0_57 br_0_57 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c56
+ bl_0_56 br_0_56 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c57
+ bl_0_57 br_0_57 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c58
+ bl_0_58 br_0_58 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c59
+ bl_0_59 br_0_59 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c58
+ bl_0_58 br_0_58 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c59
+ bl_0_59 br_0_59 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c60
+ bl_0_60 br_0_60 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c61
+ bl_0_61 br_0_61 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c60
+ bl_0_60 br_0_60 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c61
+ bl_0_61 br_0_61 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c62
+ bl_0_62 br_0_62 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c63
+ bl_0_63 br_0_63 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c62
+ bl_0_62 br_0_62 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c63
+ bl_0_63 br_0_63 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c64
+ bl_0_64 br_0_64 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c65
+ bl_0_65 br_0_65 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c64
+ bl_0_64 br_0_64 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c65
+ bl_0_65 br_0_65 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c66
+ bl_0_66 br_0_66 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c67
+ bl_0_67 br_0_67 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c66
+ bl_0_66 br_0_66 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c67
+ bl_0_67 br_0_67 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c68
+ bl_0_68 br_0_68 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c69
+ bl_0_69 br_0_69 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c68
+ bl_0_68 br_0_68 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c69
+ bl_0_69 br_0_69 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c70
+ bl_0_70 br_0_70 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c71
+ bl_0_71 br_0_71 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c70
+ bl_0_70 br_0_70 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c71
+ bl_0_71 br_0_71 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c72
+ bl_0_72 br_0_72 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c73
+ bl_0_73 br_0_73 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c72
+ bl_0_72 br_0_72 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c73
+ bl_0_73 br_0_73 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c74
+ bl_0_74 br_0_74 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c75
+ bl_0_75 br_0_75 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c74
+ bl_0_74 br_0_74 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c75
+ bl_0_75 br_0_75 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c76
+ bl_0_76 br_0_76 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c77
+ bl_0_77 br_0_77 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c76
+ bl_0_76 br_0_76 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c77
+ bl_0_77 br_0_77 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c78
+ bl_0_78 br_0_78 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c79
+ bl_0_79 br_0_79 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c78
+ bl_0_78 br_0_78 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c79
+ bl_0_79 br_0_79 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c80
+ bl_0_80 br_0_80 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c81
+ bl_0_81 br_0_81 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c80
+ bl_0_80 br_0_80 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c81
+ bl_0_81 br_0_81 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c82
+ bl_0_82 br_0_82 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c83
+ bl_0_83 br_0_83 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c82
+ bl_0_82 br_0_82 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c83
+ bl_0_83 br_0_83 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c84
+ bl_0_84 br_0_84 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c85
+ bl_0_85 br_0_85 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c84
+ bl_0_84 br_0_84 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c85
+ bl_0_85 br_0_85 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c86
+ bl_0_86 br_0_86 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c87
+ bl_0_87 br_0_87 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c86
+ bl_0_86 br_0_86 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c87
+ bl_0_87 br_0_87 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c88
+ bl_0_88 br_0_88 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c89
+ bl_0_89 br_0_89 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c88
+ bl_0_88 br_0_88 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c89
+ bl_0_89 br_0_89 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c90
+ bl_0_90 br_0_90 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c91
+ bl_0_91 br_0_91 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c90
+ bl_0_90 br_0_90 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c91
+ bl_0_91 br_0_91 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c92
+ bl_0_92 br_0_92 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c93
+ bl_0_93 br_0_93 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c92
+ bl_0_92 br_0_92 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c93
+ bl_0_93 br_0_93 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c94
+ bl_0_94 br_0_94 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c95
+ bl_0_95 br_0_95 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c94
+ bl_0_94 br_0_94 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c95
+ bl_0_95 br_0_95 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c96
+ bl_0_96 br_0_96 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c97
+ bl_0_97 br_0_97 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c96
+ bl_0_96 br_0_96 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c97
+ bl_0_97 br_0_97 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c98
+ bl_0_98 br_0_98 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c99
+ bl_0_99 br_0_99 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c98
+ bl_0_98 br_0_98 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c99
+ bl_0_99 br_0_99 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c100
+ bl_0_100 br_0_100 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c101
+ bl_0_101 br_0_101 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c100
+ bl_0_100 br_0_100 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c101
+ bl_0_101 br_0_101 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c102
+ bl_0_102 br_0_102 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c103
+ bl_0_103 br_0_103 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c102
+ bl_0_102 br_0_102 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c103
+ bl_0_103 br_0_103 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c104
+ bl_0_104 br_0_104 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c105
+ bl_0_105 br_0_105 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c104
+ bl_0_104 br_0_104 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c105
+ bl_0_105 br_0_105 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c106
+ bl_0_106 br_0_106 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c107
+ bl_0_107 br_0_107 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c106
+ bl_0_106 br_0_106 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c107
+ bl_0_107 br_0_107 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c108
+ bl_0_108 br_0_108 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c109
+ bl_0_109 br_0_109 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c108
+ bl_0_108 br_0_108 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c109
+ bl_0_109 br_0_109 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c110
+ bl_0_110 br_0_110 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c111
+ bl_0_111 br_0_111 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c110
+ bl_0_110 br_0_110 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c111
+ bl_0_111 br_0_111 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c112
+ bl_0_112 br_0_112 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c113
+ bl_0_113 br_0_113 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c112
+ bl_0_112 br_0_112 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c113
+ bl_0_113 br_0_113 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c114
+ bl_0_114 br_0_114 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c115
+ bl_0_115 br_0_115 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c114
+ bl_0_114 br_0_114 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c115
+ bl_0_115 br_0_115 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c116
+ bl_0_116 br_0_116 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c117
+ bl_0_117 br_0_117 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c116
+ bl_0_116 br_0_116 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c117
+ bl_0_117 br_0_117 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c118
+ bl_0_118 br_0_118 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c119
+ bl_0_119 br_0_119 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c118
+ bl_0_118 br_0_118 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c119
+ bl_0_119 br_0_119 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c120
+ bl_0_120 br_0_120 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c121
+ bl_0_121 br_0_121 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c120
+ bl_0_120 br_0_120 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c121
+ bl_0_121 br_0_121 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c122
+ bl_0_122 br_0_122 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c123
+ bl_0_123 br_0_123 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c122
+ bl_0_122 br_0_122 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c123
+ bl_0_123 br_0_123 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c124
+ bl_0_124 br_0_124 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c125
+ bl_0_125 br_0_125 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c124
+ bl_0_124 br_0_124 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c125
+ bl_0_125 br_0_125 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c126
+ bl_0_126 br_0_126 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c127
+ bl_0_127 br_0_127 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c126
+ bl_0_126 br_0_126 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c127
+ bl_0_127 br_0_127 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c128
+ bl_0_128 br_0_128 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c129
+ bl_0_129 br_0_129 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c128
+ bl_0_128 br_0_128 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c129
+ bl_0_129 br_0_129 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c130
+ bl_0_130 br_0_130 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c131
+ bl_0_131 br_0_131 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c130
+ bl_0_130 br_0_130 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c131
+ bl_0_131 br_0_131 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c132
+ bl_0_132 br_0_132 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c133
+ bl_0_133 br_0_133 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c132
+ bl_0_132 br_0_132 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c133
+ bl_0_133 br_0_133 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c134
+ bl_0_134 br_0_134 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c135
+ bl_0_135 br_0_135 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c134
+ bl_0_134 br_0_134 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c135
+ bl_0_135 br_0_135 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c136
+ bl_0_136 br_0_136 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c137
+ bl_0_137 br_0_137 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c136
+ bl_0_136 br_0_136 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c137
+ bl_0_137 br_0_137 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c138
+ bl_0_138 br_0_138 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c139
+ bl_0_139 br_0_139 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c138
+ bl_0_138 br_0_138 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c139
+ bl_0_139 br_0_139 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c140
+ bl_0_140 br_0_140 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c141
+ bl_0_141 br_0_141 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c140
+ bl_0_140 br_0_140 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c141
+ bl_0_141 br_0_141 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c142
+ bl_0_142 br_0_142 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c143
+ bl_0_143 br_0_143 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c142
+ bl_0_142 br_0_142 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c143
+ bl_0_143 br_0_143 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c144
+ bl_0_144 br_0_144 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c145
+ bl_0_145 br_0_145 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c144
+ bl_0_144 br_0_144 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c145
+ bl_0_145 br_0_145 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c146
+ bl_0_146 br_0_146 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c147
+ bl_0_147 br_0_147 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c146
+ bl_0_146 br_0_146 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c147
+ bl_0_147 br_0_147 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c148
+ bl_0_148 br_0_148 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c149
+ bl_0_149 br_0_149 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c148
+ bl_0_148 br_0_148 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c149
+ bl_0_149 br_0_149 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c150
+ bl_0_150 br_0_150 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c151
+ bl_0_151 br_0_151 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c150
+ bl_0_150 br_0_150 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c151
+ bl_0_151 br_0_151 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c152
+ bl_0_152 br_0_152 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c153
+ bl_0_153 br_0_153 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c152
+ bl_0_152 br_0_152 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c153
+ bl_0_153 br_0_153 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c154
+ bl_0_154 br_0_154 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c155
+ bl_0_155 br_0_155 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c154
+ bl_0_154 br_0_154 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c155
+ bl_0_155 br_0_155 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c156
+ bl_0_156 br_0_156 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c157
+ bl_0_157 br_0_157 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c156
+ bl_0_156 br_0_156 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c157
+ bl_0_157 br_0_157 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c158
+ bl_0_158 br_0_158 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c159
+ bl_0_159 br_0_159 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c158
+ bl_0_158 br_0_158 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c159
+ bl_0_159 br_0_159 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c160
+ bl_0_160 br_0_160 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c161
+ bl_0_161 br_0_161 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c160
+ bl_0_160 br_0_160 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c161
+ bl_0_161 br_0_161 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c162
+ bl_0_162 br_0_162 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c163
+ bl_0_163 br_0_163 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c162
+ bl_0_162 br_0_162 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c163
+ bl_0_163 br_0_163 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c164
+ bl_0_164 br_0_164 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c165
+ bl_0_165 br_0_165 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c164
+ bl_0_164 br_0_164 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c165
+ bl_0_165 br_0_165 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c166
+ bl_0_166 br_0_166 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c167
+ bl_0_167 br_0_167 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c166
+ bl_0_166 br_0_166 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c167
+ bl_0_167 br_0_167 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c168
+ bl_0_168 br_0_168 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c169
+ bl_0_169 br_0_169 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c168
+ bl_0_168 br_0_168 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c169
+ bl_0_169 br_0_169 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c170
+ bl_0_170 br_0_170 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c171
+ bl_0_171 br_0_171 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c170
+ bl_0_170 br_0_170 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c171
+ bl_0_171 br_0_171 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c172
+ bl_0_172 br_0_172 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c173
+ bl_0_173 br_0_173 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c172
+ bl_0_172 br_0_172 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c173
+ bl_0_173 br_0_173 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c174
+ bl_0_174 br_0_174 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c175
+ bl_0_175 br_0_175 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c174
+ bl_0_174 br_0_174 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c175
+ bl_0_175 br_0_175 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c176
+ bl_0_176 br_0_176 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c177
+ bl_0_177 br_0_177 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c176
+ bl_0_176 br_0_176 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c177
+ bl_0_177 br_0_177 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c178
+ bl_0_178 br_0_178 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c179
+ bl_0_179 br_0_179 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c178
+ bl_0_178 br_0_178 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c179
+ bl_0_179 br_0_179 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c180
+ bl_0_180 br_0_180 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c181
+ bl_0_181 br_0_181 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c180
+ bl_0_180 br_0_180 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c181
+ bl_0_181 br_0_181 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c182
+ bl_0_182 br_0_182 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c183
+ bl_0_183 br_0_183 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c182
+ bl_0_182 br_0_182 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c183
+ bl_0_183 br_0_183 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c184
+ bl_0_184 br_0_184 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c185
+ bl_0_185 br_0_185 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c184
+ bl_0_184 br_0_184 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c185
+ bl_0_185 br_0_185 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c186
+ bl_0_186 br_0_186 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c187
+ bl_0_187 br_0_187 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c186
+ bl_0_186 br_0_186 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c187
+ bl_0_187 br_0_187 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c188
+ bl_0_188 br_0_188 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c189
+ bl_0_189 br_0_189 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c188
+ bl_0_188 br_0_188 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c189
+ bl_0_189 br_0_189 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c190
+ bl_0_190 br_0_190 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r8_c191
+ bl_0_191 br_0_191 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c190
+ bl_0_190 br_0_190 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r9_c191
+ bl_0_191 br_0_191 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r8_c192
+ bl_0_192 br_0_192 wl_0_8 vdd gnd
+ sky130_custom_cell
Xbit_r9_c192
+ bl_0_192 br_0_192 wl_0_9 vdd gnd
+ sky130_custom_cell
Xbit_r10_c0
+ bl_0_0 br_0_0 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c1
+ bl_0_1 br_0_1 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c0
+ bl_0_0 br_0_0 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c1
+ bl_0_1 br_0_1 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c2
+ bl_0_2 br_0_2 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c3
+ bl_0_3 br_0_3 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c2
+ bl_0_2 br_0_2 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c3
+ bl_0_3 br_0_3 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c4
+ bl_0_4 br_0_4 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c5
+ bl_0_5 br_0_5 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c4
+ bl_0_4 br_0_4 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c5
+ bl_0_5 br_0_5 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c6
+ bl_0_6 br_0_6 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c7
+ bl_0_7 br_0_7 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c6
+ bl_0_6 br_0_6 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c7
+ bl_0_7 br_0_7 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c8
+ bl_0_8 br_0_8 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c9
+ bl_0_9 br_0_9 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c8
+ bl_0_8 br_0_8 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c9
+ bl_0_9 br_0_9 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c10
+ bl_0_10 br_0_10 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c11
+ bl_0_11 br_0_11 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c10
+ bl_0_10 br_0_10 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c11
+ bl_0_11 br_0_11 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c12
+ bl_0_12 br_0_12 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c13
+ bl_0_13 br_0_13 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c12
+ bl_0_12 br_0_12 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c13
+ bl_0_13 br_0_13 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c14
+ bl_0_14 br_0_14 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c15
+ bl_0_15 br_0_15 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c14
+ bl_0_14 br_0_14 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c15
+ bl_0_15 br_0_15 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c16
+ bl_0_16 br_0_16 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c17
+ bl_0_17 br_0_17 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c16
+ bl_0_16 br_0_16 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c17
+ bl_0_17 br_0_17 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c18
+ bl_0_18 br_0_18 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c19
+ bl_0_19 br_0_19 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c18
+ bl_0_18 br_0_18 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c19
+ bl_0_19 br_0_19 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c20
+ bl_0_20 br_0_20 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c21
+ bl_0_21 br_0_21 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c20
+ bl_0_20 br_0_20 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c21
+ bl_0_21 br_0_21 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c22
+ bl_0_22 br_0_22 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c23
+ bl_0_23 br_0_23 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c22
+ bl_0_22 br_0_22 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c23
+ bl_0_23 br_0_23 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c24
+ bl_0_24 br_0_24 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c25
+ bl_0_25 br_0_25 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c24
+ bl_0_24 br_0_24 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c25
+ bl_0_25 br_0_25 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c26
+ bl_0_26 br_0_26 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c27
+ bl_0_27 br_0_27 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c26
+ bl_0_26 br_0_26 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c27
+ bl_0_27 br_0_27 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c28
+ bl_0_28 br_0_28 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c29
+ bl_0_29 br_0_29 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c28
+ bl_0_28 br_0_28 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c29
+ bl_0_29 br_0_29 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c30
+ bl_0_30 br_0_30 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c31
+ bl_0_31 br_0_31 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c30
+ bl_0_30 br_0_30 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c31
+ bl_0_31 br_0_31 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c32
+ bl_0_32 br_0_32 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c33
+ bl_0_33 br_0_33 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c32
+ bl_0_32 br_0_32 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c33
+ bl_0_33 br_0_33 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c34
+ bl_0_34 br_0_34 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c35
+ bl_0_35 br_0_35 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c34
+ bl_0_34 br_0_34 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c35
+ bl_0_35 br_0_35 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c36
+ bl_0_36 br_0_36 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c37
+ bl_0_37 br_0_37 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c36
+ bl_0_36 br_0_36 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c37
+ bl_0_37 br_0_37 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c38
+ bl_0_38 br_0_38 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c39
+ bl_0_39 br_0_39 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c38
+ bl_0_38 br_0_38 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c39
+ bl_0_39 br_0_39 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c40
+ bl_0_40 br_0_40 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c41
+ bl_0_41 br_0_41 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c40
+ bl_0_40 br_0_40 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c41
+ bl_0_41 br_0_41 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c42
+ bl_0_42 br_0_42 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c43
+ bl_0_43 br_0_43 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c42
+ bl_0_42 br_0_42 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c43
+ bl_0_43 br_0_43 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c44
+ bl_0_44 br_0_44 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c45
+ bl_0_45 br_0_45 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c44
+ bl_0_44 br_0_44 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c45
+ bl_0_45 br_0_45 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c46
+ bl_0_46 br_0_46 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c47
+ bl_0_47 br_0_47 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c46
+ bl_0_46 br_0_46 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c47
+ bl_0_47 br_0_47 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c48
+ bl_0_48 br_0_48 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c49
+ bl_0_49 br_0_49 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c48
+ bl_0_48 br_0_48 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c49
+ bl_0_49 br_0_49 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c50
+ bl_0_50 br_0_50 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c51
+ bl_0_51 br_0_51 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c50
+ bl_0_50 br_0_50 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c51
+ bl_0_51 br_0_51 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c52
+ bl_0_52 br_0_52 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c53
+ bl_0_53 br_0_53 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c52
+ bl_0_52 br_0_52 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c53
+ bl_0_53 br_0_53 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c54
+ bl_0_54 br_0_54 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c55
+ bl_0_55 br_0_55 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c54
+ bl_0_54 br_0_54 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c55
+ bl_0_55 br_0_55 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c56
+ bl_0_56 br_0_56 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c57
+ bl_0_57 br_0_57 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c56
+ bl_0_56 br_0_56 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c57
+ bl_0_57 br_0_57 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c58
+ bl_0_58 br_0_58 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c59
+ bl_0_59 br_0_59 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c58
+ bl_0_58 br_0_58 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c59
+ bl_0_59 br_0_59 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c60
+ bl_0_60 br_0_60 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c61
+ bl_0_61 br_0_61 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c60
+ bl_0_60 br_0_60 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c61
+ bl_0_61 br_0_61 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c62
+ bl_0_62 br_0_62 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c63
+ bl_0_63 br_0_63 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c62
+ bl_0_62 br_0_62 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c63
+ bl_0_63 br_0_63 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c64
+ bl_0_64 br_0_64 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c65
+ bl_0_65 br_0_65 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c64
+ bl_0_64 br_0_64 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c65
+ bl_0_65 br_0_65 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c66
+ bl_0_66 br_0_66 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c67
+ bl_0_67 br_0_67 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c66
+ bl_0_66 br_0_66 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c67
+ bl_0_67 br_0_67 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c68
+ bl_0_68 br_0_68 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c69
+ bl_0_69 br_0_69 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c68
+ bl_0_68 br_0_68 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c69
+ bl_0_69 br_0_69 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c70
+ bl_0_70 br_0_70 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c71
+ bl_0_71 br_0_71 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c70
+ bl_0_70 br_0_70 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c71
+ bl_0_71 br_0_71 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c72
+ bl_0_72 br_0_72 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c73
+ bl_0_73 br_0_73 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c72
+ bl_0_72 br_0_72 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c73
+ bl_0_73 br_0_73 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c74
+ bl_0_74 br_0_74 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c75
+ bl_0_75 br_0_75 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c74
+ bl_0_74 br_0_74 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c75
+ bl_0_75 br_0_75 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c76
+ bl_0_76 br_0_76 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c77
+ bl_0_77 br_0_77 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c76
+ bl_0_76 br_0_76 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c77
+ bl_0_77 br_0_77 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c78
+ bl_0_78 br_0_78 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c79
+ bl_0_79 br_0_79 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c78
+ bl_0_78 br_0_78 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c79
+ bl_0_79 br_0_79 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c80
+ bl_0_80 br_0_80 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c81
+ bl_0_81 br_0_81 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c80
+ bl_0_80 br_0_80 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c81
+ bl_0_81 br_0_81 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c82
+ bl_0_82 br_0_82 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c83
+ bl_0_83 br_0_83 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c82
+ bl_0_82 br_0_82 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c83
+ bl_0_83 br_0_83 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c84
+ bl_0_84 br_0_84 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c85
+ bl_0_85 br_0_85 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c84
+ bl_0_84 br_0_84 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c85
+ bl_0_85 br_0_85 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c86
+ bl_0_86 br_0_86 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c87
+ bl_0_87 br_0_87 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c86
+ bl_0_86 br_0_86 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c87
+ bl_0_87 br_0_87 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c88
+ bl_0_88 br_0_88 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c89
+ bl_0_89 br_0_89 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c88
+ bl_0_88 br_0_88 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c89
+ bl_0_89 br_0_89 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c90
+ bl_0_90 br_0_90 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c91
+ bl_0_91 br_0_91 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c90
+ bl_0_90 br_0_90 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c91
+ bl_0_91 br_0_91 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c92
+ bl_0_92 br_0_92 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c93
+ bl_0_93 br_0_93 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c92
+ bl_0_92 br_0_92 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c93
+ bl_0_93 br_0_93 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c94
+ bl_0_94 br_0_94 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c95
+ bl_0_95 br_0_95 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c94
+ bl_0_94 br_0_94 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c95
+ bl_0_95 br_0_95 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c96
+ bl_0_96 br_0_96 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c97
+ bl_0_97 br_0_97 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c96
+ bl_0_96 br_0_96 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c97
+ bl_0_97 br_0_97 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c98
+ bl_0_98 br_0_98 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c99
+ bl_0_99 br_0_99 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c98
+ bl_0_98 br_0_98 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c99
+ bl_0_99 br_0_99 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c100
+ bl_0_100 br_0_100 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c101
+ bl_0_101 br_0_101 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c100
+ bl_0_100 br_0_100 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c101
+ bl_0_101 br_0_101 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c102
+ bl_0_102 br_0_102 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c103
+ bl_0_103 br_0_103 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c102
+ bl_0_102 br_0_102 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c103
+ bl_0_103 br_0_103 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c104
+ bl_0_104 br_0_104 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c105
+ bl_0_105 br_0_105 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c104
+ bl_0_104 br_0_104 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c105
+ bl_0_105 br_0_105 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c106
+ bl_0_106 br_0_106 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c107
+ bl_0_107 br_0_107 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c106
+ bl_0_106 br_0_106 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c107
+ bl_0_107 br_0_107 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c108
+ bl_0_108 br_0_108 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c109
+ bl_0_109 br_0_109 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c108
+ bl_0_108 br_0_108 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c109
+ bl_0_109 br_0_109 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c110
+ bl_0_110 br_0_110 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c111
+ bl_0_111 br_0_111 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c110
+ bl_0_110 br_0_110 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c111
+ bl_0_111 br_0_111 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c112
+ bl_0_112 br_0_112 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c113
+ bl_0_113 br_0_113 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c112
+ bl_0_112 br_0_112 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c113
+ bl_0_113 br_0_113 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c114
+ bl_0_114 br_0_114 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c115
+ bl_0_115 br_0_115 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c114
+ bl_0_114 br_0_114 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c115
+ bl_0_115 br_0_115 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c116
+ bl_0_116 br_0_116 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c117
+ bl_0_117 br_0_117 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c116
+ bl_0_116 br_0_116 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c117
+ bl_0_117 br_0_117 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c118
+ bl_0_118 br_0_118 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c119
+ bl_0_119 br_0_119 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c118
+ bl_0_118 br_0_118 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c119
+ bl_0_119 br_0_119 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c120
+ bl_0_120 br_0_120 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c121
+ bl_0_121 br_0_121 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c120
+ bl_0_120 br_0_120 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c121
+ bl_0_121 br_0_121 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c122
+ bl_0_122 br_0_122 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c123
+ bl_0_123 br_0_123 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c122
+ bl_0_122 br_0_122 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c123
+ bl_0_123 br_0_123 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c124
+ bl_0_124 br_0_124 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c125
+ bl_0_125 br_0_125 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c124
+ bl_0_124 br_0_124 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c125
+ bl_0_125 br_0_125 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c126
+ bl_0_126 br_0_126 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c127
+ bl_0_127 br_0_127 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c126
+ bl_0_126 br_0_126 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c127
+ bl_0_127 br_0_127 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c128
+ bl_0_128 br_0_128 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c129
+ bl_0_129 br_0_129 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c128
+ bl_0_128 br_0_128 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c129
+ bl_0_129 br_0_129 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c130
+ bl_0_130 br_0_130 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c131
+ bl_0_131 br_0_131 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c130
+ bl_0_130 br_0_130 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c131
+ bl_0_131 br_0_131 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c132
+ bl_0_132 br_0_132 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c133
+ bl_0_133 br_0_133 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c132
+ bl_0_132 br_0_132 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c133
+ bl_0_133 br_0_133 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c134
+ bl_0_134 br_0_134 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c135
+ bl_0_135 br_0_135 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c134
+ bl_0_134 br_0_134 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c135
+ bl_0_135 br_0_135 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c136
+ bl_0_136 br_0_136 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c137
+ bl_0_137 br_0_137 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c136
+ bl_0_136 br_0_136 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c137
+ bl_0_137 br_0_137 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c138
+ bl_0_138 br_0_138 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c139
+ bl_0_139 br_0_139 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c138
+ bl_0_138 br_0_138 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c139
+ bl_0_139 br_0_139 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c140
+ bl_0_140 br_0_140 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c141
+ bl_0_141 br_0_141 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c140
+ bl_0_140 br_0_140 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c141
+ bl_0_141 br_0_141 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c142
+ bl_0_142 br_0_142 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c143
+ bl_0_143 br_0_143 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c142
+ bl_0_142 br_0_142 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c143
+ bl_0_143 br_0_143 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c144
+ bl_0_144 br_0_144 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c145
+ bl_0_145 br_0_145 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c144
+ bl_0_144 br_0_144 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c145
+ bl_0_145 br_0_145 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c146
+ bl_0_146 br_0_146 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c147
+ bl_0_147 br_0_147 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c146
+ bl_0_146 br_0_146 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c147
+ bl_0_147 br_0_147 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c148
+ bl_0_148 br_0_148 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c149
+ bl_0_149 br_0_149 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c148
+ bl_0_148 br_0_148 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c149
+ bl_0_149 br_0_149 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c150
+ bl_0_150 br_0_150 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c151
+ bl_0_151 br_0_151 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c150
+ bl_0_150 br_0_150 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c151
+ bl_0_151 br_0_151 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c152
+ bl_0_152 br_0_152 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c153
+ bl_0_153 br_0_153 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c152
+ bl_0_152 br_0_152 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c153
+ bl_0_153 br_0_153 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c154
+ bl_0_154 br_0_154 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c155
+ bl_0_155 br_0_155 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c154
+ bl_0_154 br_0_154 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c155
+ bl_0_155 br_0_155 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c156
+ bl_0_156 br_0_156 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c157
+ bl_0_157 br_0_157 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c156
+ bl_0_156 br_0_156 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c157
+ bl_0_157 br_0_157 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c158
+ bl_0_158 br_0_158 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c159
+ bl_0_159 br_0_159 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c158
+ bl_0_158 br_0_158 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c159
+ bl_0_159 br_0_159 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c160
+ bl_0_160 br_0_160 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c161
+ bl_0_161 br_0_161 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c160
+ bl_0_160 br_0_160 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c161
+ bl_0_161 br_0_161 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c162
+ bl_0_162 br_0_162 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c163
+ bl_0_163 br_0_163 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c162
+ bl_0_162 br_0_162 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c163
+ bl_0_163 br_0_163 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c164
+ bl_0_164 br_0_164 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c165
+ bl_0_165 br_0_165 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c164
+ bl_0_164 br_0_164 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c165
+ bl_0_165 br_0_165 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c166
+ bl_0_166 br_0_166 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c167
+ bl_0_167 br_0_167 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c166
+ bl_0_166 br_0_166 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c167
+ bl_0_167 br_0_167 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c168
+ bl_0_168 br_0_168 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c169
+ bl_0_169 br_0_169 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c168
+ bl_0_168 br_0_168 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c169
+ bl_0_169 br_0_169 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c170
+ bl_0_170 br_0_170 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c171
+ bl_0_171 br_0_171 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c170
+ bl_0_170 br_0_170 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c171
+ bl_0_171 br_0_171 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c172
+ bl_0_172 br_0_172 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c173
+ bl_0_173 br_0_173 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c172
+ bl_0_172 br_0_172 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c173
+ bl_0_173 br_0_173 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c174
+ bl_0_174 br_0_174 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c175
+ bl_0_175 br_0_175 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c174
+ bl_0_174 br_0_174 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c175
+ bl_0_175 br_0_175 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c176
+ bl_0_176 br_0_176 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c177
+ bl_0_177 br_0_177 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c176
+ bl_0_176 br_0_176 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c177
+ bl_0_177 br_0_177 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c178
+ bl_0_178 br_0_178 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c179
+ bl_0_179 br_0_179 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c178
+ bl_0_178 br_0_178 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c179
+ bl_0_179 br_0_179 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c180
+ bl_0_180 br_0_180 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c181
+ bl_0_181 br_0_181 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c180
+ bl_0_180 br_0_180 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c181
+ bl_0_181 br_0_181 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c182
+ bl_0_182 br_0_182 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c183
+ bl_0_183 br_0_183 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c182
+ bl_0_182 br_0_182 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c183
+ bl_0_183 br_0_183 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c184
+ bl_0_184 br_0_184 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c185
+ bl_0_185 br_0_185 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c184
+ bl_0_184 br_0_184 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c185
+ bl_0_185 br_0_185 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c186
+ bl_0_186 br_0_186 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c187
+ bl_0_187 br_0_187 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c186
+ bl_0_186 br_0_186 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c187
+ bl_0_187 br_0_187 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c188
+ bl_0_188 br_0_188 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c189
+ bl_0_189 br_0_189 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c188
+ bl_0_188 br_0_188 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c189
+ bl_0_189 br_0_189 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c190
+ bl_0_190 br_0_190 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r10_c191
+ bl_0_191 br_0_191 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c190
+ bl_0_190 br_0_190 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r11_c191
+ bl_0_191 br_0_191 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r10_c192
+ bl_0_192 br_0_192 wl_0_10 vdd gnd
+ sky130_custom_cell
Xbit_r11_c192
+ bl_0_192 br_0_192 wl_0_11 vdd gnd
+ sky130_custom_cell
Xbit_r12_c0
+ bl_0_0 br_0_0 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c1
+ bl_0_1 br_0_1 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c0
+ bl_0_0 br_0_0 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c1
+ bl_0_1 br_0_1 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c2
+ bl_0_2 br_0_2 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c3
+ bl_0_3 br_0_3 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c2
+ bl_0_2 br_0_2 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c3
+ bl_0_3 br_0_3 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c4
+ bl_0_4 br_0_4 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c5
+ bl_0_5 br_0_5 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c4
+ bl_0_4 br_0_4 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c5
+ bl_0_5 br_0_5 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c6
+ bl_0_6 br_0_6 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c7
+ bl_0_7 br_0_7 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c6
+ bl_0_6 br_0_6 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c7
+ bl_0_7 br_0_7 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c8
+ bl_0_8 br_0_8 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c9
+ bl_0_9 br_0_9 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c8
+ bl_0_8 br_0_8 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c9
+ bl_0_9 br_0_9 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c10
+ bl_0_10 br_0_10 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c11
+ bl_0_11 br_0_11 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c10
+ bl_0_10 br_0_10 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c11
+ bl_0_11 br_0_11 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c12
+ bl_0_12 br_0_12 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c13
+ bl_0_13 br_0_13 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c12
+ bl_0_12 br_0_12 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c13
+ bl_0_13 br_0_13 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c14
+ bl_0_14 br_0_14 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c15
+ bl_0_15 br_0_15 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c14
+ bl_0_14 br_0_14 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c15
+ bl_0_15 br_0_15 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c16
+ bl_0_16 br_0_16 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c17
+ bl_0_17 br_0_17 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c16
+ bl_0_16 br_0_16 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c17
+ bl_0_17 br_0_17 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c18
+ bl_0_18 br_0_18 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c19
+ bl_0_19 br_0_19 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c18
+ bl_0_18 br_0_18 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c19
+ bl_0_19 br_0_19 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c20
+ bl_0_20 br_0_20 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c21
+ bl_0_21 br_0_21 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c20
+ bl_0_20 br_0_20 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c21
+ bl_0_21 br_0_21 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c22
+ bl_0_22 br_0_22 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c23
+ bl_0_23 br_0_23 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c22
+ bl_0_22 br_0_22 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c23
+ bl_0_23 br_0_23 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c24
+ bl_0_24 br_0_24 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c25
+ bl_0_25 br_0_25 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c24
+ bl_0_24 br_0_24 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c25
+ bl_0_25 br_0_25 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c26
+ bl_0_26 br_0_26 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c27
+ bl_0_27 br_0_27 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c26
+ bl_0_26 br_0_26 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c27
+ bl_0_27 br_0_27 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c28
+ bl_0_28 br_0_28 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c29
+ bl_0_29 br_0_29 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c28
+ bl_0_28 br_0_28 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c29
+ bl_0_29 br_0_29 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c30
+ bl_0_30 br_0_30 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c31
+ bl_0_31 br_0_31 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c30
+ bl_0_30 br_0_30 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c31
+ bl_0_31 br_0_31 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c32
+ bl_0_32 br_0_32 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c33
+ bl_0_33 br_0_33 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c32
+ bl_0_32 br_0_32 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c33
+ bl_0_33 br_0_33 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c34
+ bl_0_34 br_0_34 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c35
+ bl_0_35 br_0_35 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c34
+ bl_0_34 br_0_34 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c35
+ bl_0_35 br_0_35 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c36
+ bl_0_36 br_0_36 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c37
+ bl_0_37 br_0_37 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c36
+ bl_0_36 br_0_36 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c37
+ bl_0_37 br_0_37 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c38
+ bl_0_38 br_0_38 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c39
+ bl_0_39 br_0_39 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c38
+ bl_0_38 br_0_38 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c39
+ bl_0_39 br_0_39 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c40
+ bl_0_40 br_0_40 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c41
+ bl_0_41 br_0_41 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c40
+ bl_0_40 br_0_40 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c41
+ bl_0_41 br_0_41 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c42
+ bl_0_42 br_0_42 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c43
+ bl_0_43 br_0_43 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c42
+ bl_0_42 br_0_42 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c43
+ bl_0_43 br_0_43 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c44
+ bl_0_44 br_0_44 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c45
+ bl_0_45 br_0_45 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c44
+ bl_0_44 br_0_44 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c45
+ bl_0_45 br_0_45 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c46
+ bl_0_46 br_0_46 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c47
+ bl_0_47 br_0_47 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c46
+ bl_0_46 br_0_46 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c47
+ bl_0_47 br_0_47 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c48
+ bl_0_48 br_0_48 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c49
+ bl_0_49 br_0_49 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c48
+ bl_0_48 br_0_48 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c49
+ bl_0_49 br_0_49 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c50
+ bl_0_50 br_0_50 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c51
+ bl_0_51 br_0_51 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c50
+ bl_0_50 br_0_50 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c51
+ bl_0_51 br_0_51 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c52
+ bl_0_52 br_0_52 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c53
+ bl_0_53 br_0_53 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c52
+ bl_0_52 br_0_52 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c53
+ bl_0_53 br_0_53 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c54
+ bl_0_54 br_0_54 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c55
+ bl_0_55 br_0_55 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c54
+ bl_0_54 br_0_54 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c55
+ bl_0_55 br_0_55 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c56
+ bl_0_56 br_0_56 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c57
+ bl_0_57 br_0_57 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c56
+ bl_0_56 br_0_56 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c57
+ bl_0_57 br_0_57 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c58
+ bl_0_58 br_0_58 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c59
+ bl_0_59 br_0_59 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c58
+ bl_0_58 br_0_58 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c59
+ bl_0_59 br_0_59 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c60
+ bl_0_60 br_0_60 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c61
+ bl_0_61 br_0_61 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c60
+ bl_0_60 br_0_60 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c61
+ bl_0_61 br_0_61 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c62
+ bl_0_62 br_0_62 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c63
+ bl_0_63 br_0_63 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c62
+ bl_0_62 br_0_62 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c63
+ bl_0_63 br_0_63 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c64
+ bl_0_64 br_0_64 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c65
+ bl_0_65 br_0_65 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c64
+ bl_0_64 br_0_64 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c65
+ bl_0_65 br_0_65 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c66
+ bl_0_66 br_0_66 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c67
+ bl_0_67 br_0_67 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c66
+ bl_0_66 br_0_66 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c67
+ bl_0_67 br_0_67 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c68
+ bl_0_68 br_0_68 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c69
+ bl_0_69 br_0_69 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c68
+ bl_0_68 br_0_68 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c69
+ bl_0_69 br_0_69 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c70
+ bl_0_70 br_0_70 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c71
+ bl_0_71 br_0_71 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c70
+ bl_0_70 br_0_70 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c71
+ bl_0_71 br_0_71 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c72
+ bl_0_72 br_0_72 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c73
+ bl_0_73 br_0_73 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c72
+ bl_0_72 br_0_72 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c73
+ bl_0_73 br_0_73 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c74
+ bl_0_74 br_0_74 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c75
+ bl_0_75 br_0_75 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c74
+ bl_0_74 br_0_74 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c75
+ bl_0_75 br_0_75 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c76
+ bl_0_76 br_0_76 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c77
+ bl_0_77 br_0_77 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c76
+ bl_0_76 br_0_76 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c77
+ bl_0_77 br_0_77 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c78
+ bl_0_78 br_0_78 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c79
+ bl_0_79 br_0_79 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c78
+ bl_0_78 br_0_78 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c79
+ bl_0_79 br_0_79 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c80
+ bl_0_80 br_0_80 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c81
+ bl_0_81 br_0_81 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c80
+ bl_0_80 br_0_80 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c81
+ bl_0_81 br_0_81 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c82
+ bl_0_82 br_0_82 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c83
+ bl_0_83 br_0_83 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c82
+ bl_0_82 br_0_82 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c83
+ bl_0_83 br_0_83 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c84
+ bl_0_84 br_0_84 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c85
+ bl_0_85 br_0_85 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c84
+ bl_0_84 br_0_84 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c85
+ bl_0_85 br_0_85 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c86
+ bl_0_86 br_0_86 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c87
+ bl_0_87 br_0_87 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c86
+ bl_0_86 br_0_86 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c87
+ bl_0_87 br_0_87 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c88
+ bl_0_88 br_0_88 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c89
+ bl_0_89 br_0_89 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c88
+ bl_0_88 br_0_88 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c89
+ bl_0_89 br_0_89 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c90
+ bl_0_90 br_0_90 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c91
+ bl_0_91 br_0_91 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c90
+ bl_0_90 br_0_90 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c91
+ bl_0_91 br_0_91 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c92
+ bl_0_92 br_0_92 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c93
+ bl_0_93 br_0_93 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c92
+ bl_0_92 br_0_92 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c93
+ bl_0_93 br_0_93 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c94
+ bl_0_94 br_0_94 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c95
+ bl_0_95 br_0_95 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c94
+ bl_0_94 br_0_94 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c95
+ bl_0_95 br_0_95 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c96
+ bl_0_96 br_0_96 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c97
+ bl_0_97 br_0_97 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c96
+ bl_0_96 br_0_96 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c97
+ bl_0_97 br_0_97 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c98
+ bl_0_98 br_0_98 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c99
+ bl_0_99 br_0_99 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c98
+ bl_0_98 br_0_98 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c99
+ bl_0_99 br_0_99 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c100
+ bl_0_100 br_0_100 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c101
+ bl_0_101 br_0_101 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c100
+ bl_0_100 br_0_100 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c101
+ bl_0_101 br_0_101 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c102
+ bl_0_102 br_0_102 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c103
+ bl_0_103 br_0_103 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c102
+ bl_0_102 br_0_102 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c103
+ bl_0_103 br_0_103 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c104
+ bl_0_104 br_0_104 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c105
+ bl_0_105 br_0_105 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c104
+ bl_0_104 br_0_104 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c105
+ bl_0_105 br_0_105 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c106
+ bl_0_106 br_0_106 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c107
+ bl_0_107 br_0_107 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c106
+ bl_0_106 br_0_106 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c107
+ bl_0_107 br_0_107 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c108
+ bl_0_108 br_0_108 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c109
+ bl_0_109 br_0_109 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c108
+ bl_0_108 br_0_108 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c109
+ bl_0_109 br_0_109 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c110
+ bl_0_110 br_0_110 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c111
+ bl_0_111 br_0_111 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c110
+ bl_0_110 br_0_110 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c111
+ bl_0_111 br_0_111 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c112
+ bl_0_112 br_0_112 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c113
+ bl_0_113 br_0_113 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c112
+ bl_0_112 br_0_112 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c113
+ bl_0_113 br_0_113 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c114
+ bl_0_114 br_0_114 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c115
+ bl_0_115 br_0_115 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c114
+ bl_0_114 br_0_114 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c115
+ bl_0_115 br_0_115 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c116
+ bl_0_116 br_0_116 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c117
+ bl_0_117 br_0_117 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c116
+ bl_0_116 br_0_116 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c117
+ bl_0_117 br_0_117 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c118
+ bl_0_118 br_0_118 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c119
+ bl_0_119 br_0_119 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c118
+ bl_0_118 br_0_118 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c119
+ bl_0_119 br_0_119 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c120
+ bl_0_120 br_0_120 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c121
+ bl_0_121 br_0_121 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c120
+ bl_0_120 br_0_120 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c121
+ bl_0_121 br_0_121 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c122
+ bl_0_122 br_0_122 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c123
+ bl_0_123 br_0_123 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c122
+ bl_0_122 br_0_122 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c123
+ bl_0_123 br_0_123 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c124
+ bl_0_124 br_0_124 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c125
+ bl_0_125 br_0_125 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c124
+ bl_0_124 br_0_124 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c125
+ bl_0_125 br_0_125 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c126
+ bl_0_126 br_0_126 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c127
+ bl_0_127 br_0_127 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c126
+ bl_0_126 br_0_126 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c127
+ bl_0_127 br_0_127 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c128
+ bl_0_128 br_0_128 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c129
+ bl_0_129 br_0_129 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c128
+ bl_0_128 br_0_128 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c129
+ bl_0_129 br_0_129 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c130
+ bl_0_130 br_0_130 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c131
+ bl_0_131 br_0_131 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c130
+ bl_0_130 br_0_130 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c131
+ bl_0_131 br_0_131 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c132
+ bl_0_132 br_0_132 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c133
+ bl_0_133 br_0_133 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c132
+ bl_0_132 br_0_132 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c133
+ bl_0_133 br_0_133 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c134
+ bl_0_134 br_0_134 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c135
+ bl_0_135 br_0_135 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c134
+ bl_0_134 br_0_134 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c135
+ bl_0_135 br_0_135 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c136
+ bl_0_136 br_0_136 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c137
+ bl_0_137 br_0_137 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c136
+ bl_0_136 br_0_136 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c137
+ bl_0_137 br_0_137 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c138
+ bl_0_138 br_0_138 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c139
+ bl_0_139 br_0_139 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c138
+ bl_0_138 br_0_138 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c139
+ bl_0_139 br_0_139 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c140
+ bl_0_140 br_0_140 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c141
+ bl_0_141 br_0_141 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c140
+ bl_0_140 br_0_140 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c141
+ bl_0_141 br_0_141 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c142
+ bl_0_142 br_0_142 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c143
+ bl_0_143 br_0_143 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c142
+ bl_0_142 br_0_142 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c143
+ bl_0_143 br_0_143 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c144
+ bl_0_144 br_0_144 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c145
+ bl_0_145 br_0_145 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c144
+ bl_0_144 br_0_144 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c145
+ bl_0_145 br_0_145 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c146
+ bl_0_146 br_0_146 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c147
+ bl_0_147 br_0_147 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c146
+ bl_0_146 br_0_146 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c147
+ bl_0_147 br_0_147 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c148
+ bl_0_148 br_0_148 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c149
+ bl_0_149 br_0_149 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c148
+ bl_0_148 br_0_148 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c149
+ bl_0_149 br_0_149 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c150
+ bl_0_150 br_0_150 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c151
+ bl_0_151 br_0_151 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c150
+ bl_0_150 br_0_150 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c151
+ bl_0_151 br_0_151 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c152
+ bl_0_152 br_0_152 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c153
+ bl_0_153 br_0_153 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c152
+ bl_0_152 br_0_152 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c153
+ bl_0_153 br_0_153 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c154
+ bl_0_154 br_0_154 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c155
+ bl_0_155 br_0_155 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c154
+ bl_0_154 br_0_154 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c155
+ bl_0_155 br_0_155 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c156
+ bl_0_156 br_0_156 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c157
+ bl_0_157 br_0_157 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c156
+ bl_0_156 br_0_156 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c157
+ bl_0_157 br_0_157 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c158
+ bl_0_158 br_0_158 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c159
+ bl_0_159 br_0_159 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c158
+ bl_0_158 br_0_158 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c159
+ bl_0_159 br_0_159 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c160
+ bl_0_160 br_0_160 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c161
+ bl_0_161 br_0_161 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c160
+ bl_0_160 br_0_160 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c161
+ bl_0_161 br_0_161 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c162
+ bl_0_162 br_0_162 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c163
+ bl_0_163 br_0_163 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c162
+ bl_0_162 br_0_162 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c163
+ bl_0_163 br_0_163 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c164
+ bl_0_164 br_0_164 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c165
+ bl_0_165 br_0_165 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c164
+ bl_0_164 br_0_164 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c165
+ bl_0_165 br_0_165 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c166
+ bl_0_166 br_0_166 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c167
+ bl_0_167 br_0_167 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c166
+ bl_0_166 br_0_166 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c167
+ bl_0_167 br_0_167 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c168
+ bl_0_168 br_0_168 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c169
+ bl_0_169 br_0_169 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c168
+ bl_0_168 br_0_168 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c169
+ bl_0_169 br_0_169 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c170
+ bl_0_170 br_0_170 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c171
+ bl_0_171 br_0_171 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c170
+ bl_0_170 br_0_170 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c171
+ bl_0_171 br_0_171 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c172
+ bl_0_172 br_0_172 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c173
+ bl_0_173 br_0_173 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c172
+ bl_0_172 br_0_172 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c173
+ bl_0_173 br_0_173 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c174
+ bl_0_174 br_0_174 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c175
+ bl_0_175 br_0_175 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c174
+ bl_0_174 br_0_174 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c175
+ bl_0_175 br_0_175 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c176
+ bl_0_176 br_0_176 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c177
+ bl_0_177 br_0_177 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c176
+ bl_0_176 br_0_176 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c177
+ bl_0_177 br_0_177 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c178
+ bl_0_178 br_0_178 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c179
+ bl_0_179 br_0_179 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c178
+ bl_0_178 br_0_178 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c179
+ bl_0_179 br_0_179 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c180
+ bl_0_180 br_0_180 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c181
+ bl_0_181 br_0_181 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c180
+ bl_0_180 br_0_180 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c181
+ bl_0_181 br_0_181 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c182
+ bl_0_182 br_0_182 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c183
+ bl_0_183 br_0_183 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c182
+ bl_0_182 br_0_182 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c183
+ bl_0_183 br_0_183 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c184
+ bl_0_184 br_0_184 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c185
+ bl_0_185 br_0_185 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c184
+ bl_0_184 br_0_184 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c185
+ bl_0_185 br_0_185 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c186
+ bl_0_186 br_0_186 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c187
+ bl_0_187 br_0_187 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c186
+ bl_0_186 br_0_186 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c187
+ bl_0_187 br_0_187 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c188
+ bl_0_188 br_0_188 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c189
+ bl_0_189 br_0_189 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c188
+ bl_0_188 br_0_188 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c189
+ bl_0_189 br_0_189 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c190
+ bl_0_190 br_0_190 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r12_c191
+ bl_0_191 br_0_191 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c190
+ bl_0_190 br_0_190 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r13_c191
+ bl_0_191 br_0_191 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r12_c192
+ bl_0_192 br_0_192 wl_0_12 vdd gnd
+ sky130_custom_cell
Xbit_r13_c192
+ bl_0_192 br_0_192 wl_0_13 vdd gnd
+ sky130_custom_cell
Xbit_r14_c0
+ bl_0_0 br_0_0 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c1
+ bl_0_1 br_0_1 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c0
+ bl_0_0 br_0_0 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c1
+ bl_0_1 br_0_1 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c2
+ bl_0_2 br_0_2 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c3
+ bl_0_3 br_0_3 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c2
+ bl_0_2 br_0_2 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c3
+ bl_0_3 br_0_3 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c4
+ bl_0_4 br_0_4 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c5
+ bl_0_5 br_0_5 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c4
+ bl_0_4 br_0_4 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c5
+ bl_0_5 br_0_5 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c6
+ bl_0_6 br_0_6 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c7
+ bl_0_7 br_0_7 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c6
+ bl_0_6 br_0_6 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c7
+ bl_0_7 br_0_7 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c8
+ bl_0_8 br_0_8 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c9
+ bl_0_9 br_0_9 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c8
+ bl_0_8 br_0_8 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c9
+ bl_0_9 br_0_9 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c10
+ bl_0_10 br_0_10 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c11
+ bl_0_11 br_0_11 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c10
+ bl_0_10 br_0_10 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c11
+ bl_0_11 br_0_11 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c12
+ bl_0_12 br_0_12 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c13
+ bl_0_13 br_0_13 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c12
+ bl_0_12 br_0_12 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c13
+ bl_0_13 br_0_13 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c14
+ bl_0_14 br_0_14 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c15
+ bl_0_15 br_0_15 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c14
+ bl_0_14 br_0_14 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c15
+ bl_0_15 br_0_15 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c16
+ bl_0_16 br_0_16 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c17
+ bl_0_17 br_0_17 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c16
+ bl_0_16 br_0_16 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c17
+ bl_0_17 br_0_17 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c18
+ bl_0_18 br_0_18 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c19
+ bl_0_19 br_0_19 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c18
+ bl_0_18 br_0_18 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c19
+ bl_0_19 br_0_19 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c20
+ bl_0_20 br_0_20 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c21
+ bl_0_21 br_0_21 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c20
+ bl_0_20 br_0_20 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c21
+ bl_0_21 br_0_21 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c22
+ bl_0_22 br_0_22 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c23
+ bl_0_23 br_0_23 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c22
+ bl_0_22 br_0_22 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c23
+ bl_0_23 br_0_23 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c24
+ bl_0_24 br_0_24 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c25
+ bl_0_25 br_0_25 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c24
+ bl_0_24 br_0_24 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c25
+ bl_0_25 br_0_25 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c26
+ bl_0_26 br_0_26 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c27
+ bl_0_27 br_0_27 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c26
+ bl_0_26 br_0_26 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c27
+ bl_0_27 br_0_27 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c28
+ bl_0_28 br_0_28 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c29
+ bl_0_29 br_0_29 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c28
+ bl_0_28 br_0_28 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c29
+ bl_0_29 br_0_29 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c30
+ bl_0_30 br_0_30 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c31
+ bl_0_31 br_0_31 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c30
+ bl_0_30 br_0_30 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c31
+ bl_0_31 br_0_31 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c32
+ bl_0_32 br_0_32 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c33
+ bl_0_33 br_0_33 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c32
+ bl_0_32 br_0_32 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c33
+ bl_0_33 br_0_33 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c34
+ bl_0_34 br_0_34 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c35
+ bl_0_35 br_0_35 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c34
+ bl_0_34 br_0_34 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c35
+ bl_0_35 br_0_35 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c36
+ bl_0_36 br_0_36 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c37
+ bl_0_37 br_0_37 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c36
+ bl_0_36 br_0_36 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c37
+ bl_0_37 br_0_37 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c38
+ bl_0_38 br_0_38 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c39
+ bl_0_39 br_0_39 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c38
+ bl_0_38 br_0_38 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c39
+ bl_0_39 br_0_39 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c40
+ bl_0_40 br_0_40 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c41
+ bl_0_41 br_0_41 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c40
+ bl_0_40 br_0_40 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c41
+ bl_0_41 br_0_41 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c42
+ bl_0_42 br_0_42 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c43
+ bl_0_43 br_0_43 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c42
+ bl_0_42 br_0_42 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c43
+ bl_0_43 br_0_43 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c44
+ bl_0_44 br_0_44 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c45
+ bl_0_45 br_0_45 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c44
+ bl_0_44 br_0_44 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c45
+ bl_0_45 br_0_45 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c46
+ bl_0_46 br_0_46 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c47
+ bl_0_47 br_0_47 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c46
+ bl_0_46 br_0_46 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c47
+ bl_0_47 br_0_47 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c48
+ bl_0_48 br_0_48 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c49
+ bl_0_49 br_0_49 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c48
+ bl_0_48 br_0_48 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c49
+ bl_0_49 br_0_49 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c50
+ bl_0_50 br_0_50 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c51
+ bl_0_51 br_0_51 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c50
+ bl_0_50 br_0_50 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c51
+ bl_0_51 br_0_51 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c52
+ bl_0_52 br_0_52 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c53
+ bl_0_53 br_0_53 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c52
+ bl_0_52 br_0_52 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c53
+ bl_0_53 br_0_53 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c54
+ bl_0_54 br_0_54 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c55
+ bl_0_55 br_0_55 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c54
+ bl_0_54 br_0_54 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c55
+ bl_0_55 br_0_55 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c56
+ bl_0_56 br_0_56 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c57
+ bl_0_57 br_0_57 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c56
+ bl_0_56 br_0_56 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c57
+ bl_0_57 br_0_57 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c58
+ bl_0_58 br_0_58 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c59
+ bl_0_59 br_0_59 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c58
+ bl_0_58 br_0_58 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c59
+ bl_0_59 br_0_59 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c60
+ bl_0_60 br_0_60 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c61
+ bl_0_61 br_0_61 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c60
+ bl_0_60 br_0_60 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c61
+ bl_0_61 br_0_61 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c62
+ bl_0_62 br_0_62 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c63
+ bl_0_63 br_0_63 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c62
+ bl_0_62 br_0_62 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c63
+ bl_0_63 br_0_63 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c64
+ bl_0_64 br_0_64 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c65
+ bl_0_65 br_0_65 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c64
+ bl_0_64 br_0_64 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c65
+ bl_0_65 br_0_65 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c66
+ bl_0_66 br_0_66 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c67
+ bl_0_67 br_0_67 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c66
+ bl_0_66 br_0_66 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c67
+ bl_0_67 br_0_67 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c68
+ bl_0_68 br_0_68 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c69
+ bl_0_69 br_0_69 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c68
+ bl_0_68 br_0_68 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c69
+ bl_0_69 br_0_69 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c70
+ bl_0_70 br_0_70 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c71
+ bl_0_71 br_0_71 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c70
+ bl_0_70 br_0_70 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c71
+ bl_0_71 br_0_71 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c72
+ bl_0_72 br_0_72 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c73
+ bl_0_73 br_0_73 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c72
+ bl_0_72 br_0_72 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c73
+ bl_0_73 br_0_73 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c74
+ bl_0_74 br_0_74 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c75
+ bl_0_75 br_0_75 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c74
+ bl_0_74 br_0_74 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c75
+ bl_0_75 br_0_75 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c76
+ bl_0_76 br_0_76 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c77
+ bl_0_77 br_0_77 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c76
+ bl_0_76 br_0_76 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c77
+ bl_0_77 br_0_77 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c78
+ bl_0_78 br_0_78 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c79
+ bl_0_79 br_0_79 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c78
+ bl_0_78 br_0_78 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c79
+ bl_0_79 br_0_79 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c80
+ bl_0_80 br_0_80 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c81
+ bl_0_81 br_0_81 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c80
+ bl_0_80 br_0_80 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c81
+ bl_0_81 br_0_81 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c82
+ bl_0_82 br_0_82 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c83
+ bl_0_83 br_0_83 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c82
+ bl_0_82 br_0_82 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c83
+ bl_0_83 br_0_83 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c84
+ bl_0_84 br_0_84 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c85
+ bl_0_85 br_0_85 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c84
+ bl_0_84 br_0_84 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c85
+ bl_0_85 br_0_85 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c86
+ bl_0_86 br_0_86 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c87
+ bl_0_87 br_0_87 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c86
+ bl_0_86 br_0_86 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c87
+ bl_0_87 br_0_87 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c88
+ bl_0_88 br_0_88 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c89
+ bl_0_89 br_0_89 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c88
+ bl_0_88 br_0_88 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c89
+ bl_0_89 br_0_89 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c90
+ bl_0_90 br_0_90 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c91
+ bl_0_91 br_0_91 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c90
+ bl_0_90 br_0_90 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c91
+ bl_0_91 br_0_91 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c92
+ bl_0_92 br_0_92 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c93
+ bl_0_93 br_0_93 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c92
+ bl_0_92 br_0_92 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c93
+ bl_0_93 br_0_93 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c94
+ bl_0_94 br_0_94 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c95
+ bl_0_95 br_0_95 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c94
+ bl_0_94 br_0_94 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c95
+ bl_0_95 br_0_95 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c96
+ bl_0_96 br_0_96 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c97
+ bl_0_97 br_0_97 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c96
+ bl_0_96 br_0_96 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c97
+ bl_0_97 br_0_97 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c98
+ bl_0_98 br_0_98 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c99
+ bl_0_99 br_0_99 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c98
+ bl_0_98 br_0_98 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c99
+ bl_0_99 br_0_99 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c100
+ bl_0_100 br_0_100 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c101
+ bl_0_101 br_0_101 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c100
+ bl_0_100 br_0_100 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c101
+ bl_0_101 br_0_101 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c102
+ bl_0_102 br_0_102 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c103
+ bl_0_103 br_0_103 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c102
+ bl_0_102 br_0_102 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c103
+ bl_0_103 br_0_103 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c104
+ bl_0_104 br_0_104 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c105
+ bl_0_105 br_0_105 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c104
+ bl_0_104 br_0_104 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c105
+ bl_0_105 br_0_105 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c106
+ bl_0_106 br_0_106 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c107
+ bl_0_107 br_0_107 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c106
+ bl_0_106 br_0_106 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c107
+ bl_0_107 br_0_107 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c108
+ bl_0_108 br_0_108 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c109
+ bl_0_109 br_0_109 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c108
+ bl_0_108 br_0_108 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c109
+ bl_0_109 br_0_109 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c110
+ bl_0_110 br_0_110 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c111
+ bl_0_111 br_0_111 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c110
+ bl_0_110 br_0_110 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c111
+ bl_0_111 br_0_111 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c112
+ bl_0_112 br_0_112 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c113
+ bl_0_113 br_0_113 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c112
+ bl_0_112 br_0_112 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c113
+ bl_0_113 br_0_113 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c114
+ bl_0_114 br_0_114 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c115
+ bl_0_115 br_0_115 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c114
+ bl_0_114 br_0_114 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c115
+ bl_0_115 br_0_115 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c116
+ bl_0_116 br_0_116 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c117
+ bl_0_117 br_0_117 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c116
+ bl_0_116 br_0_116 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c117
+ bl_0_117 br_0_117 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c118
+ bl_0_118 br_0_118 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c119
+ bl_0_119 br_0_119 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c118
+ bl_0_118 br_0_118 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c119
+ bl_0_119 br_0_119 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c120
+ bl_0_120 br_0_120 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c121
+ bl_0_121 br_0_121 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c120
+ bl_0_120 br_0_120 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c121
+ bl_0_121 br_0_121 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c122
+ bl_0_122 br_0_122 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c123
+ bl_0_123 br_0_123 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c122
+ bl_0_122 br_0_122 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c123
+ bl_0_123 br_0_123 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c124
+ bl_0_124 br_0_124 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c125
+ bl_0_125 br_0_125 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c124
+ bl_0_124 br_0_124 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c125
+ bl_0_125 br_0_125 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c126
+ bl_0_126 br_0_126 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c127
+ bl_0_127 br_0_127 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c126
+ bl_0_126 br_0_126 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c127
+ bl_0_127 br_0_127 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c128
+ bl_0_128 br_0_128 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c129
+ bl_0_129 br_0_129 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c128
+ bl_0_128 br_0_128 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c129
+ bl_0_129 br_0_129 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c130
+ bl_0_130 br_0_130 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c131
+ bl_0_131 br_0_131 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c130
+ bl_0_130 br_0_130 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c131
+ bl_0_131 br_0_131 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c132
+ bl_0_132 br_0_132 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c133
+ bl_0_133 br_0_133 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c132
+ bl_0_132 br_0_132 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c133
+ bl_0_133 br_0_133 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c134
+ bl_0_134 br_0_134 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c135
+ bl_0_135 br_0_135 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c134
+ bl_0_134 br_0_134 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c135
+ bl_0_135 br_0_135 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c136
+ bl_0_136 br_0_136 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c137
+ bl_0_137 br_0_137 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c136
+ bl_0_136 br_0_136 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c137
+ bl_0_137 br_0_137 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c138
+ bl_0_138 br_0_138 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c139
+ bl_0_139 br_0_139 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c138
+ bl_0_138 br_0_138 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c139
+ bl_0_139 br_0_139 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c140
+ bl_0_140 br_0_140 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c141
+ bl_0_141 br_0_141 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c140
+ bl_0_140 br_0_140 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c141
+ bl_0_141 br_0_141 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c142
+ bl_0_142 br_0_142 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c143
+ bl_0_143 br_0_143 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c142
+ bl_0_142 br_0_142 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c143
+ bl_0_143 br_0_143 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c144
+ bl_0_144 br_0_144 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c145
+ bl_0_145 br_0_145 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c144
+ bl_0_144 br_0_144 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c145
+ bl_0_145 br_0_145 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c146
+ bl_0_146 br_0_146 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c147
+ bl_0_147 br_0_147 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c146
+ bl_0_146 br_0_146 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c147
+ bl_0_147 br_0_147 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c148
+ bl_0_148 br_0_148 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c149
+ bl_0_149 br_0_149 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c148
+ bl_0_148 br_0_148 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c149
+ bl_0_149 br_0_149 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c150
+ bl_0_150 br_0_150 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c151
+ bl_0_151 br_0_151 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c150
+ bl_0_150 br_0_150 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c151
+ bl_0_151 br_0_151 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c152
+ bl_0_152 br_0_152 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c153
+ bl_0_153 br_0_153 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c152
+ bl_0_152 br_0_152 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c153
+ bl_0_153 br_0_153 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c154
+ bl_0_154 br_0_154 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c155
+ bl_0_155 br_0_155 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c154
+ bl_0_154 br_0_154 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c155
+ bl_0_155 br_0_155 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c156
+ bl_0_156 br_0_156 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c157
+ bl_0_157 br_0_157 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c156
+ bl_0_156 br_0_156 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c157
+ bl_0_157 br_0_157 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c158
+ bl_0_158 br_0_158 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c159
+ bl_0_159 br_0_159 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c158
+ bl_0_158 br_0_158 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c159
+ bl_0_159 br_0_159 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c160
+ bl_0_160 br_0_160 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c161
+ bl_0_161 br_0_161 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c160
+ bl_0_160 br_0_160 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c161
+ bl_0_161 br_0_161 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c162
+ bl_0_162 br_0_162 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c163
+ bl_0_163 br_0_163 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c162
+ bl_0_162 br_0_162 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c163
+ bl_0_163 br_0_163 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c164
+ bl_0_164 br_0_164 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c165
+ bl_0_165 br_0_165 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c164
+ bl_0_164 br_0_164 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c165
+ bl_0_165 br_0_165 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c166
+ bl_0_166 br_0_166 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c167
+ bl_0_167 br_0_167 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c166
+ bl_0_166 br_0_166 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c167
+ bl_0_167 br_0_167 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c168
+ bl_0_168 br_0_168 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c169
+ bl_0_169 br_0_169 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c168
+ bl_0_168 br_0_168 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c169
+ bl_0_169 br_0_169 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c170
+ bl_0_170 br_0_170 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c171
+ bl_0_171 br_0_171 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c170
+ bl_0_170 br_0_170 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c171
+ bl_0_171 br_0_171 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c172
+ bl_0_172 br_0_172 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c173
+ bl_0_173 br_0_173 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c172
+ bl_0_172 br_0_172 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c173
+ bl_0_173 br_0_173 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c174
+ bl_0_174 br_0_174 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c175
+ bl_0_175 br_0_175 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c174
+ bl_0_174 br_0_174 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c175
+ bl_0_175 br_0_175 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c176
+ bl_0_176 br_0_176 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c177
+ bl_0_177 br_0_177 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c176
+ bl_0_176 br_0_176 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c177
+ bl_0_177 br_0_177 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c178
+ bl_0_178 br_0_178 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c179
+ bl_0_179 br_0_179 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c178
+ bl_0_178 br_0_178 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c179
+ bl_0_179 br_0_179 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c180
+ bl_0_180 br_0_180 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c181
+ bl_0_181 br_0_181 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c180
+ bl_0_180 br_0_180 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c181
+ bl_0_181 br_0_181 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c182
+ bl_0_182 br_0_182 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c183
+ bl_0_183 br_0_183 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c182
+ bl_0_182 br_0_182 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c183
+ bl_0_183 br_0_183 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c184
+ bl_0_184 br_0_184 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c185
+ bl_0_185 br_0_185 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c184
+ bl_0_184 br_0_184 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c185
+ bl_0_185 br_0_185 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c186
+ bl_0_186 br_0_186 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c187
+ bl_0_187 br_0_187 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c186
+ bl_0_186 br_0_186 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c187
+ bl_0_187 br_0_187 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c188
+ bl_0_188 br_0_188 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c189
+ bl_0_189 br_0_189 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c188
+ bl_0_188 br_0_188 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c189
+ bl_0_189 br_0_189 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c190
+ bl_0_190 br_0_190 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r14_c191
+ bl_0_191 br_0_191 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c190
+ bl_0_190 br_0_190 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r15_c191
+ bl_0_191 br_0_191 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r14_c192
+ bl_0_192 br_0_192 wl_0_14 vdd gnd
+ sky130_custom_cell
Xbit_r15_c192
+ bl_0_192 br_0_192 wl_0_15 vdd gnd
+ sky130_custom_cell
Xbit_r16_c0
+ bl_0_0 br_0_0 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c1
+ bl_0_1 br_0_1 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c2
+ bl_0_2 br_0_2 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c3
+ bl_0_3 br_0_3 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c4
+ bl_0_4 br_0_4 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c5
+ bl_0_5 br_0_5 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c6
+ bl_0_6 br_0_6 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c7
+ bl_0_7 br_0_7 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c8
+ bl_0_8 br_0_8 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c9
+ bl_0_9 br_0_9 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c10
+ bl_0_10 br_0_10 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c11
+ bl_0_11 br_0_11 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c12
+ bl_0_12 br_0_12 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c13
+ bl_0_13 br_0_13 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c14
+ bl_0_14 br_0_14 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c15
+ bl_0_15 br_0_15 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c16
+ bl_0_16 br_0_16 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c17
+ bl_0_17 br_0_17 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c18
+ bl_0_18 br_0_18 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c19
+ bl_0_19 br_0_19 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c20
+ bl_0_20 br_0_20 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c21
+ bl_0_21 br_0_21 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c22
+ bl_0_22 br_0_22 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c23
+ bl_0_23 br_0_23 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c24
+ bl_0_24 br_0_24 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c25
+ bl_0_25 br_0_25 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c26
+ bl_0_26 br_0_26 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c27
+ bl_0_27 br_0_27 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c28
+ bl_0_28 br_0_28 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c29
+ bl_0_29 br_0_29 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c30
+ bl_0_30 br_0_30 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c31
+ bl_0_31 br_0_31 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c32
+ bl_0_32 br_0_32 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c33
+ bl_0_33 br_0_33 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c34
+ bl_0_34 br_0_34 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c35
+ bl_0_35 br_0_35 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c36
+ bl_0_36 br_0_36 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c37
+ bl_0_37 br_0_37 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c38
+ bl_0_38 br_0_38 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c39
+ bl_0_39 br_0_39 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c40
+ bl_0_40 br_0_40 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c41
+ bl_0_41 br_0_41 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c42
+ bl_0_42 br_0_42 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c43
+ bl_0_43 br_0_43 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c44
+ bl_0_44 br_0_44 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c45
+ bl_0_45 br_0_45 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c46
+ bl_0_46 br_0_46 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c47
+ bl_0_47 br_0_47 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c48
+ bl_0_48 br_0_48 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c49
+ bl_0_49 br_0_49 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c50
+ bl_0_50 br_0_50 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c51
+ bl_0_51 br_0_51 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c52
+ bl_0_52 br_0_52 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c53
+ bl_0_53 br_0_53 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c54
+ bl_0_54 br_0_54 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c55
+ bl_0_55 br_0_55 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c56
+ bl_0_56 br_0_56 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c57
+ bl_0_57 br_0_57 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c58
+ bl_0_58 br_0_58 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c59
+ bl_0_59 br_0_59 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c60
+ bl_0_60 br_0_60 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c61
+ bl_0_61 br_0_61 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c62
+ bl_0_62 br_0_62 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c63
+ bl_0_63 br_0_63 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c64
+ bl_0_64 br_0_64 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c65
+ bl_0_65 br_0_65 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c66
+ bl_0_66 br_0_66 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c67
+ bl_0_67 br_0_67 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c68
+ bl_0_68 br_0_68 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c69
+ bl_0_69 br_0_69 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c70
+ bl_0_70 br_0_70 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c71
+ bl_0_71 br_0_71 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c72
+ bl_0_72 br_0_72 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c73
+ bl_0_73 br_0_73 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c74
+ bl_0_74 br_0_74 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c75
+ bl_0_75 br_0_75 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c76
+ bl_0_76 br_0_76 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c77
+ bl_0_77 br_0_77 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c78
+ bl_0_78 br_0_78 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c79
+ bl_0_79 br_0_79 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c80
+ bl_0_80 br_0_80 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c81
+ bl_0_81 br_0_81 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c82
+ bl_0_82 br_0_82 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c83
+ bl_0_83 br_0_83 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c84
+ bl_0_84 br_0_84 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c85
+ bl_0_85 br_0_85 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c86
+ bl_0_86 br_0_86 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c87
+ bl_0_87 br_0_87 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c88
+ bl_0_88 br_0_88 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c89
+ bl_0_89 br_0_89 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c90
+ bl_0_90 br_0_90 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c91
+ bl_0_91 br_0_91 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c92
+ bl_0_92 br_0_92 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c93
+ bl_0_93 br_0_93 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c94
+ bl_0_94 br_0_94 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c95
+ bl_0_95 br_0_95 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c96
+ bl_0_96 br_0_96 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c97
+ bl_0_97 br_0_97 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c98
+ bl_0_98 br_0_98 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c99
+ bl_0_99 br_0_99 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c100
+ bl_0_100 br_0_100 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c101
+ bl_0_101 br_0_101 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c102
+ bl_0_102 br_0_102 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c103
+ bl_0_103 br_0_103 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c104
+ bl_0_104 br_0_104 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c105
+ bl_0_105 br_0_105 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c106
+ bl_0_106 br_0_106 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c107
+ bl_0_107 br_0_107 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c108
+ bl_0_108 br_0_108 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c109
+ bl_0_109 br_0_109 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c110
+ bl_0_110 br_0_110 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c111
+ bl_0_111 br_0_111 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c112
+ bl_0_112 br_0_112 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c113
+ bl_0_113 br_0_113 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c114
+ bl_0_114 br_0_114 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c115
+ bl_0_115 br_0_115 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c116
+ bl_0_116 br_0_116 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c117
+ bl_0_117 br_0_117 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c118
+ bl_0_118 br_0_118 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c119
+ bl_0_119 br_0_119 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c120
+ bl_0_120 br_0_120 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c121
+ bl_0_121 br_0_121 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c122
+ bl_0_122 br_0_122 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c123
+ bl_0_123 br_0_123 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c124
+ bl_0_124 br_0_124 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c125
+ bl_0_125 br_0_125 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c126
+ bl_0_126 br_0_126 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c127
+ bl_0_127 br_0_127 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c128
+ bl_0_128 br_0_128 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c129
+ bl_0_129 br_0_129 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c130
+ bl_0_130 br_0_130 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c131
+ bl_0_131 br_0_131 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c132
+ bl_0_132 br_0_132 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c133
+ bl_0_133 br_0_133 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c134
+ bl_0_134 br_0_134 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c135
+ bl_0_135 br_0_135 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c136
+ bl_0_136 br_0_136 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c137
+ bl_0_137 br_0_137 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c138
+ bl_0_138 br_0_138 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c139
+ bl_0_139 br_0_139 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c140
+ bl_0_140 br_0_140 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c141
+ bl_0_141 br_0_141 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c142
+ bl_0_142 br_0_142 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c143
+ bl_0_143 br_0_143 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c144
+ bl_0_144 br_0_144 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c145
+ bl_0_145 br_0_145 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c146
+ bl_0_146 br_0_146 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c147
+ bl_0_147 br_0_147 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c148
+ bl_0_148 br_0_148 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c149
+ bl_0_149 br_0_149 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c150
+ bl_0_150 br_0_150 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c151
+ bl_0_151 br_0_151 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c152
+ bl_0_152 br_0_152 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c153
+ bl_0_153 br_0_153 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c154
+ bl_0_154 br_0_154 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c155
+ bl_0_155 br_0_155 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c156
+ bl_0_156 br_0_156 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c157
+ bl_0_157 br_0_157 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c158
+ bl_0_158 br_0_158 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c159
+ bl_0_159 br_0_159 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c160
+ bl_0_160 br_0_160 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c161
+ bl_0_161 br_0_161 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c162
+ bl_0_162 br_0_162 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c163
+ bl_0_163 br_0_163 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c164
+ bl_0_164 br_0_164 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c165
+ bl_0_165 br_0_165 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c166
+ bl_0_166 br_0_166 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c167
+ bl_0_167 br_0_167 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c168
+ bl_0_168 br_0_168 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c169
+ bl_0_169 br_0_169 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c170
+ bl_0_170 br_0_170 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c171
+ bl_0_171 br_0_171 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c172
+ bl_0_172 br_0_172 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c173
+ bl_0_173 br_0_173 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c174
+ bl_0_174 br_0_174 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c175
+ bl_0_175 br_0_175 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c176
+ bl_0_176 br_0_176 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c177
+ bl_0_177 br_0_177 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c178
+ bl_0_178 br_0_178 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c179
+ bl_0_179 br_0_179 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c180
+ bl_0_180 br_0_180 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c181
+ bl_0_181 br_0_181 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c182
+ bl_0_182 br_0_182 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c183
+ bl_0_183 br_0_183 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c184
+ bl_0_184 br_0_184 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c185
+ bl_0_185 br_0_185 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c186
+ bl_0_186 br_0_186 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c187
+ bl_0_187 br_0_187 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c188
+ bl_0_188 br_0_188 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c189
+ bl_0_189 br_0_189 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c190
+ bl_0_190 br_0_190 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c191
+ bl_0_191 br_0_191 wl_0_16 vdd gnd
+ sky130_custom_cell
Xbit_r16_c192
+ bl_0_192 br_0_192 wl_0_16 vdd gnd
+ sky130_custom_cell
.ENDS sky130_sram_1rw_24x128_bitcell_array

.SUBCKT sky130_sram_1rw_24x128_replica_bitcell_array
+ rbl_bl_0_0 rbl_br_0_0 bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3
+ br_0_3 bl_0_4 br_0_4 bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8
+ br_0_8 bl_0_9 br_0_9 bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12
+ bl_0_13 br_0_13 bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16
+ bl_0_17 br_0_17 bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20
+ bl_0_21 br_0_21 bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24
+ bl_0_25 br_0_25 bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28
+ bl_0_29 br_0_29 bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32
+ bl_0_33 br_0_33 bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36
+ bl_0_37 br_0_37 bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40
+ bl_0_41 br_0_41 bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44
+ bl_0_45 br_0_45 bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48
+ bl_0_49 br_0_49 bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52
+ bl_0_53 br_0_53 bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56
+ bl_0_57 br_0_57 bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60
+ bl_0_61 br_0_61 bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64
+ bl_0_65 br_0_65 bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68
+ bl_0_69 br_0_69 bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72
+ bl_0_73 br_0_73 bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76
+ bl_0_77 br_0_77 bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80
+ bl_0_81 br_0_81 bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84
+ bl_0_85 br_0_85 bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88
+ bl_0_89 br_0_89 bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92
+ bl_0_93 br_0_93 bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96
+ bl_0_97 br_0_97 bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100
+ bl_0_101 br_0_101 bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104
+ br_0_104 bl_0_105 br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107
+ bl_0_108 br_0_108 bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111
+ br_0_111 bl_0_112 br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114
+ bl_0_115 br_0_115 bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118
+ br_0_118 bl_0_119 br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121
+ bl_0_122 br_0_122 bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125
+ br_0_125 bl_0_126 br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128
+ bl_0_129 br_0_129 bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132
+ br_0_132 bl_0_133 br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135
+ bl_0_136 br_0_136 bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139
+ br_0_139 bl_0_140 br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142
+ bl_0_143 br_0_143 bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146
+ br_0_146 bl_0_147 br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149
+ bl_0_150 br_0_150 bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153
+ br_0_153 bl_0_154 br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156
+ bl_0_157 br_0_157 bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160
+ br_0_160 bl_0_161 br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163
+ bl_0_164 br_0_164 bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167
+ br_0_167 bl_0_168 br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170
+ bl_0_171 br_0_171 bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174
+ br_0_174 bl_0_175 br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177
+ bl_0_178 br_0_178 bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181
+ br_0_181 bl_0_182 br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184
+ bl_0_185 br_0_185 bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188
+ br_0_188 bl_0_189 br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191
+ bl_0_192 br_0_192 rbl_wl_0_0 wl_0_0 wl_0_1 wl_0_2 wl_0_3 wl_0_4 wl_0_5
+ wl_0_6 wl_0_7 wl_0_8 wl_0_9 wl_0_10 wl_0_11 wl_0_12 wl_0_13 wl_0_14
+ wl_0_15 wl_0_16 vdd gnd
* INOUT : rbl_bl_0_0 
* INOUT : rbl_br_0_0 
* INOUT : bl_0_0 
* INOUT : br_0_0 
* INOUT : bl_0_1 
* INOUT : br_0_1 
* INOUT : bl_0_2 
* INOUT : br_0_2 
* INOUT : bl_0_3 
* INOUT : br_0_3 
* INOUT : bl_0_4 
* INOUT : br_0_4 
* INOUT : bl_0_5 
* INOUT : br_0_5 
* INOUT : bl_0_6 
* INOUT : br_0_6 
* INOUT : bl_0_7 
* INOUT : br_0_7 
* INOUT : bl_0_8 
* INOUT : br_0_8 
* INOUT : bl_0_9 
* INOUT : br_0_9 
* INOUT : bl_0_10 
* INOUT : br_0_10 
* INOUT : bl_0_11 
* INOUT : br_0_11 
* INOUT : bl_0_12 
* INOUT : br_0_12 
* INOUT : bl_0_13 
* INOUT : br_0_13 
* INOUT : bl_0_14 
* INOUT : br_0_14 
* INOUT : bl_0_15 
* INOUT : br_0_15 
* INOUT : bl_0_16 
* INOUT : br_0_16 
* INOUT : bl_0_17 
* INOUT : br_0_17 
* INOUT : bl_0_18 
* INOUT : br_0_18 
* INOUT : bl_0_19 
* INOUT : br_0_19 
* INOUT : bl_0_20 
* INOUT : br_0_20 
* INOUT : bl_0_21 
* INOUT : br_0_21 
* INOUT : bl_0_22 
* INOUT : br_0_22 
* INOUT : bl_0_23 
* INOUT : br_0_23 
* INOUT : bl_0_24 
* INOUT : br_0_24 
* INOUT : bl_0_25 
* INOUT : br_0_25 
* INOUT : bl_0_26 
* INOUT : br_0_26 
* INOUT : bl_0_27 
* INOUT : br_0_27 
* INOUT : bl_0_28 
* INOUT : br_0_28 
* INOUT : bl_0_29 
* INOUT : br_0_29 
* INOUT : bl_0_30 
* INOUT : br_0_30 
* INOUT : bl_0_31 
* INOUT : br_0_31 
* INOUT : bl_0_32 
* INOUT : br_0_32 
* INOUT : bl_0_33 
* INOUT : br_0_33 
* INOUT : bl_0_34 
* INOUT : br_0_34 
* INOUT : bl_0_35 
* INOUT : br_0_35 
* INOUT : bl_0_36 
* INOUT : br_0_36 
* INOUT : bl_0_37 
* INOUT : br_0_37 
* INOUT : bl_0_38 
* INOUT : br_0_38 
* INOUT : bl_0_39 
* INOUT : br_0_39 
* INOUT : bl_0_40 
* INOUT : br_0_40 
* INOUT : bl_0_41 
* INOUT : br_0_41 
* INOUT : bl_0_42 
* INOUT : br_0_42 
* INOUT : bl_0_43 
* INOUT : br_0_43 
* INOUT : bl_0_44 
* INOUT : br_0_44 
* INOUT : bl_0_45 
* INOUT : br_0_45 
* INOUT : bl_0_46 
* INOUT : br_0_46 
* INOUT : bl_0_47 
* INOUT : br_0_47 
* INOUT : bl_0_48 
* INOUT : br_0_48 
* INOUT : bl_0_49 
* INOUT : br_0_49 
* INOUT : bl_0_50 
* INOUT : br_0_50 
* INOUT : bl_0_51 
* INOUT : br_0_51 
* INOUT : bl_0_52 
* INOUT : br_0_52 
* INOUT : bl_0_53 
* INOUT : br_0_53 
* INOUT : bl_0_54 
* INOUT : br_0_54 
* INOUT : bl_0_55 
* INOUT : br_0_55 
* INOUT : bl_0_56 
* INOUT : br_0_56 
* INOUT : bl_0_57 
* INOUT : br_0_57 
* INOUT : bl_0_58 
* INOUT : br_0_58 
* INOUT : bl_0_59 
* INOUT : br_0_59 
* INOUT : bl_0_60 
* INOUT : br_0_60 
* INOUT : bl_0_61 
* INOUT : br_0_61 
* INOUT : bl_0_62 
* INOUT : br_0_62 
* INOUT : bl_0_63 
* INOUT : br_0_63 
* INOUT : bl_0_64 
* INOUT : br_0_64 
* INOUT : bl_0_65 
* INOUT : br_0_65 
* INOUT : bl_0_66 
* INOUT : br_0_66 
* INOUT : bl_0_67 
* INOUT : br_0_67 
* INOUT : bl_0_68 
* INOUT : br_0_68 
* INOUT : bl_0_69 
* INOUT : br_0_69 
* INOUT : bl_0_70 
* INOUT : br_0_70 
* INOUT : bl_0_71 
* INOUT : br_0_71 
* INOUT : bl_0_72 
* INOUT : br_0_72 
* INOUT : bl_0_73 
* INOUT : br_0_73 
* INOUT : bl_0_74 
* INOUT : br_0_74 
* INOUT : bl_0_75 
* INOUT : br_0_75 
* INOUT : bl_0_76 
* INOUT : br_0_76 
* INOUT : bl_0_77 
* INOUT : br_0_77 
* INOUT : bl_0_78 
* INOUT : br_0_78 
* INOUT : bl_0_79 
* INOUT : br_0_79 
* INOUT : bl_0_80 
* INOUT : br_0_80 
* INOUT : bl_0_81 
* INOUT : br_0_81 
* INOUT : bl_0_82 
* INOUT : br_0_82 
* INOUT : bl_0_83 
* INOUT : br_0_83 
* INOUT : bl_0_84 
* INOUT : br_0_84 
* INOUT : bl_0_85 
* INOUT : br_0_85 
* INOUT : bl_0_86 
* INOUT : br_0_86 
* INOUT : bl_0_87 
* INOUT : br_0_87 
* INOUT : bl_0_88 
* INOUT : br_0_88 
* INOUT : bl_0_89 
* INOUT : br_0_89 
* INOUT : bl_0_90 
* INOUT : br_0_90 
* INOUT : bl_0_91 
* INOUT : br_0_91 
* INOUT : bl_0_92 
* INOUT : br_0_92 
* INOUT : bl_0_93 
* INOUT : br_0_93 
* INOUT : bl_0_94 
* INOUT : br_0_94 
* INOUT : bl_0_95 
* INOUT : br_0_95 
* INOUT : bl_0_96 
* INOUT : br_0_96 
* INOUT : bl_0_97 
* INOUT : br_0_97 
* INOUT : bl_0_98 
* INOUT : br_0_98 
* INOUT : bl_0_99 
* INOUT : br_0_99 
* INOUT : bl_0_100 
* INOUT : br_0_100 
* INOUT : bl_0_101 
* INOUT : br_0_101 
* INOUT : bl_0_102 
* INOUT : br_0_102 
* INOUT : bl_0_103 
* INOUT : br_0_103 
* INOUT : bl_0_104 
* INOUT : br_0_104 
* INOUT : bl_0_105 
* INOUT : br_0_105 
* INOUT : bl_0_106 
* INOUT : br_0_106 
* INOUT : bl_0_107 
* INOUT : br_0_107 
* INOUT : bl_0_108 
* INOUT : br_0_108 
* INOUT : bl_0_109 
* INOUT : br_0_109 
* INOUT : bl_0_110 
* INOUT : br_0_110 
* INOUT : bl_0_111 
* INOUT : br_0_111 
* INOUT : bl_0_112 
* INOUT : br_0_112 
* INOUT : bl_0_113 
* INOUT : br_0_113 
* INOUT : bl_0_114 
* INOUT : br_0_114 
* INOUT : bl_0_115 
* INOUT : br_0_115 
* INOUT : bl_0_116 
* INOUT : br_0_116 
* INOUT : bl_0_117 
* INOUT : br_0_117 
* INOUT : bl_0_118 
* INOUT : br_0_118 
* INOUT : bl_0_119 
* INOUT : br_0_119 
* INOUT : bl_0_120 
* INOUT : br_0_120 
* INOUT : bl_0_121 
* INOUT : br_0_121 
* INOUT : bl_0_122 
* INOUT : br_0_122 
* INOUT : bl_0_123 
* INOUT : br_0_123 
* INOUT : bl_0_124 
* INOUT : br_0_124 
* INOUT : bl_0_125 
* INOUT : br_0_125 
* INOUT : bl_0_126 
* INOUT : br_0_126 
* INOUT : bl_0_127 
* INOUT : br_0_127 
* INOUT : bl_0_128 
* INOUT : br_0_128 
* INOUT : bl_0_129 
* INOUT : br_0_129 
* INOUT : bl_0_130 
* INOUT : br_0_130 
* INOUT : bl_0_131 
* INOUT : br_0_131 
* INOUT : bl_0_132 
* INOUT : br_0_132 
* INOUT : bl_0_133 
* INOUT : br_0_133 
* INOUT : bl_0_134 
* INOUT : br_0_134 
* INOUT : bl_0_135 
* INOUT : br_0_135 
* INOUT : bl_0_136 
* INOUT : br_0_136 
* INOUT : bl_0_137 
* INOUT : br_0_137 
* INOUT : bl_0_138 
* INOUT : br_0_138 
* INOUT : bl_0_139 
* INOUT : br_0_139 
* INOUT : bl_0_140 
* INOUT : br_0_140 
* INOUT : bl_0_141 
* INOUT : br_0_141 
* INOUT : bl_0_142 
* INOUT : br_0_142 
* INOUT : bl_0_143 
* INOUT : br_0_143 
* INOUT : bl_0_144 
* INOUT : br_0_144 
* INOUT : bl_0_145 
* INOUT : br_0_145 
* INOUT : bl_0_146 
* INOUT : br_0_146 
* INOUT : bl_0_147 
* INOUT : br_0_147 
* INOUT : bl_0_148 
* INOUT : br_0_148 
* INOUT : bl_0_149 
* INOUT : br_0_149 
* INOUT : bl_0_150 
* INOUT : br_0_150 
* INOUT : bl_0_151 
* INOUT : br_0_151 
* INOUT : bl_0_152 
* INOUT : br_0_152 
* INOUT : bl_0_153 
* INOUT : br_0_153 
* INOUT : bl_0_154 
* INOUT : br_0_154 
* INOUT : bl_0_155 
* INOUT : br_0_155 
* INOUT : bl_0_156 
* INOUT : br_0_156 
* INOUT : bl_0_157 
* INOUT : br_0_157 
* INOUT : bl_0_158 
* INOUT : br_0_158 
* INOUT : bl_0_159 
* INOUT : br_0_159 
* INOUT : bl_0_160 
* INOUT : br_0_160 
* INOUT : bl_0_161 
* INOUT : br_0_161 
* INOUT : bl_0_162 
* INOUT : br_0_162 
* INOUT : bl_0_163 
* INOUT : br_0_163 
* INOUT : bl_0_164 
* INOUT : br_0_164 
* INOUT : bl_0_165 
* INOUT : br_0_165 
* INOUT : bl_0_166 
* INOUT : br_0_166 
* INOUT : bl_0_167 
* INOUT : br_0_167 
* INOUT : bl_0_168 
* INOUT : br_0_168 
* INOUT : bl_0_169 
* INOUT : br_0_169 
* INOUT : bl_0_170 
* INOUT : br_0_170 
* INOUT : bl_0_171 
* INOUT : br_0_171 
* INOUT : bl_0_172 
* INOUT : br_0_172 
* INOUT : bl_0_173 
* INOUT : br_0_173 
* INOUT : bl_0_174 
* INOUT : br_0_174 
* INOUT : bl_0_175 
* INOUT : br_0_175 
* INOUT : bl_0_176 
* INOUT : br_0_176 
* INOUT : bl_0_177 
* INOUT : br_0_177 
* INOUT : bl_0_178 
* INOUT : br_0_178 
* INOUT : bl_0_179 
* INOUT : br_0_179 
* INOUT : bl_0_180 
* INOUT : br_0_180 
* INOUT : bl_0_181 
* INOUT : br_0_181 
* INOUT : bl_0_182 
* INOUT : br_0_182 
* INOUT : bl_0_183 
* INOUT : br_0_183 
* INOUT : bl_0_184 
* INOUT : br_0_184 
* INOUT : bl_0_185 
* INOUT : br_0_185 
* INOUT : bl_0_186 
* INOUT : br_0_186 
* INOUT : bl_0_187 
* INOUT : br_0_187 
* INOUT : bl_0_188 
* INOUT : br_0_188 
* INOUT : bl_0_189 
* INOUT : br_0_189 
* INOUT : bl_0_190 
* INOUT : br_0_190 
* INOUT : bl_0_191 
* INOUT : br_0_191 
* INOUT : bl_0_192 
* INOUT : br_0_192 
* INPUT : rbl_wl_0_0 
* INPUT : wl_0_0 
* INPUT : wl_0_1 
* INPUT : wl_0_2 
* INPUT : wl_0_3 
* INPUT : wl_0_4 
* INPUT : wl_0_5 
* INPUT : wl_0_6 
* INPUT : wl_0_7 
* INPUT : wl_0_8 
* INPUT : wl_0_9 
* INPUT : wl_0_10 
* INPUT : wl_0_11 
* INPUT : wl_0_12 
* INPUT : wl_0_13 
* INPUT : wl_0_14 
* INPUT : wl_0_15 
* INPUT : wl_0_16 
* POWER : vdd 
* GROUND: gnd 
* rows: 17 cols: 193
* rbl: [1, 0] left_rbl: [0] right_rbl: []
Xbitcell_array
+ bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3 br_0_3 bl_0_4 br_0_4
+ bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8 br_0_8 bl_0_9 br_0_9
+ bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12 bl_0_13 br_0_13
+ bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16 bl_0_17 br_0_17
+ bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20 bl_0_21 br_0_21
+ bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24 bl_0_25 br_0_25
+ bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28 bl_0_29 br_0_29
+ bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32 bl_0_33 br_0_33
+ bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36 bl_0_37 br_0_37
+ bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40 bl_0_41 br_0_41
+ bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44 bl_0_45 br_0_45
+ bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48 bl_0_49 br_0_49
+ bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52 bl_0_53 br_0_53
+ bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56 bl_0_57 br_0_57
+ bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60 bl_0_61 br_0_61
+ bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64 bl_0_65 br_0_65
+ bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68 bl_0_69 br_0_69
+ bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72 bl_0_73 br_0_73
+ bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76 bl_0_77 br_0_77
+ bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80 bl_0_81 br_0_81
+ bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84 bl_0_85 br_0_85
+ bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88 bl_0_89 br_0_89
+ bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92 bl_0_93 br_0_93
+ bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96 bl_0_97 br_0_97
+ bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100 bl_0_101 br_0_101
+ bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104 br_0_104 bl_0_105
+ br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107 bl_0_108 br_0_108
+ bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111 br_0_111 bl_0_112
+ br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114 bl_0_115 br_0_115
+ bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118 br_0_118 bl_0_119
+ br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121 bl_0_122 br_0_122
+ bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125 br_0_125 bl_0_126
+ br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128 bl_0_129 br_0_129
+ bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132 br_0_132 bl_0_133
+ br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135 bl_0_136 br_0_136
+ bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139 br_0_139 bl_0_140
+ br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142 bl_0_143 br_0_143
+ bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146 br_0_146 bl_0_147
+ br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149 bl_0_150 br_0_150
+ bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153 br_0_153 bl_0_154
+ br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156 bl_0_157 br_0_157
+ bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160 br_0_160 bl_0_161
+ br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163 bl_0_164 br_0_164
+ bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167 br_0_167 bl_0_168
+ br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170 bl_0_171 br_0_171
+ bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174 br_0_174 bl_0_175
+ br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177 bl_0_178 br_0_178
+ bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181 br_0_181 bl_0_182
+ br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184 bl_0_185 br_0_185
+ bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188 br_0_188 bl_0_189
+ br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191 bl_0_192 br_0_192 wl_0_0
+ wl_0_1 wl_0_2 wl_0_3 wl_0_4 wl_0_5 wl_0_6 wl_0_7 wl_0_8 wl_0_9 wl_0_10
+ wl_0_11 wl_0_12 wl_0_13 wl_0_14 wl_0_15 wl_0_16 vdd gnd
+ sky130_sram_1rw_24x128_bitcell_array
Xreplica_col_0
+ rbl_bl_0_0 rbl_br_0_0 rbl_wl_0_0 wl_0_0 wl_0_1 wl_0_2 wl_0_3 wl_0_4
+ wl_0_5 wl_0_6 wl_0_7 wl_0_8 wl_0_9 wl_0_10 wl_0_11 wl_0_12 wl_0_13
+ wl_0_14 wl_0_15 wl_0_16 vdd gnd
+ sky130_sram_1rw_24x128_replica_column
Xdummy_row_0
+ bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3 br_0_3 bl_0_4 br_0_4
+ bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8 br_0_8 bl_0_9 br_0_9
+ bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12 bl_0_13 br_0_13
+ bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16 bl_0_17 br_0_17
+ bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20 bl_0_21 br_0_21
+ bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24 bl_0_25 br_0_25
+ bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28 bl_0_29 br_0_29
+ bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32 bl_0_33 br_0_33
+ bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36 bl_0_37 br_0_37
+ bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40 bl_0_41 br_0_41
+ bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44 bl_0_45 br_0_45
+ bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48 bl_0_49 br_0_49
+ bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52 bl_0_53 br_0_53
+ bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56 bl_0_57 br_0_57
+ bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60 bl_0_61 br_0_61
+ bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64 bl_0_65 br_0_65
+ bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68 bl_0_69 br_0_69
+ bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72 bl_0_73 br_0_73
+ bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76 bl_0_77 br_0_77
+ bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80 bl_0_81 br_0_81
+ bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84 bl_0_85 br_0_85
+ bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88 bl_0_89 br_0_89
+ bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92 bl_0_93 br_0_93
+ bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96 bl_0_97 br_0_97
+ bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100 bl_0_101 br_0_101
+ bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104 br_0_104 bl_0_105
+ br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107 bl_0_108 br_0_108
+ bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111 br_0_111 bl_0_112
+ br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114 bl_0_115 br_0_115
+ bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118 br_0_118 bl_0_119
+ br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121 bl_0_122 br_0_122
+ bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125 br_0_125 bl_0_126
+ br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128 bl_0_129 br_0_129
+ bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132 br_0_132 bl_0_133
+ br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135 bl_0_136 br_0_136
+ bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139 br_0_139 bl_0_140
+ br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142 bl_0_143 br_0_143
+ bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146 br_0_146 bl_0_147
+ br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149 bl_0_150 br_0_150
+ bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153 br_0_153 bl_0_154
+ br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156 bl_0_157 br_0_157
+ bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160 br_0_160 bl_0_161
+ br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163 bl_0_164 br_0_164
+ bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167 br_0_167 bl_0_168
+ br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170 bl_0_171 br_0_171
+ bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174 br_0_174 bl_0_175
+ br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177 bl_0_178 br_0_178
+ bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181 br_0_181 bl_0_182
+ br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184 bl_0_185 br_0_185
+ bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188 br_0_188 bl_0_189
+ br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191 bl_0_192 br_0_192
+ rbl_wl_0_0 vdd gnd
+ sky130_sram_1rw_24x128_dummy_array
.ENDS sky130_sram_1rw_24x128_replica_bitcell_array

.SUBCKT sky130_sram_1rw_24x128_dummy_array_1
+ bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3 br_0_3 bl_0_4 br_0_4
+ bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8 br_0_8 bl_0_9 br_0_9
+ bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12 bl_0_13 br_0_13
+ bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16 bl_0_17 br_0_17
+ bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20 bl_0_21 br_0_21
+ bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24 bl_0_25 br_0_25
+ bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28 bl_0_29 br_0_29
+ bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32 bl_0_33 br_0_33
+ bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36 bl_0_37 br_0_37
+ bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40 bl_0_41 br_0_41
+ bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44 bl_0_45 br_0_45
+ bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48 bl_0_49 br_0_49
+ bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52 bl_0_53 br_0_53
+ bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56 bl_0_57 br_0_57
+ bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60 bl_0_61 br_0_61
+ bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64 bl_0_65 br_0_65
+ bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68 bl_0_69 br_0_69
+ bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72 bl_0_73 br_0_73
+ bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76 bl_0_77 br_0_77
+ bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80 bl_0_81 br_0_81
+ bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84 bl_0_85 br_0_85
+ bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88 bl_0_89 br_0_89
+ bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92 bl_0_93 br_0_93
+ bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96 bl_0_97 br_0_97
+ bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100 bl_0_101 br_0_101
+ bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104 br_0_104 bl_0_105
+ br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107 bl_0_108 br_0_108
+ bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111 br_0_111 bl_0_112
+ br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114 bl_0_115 br_0_115
+ bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118 br_0_118 bl_0_119
+ br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121 bl_0_122 br_0_122
+ bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125 br_0_125 bl_0_126
+ br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128 bl_0_129 br_0_129
+ bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132 br_0_132 bl_0_133
+ br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135 bl_0_136 br_0_136
+ bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139 br_0_139 bl_0_140
+ br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142 bl_0_143 br_0_143
+ bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146 br_0_146 bl_0_147
+ br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149 bl_0_150 br_0_150
+ bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153 br_0_153 bl_0_154
+ br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156 bl_0_157 br_0_157
+ bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160 br_0_160 bl_0_161
+ br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163 bl_0_164 br_0_164
+ bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167 br_0_167 bl_0_168
+ br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170 bl_0_171 br_0_171
+ bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174 br_0_174 bl_0_175
+ br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177 bl_0_178 br_0_178
+ bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181 br_0_181 bl_0_182
+ br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184 bl_0_185 br_0_185
+ bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188 br_0_188 bl_0_189
+ br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191 bl_0_192 br_0_192
+ bl_0_193 br_0_193 wl_0_0 vdd gnd
* INOUT : bl_0_0 
* INOUT : br_0_0 
* INOUT : bl_0_1 
* INOUT : br_0_1 
* INOUT : bl_0_2 
* INOUT : br_0_2 
* INOUT : bl_0_3 
* INOUT : br_0_3 
* INOUT : bl_0_4 
* INOUT : br_0_4 
* INOUT : bl_0_5 
* INOUT : br_0_5 
* INOUT : bl_0_6 
* INOUT : br_0_6 
* INOUT : bl_0_7 
* INOUT : br_0_7 
* INOUT : bl_0_8 
* INOUT : br_0_8 
* INOUT : bl_0_9 
* INOUT : br_0_9 
* INOUT : bl_0_10 
* INOUT : br_0_10 
* INOUT : bl_0_11 
* INOUT : br_0_11 
* INOUT : bl_0_12 
* INOUT : br_0_12 
* INOUT : bl_0_13 
* INOUT : br_0_13 
* INOUT : bl_0_14 
* INOUT : br_0_14 
* INOUT : bl_0_15 
* INOUT : br_0_15 
* INOUT : bl_0_16 
* INOUT : br_0_16 
* INOUT : bl_0_17 
* INOUT : br_0_17 
* INOUT : bl_0_18 
* INOUT : br_0_18 
* INOUT : bl_0_19 
* INOUT : br_0_19 
* INOUT : bl_0_20 
* INOUT : br_0_20 
* INOUT : bl_0_21 
* INOUT : br_0_21 
* INOUT : bl_0_22 
* INOUT : br_0_22 
* INOUT : bl_0_23 
* INOUT : br_0_23 
* INOUT : bl_0_24 
* INOUT : br_0_24 
* INOUT : bl_0_25 
* INOUT : br_0_25 
* INOUT : bl_0_26 
* INOUT : br_0_26 
* INOUT : bl_0_27 
* INOUT : br_0_27 
* INOUT : bl_0_28 
* INOUT : br_0_28 
* INOUT : bl_0_29 
* INOUT : br_0_29 
* INOUT : bl_0_30 
* INOUT : br_0_30 
* INOUT : bl_0_31 
* INOUT : br_0_31 
* INOUT : bl_0_32 
* INOUT : br_0_32 
* INOUT : bl_0_33 
* INOUT : br_0_33 
* INOUT : bl_0_34 
* INOUT : br_0_34 
* INOUT : bl_0_35 
* INOUT : br_0_35 
* INOUT : bl_0_36 
* INOUT : br_0_36 
* INOUT : bl_0_37 
* INOUT : br_0_37 
* INOUT : bl_0_38 
* INOUT : br_0_38 
* INOUT : bl_0_39 
* INOUT : br_0_39 
* INOUT : bl_0_40 
* INOUT : br_0_40 
* INOUT : bl_0_41 
* INOUT : br_0_41 
* INOUT : bl_0_42 
* INOUT : br_0_42 
* INOUT : bl_0_43 
* INOUT : br_0_43 
* INOUT : bl_0_44 
* INOUT : br_0_44 
* INOUT : bl_0_45 
* INOUT : br_0_45 
* INOUT : bl_0_46 
* INOUT : br_0_46 
* INOUT : bl_0_47 
* INOUT : br_0_47 
* INOUT : bl_0_48 
* INOUT : br_0_48 
* INOUT : bl_0_49 
* INOUT : br_0_49 
* INOUT : bl_0_50 
* INOUT : br_0_50 
* INOUT : bl_0_51 
* INOUT : br_0_51 
* INOUT : bl_0_52 
* INOUT : br_0_52 
* INOUT : bl_0_53 
* INOUT : br_0_53 
* INOUT : bl_0_54 
* INOUT : br_0_54 
* INOUT : bl_0_55 
* INOUT : br_0_55 
* INOUT : bl_0_56 
* INOUT : br_0_56 
* INOUT : bl_0_57 
* INOUT : br_0_57 
* INOUT : bl_0_58 
* INOUT : br_0_58 
* INOUT : bl_0_59 
* INOUT : br_0_59 
* INOUT : bl_0_60 
* INOUT : br_0_60 
* INOUT : bl_0_61 
* INOUT : br_0_61 
* INOUT : bl_0_62 
* INOUT : br_0_62 
* INOUT : bl_0_63 
* INOUT : br_0_63 
* INOUT : bl_0_64 
* INOUT : br_0_64 
* INOUT : bl_0_65 
* INOUT : br_0_65 
* INOUT : bl_0_66 
* INOUT : br_0_66 
* INOUT : bl_0_67 
* INOUT : br_0_67 
* INOUT : bl_0_68 
* INOUT : br_0_68 
* INOUT : bl_0_69 
* INOUT : br_0_69 
* INOUT : bl_0_70 
* INOUT : br_0_70 
* INOUT : bl_0_71 
* INOUT : br_0_71 
* INOUT : bl_0_72 
* INOUT : br_0_72 
* INOUT : bl_0_73 
* INOUT : br_0_73 
* INOUT : bl_0_74 
* INOUT : br_0_74 
* INOUT : bl_0_75 
* INOUT : br_0_75 
* INOUT : bl_0_76 
* INOUT : br_0_76 
* INOUT : bl_0_77 
* INOUT : br_0_77 
* INOUT : bl_0_78 
* INOUT : br_0_78 
* INOUT : bl_0_79 
* INOUT : br_0_79 
* INOUT : bl_0_80 
* INOUT : br_0_80 
* INOUT : bl_0_81 
* INOUT : br_0_81 
* INOUT : bl_0_82 
* INOUT : br_0_82 
* INOUT : bl_0_83 
* INOUT : br_0_83 
* INOUT : bl_0_84 
* INOUT : br_0_84 
* INOUT : bl_0_85 
* INOUT : br_0_85 
* INOUT : bl_0_86 
* INOUT : br_0_86 
* INOUT : bl_0_87 
* INOUT : br_0_87 
* INOUT : bl_0_88 
* INOUT : br_0_88 
* INOUT : bl_0_89 
* INOUT : br_0_89 
* INOUT : bl_0_90 
* INOUT : br_0_90 
* INOUT : bl_0_91 
* INOUT : br_0_91 
* INOUT : bl_0_92 
* INOUT : br_0_92 
* INOUT : bl_0_93 
* INOUT : br_0_93 
* INOUT : bl_0_94 
* INOUT : br_0_94 
* INOUT : bl_0_95 
* INOUT : br_0_95 
* INOUT : bl_0_96 
* INOUT : br_0_96 
* INOUT : bl_0_97 
* INOUT : br_0_97 
* INOUT : bl_0_98 
* INOUT : br_0_98 
* INOUT : bl_0_99 
* INOUT : br_0_99 
* INOUT : bl_0_100 
* INOUT : br_0_100 
* INOUT : bl_0_101 
* INOUT : br_0_101 
* INOUT : bl_0_102 
* INOUT : br_0_102 
* INOUT : bl_0_103 
* INOUT : br_0_103 
* INOUT : bl_0_104 
* INOUT : br_0_104 
* INOUT : bl_0_105 
* INOUT : br_0_105 
* INOUT : bl_0_106 
* INOUT : br_0_106 
* INOUT : bl_0_107 
* INOUT : br_0_107 
* INOUT : bl_0_108 
* INOUT : br_0_108 
* INOUT : bl_0_109 
* INOUT : br_0_109 
* INOUT : bl_0_110 
* INOUT : br_0_110 
* INOUT : bl_0_111 
* INOUT : br_0_111 
* INOUT : bl_0_112 
* INOUT : br_0_112 
* INOUT : bl_0_113 
* INOUT : br_0_113 
* INOUT : bl_0_114 
* INOUT : br_0_114 
* INOUT : bl_0_115 
* INOUT : br_0_115 
* INOUT : bl_0_116 
* INOUT : br_0_116 
* INOUT : bl_0_117 
* INOUT : br_0_117 
* INOUT : bl_0_118 
* INOUT : br_0_118 
* INOUT : bl_0_119 
* INOUT : br_0_119 
* INOUT : bl_0_120 
* INOUT : br_0_120 
* INOUT : bl_0_121 
* INOUT : br_0_121 
* INOUT : bl_0_122 
* INOUT : br_0_122 
* INOUT : bl_0_123 
* INOUT : br_0_123 
* INOUT : bl_0_124 
* INOUT : br_0_124 
* INOUT : bl_0_125 
* INOUT : br_0_125 
* INOUT : bl_0_126 
* INOUT : br_0_126 
* INOUT : bl_0_127 
* INOUT : br_0_127 
* INOUT : bl_0_128 
* INOUT : br_0_128 
* INOUT : bl_0_129 
* INOUT : br_0_129 
* INOUT : bl_0_130 
* INOUT : br_0_130 
* INOUT : bl_0_131 
* INOUT : br_0_131 
* INOUT : bl_0_132 
* INOUT : br_0_132 
* INOUT : bl_0_133 
* INOUT : br_0_133 
* INOUT : bl_0_134 
* INOUT : br_0_134 
* INOUT : bl_0_135 
* INOUT : br_0_135 
* INOUT : bl_0_136 
* INOUT : br_0_136 
* INOUT : bl_0_137 
* INOUT : br_0_137 
* INOUT : bl_0_138 
* INOUT : br_0_138 
* INOUT : bl_0_139 
* INOUT : br_0_139 
* INOUT : bl_0_140 
* INOUT : br_0_140 
* INOUT : bl_0_141 
* INOUT : br_0_141 
* INOUT : bl_0_142 
* INOUT : br_0_142 
* INOUT : bl_0_143 
* INOUT : br_0_143 
* INOUT : bl_0_144 
* INOUT : br_0_144 
* INOUT : bl_0_145 
* INOUT : br_0_145 
* INOUT : bl_0_146 
* INOUT : br_0_146 
* INOUT : bl_0_147 
* INOUT : br_0_147 
* INOUT : bl_0_148 
* INOUT : br_0_148 
* INOUT : bl_0_149 
* INOUT : br_0_149 
* INOUT : bl_0_150 
* INOUT : br_0_150 
* INOUT : bl_0_151 
* INOUT : br_0_151 
* INOUT : bl_0_152 
* INOUT : br_0_152 
* INOUT : bl_0_153 
* INOUT : br_0_153 
* INOUT : bl_0_154 
* INOUT : br_0_154 
* INOUT : bl_0_155 
* INOUT : br_0_155 
* INOUT : bl_0_156 
* INOUT : br_0_156 
* INOUT : bl_0_157 
* INOUT : br_0_157 
* INOUT : bl_0_158 
* INOUT : br_0_158 
* INOUT : bl_0_159 
* INOUT : br_0_159 
* INOUT : bl_0_160 
* INOUT : br_0_160 
* INOUT : bl_0_161 
* INOUT : br_0_161 
* INOUT : bl_0_162 
* INOUT : br_0_162 
* INOUT : bl_0_163 
* INOUT : br_0_163 
* INOUT : bl_0_164 
* INOUT : br_0_164 
* INOUT : bl_0_165 
* INOUT : br_0_165 
* INOUT : bl_0_166 
* INOUT : br_0_166 
* INOUT : bl_0_167 
* INOUT : br_0_167 
* INOUT : bl_0_168 
* INOUT : br_0_168 
* INOUT : bl_0_169 
* INOUT : br_0_169 
* INOUT : bl_0_170 
* INOUT : br_0_170 
* INOUT : bl_0_171 
* INOUT : br_0_171 
* INOUT : bl_0_172 
* INOUT : br_0_172 
* INOUT : bl_0_173 
* INOUT : br_0_173 
* INOUT : bl_0_174 
* INOUT : br_0_174 
* INOUT : bl_0_175 
* INOUT : br_0_175 
* INOUT : bl_0_176 
* INOUT : br_0_176 
* INOUT : bl_0_177 
* INOUT : br_0_177 
* INOUT : bl_0_178 
* INOUT : br_0_178 
* INOUT : bl_0_179 
* INOUT : br_0_179 
* INOUT : bl_0_180 
* INOUT : br_0_180 
* INOUT : bl_0_181 
* INOUT : br_0_181 
* INOUT : bl_0_182 
* INOUT : br_0_182 
* INOUT : bl_0_183 
* INOUT : br_0_183 
* INOUT : bl_0_184 
* INOUT : br_0_184 
* INOUT : bl_0_185 
* INOUT : br_0_185 
* INOUT : bl_0_186 
* INOUT : br_0_186 
* INOUT : bl_0_187 
* INOUT : br_0_187 
* INOUT : bl_0_188 
* INOUT : br_0_188 
* INOUT : bl_0_189 
* INOUT : br_0_189 
* INOUT : bl_0_190 
* INOUT : br_0_190 
* INOUT : bl_0_191 
* INOUT : br_0_191 
* INOUT : bl_0_192 
* INOUT : br_0_192 
* INOUT : bl_0_193 
* INOUT : br_0_193 
* INPUT : wl_0_0 
* POWER : vdd 
* GROUND: gnd 
Xbit_r0_c0
+ bl_0_0 br_0_0 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c1
+ bl_0_1 br_0_1 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c2
+ bl_0_2 br_0_2 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c3
+ bl_0_3 br_0_3 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c4
+ bl_0_4 br_0_4 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c5
+ bl_0_5 br_0_5 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c6
+ bl_0_6 br_0_6 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c7
+ bl_0_7 br_0_7 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c8
+ bl_0_8 br_0_8 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c9
+ bl_0_9 br_0_9 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c10
+ bl_0_10 br_0_10 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c11
+ bl_0_11 br_0_11 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c12
+ bl_0_12 br_0_12 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c13
+ bl_0_13 br_0_13 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c14
+ bl_0_14 br_0_14 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c15
+ bl_0_15 br_0_15 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c16
+ bl_0_16 br_0_16 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c17
+ bl_0_17 br_0_17 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c18
+ bl_0_18 br_0_18 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c19
+ bl_0_19 br_0_19 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c20
+ bl_0_20 br_0_20 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c21
+ bl_0_21 br_0_21 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c22
+ bl_0_22 br_0_22 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c23
+ bl_0_23 br_0_23 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c24
+ bl_0_24 br_0_24 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c25
+ bl_0_25 br_0_25 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c26
+ bl_0_26 br_0_26 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c27
+ bl_0_27 br_0_27 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c28
+ bl_0_28 br_0_28 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c29
+ bl_0_29 br_0_29 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c30
+ bl_0_30 br_0_30 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c31
+ bl_0_31 br_0_31 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c32
+ bl_0_32 br_0_32 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c33
+ bl_0_33 br_0_33 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c34
+ bl_0_34 br_0_34 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c35
+ bl_0_35 br_0_35 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c36
+ bl_0_36 br_0_36 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c37
+ bl_0_37 br_0_37 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c38
+ bl_0_38 br_0_38 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c39
+ bl_0_39 br_0_39 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c40
+ bl_0_40 br_0_40 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c41
+ bl_0_41 br_0_41 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c42
+ bl_0_42 br_0_42 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c43
+ bl_0_43 br_0_43 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c44
+ bl_0_44 br_0_44 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c45
+ bl_0_45 br_0_45 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c46
+ bl_0_46 br_0_46 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c47
+ bl_0_47 br_0_47 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c48
+ bl_0_48 br_0_48 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c49
+ bl_0_49 br_0_49 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c50
+ bl_0_50 br_0_50 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c51
+ bl_0_51 br_0_51 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c52
+ bl_0_52 br_0_52 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c53
+ bl_0_53 br_0_53 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c54
+ bl_0_54 br_0_54 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c55
+ bl_0_55 br_0_55 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c56
+ bl_0_56 br_0_56 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c57
+ bl_0_57 br_0_57 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c58
+ bl_0_58 br_0_58 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c59
+ bl_0_59 br_0_59 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c60
+ bl_0_60 br_0_60 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c61
+ bl_0_61 br_0_61 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c62
+ bl_0_62 br_0_62 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c63
+ bl_0_63 br_0_63 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c64
+ bl_0_64 br_0_64 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c65
+ bl_0_65 br_0_65 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c66
+ bl_0_66 br_0_66 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c67
+ bl_0_67 br_0_67 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c68
+ bl_0_68 br_0_68 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c69
+ bl_0_69 br_0_69 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c70
+ bl_0_70 br_0_70 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c71
+ bl_0_71 br_0_71 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c72
+ bl_0_72 br_0_72 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c73
+ bl_0_73 br_0_73 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c74
+ bl_0_74 br_0_74 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c75
+ bl_0_75 br_0_75 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c76
+ bl_0_76 br_0_76 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c77
+ bl_0_77 br_0_77 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c78
+ bl_0_78 br_0_78 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c79
+ bl_0_79 br_0_79 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c80
+ bl_0_80 br_0_80 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c81
+ bl_0_81 br_0_81 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c82
+ bl_0_82 br_0_82 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c83
+ bl_0_83 br_0_83 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c84
+ bl_0_84 br_0_84 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c85
+ bl_0_85 br_0_85 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c86
+ bl_0_86 br_0_86 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c87
+ bl_0_87 br_0_87 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c88
+ bl_0_88 br_0_88 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c89
+ bl_0_89 br_0_89 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c90
+ bl_0_90 br_0_90 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c91
+ bl_0_91 br_0_91 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c92
+ bl_0_92 br_0_92 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c93
+ bl_0_93 br_0_93 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c94
+ bl_0_94 br_0_94 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c95
+ bl_0_95 br_0_95 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c96
+ bl_0_96 br_0_96 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c97
+ bl_0_97 br_0_97 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c98
+ bl_0_98 br_0_98 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c99
+ bl_0_99 br_0_99 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c100
+ bl_0_100 br_0_100 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c101
+ bl_0_101 br_0_101 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c102
+ bl_0_102 br_0_102 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c103
+ bl_0_103 br_0_103 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c104
+ bl_0_104 br_0_104 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c105
+ bl_0_105 br_0_105 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c106
+ bl_0_106 br_0_106 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c107
+ bl_0_107 br_0_107 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c108
+ bl_0_108 br_0_108 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c109
+ bl_0_109 br_0_109 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c110
+ bl_0_110 br_0_110 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c111
+ bl_0_111 br_0_111 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c112
+ bl_0_112 br_0_112 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c113
+ bl_0_113 br_0_113 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c114
+ bl_0_114 br_0_114 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c115
+ bl_0_115 br_0_115 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c116
+ bl_0_116 br_0_116 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c117
+ bl_0_117 br_0_117 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c118
+ bl_0_118 br_0_118 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c119
+ bl_0_119 br_0_119 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c120
+ bl_0_120 br_0_120 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c121
+ bl_0_121 br_0_121 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c122
+ bl_0_122 br_0_122 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c123
+ bl_0_123 br_0_123 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c124
+ bl_0_124 br_0_124 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c125
+ bl_0_125 br_0_125 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c126
+ bl_0_126 br_0_126 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c127
+ bl_0_127 br_0_127 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c128
+ bl_0_128 br_0_128 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c129
+ bl_0_129 br_0_129 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c130
+ bl_0_130 br_0_130 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c131
+ bl_0_131 br_0_131 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c132
+ bl_0_132 br_0_132 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c133
+ bl_0_133 br_0_133 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c134
+ bl_0_134 br_0_134 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c135
+ bl_0_135 br_0_135 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c136
+ bl_0_136 br_0_136 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c137
+ bl_0_137 br_0_137 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c138
+ bl_0_138 br_0_138 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c139
+ bl_0_139 br_0_139 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c140
+ bl_0_140 br_0_140 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c141
+ bl_0_141 br_0_141 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c142
+ bl_0_142 br_0_142 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c143
+ bl_0_143 br_0_143 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c144
+ bl_0_144 br_0_144 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c145
+ bl_0_145 br_0_145 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c146
+ bl_0_146 br_0_146 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c147
+ bl_0_147 br_0_147 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c148
+ bl_0_148 br_0_148 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c149
+ bl_0_149 br_0_149 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c150
+ bl_0_150 br_0_150 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c151
+ bl_0_151 br_0_151 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c152
+ bl_0_152 br_0_152 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c153
+ bl_0_153 br_0_153 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c154
+ bl_0_154 br_0_154 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c155
+ bl_0_155 br_0_155 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c156
+ bl_0_156 br_0_156 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c157
+ bl_0_157 br_0_157 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c158
+ bl_0_158 br_0_158 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c159
+ bl_0_159 br_0_159 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c160
+ bl_0_160 br_0_160 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c161
+ bl_0_161 br_0_161 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c162
+ bl_0_162 br_0_162 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c163
+ bl_0_163 br_0_163 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c164
+ bl_0_164 br_0_164 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c165
+ bl_0_165 br_0_165 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c166
+ bl_0_166 br_0_166 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c167
+ bl_0_167 br_0_167 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c168
+ bl_0_168 br_0_168 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c169
+ bl_0_169 br_0_169 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c170
+ bl_0_170 br_0_170 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c171
+ bl_0_171 br_0_171 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c172
+ bl_0_172 br_0_172 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c173
+ bl_0_173 br_0_173 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c174
+ bl_0_174 br_0_174 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c175
+ bl_0_175 br_0_175 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c176
+ bl_0_176 br_0_176 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c177
+ bl_0_177 br_0_177 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c178
+ bl_0_178 br_0_178 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c179
+ bl_0_179 br_0_179 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c180
+ bl_0_180 br_0_180 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c181
+ bl_0_181 br_0_181 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c182
+ bl_0_182 br_0_182 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c183
+ bl_0_183 br_0_183 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c184
+ bl_0_184 br_0_184 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c185
+ bl_0_185 br_0_185 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c186
+ bl_0_186 br_0_186 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c187
+ bl_0_187 br_0_187 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c188
+ bl_0_188 br_0_188 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c189
+ bl_0_189 br_0_189 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c190
+ bl_0_190 br_0_190 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c191
+ bl_0_191 br_0_191 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c192
+ bl_0_192 br_0_192 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c193
+ bl_0_193 br_0_193 wl_0_0 vdd gnd
+ sky130_custom_dummy
.ENDS sky130_sram_1rw_24x128_dummy_array_1

.SUBCKT sky130_sram_1rw_24x128_dummy_array_0
+ bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3 br_0_3 bl_0_4 br_0_4
+ bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8 br_0_8 bl_0_9 br_0_9
+ bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12 bl_0_13 br_0_13
+ bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16 bl_0_17 br_0_17
+ bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20 bl_0_21 br_0_21
+ bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24 bl_0_25 br_0_25
+ bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28 bl_0_29 br_0_29
+ bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32 bl_0_33 br_0_33
+ bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36 bl_0_37 br_0_37
+ bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40 bl_0_41 br_0_41
+ bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44 bl_0_45 br_0_45
+ bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48 bl_0_49 br_0_49
+ bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52 bl_0_53 br_0_53
+ bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56 bl_0_57 br_0_57
+ bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60 bl_0_61 br_0_61
+ bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64 bl_0_65 br_0_65
+ bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68 bl_0_69 br_0_69
+ bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72 bl_0_73 br_0_73
+ bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76 bl_0_77 br_0_77
+ bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80 bl_0_81 br_0_81
+ bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84 bl_0_85 br_0_85
+ bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88 bl_0_89 br_0_89
+ bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92 bl_0_93 br_0_93
+ bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96 bl_0_97 br_0_97
+ bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100 bl_0_101 br_0_101
+ bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104 br_0_104 bl_0_105
+ br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107 bl_0_108 br_0_108
+ bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111 br_0_111 bl_0_112
+ br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114 bl_0_115 br_0_115
+ bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118 br_0_118 bl_0_119
+ br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121 bl_0_122 br_0_122
+ bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125 br_0_125 bl_0_126
+ br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128 bl_0_129 br_0_129
+ bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132 br_0_132 bl_0_133
+ br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135 bl_0_136 br_0_136
+ bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139 br_0_139 bl_0_140
+ br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142 bl_0_143 br_0_143
+ bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146 br_0_146 bl_0_147
+ br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149 bl_0_150 br_0_150
+ bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153 br_0_153 bl_0_154
+ br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156 bl_0_157 br_0_157
+ bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160 br_0_160 bl_0_161
+ br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163 bl_0_164 br_0_164
+ bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167 br_0_167 bl_0_168
+ br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170 bl_0_171 br_0_171
+ bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174 br_0_174 bl_0_175
+ br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177 bl_0_178 br_0_178
+ bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181 br_0_181 bl_0_182
+ br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184 bl_0_185 br_0_185
+ bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188 br_0_188 bl_0_189
+ br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191 bl_0_192 br_0_192
+ bl_0_193 br_0_193 wl_0_0 vdd gnd
* INOUT : bl_0_0 
* INOUT : br_0_0 
* INOUT : bl_0_1 
* INOUT : br_0_1 
* INOUT : bl_0_2 
* INOUT : br_0_2 
* INOUT : bl_0_3 
* INOUT : br_0_3 
* INOUT : bl_0_4 
* INOUT : br_0_4 
* INOUT : bl_0_5 
* INOUT : br_0_5 
* INOUT : bl_0_6 
* INOUT : br_0_6 
* INOUT : bl_0_7 
* INOUT : br_0_7 
* INOUT : bl_0_8 
* INOUT : br_0_8 
* INOUT : bl_0_9 
* INOUT : br_0_9 
* INOUT : bl_0_10 
* INOUT : br_0_10 
* INOUT : bl_0_11 
* INOUT : br_0_11 
* INOUT : bl_0_12 
* INOUT : br_0_12 
* INOUT : bl_0_13 
* INOUT : br_0_13 
* INOUT : bl_0_14 
* INOUT : br_0_14 
* INOUT : bl_0_15 
* INOUT : br_0_15 
* INOUT : bl_0_16 
* INOUT : br_0_16 
* INOUT : bl_0_17 
* INOUT : br_0_17 
* INOUT : bl_0_18 
* INOUT : br_0_18 
* INOUT : bl_0_19 
* INOUT : br_0_19 
* INOUT : bl_0_20 
* INOUT : br_0_20 
* INOUT : bl_0_21 
* INOUT : br_0_21 
* INOUT : bl_0_22 
* INOUT : br_0_22 
* INOUT : bl_0_23 
* INOUT : br_0_23 
* INOUT : bl_0_24 
* INOUT : br_0_24 
* INOUT : bl_0_25 
* INOUT : br_0_25 
* INOUT : bl_0_26 
* INOUT : br_0_26 
* INOUT : bl_0_27 
* INOUT : br_0_27 
* INOUT : bl_0_28 
* INOUT : br_0_28 
* INOUT : bl_0_29 
* INOUT : br_0_29 
* INOUT : bl_0_30 
* INOUT : br_0_30 
* INOUT : bl_0_31 
* INOUT : br_0_31 
* INOUT : bl_0_32 
* INOUT : br_0_32 
* INOUT : bl_0_33 
* INOUT : br_0_33 
* INOUT : bl_0_34 
* INOUT : br_0_34 
* INOUT : bl_0_35 
* INOUT : br_0_35 
* INOUT : bl_0_36 
* INOUT : br_0_36 
* INOUT : bl_0_37 
* INOUT : br_0_37 
* INOUT : bl_0_38 
* INOUT : br_0_38 
* INOUT : bl_0_39 
* INOUT : br_0_39 
* INOUT : bl_0_40 
* INOUT : br_0_40 
* INOUT : bl_0_41 
* INOUT : br_0_41 
* INOUT : bl_0_42 
* INOUT : br_0_42 
* INOUT : bl_0_43 
* INOUT : br_0_43 
* INOUT : bl_0_44 
* INOUT : br_0_44 
* INOUT : bl_0_45 
* INOUT : br_0_45 
* INOUT : bl_0_46 
* INOUT : br_0_46 
* INOUT : bl_0_47 
* INOUT : br_0_47 
* INOUT : bl_0_48 
* INOUT : br_0_48 
* INOUT : bl_0_49 
* INOUT : br_0_49 
* INOUT : bl_0_50 
* INOUT : br_0_50 
* INOUT : bl_0_51 
* INOUT : br_0_51 
* INOUT : bl_0_52 
* INOUT : br_0_52 
* INOUT : bl_0_53 
* INOUT : br_0_53 
* INOUT : bl_0_54 
* INOUT : br_0_54 
* INOUT : bl_0_55 
* INOUT : br_0_55 
* INOUT : bl_0_56 
* INOUT : br_0_56 
* INOUT : bl_0_57 
* INOUT : br_0_57 
* INOUT : bl_0_58 
* INOUT : br_0_58 
* INOUT : bl_0_59 
* INOUT : br_0_59 
* INOUT : bl_0_60 
* INOUT : br_0_60 
* INOUT : bl_0_61 
* INOUT : br_0_61 
* INOUT : bl_0_62 
* INOUT : br_0_62 
* INOUT : bl_0_63 
* INOUT : br_0_63 
* INOUT : bl_0_64 
* INOUT : br_0_64 
* INOUT : bl_0_65 
* INOUT : br_0_65 
* INOUT : bl_0_66 
* INOUT : br_0_66 
* INOUT : bl_0_67 
* INOUT : br_0_67 
* INOUT : bl_0_68 
* INOUT : br_0_68 
* INOUT : bl_0_69 
* INOUT : br_0_69 
* INOUT : bl_0_70 
* INOUT : br_0_70 
* INOUT : bl_0_71 
* INOUT : br_0_71 
* INOUT : bl_0_72 
* INOUT : br_0_72 
* INOUT : bl_0_73 
* INOUT : br_0_73 
* INOUT : bl_0_74 
* INOUT : br_0_74 
* INOUT : bl_0_75 
* INOUT : br_0_75 
* INOUT : bl_0_76 
* INOUT : br_0_76 
* INOUT : bl_0_77 
* INOUT : br_0_77 
* INOUT : bl_0_78 
* INOUT : br_0_78 
* INOUT : bl_0_79 
* INOUT : br_0_79 
* INOUT : bl_0_80 
* INOUT : br_0_80 
* INOUT : bl_0_81 
* INOUT : br_0_81 
* INOUT : bl_0_82 
* INOUT : br_0_82 
* INOUT : bl_0_83 
* INOUT : br_0_83 
* INOUT : bl_0_84 
* INOUT : br_0_84 
* INOUT : bl_0_85 
* INOUT : br_0_85 
* INOUT : bl_0_86 
* INOUT : br_0_86 
* INOUT : bl_0_87 
* INOUT : br_0_87 
* INOUT : bl_0_88 
* INOUT : br_0_88 
* INOUT : bl_0_89 
* INOUT : br_0_89 
* INOUT : bl_0_90 
* INOUT : br_0_90 
* INOUT : bl_0_91 
* INOUT : br_0_91 
* INOUT : bl_0_92 
* INOUT : br_0_92 
* INOUT : bl_0_93 
* INOUT : br_0_93 
* INOUT : bl_0_94 
* INOUT : br_0_94 
* INOUT : bl_0_95 
* INOUT : br_0_95 
* INOUT : bl_0_96 
* INOUT : br_0_96 
* INOUT : bl_0_97 
* INOUT : br_0_97 
* INOUT : bl_0_98 
* INOUT : br_0_98 
* INOUT : bl_0_99 
* INOUT : br_0_99 
* INOUT : bl_0_100 
* INOUT : br_0_100 
* INOUT : bl_0_101 
* INOUT : br_0_101 
* INOUT : bl_0_102 
* INOUT : br_0_102 
* INOUT : bl_0_103 
* INOUT : br_0_103 
* INOUT : bl_0_104 
* INOUT : br_0_104 
* INOUT : bl_0_105 
* INOUT : br_0_105 
* INOUT : bl_0_106 
* INOUT : br_0_106 
* INOUT : bl_0_107 
* INOUT : br_0_107 
* INOUT : bl_0_108 
* INOUT : br_0_108 
* INOUT : bl_0_109 
* INOUT : br_0_109 
* INOUT : bl_0_110 
* INOUT : br_0_110 
* INOUT : bl_0_111 
* INOUT : br_0_111 
* INOUT : bl_0_112 
* INOUT : br_0_112 
* INOUT : bl_0_113 
* INOUT : br_0_113 
* INOUT : bl_0_114 
* INOUT : br_0_114 
* INOUT : bl_0_115 
* INOUT : br_0_115 
* INOUT : bl_0_116 
* INOUT : br_0_116 
* INOUT : bl_0_117 
* INOUT : br_0_117 
* INOUT : bl_0_118 
* INOUT : br_0_118 
* INOUT : bl_0_119 
* INOUT : br_0_119 
* INOUT : bl_0_120 
* INOUT : br_0_120 
* INOUT : bl_0_121 
* INOUT : br_0_121 
* INOUT : bl_0_122 
* INOUT : br_0_122 
* INOUT : bl_0_123 
* INOUT : br_0_123 
* INOUT : bl_0_124 
* INOUT : br_0_124 
* INOUT : bl_0_125 
* INOUT : br_0_125 
* INOUT : bl_0_126 
* INOUT : br_0_126 
* INOUT : bl_0_127 
* INOUT : br_0_127 
* INOUT : bl_0_128 
* INOUT : br_0_128 
* INOUT : bl_0_129 
* INOUT : br_0_129 
* INOUT : bl_0_130 
* INOUT : br_0_130 
* INOUT : bl_0_131 
* INOUT : br_0_131 
* INOUT : bl_0_132 
* INOUT : br_0_132 
* INOUT : bl_0_133 
* INOUT : br_0_133 
* INOUT : bl_0_134 
* INOUT : br_0_134 
* INOUT : bl_0_135 
* INOUT : br_0_135 
* INOUT : bl_0_136 
* INOUT : br_0_136 
* INOUT : bl_0_137 
* INOUT : br_0_137 
* INOUT : bl_0_138 
* INOUT : br_0_138 
* INOUT : bl_0_139 
* INOUT : br_0_139 
* INOUT : bl_0_140 
* INOUT : br_0_140 
* INOUT : bl_0_141 
* INOUT : br_0_141 
* INOUT : bl_0_142 
* INOUT : br_0_142 
* INOUT : bl_0_143 
* INOUT : br_0_143 
* INOUT : bl_0_144 
* INOUT : br_0_144 
* INOUT : bl_0_145 
* INOUT : br_0_145 
* INOUT : bl_0_146 
* INOUT : br_0_146 
* INOUT : bl_0_147 
* INOUT : br_0_147 
* INOUT : bl_0_148 
* INOUT : br_0_148 
* INOUT : bl_0_149 
* INOUT : br_0_149 
* INOUT : bl_0_150 
* INOUT : br_0_150 
* INOUT : bl_0_151 
* INOUT : br_0_151 
* INOUT : bl_0_152 
* INOUT : br_0_152 
* INOUT : bl_0_153 
* INOUT : br_0_153 
* INOUT : bl_0_154 
* INOUT : br_0_154 
* INOUT : bl_0_155 
* INOUT : br_0_155 
* INOUT : bl_0_156 
* INOUT : br_0_156 
* INOUT : bl_0_157 
* INOUT : br_0_157 
* INOUT : bl_0_158 
* INOUT : br_0_158 
* INOUT : bl_0_159 
* INOUT : br_0_159 
* INOUT : bl_0_160 
* INOUT : br_0_160 
* INOUT : bl_0_161 
* INOUT : br_0_161 
* INOUT : bl_0_162 
* INOUT : br_0_162 
* INOUT : bl_0_163 
* INOUT : br_0_163 
* INOUT : bl_0_164 
* INOUT : br_0_164 
* INOUT : bl_0_165 
* INOUT : br_0_165 
* INOUT : bl_0_166 
* INOUT : br_0_166 
* INOUT : bl_0_167 
* INOUT : br_0_167 
* INOUT : bl_0_168 
* INOUT : br_0_168 
* INOUT : bl_0_169 
* INOUT : br_0_169 
* INOUT : bl_0_170 
* INOUT : br_0_170 
* INOUT : bl_0_171 
* INOUT : br_0_171 
* INOUT : bl_0_172 
* INOUT : br_0_172 
* INOUT : bl_0_173 
* INOUT : br_0_173 
* INOUT : bl_0_174 
* INOUT : br_0_174 
* INOUT : bl_0_175 
* INOUT : br_0_175 
* INOUT : bl_0_176 
* INOUT : br_0_176 
* INOUT : bl_0_177 
* INOUT : br_0_177 
* INOUT : bl_0_178 
* INOUT : br_0_178 
* INOUT : bl_0_179 
* INOUT : br_0_179 
* INOUT : bl_0_180 
* INOUT : br_0_180 
* INOUT : bl_0_181 
* INOUT : br_0_181 
* INOUT : bl_0_182 
* INOUT : br_0_182 
* INOUT : bl_0_183 
* INOUT : br_0_183 
* INOUT : bl_0_184 
* INOUT : br_0_184 
* INOUT : bl_0_185 
* INOUT : br_0_185 
* INOUT : bl_0_186 
* INOUT : br_0_186 
* INOUT : bl_0_187 
* INOUT : br_0_187 
* INOUT : bl_0_188 
* INOUT : br_0_188 
* INOUT : bl_0_189 
* INOUT : br_0_189 
* INOUT : bl_0_190 
* INOUT : br_0_190 
* INOUT : bl_0_191 
* INOUT : br_0_191 
* INOUT : bl_0_192 
* INOUT : br_0_192 
* INOUT : bl_0_193 
* INOUT : br_0_193 
* INPUT : wl_0_0 
* POWER : vdd 
* GROUND: gnd 
Xbit_r0_c0
+ bl_0_0 br_0_0 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c1
+ bl_0_1 br_0_1 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c2
+ bl_0_2 br_0_2 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c3
+ bl_0_3 br_0_3 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c4
+ bl_0_4 br_0_4 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c5
+ bl_0_5 br_0_5 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c6
+ bl_0_6 br_0_6 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c7
+ bl_0_7 br_0_7 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c8
+ bl_0_8 br_0_8 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c9
+ bl_0_9 br_0_9 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c10
+ bl_0_10 br_0_10 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c11
+ bl_0_11 br_0_11 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c12
+ bl_0_12 br_0_12 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c13
+ bl_0_13 br_0_13 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c14
+ bl_0_14 br_0_14 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c15
+ bl_0_15 br_0_15 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c16
+ bl_0_16 br_0_16 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c17
+ bl_0_17 br_0_17 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c18
+ bl_0_18 br_0_18 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c19
+ bl_0_19 br_0_19 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c20
+ bl_0_20 br_0_20 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c21
+ bl_0_21 br_0_21 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c22
+ bl_0_22 br_0_22 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c23
+ bl_0_23 br_0_23 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c24
+ bl_0_24 br_0_24 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c25
+ bl_0_25 br_0_25 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c26
+ bl_0_26 br_0_26 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c27
+ bl_0_27 br_0_27 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c28
+ bl_0_28 br_0_28 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c29
+ bl_0_29 br_0_29 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c30
+ bl_0_30 br_0_30 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c31
+ bl_0_31 br_0_31 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c32
+ bl_0_32 br_0_32 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c33
+ bl_0_33 br_0_33 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c34
+ bl_0_34 br_0_34 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c35
+ bl_0_35 br_0_35 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c36
+ bl_0_36 br_0_36 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c37
+ bl_0_37 br_0_37 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c38
+ bl_0_38 br_0_38 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c39
+ bl_0_39 br_0_39 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c40
+ bl_0_40 br_0_40 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c41
+ bl_0_41 br_0_41 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c42
+ bl_0_42 br_0_42 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c43
+ bl_0_43 br_0_43 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c44
+ bl_0_44 br_0_44 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c45
+ bl_0_45 br_0_45 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c46
+ bl_0_46 br_0_46 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c47
+ bl_0_47 br_0_47 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c48
+ bl_0_48 br_0_48 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c49
+ bl_0_49 br_0_49 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c50
+ bl_0_50 br_0_50 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c51
+ bl_0_51 br_0_51 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c52
+ bl_0_52 br_0_52 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c53
+ bl_0_53 br_0_53 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c54
+ bl_0_54 br_0_54 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c55
+ bl_0_55 br_0_55 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c56
+ bl_0_56 br_0_56 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c57
+ bl_0_57 br_0_57 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c58
+ bl_0_58 br_0_58 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c59
+ bl_0_59 br_0_59 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c60
+ bl_0_60 br_0_60 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c61
+ bl_0_61 br_0_61 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c62
+ bl_0_62 br_0_62 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c63
+ bl_0_63 br_0_63 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c64
+ bl_0_64 br_0_64 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c65
+ bl_0_65 br_0_65 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c66
+ bl_0_66 br_0_66 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c67
+ bl_0_67 br_0_67 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c68
+ bl_0_68 br_0_68 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c69
+ bl_0_69 br_0_69 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c70
+ bl_0_70 br_0_70 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c71
+ bl_0_71 br_0_71 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c72
+ bl_0_72 br_0_72 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c73
+ bl_0_73 br_0_73 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c74
+ bl_0_74 br_0_74 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c75
+ bl_0_75 br_0_75 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c76
+ bl_0_76 br_0_76 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c77
+ bl_0_77 br_0_77 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c78
+ bl_0_78 br_0_78 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c79
+ bl_0_79 br_0_79 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c80
+ bl_0_80 br_0_80 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c81
+ bl_0_81 br_0_81 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c82
+ bl_0_82 br_0_82 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c83
+ bl_0_83 br_0_83 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c84
+ bl_0_84 br_0_84 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c85
+ bl_0_85 br_0_85 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c86
+ bl_0_86 br_0_86 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c87
+ bl_0_87 br_0_87 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c88
+ bl_0_88 br_0_88 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c89
+ bl_0_89 br_0_89 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c90
+ bl_0_90 br_0_90 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c91
+ bl_0_91 br_0_91 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c92
+ bl_0_92 br_0_92 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c93
+ bl_0_93 br_0_93 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c94
+ bl_0_94 br_0_94 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c95
+ bl_0_95 br_0_95 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c96
+ bl_0_96 br_0_96 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c97
+ bl_0_97 br_0_97 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c98
+ bl_0_98 br_0_98 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c99
+ bl_0_99 br_0_99 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c100
+ bl_0_100 br_0_100 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c101
+ bl_0_101 br_0_101 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c102
+ bl_0_102 br_0_102 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c103
+ bl_0_103 br_0_103 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c104
+ bl_0_104 br_0_104 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c105
+ bl_0_105 br_0_105 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c106
+ bl_0_106 br_0_106 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c107
+ bl_0_107 br_0_107 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c108
+ bl_0_108 br_0_108 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c109
+ bl_0_109 br_0_109 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c110
+ bl_0_110 br_0_110 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c111
+ bl_0_111 br_0_111 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c112
+ bl_0_112 br_0_112 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c113
+ bl_0_113 br_0_113 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c114
+ bl_0_114 br_0_114 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c115
+ bl_0_115 br_0_115 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c116
+ bl_0_116 br_0_116 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c117
+ bl_0_117 br_0_117 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c118
+ bl_0_118 br_0_118 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c119
+ bl_0_119 br_0_119 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c120
+ bl_0_120 br_0_120 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c121
+ bl_0_121 br_0_121 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c122
+ bl_0_122 br_0_122 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c123
+ bl_0_123 br_0_123 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c124
+ bl_0_124 br_0_124 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c125
+ bl_0_125 br_0_125 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c126
+ bl_0_126 br_0_126 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c127
+ bl_0_127 br_0_127 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c128
+ bl_0_128 br_0_128 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c129
+ bl_0_129 br_0_129 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c130
+ bl_0_130 br_0_130 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c131
+ bl_0_131 br_0_131 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c132
+ bl_0_132 br_0_132 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c133
+ bl_0_133 br_0_133 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c134
+ bl_0_134 br_0_134 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c135
+ bl_0_135 br_0_135 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c136
+ bl_0_136 br_0_136 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c137
+ bl_0_137 br_0_137 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c138
+ bl_0_138 br_0_138 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c139
+ bl_0_139 br_0_139 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c140
+ bl_0_140 br_0_140 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c141
+ bl_0_141 br_0_141 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c142
+ bl_0_142 br_0_142 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c143
+ bl_0_143 br_0_143 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c144
+ bl_0_144 br_0_144 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c145
+ bl_0_145 br_0_145 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c146
+ bl_0_146 br_0_146 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c147
+ bl_0_147 br_0_147 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c148
+ bl_0_148 br_0_148 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c149
+ bl_0_149 br_0_149 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c150
+ bl_0_150 br_0_150 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c151
+ bl_0_151 br_0_151 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c152
+ bl_0_152 br_0_152 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c153
+ bl_0_153 br_0_153 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c154
+ bl_0_154 br_0_154 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c155
+ bl_0_155 br_0_155 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c156
+ bl_0_156 br_0_156 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c157
+ bl_0_157 br_0_157 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c158
+ bl_0_158 br_0_158 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c159
+ bl_0_159 br_0_159 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c160
+ bl_0_160 br_0_160 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c161
+ bl_0_161 br_0_161 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c162
+ bl_0_162 br_0_162 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c163
+ bl_0_163 br_0_163 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c164
+ bl_0_164 br_0_164 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c165
+ bl_0_165 br_0_165 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c166
+ bl_0_166 br_0_166 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c167
+ bl_0_167 br_0_167 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c168
+ bl_0_168 br_0_168 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c169
+ bl_0_169 br_0_169 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c170
+ bl_0_170 br_0_170 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c171
+ bl_0_171 br_0_171 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c172
+ bl_0_172 br_0_172 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c173
+ bl_0_173 br_0_173 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c174
+ bl_0_174 br_0_174 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c175
+ bl_0_175 br_0_175 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c176
+ bl_0_176 br_0_176 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c177
+ bl_0_177 br_0_177 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c178
+ bl_0_178 br_0_178 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c179
+ bl_0_179 br_0_179 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c180
+ bl_0_180 br_0_180 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c181
+ bl_0_181 br_0_181 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c182
+ bl_0_182 br_0_182 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c183
+ bl_0_183 br_0_183 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c184
+ bl_0_184 br_0_184 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c185
+ bl_0_185 br_0_185 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c186
+ bl_0_186 br_0_186 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c187
+ bl_0_187 br_0_187 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c188
+ bl_0_188 br_0_188 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c189
+ bl_0_189 br_0_189 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c190
+ bl_0_190 br_0_190 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c191
+ bl_0_191 br_0_191 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c192
+ bl_0_192 br_0_192 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r0_c193
+ bl_0_193 br_0_193 wl_0_0 vdd gnd
+ sky130_custom_dummy
.ENDS sky130_sram_1rw_24x128_dummy_array_0

.SUBCKT sky130_sram_1rw_24x128_dummy_array_3
+ bl_0_0 br_0_0 wl_0_0 wl_0_1 wl_0_2 wl_0_3 wl_0_4 wl_0_5 wl_0_6 wl_0_7
+ wl_0_8 wl_0_9 wl_0_10 wl_0_11 wl_0_12 wl_0_13 wl_0_14 wl_0_15 wl_0_16
+ wl_0_17 wl_0_18 wl_0_19 vdd gnd
* INOUT : bl_0_0 
* INOUT : br_0_0 
* INPUT : wl_0_0 
* INPUT : wl_0_1 
* INPUT : wl_0_2 
* INPUT : wl_0_3 
* INPUT : wl_0_4 
* INPUT : wl_0_5 
* INPUT : wl_0_6 
* INPUT : wl_0_7 
* INPUT : wl_0_8 
* INPUT : wl_0_9 
* INPUT : wl_0_10 
* INPUT : wl_0_11 
* INPUT : wl_0_12 
* INPUT : wl_0_13 
* INPUT : wl_0_14 
* INPUT : wl_0_15 
* INPUT : wl_0_16 
* INPUT : wl_0_17 
* INPUT : wl_0_18 
* INPUT : wl_0_19 
* POWER : vdd 
* GROUND: gnd 
Xbit_r0_c0
+ bl_0_0 br_0_0 wl_0_0 vdd gnd
+ sky130_custom_dummy
Xbit_r1_c0
+ bl_0_0 br_0_0 wl_0_1 vdd gnd
+ sky130_custom_dummy
Xbit_r2_c0
+ bl_0_0 br_0_0 wl_0_2 vdd gnd
+ sky130_custom_dummy
Xbit_r3_c0
+ bl_0_0 br_0_0 wl_0_3 vdd gnd
+ sky130_custom_dummy
Xbit_r4_c0
+ bl_0_0 br_0_0 wl_0_4 vdd gnd
+ sky130_custom_dummy
Xbit_r5_c0
+ bl_0_0 br_0_0 wl_0_5 vdd gnd
+ sky130_custom_dummy
Xbit_r6_c0
+ bl_0_0 br_0_0 wl_0_6 vdd gnd
+ sky130_custom_dummy
Xbit_r7_c0
+ bl_0_0 br_0_0 wl_0_7 vdd gnd
+ sky130_custom_dummy
Xbit_r8_c0
+ bl_0_0 br_0_0 wl_0_8 vdd gnd
+ sky130_custom_dummy
Xbit_r9_c0
+ bl_0_0 br_0_0 wl_0_9 vdd gnd
+ sky130_custom_dummy
Xbit_r10_c0
+ bl_0_0 br_0_0 wl_0_10 vdd gnd
+ sky130_custom_dummy
Xbit_r11_c0
+ bl_0_0 br_0_0 wl_0_11 vdd gnd
+ sky130_custom_dummy
Xbit_r12_c0
+ bl_0_0 br_0_0 wl_0_12 vdd gnd
+ sky130_custom_dummy
Xbit_r13_c0
+ bl_0_0 br_0_0 wl_0_13 vdd gnd
+ sky130_custom_dummy
Xbit_r14_c0
+ bl_0_0 br_0_0 wl_0_14 vdd gnd
+ sky130_custom_dummy
Xbit_r15_c0
+ bl_0_0 br_0_0 wl_0_15 vdd gnd
+ sky130_custom_dummy
Xbit_r16_c0
+ bl_0_0 br_0_0 wl_0_16 vdd gnd
+ sky130_custom_dummy
Xbit_r17_c0
+ bl_0_0 br_0_0 wl_0_17 vdd gnd
+ sky130_custom_dummy
Xbit_r18_c0
+ bl_0_0 br_0_0 wl_0_18 vdd gnd
+ sky130_custom_dummy
Xbit_r19_c0
+ bl_0_0 br_0_0 wl_0_19 vdd gnd
+ sky130_custom_dummy
.ENDS sky130_sram_1rw_24x128_dummy_array_3

.SUBCKT sky130_sram_1rw_24x128_capped_replica_bitcell_array
+ rbl_bl_0_0 rbl_br_0_0 bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3
+ br_0_3 bl_0_4 br_0_4 bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8
+ br_0_8 bl_0_9 br_0_9 bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12
+ bl_0_13 br_0_13 bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16
+ bl_0_17 br_0_17 bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20
+ bl_0_21 br_0_21 bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24
+ bl_0_25 br_0_25 bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28
+ bl_0_29 br_0_29 bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32
+ bl_0_33 br_0_33 bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36
+ bl_0_37 br_0_37 bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40
+ bl_0_41 br_0_41 bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44
+ bl_0_45 br_0_45 bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48
+ bl_0_49 br_0_49 bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52
+ bl_0_53 br_0_53 bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56
+ bl_0_57 br_0_57 bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60
+ bl_0_61 br_0_61 bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64
+ bl_0_65 br_0_65 bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68
+ bl_0_69 br_0_69 bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72
+ bl_0_73 br_0_73 bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76
+ bl_0_77 br_0_77 bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80
+ bl_0_81 br_0_81 bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84
+ bl_0_85 br_0_85 bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88
+ bl_0_89 br_0_89 bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92
+ bl_0_93 br_0_93 bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96
+ bl_0_97 br_0_97 bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100
+ bl_0_101 br_0_101 bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104
+ br_0_104 bl_0_105 br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107
+ bl_0_108 br_0_108 bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111
+ br_0_111 bl_0_112 br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114
+ bl_0_115 br_0_115 bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118
+ br_0_118 bl_0_119 br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121
+ bl_0_122 br_0_122 bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125
+ br_0_125 bl_0_126 br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128
+ bl_0_129 br_0_129 bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132
+ br_0_132 bl_0_133 br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135
+ bl_0_136 br_0_136 bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139
+ br_0_139 bl_0_140 br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142
+ bl_0_143 br_0_143 bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146
+ br_0_146 bl_0_147 br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149
+ bl_0_150 br_0_150 bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153
+ br_0_153 bl_0_154 br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156
+ bl_0_157 br_0_157 bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160
+ br_0_160 bl_0_161 br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163
+ bl_0_164 br_0_164 bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167
+ br_0_167 bl_0_168 br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170
+ bl_0_171 br_0_171 bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174
+ br_0_174 bl_0_175 br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177
+ bl_0_178 br_0_178 bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181
+ br_0_181 bl_0_182 br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184
+ bl_0_185 br_0_185 bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188
+ br_0_188 bl_0_189 br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191
+ bl_0_192 br_0_192 rbl_wl_0_0 wl_0_0 wl_0_1 wl_0_2 wl_0_3 wl_0_4 wl_0_5
+ wl_0_6 wl_0_7 wl_0_8 wl_0_9 wl_0_10 wl_0_11 wl_0_12 wl_0_13 wl_0_14
+ wl_0_15 wl_0_16 vdd gnd
* INOUT : rbl_bl_0_0 
* INOUT : rbl_br_0_0 
* INOUT : bl_0_0 
* INOUT : br_0_0 
* INOUT : bl_0_1 
* INOUT : br_0_1 
* INOUT : bl_0_2 
* INOUT : br_0_2 
* INOUT : bl_0_3 
* INOUT : br_0_3 
* INOUT : bl_0_4 
* INOUT : br_0_4 
* INOUT : bl_0_5 
* INOUT : br_0_5 
* INOUT : bl_0_6 
* INOUT : br_0_6 
* INOUT : bl_0_7 
* INOUT : br_0_7 
* INOUT : bl_0_8 
* INOUT : br_0_8 
* INOUT : bl_0_9 
* INOUT : br_0_9 
* INOUT : bl_0_10 
* INOUT : br_0_10 
* INOUT : bl_0_11 
* INOUT : br_0_11 
* INOUT : bl_0_12 
* INOUT : br_0_12 
* INOUT : bl_0_13 
* INOUT : br_0_13 
* INOUT : bl_0_14 
* INOUT : br_0_14 
* INOUT : bl_0_15 
* INOUT : br_0_15 
* INOUT : bl_0_16 
* INOUT : br_0_16 
* INOUT : bl_0_17 
* INOUT : br_0_17 
* INOUT : bl_0_18 
* INOUT : br_0_18 
* INOUT : bl_0_19 
* INOUT : br_0_19 
* INOUT : bl_0_20 
* INOUT : br_0_20 
* INOUT : bl_0_21 
* INOUT : br_0_21 
* INOUT : bl_0_22 
* INOUT : br_0_22 
* INOUT : bl_0_23 
* INOUT : br_0_23 
* INOUT : bl_0_24 
* INOUT : br_0_24 
* INOUT : bl_0_25 
* INOUT : br_0_25 
* INOUT : bl_0_26 
* INOUT : br_0_26 
* INOUT : bl_0_27 
* INOUT : br_0_27 
* INOUT : bl_0_28 
* INOUT : br_0_28 
* INOUT : bl_0_29 
* INOUT : br_0_29 
* INOUT : bl_0_30 
* INOUT : br_0_30 
* INOUT : bl_0_31 
* INOUT : br_0_31 
* INOUT : bl_0_32 
* INOUT : br_0_32 
* INOUT : bl_0_33 
* INOUT : br_0_33 
* INOUT : bl_0_34 
* INOUT : br_0_34 
* INOUT : bl_0_35 
* INOUT : br_0_35 
* INOUT : bl_0_36 
* INOUT : br_0_36 
* INOUT : bl_0_37 
* INOUT : br_0_37 
* INOUT : bl_0_38 
* INOUT : br_0_38 
* INOUT : bl_0_39 
* INOUT : br_0_39 
* INOUT : bl_0_40 
* INOUT : br_0_40 
* INOUT : bl_0_41 
* INOUT : br_0_41 
* INOUT : bl_0_42 
* INOUT : br_0_42 
* INOUT : bl_0_43 
* INOUT : br_0_43 
* INOUT : bl_0_44 
* INOUT : br_0_44 
* INOUT : bl_0_45 
* INOUT : br_0_45 
* INOUT : bl_0_46 
* INOUT : br_0_46 
* INOUT : bl_0_47 
* INOUT : br_0_47 
* INOUT : bl_0_48 
* INOUT : br_0_48 
* INOUT : bl_0_49 
* INOUT : br_0_49 
* INOUT : bl_0_50 
* INOUT : br_0_50 
* INOUT : bl_0_51 
* INOUT : br_0_51 
* INOUT : bl_0_52 
* INOUT : br_0_52 
* INOUT : bl_0_53 
* INOUT : br_0_53 
* INOUT : bl_0_54 
* INOUT : br_0_54 
* INOUT : bl_0_55 
* INOUT : br_0_55 
* INOUT : bl_0_56 
* INOUT : br_0_56 
* INOUT : bl_0_57 
* INOUT : br_0_57 
* INOUT : bl_0_58 
* INOUT : br_0_58 
* INOUT : bl_0_59 
* INOUT : br_0_59 
* INOUT : bl_0_60 
* INOUT : br_0_60 
* INOUT : bl_0_61 
* INOUT : br_0_61 
* INOUT : bl_0_62 
* INOUT : br_0_62 
* INOUT : bl_0_63 
* INOUT : br_0_63 
* INOUT : bl_0_64 
* INOUT : br_0_64 
* INOUT : bl_0_65 
* INOUT : br_0_65 
* INOUT : bl_0_66 
* INOUT : br_0_66 
* INOUT : bl_0_67 
* INOUT : br_0_67 
* INOUT : bl_0_68 
* INOUT : br_0_68 
* INOUT : bl_0_69 
* INOUT : br_0_69 
* INOUT : bl_0_70 
* INOUT : br_0_70 
* INOUT : bl_0_71 
* INOUT : br_0_71 
* INOUT : bl_0_72 
* INOUT : br_0_72 
* INOUT : bl_0_73 
* INOUT : br_0_73 
* INOUT : bl_0_74 
* INOUT : br_0_74 
* INOUT : bl_0_75 
* INOUT : br_0_75 
* INOUT : bl_0_76 
* INOUT : br_0_76 
* INOUT : bl_0_77 
* INOUT : br_0_77 
* INOUT : bl_0_78 
* INOUT : br_0_78 
* INOUT : bl_0_79 
* INOUT : br_0_79 
* INOUT : bl_0_80 
* INOUT : br_0_80 
* INOUT : bl_0_81 
* INOUT : br_0_81 
* INOUT : bl_0_82 
* INOUT : br_0_82 
* INOUT : bl_0_83 
* INOUT : br_0_83 
* INOUT : bl_0_84 
* INOUT : br_0_84 
* INOUT : bl_0_85 
* INOUT : br_0_85 
* INOUT : bl_0_86 
* INOUT : br_0_86 
* INOUT : bl_0_87 
* INOUT : br_0_87 
* INOUT : bl_0_88 
* INOUT : br_0_88 
* INOUT : bl_0_89 
* INOUT : br_0_89 
* INOUT : bl_0_90 
* INOUT : br_0_90 
* INOUT : bl_0_91 
* INOUT : br_0_91 
* INOUT : bl_0_92 
* INOUT : br_0_92 
* INOUT : bl_0_93 
* INOUT : br_0_93 
* INOUT : bl_0_94 
* INOUT : br_0_94 
* INOUT : bl_0_95 
* INOUT : br_0_95 
* INOUT : bl_0_96 
* INOUT : br_0_96 
* INOUT : bl_0_97 
* INOUT : br_0_97 
* INOUT : bl_0_98 
* INOUT : br_0_98 
* INOUT : bl_0_99 
* INOUT : br_0_99 
* INOUT : bl_0_100 
* INOUT : br_0_100 
* INOUT : bl_0_101 
* INOUT : br_0_101 
* INOUT : bl_0_102 
* INOUT : br_0_102 
* INOUT : bl_0_103 
* INOUT : br_0_103 
* INOUT : bl_0_104 
* INOUT : br_0_104 
* INOUT : bl_0_105 
* INOUT : br_0_105 
* INOUT : bl_0_106 
* INOUT : br_0_106 
* INOUT : bl_0_107 
* INOUT : br_0_107 
* INOUT : bl_0_108 
* INOUT : br_0_108 
* INOUT : bl_0_109 
* INOUT : br_0_109 
* INOUT : bl_0_110 
* INOUT : br_0_110 
* INOUT : bl_0_111 
* INOUT : br_0_111 
* INOUT : bl_0_112 
* INOUT : br_0_112 
* INOUT : bl_0_113 
* INOUT : br_0_113 
* INOUT : bl_0_114 
* INOUT : br_0_114 
* INOUT : bl_0_115 
* INOUT : br_0_115 
* INOUT : bl_0_116 
* INOUT : br_0_116 
* INOUT : bl_0_117 
* INOUT : br_0_117 
* INOUT : bl_0_118 
* INOUT : br_0_118 
* INOUT : bl_0_119 
* INOUT : br_0_119 
* INOUT : bl_0_120 
* INOUT : br_0_120 
* INOUT : bl_0_121 
* INOUT : br_0_121 
* INOUT : bl_0_122 
* INOUT : br_0_122 
* INOUT : bl_0_123 
* INOUT : br_0_123 
* INOUT : bl_0_124 
* INOUT : br_0_124 
* INOUT : bl_0_125 
* INOUT : br_0_125 
* INOUT : bl_0_126 
* INOUT : br_0_126 
* INOUT : bl_0_127 
* INOUT : br_0_127 
* INOUT : bl_0_128 
* INOUT : br_0_128 
* INOUT : bl_0_129 
* INOUT : br_0_129 
* INOUT : bl_0_130 
* INOUT : br_0_130 
* INOUT : bl_0_131 
* INOUT : br_0_131 
* INOUT : bl_0_132 
* INOUT : br_0_132 
* INOUT : bl_0_133 
* INOUT : br_0_133 
* INOUT : bl_0_134 
* INOUT : br_0_134 
* INOUT : bl_0_135 
* INOUT : br_0_135 
* INOUT : bl_0_136 
* INOUT : br_0_136 
* INOUT : bl_0_137 
* INOUT : br_0_137 
* INOUT : bl_0_138 
* INOUT : br_0_138 
* INOUT : bl_0_139 
* INOUT : br_0_139 
* INOUT : bl_0_140 
* INOUT : br_0_140 
* INOUT : bl_0_141 
* INOUT : br_0_141 
* INOUT : bl_0_142 
* INOUT : br_0_142 
* INOUT : bl_0_143 
* INOUT : br_0_143 
* INOUT : bl_0_144 
* INOUT : br_0_144 
* INOUT : bl_0_145 
* INOUT : br_0_145 
* INOUT : bl_0_146 
* INOUT : br_0_146 
* INOUT : bl_0_147 
* INOUT : br_0_147 
* INOUT : bl_0_148 
* INOUT : br_0_148 
* INOUT : bl_0_149 
* INOUT : br_0_149 
* INOUT : bl_0_150 
* INOUT : br_0_150 
* INOUT : bl_0_151 
* INOUT : br_0_151 
* INOUT : bl_0_152 
* INOUT : br_0_152 
* INOUT : bl_0_153 
* INOUT : br_0_153 
* INOUT : bl_0_154 
* INOUT : br_0_154 
* INOUT : bl_0_155 
* INOUT : br_0_155 
* INOUT : bl_0_156 
* INOUT : br_0_156 
* INOUT : bl_0_157 
* INOUT : br_0_157 
* INOUT : bl_0_158 
* INOUT : br_0_158 
* INOUT : bl_0_159 
* INOUT : br_0_159 
* INOUT : bl_0_160 
* INOUT : br_0_160 
* INOUT : bl_0_161 
* INOUT : br_0_161 
* INOUT : bl_0_162 
* INOUT : br_0_162 
* INOUT : bl_0_163 
* INOUT : br_0_163 
* INOUT : bl_0_164 
* INOUT : br_0_164 
* INOUT : bl_0_165 
* INOUT : br_0_165 
* INOUT : bl_0_166 
* INOUT : br_0_166 
* INOUT : bl_0_167 
* INOUT : br_0_167 
* INOUT : bl_0_168 
* INOUT : br_0_168 
* INOUT : bl_0_169 
* INOUT : br_0_169 
* INOUT : bl_0_170 
* INOUT : br_0_170 
* INOUT : bl_0_171 
* INOUT : br_0_171 
* INOUT : bl_0_172 
* INOUT : br_0_172 
* INOUT : bl_0_173 
* INOUT : br_0_173 
* INOUT : bl_0_174 
* INOUT : br_0_174 
* INOUT : bl_0_175 
* INOUT : br_0_175 
* INOUT : bl_0_176 
* INOUT : br_0_176 
* INOUT : bl_0_177 
* INOUT : br_0_177 
* INOUT : bl_0_178 
* INOUT : br_0_178 
* INOUT : bl_0_179 
* INOUT : br_0_179 
* INOUT : bl_0_180 
* INOUT : br_0_180 
* INOUT : bl_0_181 
* INOUT : br_0_181 
* INOUT : bl_0_182 
* INOUT : br_0_182 
* INOUT : bl_0_183 
* INOUT : br_0_183 
* INOUT : bl_0_184 
* INOUT : br_0_184 
* INOUT : bl_0_185 
* INOUT : br_0_185 
* INOUT : bl_0_186 
* INOUT : br_0_186 
* INOUT : bl_0_187 
* INOUT : br_0_187 
* INOUT : bl_0_188 
* INOUT : br_0_188 
* INOUT : bl_0_189 
* INOUT : br_0_189 
* INOUT : bl_0_190 
* INOUT : br_0_190 
* INOUT : bl_0_191 
* INOUT : br_0_191 
* INOUT : bl_0_192 
* INOUT : br_0_192 
* INPUT : rbl_wl_0_0 
* INPUT : wl_0_0 
* INPUT : wl_0_1 
* INPUT : wl_0_2 
* INPUT : wl_0_3 
* INPUT : wl_0_4 
* INPUT : wl_0_5 
* INPUT : wl_0_6 
* INPUT : wl_0_7 
* INPUT : wl_0_8 
* INPUT : wl_0_9 
* INPUT : wl_0_10 
* INPUT : wl_0_11 
* INPUT : wl_0_12 
* INPUT : wl_0_13 
* INPUT : wl_0_14 
* INPUT : wl_0_15 
* INPUT : wl_0_16 
* POWER : vdd 
* GROUND: gnd 
* rows: 17 cols: 193
* rbl: [1, 0] left_rbl: [0] right_rbl: []
Xreplica_bitcell_array
+ rbl_bl_0_0 rbl_br_0_0 bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3
+ br_0_3 bl_0_4 br_0_4 bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8
+ br_0_8 bl_0_9 br_0_9 bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12
+ bl_0_13 br_0_13 bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16
+ bl_0_17 br_0_17 bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20
+ bl_0_21 br_0_21 bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24
+ bl_0_25 br_0_25 bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28
+ bl_0_29 br_0_29 bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32
+ bl_0_33 br_0_33 bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36
+ bl_0_37 br_0_37 bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40
+ bl_0_41 br_0_41 bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44
+ bl_0_45 br_0_45 bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48
+ bl_0_49 br_0_49 bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52
+ bl_0_53 br_0_53 bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56
+ bl_0_57 br_0_57 bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60
+ bl_0_61 br_0_61 bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64
+ bl_0_65 br_0_65 bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68
+ bl_0_69 br_0_69 bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72
+ bl_0_73 br_0_73 bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76
+ bl_0_77 br_0_77 bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80
+ bl_0_81 br_0_81 bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84
+ bl_0_85 br_0_85 bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88
+ bl_0_89 br_0_89 bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92
+ bl_0_93 br_0_93 bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96
+ bl_0_97 br_0_97 bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100
+ bl_0_101 br_0_101 bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104
+ br_0_104 bl_0_105 br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107
+ bl_0_108 br_0_108 bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111
+ br_0_111 bl_0_112 br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114
+ bl_0_115 br_0_115 bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118
+ br_0_118 bl_0_119 br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121
+ bl_0_122 br_0_122 bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125
+ br_0_125 bl_0_126 br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128
+ bl_0_129 br_0_129 bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132
+ br_0_132 bl_0_133 br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135
+ bl_0_136 br_0_136 bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139
+ br_0_139 bl_0_140 br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142
+ bl_0_143 br_0_143 bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146
+ br_0_146 bl_0_147 br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149
+ bl_0_150 br_0_150 bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153
+ br_0_153 bl_0_154 br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156
+ bl_0_157 br_0_157 bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160
+ br_0_160 bl_0_161 br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163
+ bl_0_164 br_0_164 bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167
+ br_0_167 bl_0_168 br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170
+ bl_0_171 br_0_171 bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174
+ br_0_174 bl_0_175 br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177
+ bl_0_178 br_0_178 bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181
+ br_0_181 bl_0_182 br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184
+ bl_0_185 br_0_185 bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188
+ br_0_188 bl_0_189 br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191
+ bl_0_192 br_0_192 rbl_wl_0_0 wl_0_0 wl_0_1 wl_0_2 wl_0_3 wl_0_4 wl_0_5
+ wl_0_6 wl_0_7 wl_0_8 wl_0_9 wl_0_10 wl_0_11 wl_0_12 wl_0_13 wl_0_14
+ wl_0_15 wl_0_16 vdd gnd
+ sky130_sram_1rw_24x128_replica_bitcell_array
Xdummy_row_bot
+ rbl_bl_0_0 rbl_br_0_0 bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3
+ br_0_3 bl_0_4 br_0_4 bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8
+ br_0_8 bl_0_9 br_0_9 bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12
+ bl_0_13 br_0_13 bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16
+ bl_0_17 br_0_17 bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20
+ bl_0_21 br_0_21 bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24
+ bl_0_25 br_0_25 bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28
+ bl_0_29 br_0_29 bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32
+ bl_0_33 br_0_33 bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36
+ bl_0_37 br_0_37 bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40
+ bl_0_41 br_0_41 bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44
+ bl_0_45 br_0_45 bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48
+ bl_0_49 br_0_49 bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52
+ bl_0_53 br_0_53 bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56
+ bl_0_57 br_0_57 bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60
+ bl_0_61 br_0_61 bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64
+ bl_0_65 br_0_65 bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68
+ bl_0_69 br_0_69 bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72
+ bl_0_73 br_0_73 bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76
+ bl_0_77 br_0_77 bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80
+ bl_0_81 br_0_81 bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84
+ bl_0_85 br_0_85 bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88
+ bl_0_89 br_0_89 bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92
+ bl_0_93 br_0_93 bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96
+ bl_0_97 br_0_97 bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100
+ bl_0_101 br_0_101 bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104
+ br_0_104 bl_0_105 br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107
+ bl_0_108 br_0_108 bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111
+ br_0_111 bl_0_112 br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114
+ bl_0_115 br_0_115 bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118
+ br_0_118 bl_0_119 br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121
+ bl_0_122 br_0_122 bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125
+ br_0_125 bl_0_126 br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128
+ bl_0_129 br_0_129 bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132
+ br_0_132 bl_0_133 br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135
+ bl_0_136 br_0_136 bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139
+ br_0_139 bl_0_140 br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142
+ bl_0_143 br_0_143 bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146
+ br_0_146 bl_0_147 br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149
+ bl_0_150 br_0_150 bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153
+ br_0_153 bl_0_154 br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156
+ bl_0_157 br_0_157 bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160
+ br_0_160 bl_0_161 br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163
+ bl_0_164 br_0_164 bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167
+ br_0_167 bl_0_168 br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170
+ bl_0_171 br_0_171 bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174
+ br_0_174 bl_0_175 br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177
+ bl_0_178 br_0_178 bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181
+ br_0_181 bl_0_182 br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184
+ bl_0_185 br_0_185 bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188
+ br_0_188 bl_0_189 br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191
+ bl_0_192 br_0_192 gnd vdd gnd
+ sky130_sram_1rw_24x128_dummy_array_1
Xdummy_row_top
+ rbl_bl_0_0 rbl_br_0_0 bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3
+ br_0_3 bl_0_4 br_0_4 bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8
+ br_0_8 bl_0_9 br_0_9 bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12
+ bl_0_13 br_0_13 bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16
+ bl_0_17 br_0_17 bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20
+ bl_0_21 br_0_21 bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24
+ bl_0_25 br_0_25 bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28
+ bl_0_29 br_0_29 bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32
+ bl_0_33 br_0_33 bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36
+ bl_0_37 br_0_37 bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40
+ bl_0_41 br_0_41 bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44
+ bl_0_45 br_0_45 bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48
+ bl_0_49 br_0_49 bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52
+ bl_0_53 br_0_53 bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56
+ bl_0_57 br_0_57 bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60
+ bl_0_61 br_0_61 bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64
+ bl_0_65 br_0_65 bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68
+ bl_0_69 br_0_69 bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72
+ bl_0_73 br_0_73 bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76
+ bl_0_77 br_0_77 bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80
+ bl_0_81 br_0_81 bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84
+ bl_0_85 br_0_85 bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88
+ bl_0_89 br_0_89 bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92
+ bl_0_93 br_0_93 bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96
+ bl_0_97 br_0_97 bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100
+ bl_0_101 br_0_101 bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104
+ br_0_104 bl_0_105 br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107
+ bl_0_108 br_0_108 bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111
+ br_0_111 bl_0_112 br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114
+ bl_0_115 br_0_115 bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118
+ br_0_118 bl_0_119 br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121
+ bl_0_122 br_0_122 bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125
+ br_0_125 bl_0_126 br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128
+ bl_0_129 br_0_129 bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132
+ br_0_132 bl_0_133 br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135
+ bl_0_136 br_0_136 bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139
+ br_0_139 bl_0_140 br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142
+ bl_0_143 br_0_143 bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146
+ br_0_146 bl_0_147 br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149
+ bl_0_150 br_0_150 bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153
+ br_0_153 bl_0_154 br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156
+ bl_0_157 br_0_157 bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160
+ br_0_160 bl_0_161 br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163
+ bl_0_164 br_0_164 bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167
+ br_0_167 bl_0_168 br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170
+ bl_0_171 br_0_171 bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174
+ br_0_174 bl_0_175 br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177
+ bl_0_178 br_0_178 bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181
+ br_0_181 bl_0_182 br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184
+ bl_0_185 br_0_185 bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188
+ br_0_188 bl_0_189 br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191
+ bl_0_192 br_0_192 gnd vdd gnd
+ sky130_sram_1rw_24x128_dummy_array_0
Xdummy_col_left
+ dummy_left_bl_0_0 dummy_left_br_0_0 gnd rbl_wl_0_0 wl_0_0 wl_0_1
+ wl_0_2 wl_0_3 wl_0_4 wl_0_5 wl_0_6 wl_0_7 wl_0_8 wl_0_9 wl_0_10
+ wl_0_11 wl_0_12 wl_0_13 wl_0_14 wl_0_15 wl_0_16 gnd vdd gnd
+ sky130_sram_1rw_24x128_dummy_array_2
Xdummy_col_right
+ dummy_right_bl_0_0 dummy_right_br_0_0 gnd rbl_wl_0_0 wl_0_0 wl_0_1
+ wl_0_2 wl_0_3 wl_0_4 wl_0_5 wl_0_6 wl_0_7 wl_0_8 wl_0_9 wl_0_10
+ wl_0_11 wl_0_12 wl_0_13 wl_0_14 wl_0_15 wl_0_16 gnd vdd gnd
+ sky130_sram_1rw_24x128_dummy_array_3
.ENDS sky130_sram_1rw_24x128_capped_replica_bitcell_array
* NGSPICE file created from sky130_fd_bd_sram__openram_sp_custom_nand2_dec.ext - technology: sky130A

.subckt sky130_custom_nand2_dec A B Z VDD GND
X0 Z A VDD VDD sky130_fd_pr__pfet_01v8 w=1.12u l=0.15u
X1 VDD B Z VDD sky130_fd_pr__pfet_01v8 w=1.12u l=0.15u
X2 a_196_224# B GND GND sky130_fd_pr__nfet_01v8 w=0.74u l=0.15u
X3 Z A a_196_224# GND sky130_fd_pr__nfet_01v8 w=0.74u l=0.15u
.ends

* spice ptx X{0} {1} sky130_fd_pr__pfet_01v8 m=1 w=7.0 l=0.15 pd=14.30 ps=14.30 as=2.62u ad=2.62u

* spice ptx X{0} {1} sky130_fd_pr__nfet_01v8 m=1 w=7.0 l=0.15 pd=14.30 ps=14.30 as=2.62u ad=2.62u

.SUBCKT sky130_sram_1rw_24x128_pinv_dec_0
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 48
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=7.0 l=0.15 pd=14.30 ps=14.30 as=2.62u ad=2.62u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=1 w=7.0 l=0.15 pd=14.30 ps=14.30 as=2.62u ad=2.62u
.ENDS sky130_sram_1rw_24x128_pinv_dec_0

.SUBCKT sky130_sram_1rw_24x128_and2_dec_0
+ A B Z vdd gnd
* INPUT : A 
* INPUT : B 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 48
Xpand2_dec_nand
+ A B zb_int vdd gnd
+ sky130_custom_nand2_dec
Xpand2_dec_inv
+ zb_int Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_dec_0
.ENDS sky130_sram_1rw_24x128_and2_dec_0

.SUBCKT sky130_sram_1rw_24x128_wordline_driver
+ A B Z vdd gnd
* INPUT : A 
* INPUT : B 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* cols: 193
Xwld_nand
+ A B zb_int vdd gnd
+ sky130_custom_nand2_dec
Xwl_driver
+ zb_int Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_dec_0
.ENDS sky130_sram_1rw_24x128_wordline_driver

.SUBCKT sky130_sram_1rw_24x128_wordline_driver_array
+ in_0 in_1 in_2 in_3 in_4 in_5 in_6 in_7 in_8 in_9 in_10 in_11 in_12
+ in_13 in_14 in_15 in_16 wl_0 wl_1 wl_2 wl_3 wl_4 wl_5 wl_6 wl_7 wl_8
+ wl_9 wl_10 wl_11 wl_12 wl_13 wl_14 wl_15 wl_16 en vdd gnd
* INPUT : in_0 
* INPUT : in_1 
* INPUT : in_2 
* INPUT : in_3 
* INPUT : in_4 
* INPUT : in_5 
* INPUT : in_6 
* INPUT : in_7 
* INPUT : in_8 
* INPUT : in_9 
* INPUT : in_10 
* INPUT : in_11 
* INPUT : in_12 
* INPUT : in_13 
* INPUT : in_14 
* INPUT : in_15 
* INPUT : in_16 
* OUTPUT: wl_0 
* OUTPUT: wl_1 
* OUTPUT: wl_2 
* OUTPUT: wl_3 
* OUTPUT: wl_4 
* OUTPUT: wl_5 
* OUTPUT: wl_6 
* OUTPUT: wl_7 
* OUTPUT: wl_8 
* OUTPUT: wl_9 
* OUTPUT: wl_10 
* OUTPUT: wl_11 
* OUTPUT: wl_12 
* OUTPUT: wl_13 
* OUTPUT: wl_14 
* OUTPUT: wl_15 
* OUTPUT: wl_16 
* INPUT : en 
* POWER : vdd 
* GROUND: gnd 
* rows: 17 cols: 193
Xwl_driver_and0
+ in_0 en wl_0 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and1
+ in_1 en wl_1 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and2
+ in_2 en wl_2 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and3
+ in_3 en wl_3 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and4
+ in_4 en wl_4 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and5
+ in_5 en wl_5 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and6
+ in_6 en wl_6 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and7
+ in_7 en wl_7 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and8
+ in_8 en wl_8 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and9
+ in_9 en wl_9 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and10
+ in_10 en wl_10 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and11
+ in_11 en wl_11 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and12
+ in_12 en wl_12 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and13
+ in_13 en wl_13 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and14
+ in_14 en wl_14 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and15
+ in_15 en wl_15 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
Xwl_driver_and16
+ in_16 en wl_16 vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver
.ENDS sky130_sram_1rw_24x128_wordline_driver_array

.SUBCKT sky130_sram_1rw_24x128_pinv_dec
+ A Z vdd gnd
* INPUT : A 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpinv_pmos Z A vdd vdd sky130_fd_pr__pfet_01v8 m=1 w=1.12 l=0.15 pd=2.54 ps=2.54 as=0.42u ad=0.42u
Xpinv_nmos Z A gnd gnd sky130_fd_pr__nfet_01v8 m=1 w=0.36 l=0.15 pd=1.02 ps=1.02 as=0.14u ad=0.14u
.ENDS sky130_sram_1rw_24x128_pinv_dec

.SUBCKT sky130_sram_1rw_24x128_and2_dec
+ A B Z vdd gnd
* INPUT : A 
* INPUT : B 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpand2_dec_nand
+ A B zb_int vdd gnd
+ sky130_custom_nand2_dec
Xpand2_dec_inv
+ zb_int Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_dec
.ENDS sky130_sram_1rw_24x128_and2_dec
* Top level circuit sky130_fd_bd_sram__openram_sp_custom_nand3_dec
.subckt sky130_custom_nand3_dec A B C Z VDD GND

X1001 Z A a_n346_328# GND sky130_fd_pr__nfet_01v8 W=0.74u L=0.15u m=1
X1002 a_n346_256# C GND GND sky130_fd_pr__nfet_01v8 W=0.74u L=0.15u m=1
X1003 a_n346_328# B a_n346_256# GND sky130_fd_pr__nfet_01v8 W=0.74u L=0.15u m=1
X1000 Z B VDD VDD sky130_fd_pr__pfet_01v8 W=1.12u L=0.15u m=1
X1004 Z A VDD VDD sky130_fd_pr__pfet_01v8 W=1.12u L=0.15u m=1
X1005 Z C VDD VDD sky130_fd_pr__pfet_01v8 W=1.12u L=0.15u m=1
.ends


.SUBCKT sky130_sram_1rw_24x128_and3_dec
+ A B C Z vdd gnd
* INPUT : A 
* INPUT : B 
* INPUT : C 
* OUTPUT: Z 
* POWER : vdd 
* GROUND: gnd 
* size: 1
Xpand3_dec_nand
+ A B C zb_int vdd gnd
+ sky130_custom_nand3_dec
Xpand3_dec_inv
+ zb_int Z vdd gnd
+ sky130_sram_1rw_24x128_pinv_dec
.ENDS sky130_sram_1rw_24x128_and3_dec

.SUBCKT sky130_sram_1rw_24x128_hierarchical_predecode3x8
+ in_0 in_1 in_2 out_0 out_1 out_2 out_3 out_4 out_5 out_6 out_7 vdd gnd
* INPUT : in_0 
* INPUT : in_1 
* INPUT : in_2 
* OUTPUT: out_0 
* OUTPUT: out_1 
* OUTPUT: out_2 
* OUTPUT: out_3 
* OUTPUT: out_4 
* OUTPUT: out_5 
* OUTPUT: out_6 
* OUTPUT: out_7 
* POWER : vdd 
* GROUND: gnd 
Xpre_inv_0
+ in_0 inbar_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_dec
Xpre_inv_1
+ in_1 inbar_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_dec
Xpre_inv_2
+ in_2 inbar_2 vdd gnd
+ sky130_sram_1rw_24x128_pinv_dec
XXpre3x8_and_0
+ inbar_0 inbar_1 inbar_2 out_0 vdd gnd
+ sky130_sram_1rw_24x128_and3_dec
XXpre3x8_and_1
+ in_0 inbar_1 inbar_2 out_1 vdd gnd
+ sky130_sram_1rw_24x128_and3_dec
XXpre3x8_and_2
+ inbar_0 in_1 inbar_2 out_2 vdd gnd
+ sky130_sram_1rw_24x128_and3_dec
XXpre3x8_and_3
+ in_0 in_1 inbar_2 out_3 vdd gnd
+ sky130_sram_1rw_24x128_and3_dec
XXpre3x8_and_4
+ inbar_0 inbar_1 in_2 out_4 vdd gnd
+ sky130_sram_1rw_24x128_and3_dec
XXpre3x8_and_5
+ in_0 inbar_1 in_2 out_5 vdd gnd
+ sky130_sram_1rw_24x128_and3_dec
XXpre3x8_and_6
+ inbar_0 in_1 in_2 out_6 vdd gnd
+ sky130_sram_1rw_24x128_and3_dec
XXpre3x8_and_7
+ in_0 in_1 in_2 out_7 vdd gnd
+ sky130_sram_1rw_24x128_and3_dec
.ENDS sky130_sram_1rw_24x128_hierarchical_predecode3x8

.SUBCKT sky130_sram_1rw_24x128_hierarchical_predecode2x4
+ in_0 in_1 out_0 out_1 out_2 out_3 vdd gnd
* INPUT : in_0 
* INPUT : in_1 
* OUTPUT: out_0 
* OUTPUT: out_1 
* OUTPUT: out_2 
* OUTPUT: out_3 
* POWER : vdd 
* GROUND: gnd 
Xpre_inv_0
+ in_0 inbar_0 vdd gnd
+ sky130_sram_1rw_24x128_pinv_dec
Xpre_inv_1
+ in_1 inbar_1 vdd gnd
+ sky130_sram_1rw_24x128_pinv_dec
XXpre2x4_and_0
+ inbar_0 inbar_1 out_0 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XXpre2x4_and_1
+ in_0 inbar_1 out_1 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XXpre2x4_and_2
+ inbar_0 in_1 out_2 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XXpre2x4_and_3
+ in_0 in_1 out_3 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
.ENDS sky130_sram_1rw_24x128_hierarchical_predecode2x4

.SUBCKT sky130_sram_1rw_24x128_hierarchical_decoder
+ addr_0 addr_1 addr_2 addr_3 addr_4 decode_0 decode_1 decode_2 decode_3
+ decode_4 decode_5 decode_6 decode_7 decode_8 decode_9 decode_10
+ decode_11 decode_12 decode_13 decode_14 decode_15 decode_16 vdd gnd
* INPUT : addr_0 
* INPUT : addr_1 
* INPUT : addr_2 
* INPUT : addr_3 
* INPUT : addr_4 
* OUTPUT: decode_0 
* OUTPUT: decode_1 
* OUTPUT: decode_2 
* OUTPUT: decode_3 
* OUTPUT: decode_4 
* OUTPUT: decode_5 
* OUTPUT: decode_6 
* OUTPUT: decode_7 
* OUTPUT: decode_8 
* OUTPUT: decode_9 
* OUTPUT: decode_10 
* OUTPUT: decode_11 
* OUTPUT: decode_12 
* OUTPUT: decode_13 
* OUTPUT: decode_14 
* OUTPUT: decode_15 
* OUTPUT: decode_16 
* POWER : vdd 
* GROUND: gnd 
Xpre_0
+ addr_0 addr_1 out_0 out_1 out_2 out_3 vdd gnd
+ sky130_sram_1rw_24x128_hierarchical_predecode2x4
Xpre3x8_0
+ addr_2 addr_3 addr_4 out_4 out_5 out_6 out_7 out_8 out_9 out_10 out_11
+ vdd gnd
+ sky130_sram_1rw_24x128_hierarchical_predecode3x8
XDEC_AND_0
+ out_0 out_4 decode_0 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_4
+ out_0 out_5 decode_4 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_8
+ out_0 out_6 decode_8 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_12
+ out_0 out_7 decode_12 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_16
+ out_0 out_8 decode_16 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_1
+ out_1 out_4 decode_1 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_5
+ out_1 out_5 decode_5 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_9
+ out_1 out_6 decode_9 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_13
+ out_1 out_7 decode_13 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_2
+ out_2 out_4 decode_2 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_6
+ out_2 out_5 decode_6 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_10
+ out_2 out_6 decode_10 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_14
+ out_2 out_7 decode_14 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_3
+ out_3 out_4 decode_3 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_7
+ out_3 out_5 decode_7 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_11
+ out_3 out_6 decode_11 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
XDEC_AND_15
+ out_3 out_7 decode_15 vdd gnd
+ sky130_sram_1rw_24x128_and2_dec
.ENDS sky130_sram_1rw_24x128_hierarchical_decoder

.SUBCKT sky130_sram_1rw_24x128_port_address
+ addr_0 addr_1 addr_2 addr_3 addr_4 wl_en wl_0 wl_1 wl_2 wl_3 wl_4 wl_5
+ wl_6 wl_7 wl_8 wl_9 wl_10 wl_11 wl_12 wl_13 wl_14 wl_15 wl_16 rbl_wl
+ vdd gnd
* INPUT : addr_0 
* INPUT : addr_1 
* INPUT : addr_2 
* INPUT : addr_3 
* INPUT : addr_4 
* INPUT : wl_en 
* OUTPUT: wl_0 
* OUTPUT: wl_1 
* OUTPUT: wl_2 
* OUTPUT: wl_3 
* OUTPUT: wl_4 
* OUTPUT: wl_5 
* OUTPUT: wl_6 
* OUTPUT: wl_7 
* OUTPUT: wl_8 
* OUTPUT: wl_9 
* OUTPUT: wl_10 
* OUTPUT: wl_11 
* OUTPUT: wl_12 
* OUTPUT: wl_13 
* OUTPUT: wl_14 
* OUTPUT: wl_15 
* OUTPUT: wl_16 
* OUTPUT: rbl_wl 
* POWER : vdd 
* GROUND: gnd 
Xrow_decoder
+ addr_0 addr_1 addr_2 addr_3 addr_4 dec_out_0 dec_out_1 dec_out_2
+ dec_out_3 dec_out_4 dec_out_5 dec_out_6 dec_out_7 dec_out_8 dec_out_9
+ dec_out_10 dec_out_11 dec_out_12 dec_out_13 dec_out_14 dec_out_15
+ dec_out_16 vdd gnd
+ sky130_sram_1rw_24x128_hierarchical_decoder
Xwordline_driver
+ dec_out_0 dec_out_1 dec_out_2 dec_out_3 dec_out_4 dec_out_5 dec_out_6
+ dec_out_7 dec_out_8 dec_out_9 dec_out_10 dec_out_11 dec_out_12
+ dec_out_13 dec_out_14 dec_out_15 dec_out_16 wl_0 wl_1 wl_2 wl_3 wl_4
+ wl_5 wl_6 wl_7 wl_8 wl_9 wl_10 wl_11 wl_12 wl_13 wl_14 wl_15 wl_16
+ wl_en vdd gnd
+ sky130_sram_1rw_24x128_wordline_driver_array
Xrbl_driver
+ wl_en vdd rbl_wl vdd gnd
+ sky130_sram_1rw_24x128_and2_dec_0
.ENDS sky130_sram_1rw_24x128_port_address

.SUBCKT sky130_sram_1rw_24x128_bank
+ dout0_0 dout0_1 dout0_2 dout0_3 dout0_4 dout0_5 dout0_6 dout0_7
+ dout0_8 dout0_9 dout0_10 dout0_11 dout0_12 dout0_13 dout0_14 dout0_15
+ dout0_16 dout0_17 dout0_18 dout0_19 dout0_20 dout0_21 dout0_22
+ dout0_23 dout0_24 rbl_bl_0_0 din0_0 din0_1 din0_2 din0_3 din0_4 din0_5
+ din0_6 din0_7 din0_8 din0_9 din0_10 din0_11 din0_12 din0_13 din0_14
+ din0_15 din0_16 din0_17 din0_18 din0_19 din0_20 din0_21 din0_22
+ din0_23 din0_24 addr0_0 addr0_1 addr0_2 addr0_3 addr0_4 addr0_5
+ addr0_6 addr0_7 s_en0 p_en_bar0 w_en0 bank_wmask0_0 bank_wmask0_1
+ bank_wmask0_2 bank_spare_wen0_0 wl_en0 vdd gnd
* OUTPUT: dout0_0 
* OUTPUT: dout0_1 
* OUTPUT: dout0_2 
* OUTPUT: dout0_3 
* OUTPUT: dout0_4 
* OUTPUT: dout0_5 
* OUTPUT: dout0_6 
* OUTPUT: dout0_7 
* OUTPUT: dout0_8 
* OUTPUT: dout0_9 
* OUTPUT: dout0_10 
* OUTPUT: dout0_11 
* OUTPUT: dout0_12 
* OUTPUT: dout0_13 
* OUTPUT: dout0_14 
* OUTPUT: dout0_15 
* OUTPUT: dout0_16 
* OUTPUT: dout0_17 
* OUTPUT: dout0_18 
* OUTPUT: dout0_19 
* OUTPUT: dout0_20 
* OUTPUT: dout0_21 
* OUTPUT: dout0_22 
* OUTPUT: dout0_23 
* OUTPUT: dout0_24 
* OUTPUT: rbl_bl_0_0 
* INPUT : din0_0 
* INPUT : din0_1 
* INPUT : din0_2 
* INPUT : din0_3 
* INPUT : din0_4 
* INPUT : din0_5 
* INPUT : din0_6 
* INPUT : din0_7 
* INPUT : din0_8 
* INPUT : din0_9 
* INPUT : din0_10 
* INPUT : din0_11 
* INPUT : din0_12 
* INPUT : din0_13 
* INPUT : din0_14 
* INPUT : din0_15 
* INPUT : din0_16 
* INPUT : din0_17 
* INPUT : din0_18 
* INPUT : din0_19 
* INPUT : din0_20 
* INPUT : din0_21 
* INPUT : din0_22 
* INPUT : din0_23 
* INPUT : din0_24 
* INPUT : addr0_0 
* INPUT : addr0_1 
* INPUT : addr0_2 
* INPUT : addr0_3 
* INPUT : addr0_4 
* INPUT : addr0_5 
* INPUT : addr0_6 
* INPUT : addr0_7 
* INPUT : s_en0 
* INPUT : p_en_bar0 
* INPUT : w_en0 
* INPUT : bank_wmask0_0 
* INPUT : bank_wmask0_1 
* INPUT : bank_wmask0_2 
* INPUT : bank_spare_wen0_0 
* INPUT : wl_en0 
* POWER : vdd 
* GROUND: gnd 
Xbitcell_array
+ rbl_bl_0_0 rbl_br_0_0 bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3
+ br_0_3 bl_0_4 br_0_4 bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8
+ br_0_8 bl_0_9 br_0_9 bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12
+ bl_0_13 br_0_13 bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16
+ bl_0_17 br_0_17 bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20
+ bl_0_21 br_0_21 bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24
+ bl_0_25 br_0_25 bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28
+ bl_0_29 br_0_29 bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32
+ bl_0_33 br_0_33 bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36
+ bl_0_37 br_0_37 bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40
+ bl_0_41 br_0_41 bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44
+ bl_0_45 br_0_45 bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48
+ bl_0_49 br_0_49 bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52
+ bl_0_53 br_0_53 bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56
+ bl_0_57 br_0_57 bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60
+ bl_0_61 br_0_61 bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64
+ bl_0_65 br_0_65 bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68
+ bl_0_69 br_0_69 bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72
+ bl_0_73 br_0_73 bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76
+ bl_0_77 br_0_77 bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80
+ bl_0_81 br_0_81 bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84
+ bl_0_85 br_0_85 bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88
+ bl_0_89 br_0_89 bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92
+ bl_0_93 br_0_93 bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96
+ bl_0_97 br_0_97 bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100
+ bl_0_101 br_0_101 bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104
+ br_0_104 bl_0_105 br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107
+ bl_0_108 br_0_108 bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111
+ br_0_111 bl_0_112 br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114
+ bl_0_115 br_0_115 bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118
+ br_0_118 bl_0_119 br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121
+ bl_0_122 br_0_122 bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125
+ br_0_125 bl_0_126 br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128
+ bl_0_129 br_0_129 bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132
+ br_0_132 bl_0_133 br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135
+ bl_0_136 br_0_136 bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139
+ br_0_139 bl_0_140 br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142
+ bl_0_143 br_0_143 bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146
+ br_0_146 bl_0_147 br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149
+ bl_0_150 br_0_150 bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153
+ br_0_153 bl_0_154 br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156
+ bl_0_157 br_0_157 bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160
+ br_0_160 bl_0_161 br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163
+ bl_0_164 br_0_164 bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167
+ br_0_167 bl_0_168 br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170
+ bl_0_171 br_0_171 bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174
+ br_0_174 bl_0_175 br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177
+ bl_0_178 br_0_178 bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181
+ br_0_181 bl_0_182 br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184
+ bl_0_185 br_0_185 bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188
+ br_0_188 bl_0_189 br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191
+ bl_0_192 br_0_192 rbl_wl0 wl_0_0 wl_0_1 wl_0_2 wl_0_3 wl_0_4 wl_0_5
+ wl_0_6 wl_0_7 wl_0_8 wl_0_9 wl_0_10 wl_0_11 wl_0_12 wl_0_13 wl_0_14
+ wl_0_15 wl_0_16 vdd gnd
+ sky130_sram_1rw_24x128_capped_replica_bitcell_array
Xport_data0
+ rbl_bl_0_0 rbl_br_0_0 bl_0_0 br_0_0 bl_0_1 br_0_1 bl_0_2 br_0_2 bl_0_3
+ br_0_3 bl_0_4 br_0_4 bl_0_5 br_0_5 bl_0_6 br_0_6 bl_0_7 br_0_7 bl_0_8
+ br_0_8 bl_0_9 br_0_9 bl_0_10 br_0_10 bl_0_11 br_0_11 bl_0_12 br_0_12
+ bl_0_13 br_0_13 bl_0_14 br_0_14 bl_0_15 br_0_15 bl_0_16 br_0_16
+ bl_0_17 br_0_17 bl_0_18 br_0_18 bl_0_19 br_0_19 bl_0_20 br_0_20
+ bl_0_21 br_0_21 bl_0_22 br_0_22 bl_0_23 br_0_23 bl_0_24 br_0_24
+ bl_0_25 br_0_25 bl_0_26 br_0_26 bl_0_27 br_0_27 bl_0_28 br_0_28
+ bl_0_29 br_0_29 bl_0_30 br_0_30 bl_0_31 br_0_31 bl_0_32 br_0_32
+ bl_0_33 br_0_33 bl_0_34 br_0_34 bl_0_35 br_0_35 bl_0_36 br_0_36
+ bl_0_37 br_0_37 bl_0_38 br_0_38 bl_0_39 br_0_39 bl_0_40 br_0_40
+ bl_0_41 br_0_41 bl_0_42 br_0_42 bl_0_43 br_0_43 bl_0_44 br_0_44
+ bl_0_45 br_0_45 bl_0_46 br_0_46 bl_0_47 br_0_47 bl_0_48 br_0_48
+ bl_0_49 br_0_49 bl_0_50 br_0_50 bl_0_51 br_0_51 bl_0_52 br_0_52
+ bl_0_53 br_0_53 bl_0_54 br_0_54 bl_0_55 br_0_55 bl_0_56 br_0_56
+ bl_0_57 br_0_57 bl_0_58 br_0_58 bl_0_59 br_0_59 bl_0_60 br_0_60
+ bl_0_61 br_0_61 bl_0_62 br_0_62 bl_0_63 br_0_63 bl_0_64 br_0_64
+ bl_0_65 br_0_65 bl_0_66 br_0_66 bl_0_67 br_0_67 bl_0_68 br_0_68
+ bl_0_69 br_0_69 bl_0_70 br_0_70 bl_0_71 br_0_71 bl_0_72 br_0_72
+ bl_0_73 br_0_73 bl_0_74 br_0_74 bl_0_75 br_0_75 bl_0_76 br_0_76
+ bl_0_77 br_0_77 bl_0_78 br_0_78 bl_0_79 br_0_79 bl_0_80 br_0_80
+ bl_0_81 br_0_81 bl_0_82 br_0_82 bl_0_83 br_0_83 bl_0_84 br_0_84
+ bl_0_85 br_0_85 bl_0_86 br_0_86 bl_0_87 br_0_87 bl_0_88 br_0_88
+ bl_0_89 br_0_89 bl_0_90 br_0_90 bl_0_91 br_0_91 bl_0_92 br_0_92
+ bl_0_93 br_0_93 bl_0_94 br_0_94 bl_0_95 br_0_95 bl_0_96 br_0_96
+ bl_0_97 br_0_97 bl_0_98 br_0_98 bl_0_99 br_0_99 bl_0_100 br_0_100
+ bl_0_101 br_0_101 bl_0_102 br_0_102 bl_0_103 br_0_103 bl_0_104
+ br_0_104 bl_0_105 br_0_105 bl_0_106 br_0_106 bl_0_107 br_0_107
+ bl_0_108 br_0_108 bl_0_109 br_0_109 bl_0_110 br_0_110 bl_0_111
+ br_0_111 bl_0_112 br_0_112 bl_0_113 br_0_113 bl_0_114 br_0_114
+ bl_0_115 br_0_115 bl_0_116 br_0_116 bl_0_117 br_0_117 bl_0_118
+ br_0_118 bl_0_119 br_0_119 bl_0_120 br_0_120 bl_0_121 br_0_121
+ bl_0_122 br_0_122 bl_0_123 br_0_123 bl_0_124 br_0_124 bl_0_125
+ br_0_125 bl_0_126 br_0_126 bl_0_127 br_0_127 bl_0_128 br_0_128
+ bl_0_129 br_0_129 bl_0_130 br_0_130 bl_0_131 br_0_131 bl_0_132
+ br_0_132 bl_0_133 br_0_133 bl_0_134 br_0_134 bl_0_135 br_0_135
+ bl_0_136 br_0_136 bl_0_137 br_0_137 bl_0_138 br_0_138 bl_0_139
+ br_0_139 bl_0_140 br_0_140 bl_0_141 br_0_141 bl_0_142 br_0_142
+ bl_0_143 br_0_143 bl_0_144 br_0_144 bl_0_145 br_0_145 bl_0_146
+ br_0_146 bl_0_147 br_0_147 bl_0_148 br_0_148 bl_0_149 br_0_149
+ bl_0_150 br_0_150 bl_0_151 br_0_151 bl_0_152 br_0_152 bl_0_153
+ br_0_153 bl_0_154 br_0_154 bl_0_155 br_0_155 bl_0_156 br_0_156
+ bl_0_157 br_0_157 bl_0_158 br_0_158 bl_0_159 br_0_159 bl_0_160
+ br_0_160 bl_0_161 br_0_161 bl_0_162 br_0_162 bl_0_163 br_0_163
+ bl_0_164 br_0_164 bl_0_165 br_0_165 bl_0_166 br_0_166 bl_0_167
+ br_0_167 bl_0_168 br_0_168 bl_0_169 br_0_169 bl_0_170 br_0_170
+ bl_0_171 br_0_171 bl_0_172 br_0_172 bl_0_173 br_0_173 bl_0_174
+ br_0_174 bl_0_175 br_0_175 bl_0_176 br_0_176 bl_0_177 br_0_177
+ bl_0_178 br_0_178 bl_0_179 br_0_179 bl_0_180 br_0_180 bl_0_181
+ br_0_181 bl_0_182 br_0_182 bl_0_183 br_0_183 bl_0_184 br_0_184
+ bl_0_185 br_0_185 bl_0_186 br_0_186 bl_0_187 br_0_187 bl_0_188
+ br_0_188 bl_0_189 br_0_189 bl_0_190 br_0_190 bl_0_191 br_0_191
+ bl_0_192 br_0_192 dout0_0 dout0_1 dout0_2 dout0_3 dout0_4 dout0_5
+ dout0_6 dout0_7 dout0_8 dout0_9 dout0_10 dout0_11 dout0_12 dout0_13
+ dout0_14 dout0_15 dout0_16 dout0_17 dout0_18 dout0_19 dout0_20
+ dout0_21 dout0_22 dout0_23 dout0_24 din0_0 din0_1 din0_2 din0_3 din0_4
+ din0_5 din0_6 din0_7 din0_8 din0_9 din0_10 din0_11 din0_12 din0_13
+ din0_14 din0_15 din0_16 din0_17 din0_18 din0_19 din0_20 din0_21
+ din0_22 din0_23 din0_24 sel0_0 sel0_1 sel0_2 sel0_3 sel0_4 sel0_5
+ sel0_6 sel0_7 s_en0 p_en_bar0 w_en0 bank_wmask0_0 bank_wmask0_1
+ bank_wmask0_2 bank_spare_wen0_0 vdd gnd
+ sky130_sram_1rw_24x128_port_data
Xport_address0
+ addr0_3 addr0_4 addr0_5 addr0_6 addr0_7 wl_en0 wl_0_0 wl_0_1 wl_0_2
+ wl_0_3 wl_0_4 wl_0_5 wl_0_6 wl_0_7 wl_0_8 wl_0_9 wl_0_10 wl_0_11
+ wl_0_12 wl_0_13 wl_0_14 wl_0_15 wl_0_16 rbl_wl0 vdd gnd
+ sky130_sram_1rw_24x128_port_address
Xcol_address_decoder0
+ addr0_0 addr0_1 addr0_2 sel0_0 sel0_1 sel0_2 sel0_3 sel0_4 sel0_5
+ sel0_6 sel0_7 vdd gnd
+ sky130_sram_1rw_24x128_column_decoder
.ENDS sky130_sram_1rw_24x128_bank

.SUBCKT sky130_sram_1rw_24x128_col_addr_dff
+ din_0 din_1 din_2 dout_0 dout_1 dout_2 clk vdd gnd
* INPUT : din_0 
* INPUT : din_1 
* INPUT : din_2 
* OUTPUT: dout_0 
* OUTPUT: dout_1 
* OUTPUT: dout_2 
* INPUT : clk 
* POWER : vdd 
* GROUND: gnd 
* rows: 1 cols: 3
Xdff_r0_c0
+ din_0 dout_0 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c1
+ din_1 dout_1 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c2
+ din_2 dout_2 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
.ENDS sky130_sram_1rw_24x128_col_addr_dff

.SUBCKT sky130_sram_1rw_24x128_data_dff
+ din_0 din_1 din_2 din_3 din_4 din_5 din_6 din_7 din_8 din_9 din_10
+ din_11 din_12 din_13 din_14 din_15 din_16 din_17 din_18 din_19 din_20
+ din_21 din_22 din_23 din_24 dout_0 dout_1 dout_2 dout_3 dout_4 dout_5
+ dout_6 dout_7 dout_8 dout_9 dout_10 dout_11 dout_12 dout_13 dout_14
+ dout_15 dout_16 dout_17 dout_18 dout_19 dout_20 dout_21 dout_22
+ dout_23 dout_24 clk vdd gnd
* INPUT : din_0 
* INPUT : din_1 
* INPUT : din_2 
* INPUT : din_3 
* INPUT : din_4 
* INPUT : din_5 
* INPUT : din_6 
* INPUT : din_7 
* INPUT : din_8 
* INPUT : din_9 
* INPUT : din_10 
* INPUT : din_11 
* INPUT : din_12 
* INPUT : din_13 
* INPUT : din_14 
* INPUT : din_15 
* INPUT : din_16 
* INPUT : din_17 
* INPUT : din_18 
* INPUT : din_19 
* INPUT : din_20 
* INPUT : din_21 
* INPUT : din_22 
* INPUT : din_23 
* INPUT : din_24 
* OUTPUT: dout_0 
* OUTPUT: dout_1 
* OUTPUT: dout_2 
* OUTPUT: dout_3 
* OUTPUT: dout_4 
* OUTPUT: dout_5 
* OUTPUT: dout_6 
* OUTPUT: dout_7 
* OUTPUT: dout_8 
* OUTPUT: dout_9 
* OUTPUT: dout_10 
* OUTPUT: dout_11 
* OUTPUT: dout_12 
* OUTPUT: dout_13 
* OUTPUT: dout_14 
* OUTPUT: dout_15 
* OUTPUT: dout_16 
* OUTPUT: dout_17 
* OUTPUT: dout_18 
* OUTPUT: dout_19 
* OUTPUT: dout_20 
* OUTPUT: dout_21 
* OUTPUT: dout_22 
* OUTPUT: dout_23 
* OUTPUT: dout_24 
* INPUT : clk 
* POWER : vdd 
* GROUND: gnd 
* rows: 1 cols: 25
Xdff_r0_c0
+ din_0 dout_0 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c1
+ din_1 dout_1 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c2
+ din_2 dout_2 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c3
+ din_3 dout_3 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c4
+ din_4 dout_4 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c5
+ din_5 dout_5 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c6
+ din_6 dout_6 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c7
+ din_7 dout_7 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c8
+ din_8 dout_8 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c9
+ din_9 dout_9 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c10
+ din_10 dout_10 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c11
+ din_11 dout_11 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c12
+ din_12 dout_12 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c13
+ din_13 dout_13 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c14
+ din_14 dout_14 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c15
+ din_15 dout_15 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c16
+ din_16 dout_16 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c17
+ din_17 dout_17 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c18
+ din_18 dout_18 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c19
+ din_19 dout_19 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c20
+ din_20 dout_20 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c21
+ din_21 dout_21 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c22
+ din_22 dout_22 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c23
+ din_23 dout_23 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
Xdff_r0_c24
+ din_24 dout_24 CLK VDD GND
+ sky130_fd_bd_sram__openram_dff
.ENDS sky130_sram_1rw_24x128_data_dff

.SUBCKT sky130_sram_1rw_24x128
+ din0[0] din0[1] din0[2] din0[3] din0[4] din0[5] din0[6] din0[7]
+ din0[8] din0[9] din0[10] din0[11] din0[12] din0[13] din0[14] din0[15]
+ din0[16] din0[17] din0[18] din0[19] din0[20] din0[21] din0[22]
+ din0[23] din0[24] addr0[0] addr0[1] addr0[2] addr0[3] addr0[4]
+ addr0[5] addr0[6] addr0[7] csb0 web0 clk0 wmask0[0] wmask0[1]
+ wmask0[2] spare_wen0 dout0[0] dout0[1] dout0[2] dout0[3] dout0[4]
+ dout0[5] dout0[6] dout0[7] dout0[8] dout0[9] dout0[10] dout0[11]
+ dout0[12] dout0[13] dout0[14] dout0[15] dout0[16] dout0[17] dout0[18]
+ dout0[19] dout0[20] dout0[21] dout0[22] dout0[23] dout0[24] vccd1
+ vssd1
* INPUT : din0[0] 
* INPUT : din0[1] 
* INPUT : din0[2] 
* INPUT : din0[3] 
* INPUT : din0[4] 
* INPUT : din0[5] 
* INPUT : din0[6] 
* INPUT : din0[7] 
* INPUT : din0[8] 
* INPUT : din0[9] 
* INPUT : din0[10] 
* INPUT : din0[11] 
* INPUT : din0[12] 
* INPUT : din0[13] 
* INPUT : din0[14] 
* INPUT : din0[15] 
* INPUT : din0[16] 
* INPUT : din0[17] 
* INPUT : din0[18] 
* INPUT : din0[19] 
* INPUT : din0[20] 
* INPUT : din0[21] 
* INPUT : din0[22] 
* INPUT : din0[23] 
* INPUT : din0[24] 
* INPUT : addr0[0] 
* INPUT : addr0[1] 
* INPUT : addr0[2] 
* INPUT : addr0[3] 
* INPUT : addr0[4] 
* INPUT : addr0[5] 
* INPUT : addr0[6] 
* INPUT : addr0[7] 
* INPUT : csb0 
* INPUT : web0 
* INPUT : clk0 
* INPUT : wmask0[0] 
* INPUT : wmask0[1] 
* INPUT : wmask0[2] 
* INPUT : spare_wen0 
* OUTPUT: dout0[0] 
* OUTPUT: dout0[1] 
* OUTPUT: dout0[2] 
* OUTPUT: dout0[3] 
* OUTPUT: dout0[4] 
* OUTPUT: dout0[5] 
* OUTPUT: dout0[6] 
* OUTPUT: dout0[7] 
* OUTPUT: dout0[8] 
* OUTPUT: dout0[9] 
* OUTPUT: dout0[10] 
* OUTPUT: dout0[11] 
* OUTPUT: dout0[12] 
* OUTPUT: dout0[13] 
* OUTPUT: dout0[14] 
* OUTPUT: dout0[15] 
* OUTPUT: dout0[16] 
* OUTPUT: dout0[17] 
* OUTPUT: dout0[18] 
* OUTPUT: dout0[19] 
* OUTPUT: dout0[20] 
* OUTPUT: dout0[21] 
* OUTPUT: dout0[22] 
* OUTPUT: dout0[23] 
* OUTPUT: dout0[24] 
* POWER : vccd1 
* GROUND: vssd1 
Xbank0
+ dout0[0] dout0[1] dout0[2] dout0[3] dout0[4] dout0[5] dout0[6]
+ dout0[7] dout0[8] dout0[9] dout0[10] dout0[11] dout0[12] dout0[13]
+ dout0[14] dout0[15] dout0[16] dout0[17] dout0[18] dout0[19] dout0[20]
+ dout0[21] dout0[22] dout0[23] dout0[24] rbl_bl0 bank_din0_0
+ bank_din0_1 bank_din0_2 bank_din0_3 bank_din0_4 bank_din0_5
+ bank_din0_6 bank_din0_7 bank_din0_8 bank_din0_9 bank_din0_10
+ bank_din0_11 bank_din0_12 bank_din0_13 bank_din0_14 bank_din0_15
+ bank_din0_16 bank_din0_17 bank_din0_18 bank_din0_19 bank_din0_20
+ bank_din0_21 bank_din0_22 bank_din0_23 bank_din0_24 a0_0 a0_1 a0_2
+ a0_3 a0_4 a0_5 a0_6 a0_7 s_en0 p_en_bar0 w_en0 bank_wmask0_0
+ bank_wmask0_1 bank_wmask0_2 bank_spare_wen0_0 wl_en0 vccd1 vssd1
+ sky130_sram_1rw_24x128_bank
Xcontrol0
+ csb0 web0 clk0 rbl_bl0 s_en0 w_en0 p_en_bar0 wl_en0 clk_buf0 vccd1
+ vssd1
+ sky130_sram_1rw_24x128_control_logic_rw
Xrow_address0
+ addr0[3] addr0[4] addr0[5] addr0[6] addr0[7] a0_3 a0_4 a0_5 a0_6 a0_7
+ clk_buf0 vccd1 vssd1
+ sky130_sram_1rw_24x128_row_addr_dff
Xcol_address0
+ addr0[0] addr0[1] addr0[2] a0_0 a0_1 a0_2 clk_buf0 vccd1 vssd1
+ sky130_sram_1rw_24x128_col_addr_dff
Xwmask_dff0
+ wmask0[0] wmask0[1] wmask0[2] bank_wmask0_0 bank_wmask0_1
+ bank_wmask0_2 clk_buf0 vccd1 vssd1
+ sky130_sram_1rw_24x128_col_addr_dff
Xdata_dff0
+ din0[0] din0[1] din0[2] din0[3] din0[4] din0[5] din0[6] din0[7]
+ din0[8] din0[9] din0[10] din0[11] din0[12] din0[13] din0[14] din0[15]
+ din0[16] din0[17] din0[18] din0[19] din0[20] din0[21] din0[22]
+ din0[23] din0[24] bank_din0_0 bank_din0_1 bank_din0_2 bank_din0_3
+ bank_din0_4 bank_din0_5 bank_din0_6 bank_din0_7 bank_din0_8
+ bank_din0_9 bank_din0_10 bank_din0_11 bank_din0_12 bank_din0_13
+ bank_din0_14 bank_din0_15 bank_din0_16 bank_din0_17 bank_din0_18
+ bank_din0_19 bank_din0_20 bank_din0_21 bank_din0_22 bank_din0_23
+ bank_din0_24 clk_buf0 vccd1 vssd1
+ sky130_sram_1rw_24x128_data_dff
Xspare_wen_dff0
+ spare_wen0 bank_spare_wen0_0 clk_buf0 vccd1 vssd1
+ sky130_sram_1rw_24x128_spare_wen_dff
.ENDS sky130_sram_1rw_24x128
