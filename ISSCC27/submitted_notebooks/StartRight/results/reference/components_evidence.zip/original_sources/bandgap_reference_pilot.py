"""Private mechanism pilot; ideal-bias characterization precedes a real loop."""
from pathlib import Path
import concurrent.futures,datetime,hashlib,json,os,re,subprocess,sys,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];PUBLIC=ROOT/'applicability_candidate/ISSCC27/submitted_notebooks/StartRight'
OUT=ROOT/'research_artifacts/bandgap_sensing_20261019'
os.environ['STARTRIGHT_PDK']=str(ROOT/'tools/sky130_fd_pr');os.environ['STARTRIGHT_NGSPICE']=str(ROOT/'tools/ngspice/Spice64/bin/ngspice_con.exe')
sys.path.insert(0,str(PUBLIC))
import pilot
from por_models import PR as HV,verify_sources
sha=lambda b:hashlib.sha256(b).hexdigest()
PNP=OUT/'upstream/sky130_fd_pr/cells/pnp_05v5'
NONFET=OUT/'upstream/sky130_fd_pr/models/corners/tt/nonfet.spice'
SOURCE=OUT/'upstream/2AMLogic/sky130-bandgap/reference_with_injector.spice'
TEMPERATURES=(-40,27,125);CURRENTS=(.1,1.,5.)

def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False),encoding='utf-8')

def provenance():
    manifest=json.loads((OUT/'source_manifest.json').read_text(encoding='utf-8'));rows=[]
    for item in manifest['files']:
        data=(OUT/item['path']).read_bytes();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        assert blob==item['sha'],item['path'];rows.append(dict(**item,bytes=len(data),sha256=sha(data)))
    return dict(source_commit=manifest['source_commit'],pdk_commit=manifest['pdk_commit'],files=rows,published_POR_model_sources=verify_sources(),ngspice_sha256=sha(pilot.EXE.read_bytes()))

def model_text(high_voltage=False):
    text=pilot.models()+'\n'+f'.include "{NONFET.as_posix()}"\n'
    for size in ('W0p68L0p68','W3p40L3p40'):
        text+=f'.include "{(PNP/("sky130_fd_pr__pnp_05v5_"+size+".model.spice")).as_posix()}"\n'
    if high_voltage:
        for kind in ('nfet','pfet'):
            name=kind+'_g5v0d10v5'
            for suffix in ('tt.corner','mismatch.corner'):
                text+=f'.include "{(HV/"cells"/name/("sky130_fd_pr__"+name+"__"+suffix+".spice")).as_posix()}"\n'
    return text

def char_deck(current_uA,temp_C):
    assert current_uA in CURRENTS and temp_C in TEMPERATURES
    current=current_uA*1e-6*(temp_C+273.15)/300.15
    return 'PNP mechanism characterization with explicit ideal PTAT current fixtures\n'+model_text()+f'''
.temp {temp_C}
.option reltol=1e-7 abstol=1e-15 vntol=1e-7 gmin=1e-15
VAVDD vdd 0 3.3
I1 vdd e1 {current:.17g}
I8 vdd e8 {current:.17g}
XQ1 0 0 e1 0 sky130_fd_pr__pnp_05v5_W3p40L3p40
XQ8 0 0 e8 0 sky130_fd_pr__pnp_05v5_W3p40L3p40 m=8 mult=8
.control
set numdgt=17
set wr_singlescale
set wr_vecnames
op
wrdata characterization.dat v(e1) v(e8) i(VAVDD)
quit
.endc
.end
'''

def run_characterization(job):
    current,temp=job;p=OUT/'characterization'/f'{current:g}uA_{temp}';p.mkdir(exist_ok=False)
    text=char_deck(*job);(p/'input.cir').write_text(text,encoding='utf-8');(p/'.spiceinit').write_text('set ngbehavior=hsa\noption sparse\nset num_threads=1\n')
    r=dict(status='in_progress',nominal_current_uA=current,temp_C=temp,script_sha256=sha(Path(__file__).read_bytes()),deck_sha256=sha(text.encode()));save(p/'run.json',r)
    start=time.monotonic()
    try:
        sub=subprocess.run([str(pilot.EXE),'-b','-o','ngspice.log','input.cir'],cwd=p,capture_output=True,text=True,timeout=60)
        (p/'console.log').write_text(sub.stdout+sub.stderr);log=(p/'ngspice.log').read_text(errors='replace')
        if sub.returncode or 'Error' in log or 'Transient op started' in log:raise ValueError('Invalid or incomplete characterization')
        d=np.loadtxt(p/'characterization.dat',skiprows=1,ndmin=2);assert d.shape==(1,4) and np.isfinite(d).all()
        requested=current*1e-6*(temp+273.15)/300.15
        assert abs(-d[0,3]-2*requested)<1e-12
        assert 0<d[0,2]<d[0,1]<1.1
        r.update(status='completed',result=dict(vbe_unit_V=float(d[0,1]),vbe_eight_V=float(d[0,2]),delta_V=float(d[0,1]-d[0,2]),supply_current_A=float(-d[0,3])),raw_sha256=sha((p/'characterization.dat').read_bytes()))
    except Exception as exc:r.update(status='unresolved',result=None,reason=type(exc).__name__+': '+str(exc))
    r['elapsed_s']=time.monotonic()-start;save(p/'run.json',r);print(current,temp,r['status'],r['result'],flush=True);return r

if __name__=='__main__':
    folder=OUT/'characterization';folder.mkdir(exist_ok=False)
    jobs=[(current,temp) for current in CURRENTS for temp in TEMPERATURES]
    save(folder/'predeclaration.json',dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=jobs,script_sha256=sha(Path(__file__).read_bytes()),sources=provenance(),
        scope='Nine nominal PNP characterization points with equal explicit ideal PTAT emitter currents. Same 3.4 um primitive at 1:8 multiplicity; four-terminal substrate tied to zero. These fixtures are not a self-biased reference, usable supervisor or energy comparison. They estimate a conventional CTAT/PTAT coefficient before a separately declared real-loop pilot. No ideal reference or bias source may remain in that candidate.'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run_characterization,jobs))
    save(folder/'results.json',dict(runs=rows,complete=sum(r['status']=='completed' for r in rows),unresolved=sum(r['status']=='unresolved' for r in rows)))
