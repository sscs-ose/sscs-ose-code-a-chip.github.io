"""Declared 1.62 V storage challenge and matched smaller-step comparisons."""
from pathlib import Path
import concurrent.futures,datetime,re,subprocess,time
import numpy as np
import reference_supervisor_pilot_v2 as study
import reference_guard_baseline as guard
from application_circuit import supply
source=study.source;OUT=source.OUT/'supervisor_followup'
VARIANTS=('original','digital_guard','reference_supervisor')
JOBS=[dict(group='trough',case=case,variant=v,max_step_s=2e-6) for case in ('cold_storage','nominal_storage','hot_storage') for v in VARIANTS]
JOBS += [dict(group='step',case=case,variant=v,max_step_s=1e-6) for case in ('nominal_storage','nominal_analog') for v in VARIANTS]
JOBS += [dict(group='step',case=case,variant='reference_supervisor',max_step_s=1e-6) for case in ('cold_shallow','hot_shallow')]

def build(job):
    case,variant,step=job['case'],job['variant'],job['max_step_s']
    text,args=guard.build(case,step) if variant=='digital_guard' else study.build(case,variant,step)
    if job['group']=='trough':
        assert study.CASES[case][1]=='none'
        vp=supply('trough');args[1]=vp
        pwl=' '.join(f'{t:.17g} {v:.17g}' for t,v in vp)
        text,count=re.subn(r'(?m)^VDVDD .*$', 'VDVDD dvdd 0 PWL('+pwl+')',text);assert count==1
    else:assert job['group']=='step'
    return text,args

def run(job):
    case,variant=job['case'],job['variant'];p=OUT/(job['group']+'_'+case+'_'+variant);p.mkdir(exist_ok=False)
    text,args=build(job);(p/'input.cir').write_text(text,encoding='utf-8');(p/'.spiceinit').write_text('set ngbehavior=hsa\noption sparse\nset num_threads=1\n')
    r=dict(status='in_progress',**job,script_sha256=source.sha(Path(__file__).read_bytes()),deck_sha256=source.sha(text.encode()),
        source_functions=dict(analog=args[0],digital=args[1],data=args[2],clock=args[3]))
    source.save(p/'run.json',r);start=time.monotonic()
    try:
        sub=subprocess.run([str(source.pilot.EXE),'-b','-o','ngspice.log','input.cir'],cwd=p,capture_output=True,text=True,timeout=180)
        (p/'console.log').write_text(sub.stdout+sub.stderr);log=(p/'ngspice.log').read_text(errors='replace')
        if sub.returncode or 'Error' in log or 'Transient op started' in log or 'timestep too small' in log.lower():raise ValueError('Invalid or incomplete acquisition')
        d=np.loadtxt(p/'history.dat',skiprows=1);assert d.shape[1]==(16 if variant=='original' else 19) and np.isfinite(d).all()
        q=study.assess(d,args,case)
        if job['group']=='trough':
            assert np.min(d[d[:,0]>=.02102501,3])>=1.62-1e-6 and np.max(d[d[:,0]>=.02102501,3])<=1.98+1e-6
        r.update(status='completed',result=q,raw_sha256=source.sha((p/'history.dat').read_bytes()))
    except Exception as exc:
        r.update(status='unresolved',result=None,reason=type(exc).__name__+': '+str(exc))
        for attr in ('stdout','stderr'):
            v=getattr(exc,attr,None)
            if v:(p/('timeout_'+attr+'.log')).write_bytes(v if isinstance(v,bytes) else v.encode())
    r['elapsed_s']=time.monotonic()-start;source.save(p/'run.json',r);print(job['group'],case,variant,r['status'],r['result']['diagnosis'] if r['result'] else r.get('reason'),flush=True);return r

if __name__=='__main__':
    frozen={j['group']+'_'+j['case']+'_'+j['variant']:source.sha(build(j)[0].encode()) for j in JOBS}
    OUT.mkdir(exist_ok=False)
    source.save(OUT/'predeclaration.json',dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=JOBS,budget_s=180,
        script_sha256=source.sha(Path(__file__).read_bytes()),comparison_script_sha256=source.sha(Path(study.__file__).read_bytes()),baseline_script_sha256=source.sha(Path(guard.__file__).read_bytes()),frozen_decks=frozen,
        scope='Seventeen declared follow-ups of the frozen controller. Nine intact benign 1.62 V trough acquisitions at three TT temperatures cover all three architectures. Eight deliberate 1 us maximum-step revisits include matched working cost anchors at no-dip and analog interruption, plus the cold/hot shallow reset cases of the new controller. Source histories, ordinary prior writing and consumer are shared. Traces include setup and functional failures; no held-out, continuous-range, noise or physical qualification claim. The primary storage cases were no-interruption controls; these troughs are a separate application challenge.'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,JOBS))
    source.save(OUT/'results.json',dict(runs=rows,complete=sum(r['status']=='completed' for r in rows),unresolved=sum(r['status']=='unresolved' for r in rows)))
