"""Unchanged released guard baseline on the reference pilot's matched cases."""
from pathlib import Path
import concurrent.futures,datetime,re,subprocess,time
import numpy as np
import reference_supervisor_pilot_v2 as study
from guard_circuit import generate,generate_condition
source=study.source;OUT=source.OUT/'released_guard_baseline'
JOBS=list(study.CASES)

def build(case,max_step=2e-6):
    temp,event=study.CASES[case]
    if event=='shallow_depth':text,args=generate_condition(event,'digital_guard',max_step)
    else:text,args=generate(event,True,'digital_guard',max_step)
    assert text.count('.temp 27\n')==1
    return text.replace('.temp 27\n',f'.temp {temp}\n'),args

def run(case):
    p=OUT/case;p.mkdir(exist_ok=False);text,args=build(case)
    (p/'input.cir').write_text(text,encoding='utf-8');(p/'.spiceinit').write_text('set ngbehavior=hsa\noption sparse\nset num_threads=1\n')
    r=dict(status='in_progress',case=case,variant='digital_guard',max_step_s=2e-6,script_sha256=source.sha(Path(__file__).read_bytes()),deck_sha256=source.sha(text.encode()),
        source_functions=dict(analog=args[0],digital=args[1],data=args[2],clock=args[3]))
    source.save(p/'run.json',r);start=time.monotonic()
    try:
        sub=subprocess.run([str(source.pilot.EXE),'-b','-o','ngspice.log','input.cir'],cwd=p,capture_output=True,text=True,timeout=180)
        (p/'console.log').write_text(sub.stdout+sub.stderr);log=(p/'ngspice.log').read_text(errors='replace')
        if sub.returncode or 'Error' in log or 'Transient op started' in log or 'timestep too small' in log.lower():raise ValueError('Invalid or incomplete acquisition')
        d=np.loadtxt(p/'history.dat',skiprows=1);assert d.shape[1]==19 and np.isfinite(d).all()
        r.update(status='completed',result=study.assess(d,args,case),raw_sha256=source.sha((p/'history.dat').read_bytes()))
    except Exception as exc:
        r.update(status='unresolved',result=None,reason=type(exc).__name__+': '+str(exc))
        for attr in ('stdout','stderr'):
            v=getattr(exc,attr,None)
            if v:(p/('timeout_'+attr+'.log')).write_bytes(v if isinstance(v,bytes) else v.encode())
    r['elapsed_s']=time.monotonic()-start;source.save(p/'run.json',r);print(case,r['status'],r['result']['diagnosis'] if r['result'] else r.get('reason'),flush=True);return r

if __name__=='__main__':
    OUT.mkdir(exist_ok=False)
    source.save(OUT/'predeclaration.json',dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=JOBS,cases=study.CASES,budget_s=180,max_step_s=2e-6,
        script_sha256=source.sha(Path(__file__).read_bytes()),comparison_script_sha256=source.sha(Path(study.__file__).read_bytes()),
        released_guard_circuit_sha256=source.sha((source.PUBLIC/'guard_circuit.py').read_bytes()),frozen_decks={case:source.sha(build(case)[0].encode()) for case in JOBS},
        scope='Post-prototype matched baseline, not held-out validation. The supported v0.15 nine-MOS guard is unchanged and repeated on exactly the same seven histories and ordinary-state contract as the reference supervisor. Source costs are compared only within matched working cases. All cold setup failures, functional misses and incomplete acquisitions remain.'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,JOBS))
    source.save(OUT/'results.json',dict(runs=rows,complete=sum(r['status']=='completed' for r in rows),unresolved=sum(r['status']=='unresolved' for r in rows)))
