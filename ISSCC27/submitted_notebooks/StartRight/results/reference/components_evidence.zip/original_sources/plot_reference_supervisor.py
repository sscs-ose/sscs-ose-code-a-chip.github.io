"""Measured reference startup, mechanism decomposition and intact state tests."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import reference_supervisor_pilot_v2 as study
import reference_guard_baseline as guard
import reference_supervisor_followup as follow
source=study.source;OUT=source.OUT
audit=json.loads((OUT/'evidence_audit.json').read_text(encoding='utf-8'));assert audit['status']=='audited'
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
colors={'original':'#777777','digital_guard':'#bd6500','reference_supervisor':'#155d9c'}
labels={'original':'Published POR','digital_guard':'POR + nine-MOS guard','reference_supervisor':'Reference supervisor'}

peak=max(float(np.loadtxt(OUT/'loop_pilot'/f"{temp}_{'startup' if startup else 'bare'}/reference.dat",skiprows=1)[:,1].max()) for temp in source.TEMPERATURES for startup in (False,True))
fig,axes=plt.subplots(2,3,figsize=(11,6),sharex=True,constrained_layout=True)
for col,temp in enumerate(source.TEMPERATURES):
    axes[0,col].set_title(f'{temp} C, TT models')
    axes[1,col].axhspan(1.20,1.26,color='#dde9d9',zorder=-1)
    for startup,color,label in [(False,'#bd6500','Bare loop'),(True,'#155d9c','With startup')]:
        p=OUT/'loop_pilot'/f"{temp}_{'startup' if startup else 'bare'}";d=np.loadtxt(p/'reference.dat',skiprows=1)
        axes[0,col].plot(d[:,0]*1000,d[:,2],color=color,lw=1)
        axes[1,col].plot(d[:,0]*1000,d[:,1],color=color,lw=1.5,label=label)
    for row in range(2):axes[row,col].set_xlim(0,20);axes[row,col].grid(alpha=.2)
    axes[0,col].set_ylim(-.1,3.6);axes[1,col].set_ylim(-.05,peak*1.08)
    axes[1,col].axvline(15,color='#777777',ls=':',lw=1)
    axes[1,col].set_xlabel('Time (ms)')
axes[0,0].set_ylabel('Analog supply (V)');axes[1,0].set_ylabel('Reference (V)')
axes[1,0].legend(loc='lower right',fontsize=8)
fig.suptitle('Reference-only startup: the bare loop misses the declared band by the deadline\nReal SKY130 devices, ideal resistors and 10 pF load; no forced initial state',fontsize=12)
fig.savefig(OUT/'reference_startup.png',dpi=170);fig.savefig(OUT/'reference_startup.pdf')
plt.close(fig)

sizing=study.bg.fit();k=sizing['ratio'];mechanism=[]
for temp in source.TEMPERATURES:
    d=np.loadtxt(OUT/'loop_pilot'/f'{temp}_startup/reference.dat',skiprows=1);last=d[-1]
    vref,va,vb,ve8=map(float,last[[1,5,6,7]])
    epsilon=vb-va;identity=va+k*(va-ve8)+(1+k)*epsilon
    char=next(r for r in audit['characterizations'] if r['nominal_current_uA']==1 and r['temp_C']==temp)['result']
    predicted=char['vbe_unit_V']+k*char['delta_V']
    mechanism.append(dict(temp_C=temp,ideal_bias_vbe_V=char['vbe_unit_V'],weighted_ideal_delta_V=k*char['delta_V'],
        ideal_bias_sum_V=predicted,actual_reference_V=vref,voltage_equality_error_V=epsilon,
        weighted_equality_error_V=(1+k)*epsilon,other_difference_V=vref-predicted-(1+k)*epsilon,
        resistor_identity_residual_V=vref-identity))
source.save(OUT/'mechanism_identity.json',dict(rows=mechanism,
    equation='Vref = Va + K*(Va - Ve8) + (1+K)*(Vb - Va), up to measured transient input-node current residual.',
    scope='Post-hoc electrical decomposition at each final sample. Ideal-bias characterization is not the actual reference. The equality term is not an isolated intrinsic input-offset measurement, and three temperatures do not qualify a continuous temperature range.'))
fig,axes=plt.subplots(1,2,figsize=(10,4.5),constrained_layout=True)
t=[r['temp_C'] for r in mechanism]
for key,color,label in [('ideal_bias_vbe_V','#bd6500','Measured VBE under ideal bias'),('weighted_ideal_delta_V','#168059','K times measured delta-VBE'),('ideal_bias_sum_V','#777777','Their calculated sum'),('actual_reference_V','#155d9c','Actual self-biased reference')]:
    axes[0].plot(t,[r[key] for r in mechanism],'-o',color=color,label=label,ms=5,lw=1.2)
axes[0].set_xticks(t);axes[0].set_ylabel('Voltage (V)');axes[0].set_ylim(0,1.4);axes[0].legend(fontsize=7,loc='lower center')
x=np.arange(3);a=np.array([r['weighted_equality_error_V']*1000 for r in mechanism]);b=np.array([r['other_difference_V']*1000 for r in mechanism])
axes[1].bar(x,a,color='#155d9c',label='Measured (1 + K) times input difference')
axes[1].bar(x,b,bottom=a,color='#bbbbbb',label='Other measured difference')
axes[1].set_ylabel('Actual reference minus ideal-bias sum (mV)');axes[1].set_xticks(x,[str(v) for v in t]);axes[1].legend(fontsize=7)
for ax in axes:ax.set_xlabel('Temperature (C)');ax.grid(axis='y',alpha=.2)
fig.suptitle('Measured device terms explain the chosen coefficient; the real loop has residual error\nLines connect three nominal samples only; algebraic terms do not isolate physical offset',fontsize=11)
fig.savefig(OUT/'temperature_mechanism.png',dpi=170);fig.savefig(OUT/'temperature_mechanism.pdf');plt.close(fig)

fig,axes=plt.subplots(3,3,figsize=(12,7.5),sharex='col',constrained_layout=True)
columns=[('primary','cold_shallow','-40 C: only the new controller\nestablishes Q=1 before resetting',20.9,29.2),
         ('primary','hot_shallow','125 C: 1.35 V reset dip\nNew controller restores the written state',24.8,29.2),
         ('trough','hot_storage','125 C: benign 1.62 V trough\nAll three preserve Q=1',24.8,29.2)]
for col,(group,case,title,lo,hi) in enumerate(columns):
    for variant in follow.VARIANTS:
        if group=='trough':p=follow.OUT/('trough_'+case+'_'+variant)
        elif variant=='digital_guard':p=guard.OUT/case
        else:p=study.OUT/(case+'_'+variant)
        d=np.loadtxt(p/'history.dat',skiprows=1);time=d[:,0]*1000;mask=(time>=lo)&(time<=hi)
        for row,idx in enumerate((3,2,1)):
            axes[row,col].plot(time[mask],d[mask,idx],color=colors[variant],label=labels[variant],ls='--' if variant=='digital_guard' else '-',lw=1.2)
    axes[0,col].set_title(title,fontsize=10)
    for row in range(3):axes[row,col].set_xlim(lo,hi);axes[row,col].set_ylim(-.1,2.0);axes[row,col].grid(alpha=.2)
    axes[2,col].set_xlabel('Time (ms)')
for row,label in enumerate(('DVDD (V)','Consumer reset-bar (V)','Q (V)')):axes[row,0].set_ylabel(label)
axes[0,0].legend(fontsize=7,loc='lower left')
fig.suptitle('Intact DFF action: compare a valid prior state before judging recovery\nTT schematic samples, 2 us maximum step; new reference/comparator use the existing 3.3 V rail',fontsize=12)
fig.savefig(OUT/'controller_histories.png',dpi=170);fig.savefig(OUT/'controller_histories.pdf');plt.close(fig)
print('Saved three measured figure pairs and the electrical identity record.')
