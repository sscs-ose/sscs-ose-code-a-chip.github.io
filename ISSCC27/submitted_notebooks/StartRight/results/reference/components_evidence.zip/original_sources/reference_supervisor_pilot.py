"""Private intact POR/DFF comparison with a real-reference supervisor."""
from pathlib import Path
import concurrent.futures,datetime,json,re,subprocess,time
import numpy as np
import bandgap_loop_pilot as bg
from por_circuit import generate as por_generate,measure
from guard_circuit import generate_condition
from reset_contract import waveform,segment
source=bg.source;OUT=source.OUT/'supervisor_pilot'
CASES={'cold_storage':(-40,'none'),'cold_shallow':(-40,'shallow_depth'),
       'nominal_storage':(27,'none'),'nominal_shallow':(27,'shallow_depth'),
       'hot_storage':(125,'none'),'hot_shallow':(125,'shallow_depth'),
       'nominal_analog':(27,'analog')}
JOBS=[(case,variant) for case in CASES for variant in ('original','reference_supervisor')]

def pnp_models():
    # Exact nominal values from the pinned nonfet file. Do not overwrite the
    # published POR's unrelated parameter declarations in the control.
    original=source.NONFET.read_text(encoding='utf-8');text=''
    names=[f'dk{key}pp{size}x' for key in ('is','bf','nf','ise') for size in (3,5)]
    names += ['sky130_fd_pr__model__parasitic__diode_ps2nw__'+kind+'_mult' for kind in ('ajunction','pjunction')]
    for name in names:
        values={m[1] for m in re.finditer(r'(?<!\w)'+name+r'\s*=\s*([^\s$]+)',original)}
        assert len(values)==1,(name,values)
        text+=f'.param {name}={next(iter(values))}\n'
    for size in ('W0p68L0p68','W3p40L3p40'):
        text+=f'.include "{(source.PNP/("sky130_fd_pr__pnp_05v5_"+size+".model.spice")).as_posix()}"\n'
    return text

def controller():
    reference=bg.build(27,True)
    start=reference.index('* Same-primitive')
    body=reference[start:reference.index('\n.control',start)]
    # Node renaming only; the licensed amplifier and startup topology is kept.
    body=re.sub(r'\bvdd\b','avdd',body,flags=re.I)
    return body+'''
* Real five-MOS comparator, biased by the self-biased reference mirror.
RCMPTOP dvdd vsense 220k
RCMPBOTTOM vsense 0 1meg
XCMPTAIL cmp_tail gdrv avdd avdd sky130_fd_pr__pfet_g5v0d10v5 L=2 W=8
XCMPP1 cmp_d1 vsense cmp_tail avdd sky130_fd_pr__pfet_g5v0d10v5 L=2 W=20
XCMPP2 cmpout vref cmp_tail avdd sky130_fd_pr__pfet_g5v0d10v5 L=2 W=20
XCMPN1 cmp_d1 cmp_d1 0 0 sky130_fd_pr__nfet_g5v0d10v5 L=2 W=4
XCMPN2 cmpout cmp_d1 0 0 sky130_fd_pr__nfet_g5v0d10v5 L=2 W=4
* High-voltage NMOS isolates the comparator from the 1.8 V inverter gate.
RLEVEL dvdd level_n 1meg
XLEVEL level_n cmpout 0 0 sky130_fd_pr__nfet_g5v0d10v5 L=.5 W=1
XRESET_P ref_reset level_n dvdd dvdd sky130_fd_pr__pfet_01v8 L=.15 W=2
XRESET_N ref_reset level_n 0 0 sky130_fd_pr__nfet_01v8 L=.15 W=.42
'''

def build(case,variant,max_step=2e-6):
    temp,event=CASES[case];assert variant in ('original','reference_supervisor')
    if event=='shallow_depth':text,args=generate_condition(event,'original',max_step)
    else:text,*args=por_generate(event,True,max_step)
    assert text.count('.temp 27\n')==1
    text=text.replace('.temp 27\n',f'.temp {temp}\n')
    if variant=='reference_supervisor':
        text,count=re.subn(r'(?m)^XPOR .*$', '* Published POR instance replaced by reference supervisor.',text);assert count==1
        text,count=re.subn(r'(?m)^XDUT clk d porb_l ', 'XDUT clk d ref_reset ',text);assert count==1
        text=text.replace(f'.temp {temp}\n',pnp_models()+f'.temp {temp}\n')
        text=text.replace('v(porb_l)','v(ref_reset)')
        text=text.replace('v(porb_h) v(por_l) v(xpor.net9)','v(vref) v(gdrv) v(cmpout)')
        for prefix in ('.save ','wrdata history.dat '):
            text,count=re.subn(r'(?m)^'+re.escape(prefix)+r'(.*)$',lambda m:prefix+m[1]+' v(vsense) v(level_n) v(cmp_tail)',text);assert count==1
        assert text.count('.save ')==1;text=text.replace('.save ',controller()+'.save ',1)
    assert not re.search(r'(?im)^\s*\.(ic|nodeset)\b',text) and not re.search(r'(?im)^\s*[BEGFI]\w+\s',text)
    return text,args

def assess(d,args,case):
    reference=measure(d[:,:16],*args,True);storage=CASES[case][1]=='none'
    t,v=waveform(d[:,0],dict(q=d[:,1],reset=d[:,2],vdd=d[:,3]))
    _,post=segment(t,v,.02102501,float(t[-1]))
    preserves=bool(np.min(post['q'])>=1.44);inactive=bool(np.min(post['reset']-.8*post['vdd'])>=0)
    functional=preserves and inactive if storage else reference['observed_pass']
    if not reference['events'][0]['pass_contract']:diagnosis='not_exercised_cold_start'
    elif not reference['declared_precondition_verified']:diagnosis='not_exercised_prior_state'
    elif functional:diagnosis='requirement_met'
    else:diagnosis='functional_requirement_missed'
    return dict(reference=reference,qualified=diagnosis=='requirement_met',diagnosis=diagnosis,
        storage_requirement=storage,normal_storage_pass=preserves if storage else None,reset_inactive_pass=inactive if storage else None,
        minimum_postwrite_q_V=float(np.min(post['q'])),
        scope='Matched published DFF, ordinary clock/data write, load, supplies and source-work measurement. New controller replaces the POR instance and uses the analog rail for a real self-biased reference/comparator. Its original POR diagnostic columns are replaced by real reference/gate/comparator signals. No fabricated probe values, ideal reference or state forcing. Finite TT-temperature development evidence, not PVT qualification or an optimized supervisor.')

def run(job):
    case,variant=job;p=OUT/(case+'_'+variant);p.mkdir(exist_ok=False)
    text,args=build(*job);(p/'input.cir').write_text(text,encoding='utf-8');(p/'.spiceinit').write_text('set ngbehavior=hsa\noption sparse\nset num_threads=1\n')
    r=dict(status='in_progress',case=case,variant=variant,max_step_s=2e-6,script_sha256=source.sha(Path(__file__).read_bytes()),deck_sha256=source.sha(text.encode()),
        source_functions=dict(analog=args[0],digital=args[1],data=args[2],clock=args[3]))
    source.save(p/'run.json',r);start=time.monotonic()
    try:
        sub=subprocess.run([str(source.pilot.EXE),'-b','-o','ngspice.log','input.cir'],cwd=p,capture_output=True,text=True,timeout=180)
        (p/'console.log').write_text(sub.stdout+sub.stderr);log=(p/'ngspice.log').read_text(errors='replace')
        if sub.returncode or 'Error' in log or 'Transient op started' in log or 'timestep too small' in log.lower():raise ValueError('Invalid or incomplete acquisition')
        d=np.loadtxt(p/'history.dat',skiprows=1);assert d.shape[1]==(19 if variant=='reference_supervisor' else 16) and np.isfinite(d).all()
        r.update(status='completed',result=assess(d,args,case),raw_sha256=source.sha((p/'history.dat').read_bytes()))
    except Exception as exc:
        r.update(status='unresolved',result=None,reason=type(exc).__name__+': '+str(exc))
        for attr in ('stdout','stderr'):
            v=getattr(exc,attr,None)
            if v:(p/('timeout_'+attr+'.log')).write_bytes(v if isinstance(v,bytes) else v.encode())
    r['elapsed_s']=time.monotonic()-start;source.save(p/'run.json',r);print(case,variant,r['status'],r['result']['diagnosis'] if r['result'] else r.get('reason'),flush=True);return r

if __name__=='__main__':
    OUT.mkdir(exist_ok=False)
    source.save(OUT/'predeclaration.json',dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),jobs=JOBS,cases=CASES,budget_s=180,max_step_s=2e-6,
        script_sha256=source.sha(Path(__file__).read_bytes()),loop_script_sha256=source.sha(Path(bg.__file__).read_bytes()),model_helper_sha256=source.sha(Path(source.__file__).read_bytes()),
        sources=source.provenance(),sizing=bg.fit(),
        probe_scope='Original 16-column schema for control. New 19-column data replaces unused columns 13/14/15 with measured vref/gdrv/cmpout and adds vsense/level_n/cmp_tail. Core/state/source measurement uses unchanged columns 0..12.',
        scope='Fourteen development acquisitions declared before collecting intact data: seven matched histories, original versus reference supervisor. Same ordinary inputs, DFF and source assumptions. New reference has ideal resistors/load, licensed amplifier/startup with declared source geometry; new comparator defaults to zero diffusion/contact geometry. Every independent source counted. No energy comparison unless both circuits meet the same contract. No physically qualified threshold, process sweep, hysteresis, silicon or globally new topology claim.'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,JOBS))
    source.save(OUT/'results.json',dict(runs=rows,complete=sum(r['status']=='completed' for r in rows),unresolved=sum(r['status']=='unresolved' for r in rows)))
