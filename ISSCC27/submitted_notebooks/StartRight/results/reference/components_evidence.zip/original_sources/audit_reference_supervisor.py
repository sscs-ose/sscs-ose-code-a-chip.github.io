"""Remeasure the private reference pilot and every matched baseline/follow-up."""
from pathlib import Path
import json
import numpy as np
import reference_supervisor_pilot_v2 as study
import reference_guard_baseline as guard
import reference_supervisor_followup as follow
import reference_supervisor_pilot as failed
from guard_policy import choose
from guard_consumer import verify_models
source=study.source;bg=study.bg;OUT=source.OUT

def sources():
    pre=json.loads((OUT/'characterization/predeclaration.json').read_text(encoding='utf-8'))
    assert source.sha(Path(source.__file__).read_bytes())==pre['script_sha256']
    assert source.provenance()==pre['sources']
    return verify_models()

def characterizations():
    folder=OUT/'characterization';pre=json.loads((folder/'predeclaration.json').read_text(encoding='utf-8'));data=json.loads((folder/'results.json').read_text(encoding='utf-8'));rows=[]
    assert len(pre['jobs'])==len(data['runs'])==9
    for (current,temp),r in zip(pre['jobs'],data['runs']):
        p=folder/f'{current:g}uA_{temp}';assert r==json.loads((p/'run.json').read_text(encoding='utf-8'))
        text=source.char_deck(current,temp);assert text==(p/'input.cir').read_text(encoding='utf-8') and source.sha(text.encode())==r['deck_sha256']
        assert r['script_sha256']==pre['script_sha256']
        if r['status']=='completed':
            assert source.sha((p/'characterization.dat').read_bytes())==r['raw_sha256']
            d=np.loadtxt(p/'characterization.dat',skiprows=1,ndmin=2);assert d.shape==(1,4) and np.isfinite(d).all()
            q=dict(vbe_unit_V=float(d[0,1]),vbe_eight_V=float(d[0,2]),delta_V=float(d[0,1]-d[0,2]),supply_current_A=float(-d[0,3]))
            assert q==r['result'];assert abs(q['supply_current_A']-2*current*1e-6*(temp+273.15)/300.15)<1e-12
        rows.append(r)
    return rows

def loops():
    folder=OUT/'loop_pilot';pre=json.loads((folder/'predeclaration.json').read_text(encoding='utf-8'));data=json.loads((folder/'results.json').read_text(encoding='utf-8'));rows=[]
    assert pre['script_sha256']==source.sha(Path(bg.__file__).read_bytes()) and pre['sizing']==bg.fit()
    assert pre['model_helper_sha256']==source.sha(Path(source.__file__).read_bytes()) and pre['sources']==source.provenance()
    for (temp,startup),r in zip(pre['jobs'],data['runs']):
        p=folder/f"{temp}_{'startup' if startup else 'bare'}";assert r==json.loads((p/'run.json').read_text(encoding='utf-8'))
        text=bg.build(temp,startup);assert text==(p/'input.cir').read_text(encoding='utf-8') and source.sha(text.encode())==r['deck_sha256']
        assert r['script_sha256']==pre['script_sha256']
        if r['status']=='completed':
            assert source.sha((p/'reference.dat').read_bytes())==r['raw_sha256']
            assert bg.measure(np.loadtxt(p/'reference.dat',skiprows=1))==r['result']
        rows.append(r)
    assert len(rows)==6
    return rows

def acquisition(folder,module,kind):
    pre=json.loads((folder/'predeclaration.json').read_text(encoding='utf-8'));data=json.loads((folder/'results.json').read_text(encoding='utf-8'));rows=[]
    assert pre['script_sha256']==source.sha(Path(module.__file__).read_bytes())
    assert len(pre['jobs'])==len(data['runs'])
    for job,r in zip(pre['jobs'],data['runs']):
        if kind=='primary':
            case,variant=job;identifier=case+'_'+variant;text,args=module.build(*job)
        elif kind=='guard':
            case=job;variant='digital_guard';identifier=case;text,args=module.build(case)
        else:
            case,variant=job['case'],job['variant'];identifier=job['group']+'_'+case+'_'+variant;text,args=module.build(job)
        p=folder/identifier;assert r==json.loads((p/'run.json').read_text(encoding='utf-8'))
        assert r['script_sha256']==pre['script_sha256']
        assert text==(p/'input.cir').read_text(encoding='utf-8') and source.sha(text.encode())==r['deck_sha256']==pre['frozen_decks'][identifier]
        assert r['source_functions']==dict(analog=args[0],digital=args[1],data=args[2],clock=args[3])
        if r['status']=='completed':
            assert source.sha((p/'history.dat').read_bytes())==r['raw_sha256']
            log=(p/'ngspice.log').read_text(errors='replace');assert 'Error' not in log and 'Transient op started' not in log and 'timestep too small' not in log.lower()
            d=np.loadtxt(p/'history.dat',skiprows=1);assert d.shape[1]==(16 if variant=='original' else 19)
            q=study.assess(d,args,case);assert q==r['result']
        row=dict(r);row.setdefault('group',kind);row['written_deck_sha256']=source.sha((p/'input.cir').read_bytes());rows.append(row)
    return rows

def failed_attempt():
    folder=OUT/'supervisor_pilot';pre=json.loads((folder/'predeclaration.json').read_text(encoding='utf-8'));summary=json.loads((folder/'execution_summary.json').read_text(encoding='utf-8'))
    assert source.sha(Path(failed.__file__).read_bytes())==pre['script_sha256']==summary['source_sha256']
    for row in summary['rows']:
        p=folder/(row['case']+'_'+row['variant'])
        if row['status']=='completed':
            r=json.loads((p/'run.json').read_text(encoding='utf-8'));text,args=failed.build(row['case'],row['variant'])
            assert text==(p/'input.cir').read_text(encoding='utf-8') and source.sha(text.encode())==r['deck_sha256']
            assert source.sha((p/'history.dat').read_bytes())==r['raw_sha256']
            assert failed.assess(np.loadtxt(p/'history.dat',skiprows=1),args,row['case'])==r['result']
        elif row['status']=='generation_failed_before_SPICE':assert not (p/'input.cir').exists() and not (p/'history.dat').exists()
    return summary

if __name__=='__main__':
    tool=sources();char=characterizations();refs=loops();first=acquisition(study.OUT,study,'primary');baseline=acquisition(guard.OUT,guard,'guard')
    # Baseline declaration keys are case names; all generators and source curves
    # are checked before any working-case comparison is made.
    later=acquisition(follow.OUT,follow,'followup')
    initial=first+baseline;index={(r['case'],r['variant']):r for r in initial};assert len(index)==21
    pairs=[]
    def comparison(rows,group,case):
        assert len(rows)==3
        assert rows[0]['source_functions']==rows[1]['source_functions']==rows[2]['source_functions']
        variants={r['variant']:r for r in rows};ref=variants['reference_supervisor']
        for variant in ('original','digital_guard'):
            control=variants[variant];eligible=all(r['status']=='completed' and r['result']['qualified'] for r in (ref,control))
            work=lambda r:r['result']['reference']['source_work']['delivered_J']
            pairs.append(dict(group=group,case=case,control=variant,both_working=eligible,reference_relative_work_change=work(ref)/work(control)-1 if eligible else None))
    for case in study.CASES:comparison([index[(case,v)] for v in follow.VARIANTS],'primary',case)
    refinements=[]
    for r in later:
        if r['group']!='step':continue
        old=index[(r['case'],r['variant'])]
        if r['status']!='completed' or old['status']!='completed':continue
        a,b=old['result'],r['result'];assert old['source_functions']==r['source_functions']
        for key in ('diagnosis','qualified','normal_storage_pass','reset_inactive_pass'):assert a[key]==b[key]
        for key in ('declared_precondition_verified','alternate_state_exercised','sampled_restoration_observed'):assert a['reference'][key]==b['reference'][key]
        work=lambda q:q['reference']['source_work']['delivered_J']
        refinements.append(dict(case=r['case'],variant=r['variant'],classifications_agree=True,working_relative_work_difference=abs(work(a)-work(b))/max(work(a),work(b)) if a['qualified'] and b['qualified'] else None))
    for case in ('nominal_storage','nominal_analog'):
        comparison([r for r in later if r['group']=='step' and r['case']==case],'step',case)
    policyrows=[]
    for r in initial+[r for r in later if r['group']=='trough']:
        condition=('trough_' if r['group']=='trough' else '')+r['case'];q=r.get('result');ref=q['reference'] if q else None
        policyrows.append(dict(condition=condition,variant=r['variant'],status=r['status'],cold_pass=ref['events'][0]['pass_contract'] if ref else None,
            prior_verified=ref['declared_precondition_verified'] if ref else None,functional_requirement_met=q['qualified'] if q else None,
            source_work_delivered_J=ref['source_work']['delivered_J'] if ref else None))
    for r in later:
        if r['group']=='step' and r['case'] in ('nominal_storage','nominal_analog') and r['status']=='completed':
            row=next(q for q in policyrows if q['condition']==r['case'] and q['variant']==r['variant'])
            row['source_work_delivered_J']=r['result']['reference']['source_work']['delivered_J']
    evidence=dict(status='audited',rows=policyrows)
    policies=dict(limited=choose(evidence,required=['nominal_storage'],anchor='nominal_storage'),
        nominal_reset=choose(evidence,required=['nominal_storage','nominal_shallow'],anchor='nominal_storage'),
        expanded=choose(evidence,required=['nominal_storage','hot_shallow','cold_shallow','trough_cold_storage','trough_hot_storage'],anchor='nominal_storage'),
        unmeasured=choose(evidence,required=['nominal_storage','unmeasured_short_zero'],anchor='nominal_storage'),
        analog_event_price=choose(evidence,required=['nominal_storage','nominal_analog'],anchor='nominal_analog'))
    record=dict(status='audited',tool=tool,characterizations=char,reference_loops=refs,primary=initial,followup=later,
        failed_adapter_attempt=failed_attempt(),comparisons=pairs,refinements=refinements,policies=policies,
        scope='Private Windows development evidence. Ideal-bias device characterization is separate from self-biased reference startup and intact DFF application action. Every real acquisition and generation error is retained. Source-work ratios require matched working circuits, and policies price explicit common refined histories rather than lifetime energy. No full process/temperature range, optimized supervisor, physical area, silicon, global novelty or publication claim.')
    source.save(OUT/'evidence_audit.json',record)
    print(json.dumps(dict(status=record['status'],primary_qualified_by_variant={v:sum(r['status']=='completed' and r['result']['qualified'] for r in initial if r['variant']==v) for v in follow.VARIANTS},policies=policies,comparisons=pairs,refinements=refinements),indent=2))
