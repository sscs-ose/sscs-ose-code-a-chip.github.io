"""Predeclared finite detector-cost feasibility study, outside the v0.11 release.
SPDX-License-Identifier: Apache-2.0
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import copy, hashlib, json, os, re, subprocess, sys, time
import numpy as np

WORKSPACE=Path(__file__).resolve().parents[2]
PROJECT=WORKSPACE/'reuse_candidate/ISSCC27/submitted_notebooks/StartRight'
sys.path.insert(0,str(PROJECT))
import external_consumer as consumer
from external_circuit import generate
from pilot import EXE


def main():
    out=Path(__file__).with_name('detector_scaling_tt');out.mkdir(exist_ok=False)
    spec=consumer.specification();tool=consumer.verify_models();sources=consumer.verify_external_sources()
    jobs=[]
    for scale in [1,2,4]:
        for history in ['retained','normal','no_dip']:
            item=copy.deepcopy(spec['configurations'][1]);s=item['scenario']
            s['normal_set']['skip_command']=history=='retained'
            s['recovery']['low_V']=1.8 if history=='no_dip' else .9
            jobs.append(dict(index=len(jobs),scale=scale,history=history,configuration=item['configuration'],scenario=s))
    declared=dict(jobs=jobs,contract=spec['contract'],settings=spec['settings'],absolute_tolerances=spec['absolute_tolerances'],solver=spec['solver'],budget_s=180,tool=tool,external_sources=sources,
        scope='Private finite TT feasibility study. RDET and all three detector transistor lengths scale together; widths, CDET, reset capacitance, consumer, source functions and contract remain fixed. Long-channel intuition is only a hypothesis under BSIM. Require retained/normal passes and no-dip Q retention before cost ranking. Count every independent source; report transistor gate-area proxy and resistance cost. Ideal R/C, source schematic geometry and model leakage limits remain. No hardware, optimum, held-out, area or energy-win claim.')
    (out/'predeclared.json').write_text(json.dumps(declared,indent=2));(out/'source.py').write_bytes(Path(__file__).read_bytes())
    for name in consumer.SOURCES:(out/('source_'+name)).write_bytes((PROJECT/name).read_bytes())
    def acquire(job):
        raw=out/f"case_{job['index']:02d}";raw.mkdir()
        text,points,windows,dp,cp=generate(job['configuration'],job['scenario'],spec['contract'],spec['settings'],spec['absolute_tolerances'])
        original=text;scale=job['scale']
        for device,length in [('XMNDET',2.),('XMPDET',.5),('XMNDRV',.5)]:
            text,count=re.subn(r'(?m)^('+device+r' .*\bl=)\S+',lambda m:m[1]+format(length*scale,'.17g'),text);assert count==1
        text,count=re.subn(r'(?m)^(RDET det_supply det )\S+',lambda m:m[1]+format(1e7*scale,'.17g'),text);assert count==1
        # Verify that the explicit four parameter edits are the complete change.
        erase=lambda t:re.sub(r'(?m)^(XMNDET|XMPDET|XMNDRV)( .*\bl=)\S+',r'\1\2<length>',re.sub(r'(?m)^(RDET det_supply det )\S+',r'\1<resistance>',t))
        assert erase(text)==erase(original)
        (raw/'input.cir').write_text(text);(raw/'.spiceinit').write_text('set ngbehavior=hsa\noption sparse\nset num_threads=1\n')
        row=dict(**job,raw=str(raw),deck_sha256=hashlib.sha256((raw/'input.cir').read_bytes()).hexdigest(),reference_generated_sha256=hashlib.sha256(original.encode()).hexdigest(),
                 detector_gate_rectangle_um2=(.42*2+2*.5+.42*.5)*scale,detector_resistance_ohm=1e7*scale)
        start=time.perf_counter()
        try:
            result=subprocess.run([str(EXE),'-b','-o','ngspice.log','input.cir'],cwd=raw,capture_output=True,text=True,timeout=180)
            (raw/'console.log').write_text(result.stdout+result.stderr)
            log=(raw/'ngspice.log').read_text(errors='replace')
            if result.returncode or 'Error' in log or 'timestep too small' in log.lower() or 'Transient op started' in log:raise ValueError('Incomplete or rejected SPICE acquisition')
            data=np.loadtxt(raw/'sequence.dat',skiprows=1)
            row.update(consumer.measure(data,job['configuration'],job['scenario'],spec['contract'],points,windows,dp,cp),acquisition_status='measured')
        except Exception as exc:
            row.update(acquisition_status='unresolved',observed_pass=None,reason=type(exc).__name__+': '+str(exc))
        row['wall_s']=time.perf_counter()-start
        (raw/'measurement.json').write_text(json.dumps(row,indent=2,allow_nan=False));return row
    rows=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        for f in as_completed([pool.submit(acquire,j) for j in jobs]):
            row=f.result();rows.append(row);rows.sort(key=lambda x:x['index']);(out/'results.json').write_text(json.dumps(dict(declared=declared,cases=rows),indent=2,allow_nan=False))
            print(json.dumps({k:row.get(k) for k in ['index','scale','history','acquisition_status','observed_pass','minimum_q_final_hold_V','wall_s','reason']}),flush=True)


if __name__=='__main__':main()
