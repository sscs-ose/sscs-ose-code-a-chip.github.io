"""Freeze scale four against scale one before acquiring new matched challenges.
SPDX-License-Identifier: Apache-2.0
"""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import copy,hashlib,json,re,subprocess,sys,time
import numpy as np
import detector_scaling as prior
consumer=prior.consumer


def main():
    out=Path(__file__).with_name('detector_scaling_refined');out.mkdir(exist_ok=False)
    pilot=json.loads((out.parent/'detector_scaling_tt/results.json').read_text())
    rows=pilot['cases'];assert len(rows)==9 and all(r['acquisition_status']=='measured' for r in rows)
    for scale in [1,2,4]:
        group={r['history']:r for r in rows if r['scale']==scale}
        assert group['retained']['observed_pass'] and group['normal']['observed_pass']
        assert group['no_dip']['minimum_q_final_hold_V']>=1.44
    # Selection is made on working matched pilot cost, not new challenge outcomes.
    selected=min([1,2,4],key=lambda scale:sum(r['source_work']['delivered_J'] for r in rows if r['scale']==scale and r['history']!='no_dip'));assert selected==4
    spec=consumer.specification();spec['settings']['max_step']=1e-6;jobs=[]
    challenges=[dict(id='tt_nominal',corner='tt',temperature_C=27,supply_V=1.8),dict(id='sf_27',corner='sf',temperature_C=27,supply_V=1.8),dict(id='tt_low_supply',corner='tt',temperature_C=27,supply_V=1.62)]
    # Inspect the actual source key; no unused pseudo-temperature parameter.
    for challenge in challenges:
        for scale in [1,selected]:
            for history in ['retained','normal','no_dip']:
                item=copy.deepcopy(spec['configurations'][1]);scenario=item['scenario']
                assert 'temperature_C' in scenario
                scenario.update({k:v for k,v in challenge.items() if k!='id'})
                scenario['normal_set']['skip_command']=history=='retained'
                scenario['recovery']['low_V']=scenario['supply_V'] if history=='no_dip' else .5*scenario['supply_V']
                jobs.append(dict(index=len(jobs),scale=scale,history=history,challenge=challenge['id'],configuration=item['configuration'],scenario=scenario))
    declared=dict(jobs=jobs,selected_scale=selected,pilot_record_sha256=hashlib.sha256((out.parent/'detector_scaling_tt/results.json').read_bytes()).hexdigest(),contract=spec['contract'],settings=spec['settings'],absolute_tolerances=spec['absolute_tolerances'],budget_s=180,tool=consumer.verify_models(),source=consumer.verify_external_sources(),scope='One-us maximum-step follow-up on the nominal point, the smallest observed work reduction (SF) and largest extra release delay (low supply). Conditions deliberately selected from prior observations, not held out. Same fixed scale-four choice and source functions. No continuous PVT, physical accuracy or optimized-reference claim.')
    (out/'predeclared.json').write_text(json.dumps(declared,indent=2));(out/'source.py').write_bytes(Path(__file__).read_bytes())
    def acquire(job):
        raw=out/f"case_{job['index']:02d}";raw.mkdir();scale=job['scale']
        text,points,windows,dp,cp=prior.generate(job['configuration'],job['scenario'],spec['contract'],spec['settings'],spec['absolute_tolerances'])
        for device,length in [('XMNDET',2.),('XMPDET',.5),('XMNDRV',.5)]:
            text,count=re.subn(r'(?m)^('+device+r' .*\bl=)\S+',lambda m:m[1]+format(length*scale,'.17g'),text);assert count==1
        text,count=re.subn(r'(?m)^(RDET det_supply det )\S+',lambda m:m[1]+format(1e7*scale,'.17g'),text);assert count==1
        assert f".temp {job['scenario']['temperature_C']}" in text
        (raw/'input.cir').write_text(text);(raw/'.spiceinit').write_text('set ngbehavior=hsa\noption sparse\nset num_threads=1\n')
        row=dict(**job,raw=str(raw),deck_sha256=hashlib.sha256((raw/'input.cir').read_bytes()).hexdigest());start=time.perf_counter()
        try:
            p=subprocess.run([str(prior.EXE),'-b','-o','ngspice.log','input.cir'],cwd=raw,capture_output=True,text=True,timeout=180);(raw/'console.log').write_text(p.stdout+p.stderr)
            log=(raw/'ngspice.log').read_text(errors='replace')
            if p.returncode or 'Error' in log or 'timestep too small' in log.lower() or 'Transient op started' in log:raise ValueError('Incomplete or rejected SPICE acquisition')
            row.update(consumer.measure(np.loadtxt(raw/'sequence.dat',skiprows=1),job['configuration'],job['scenario'],spec['contract'],points,windows,dp,cp),acquisition_status='measured')
        except Exception as exc:row.update(acquisition_status='unresolved',observed_pass=None,reason=type(exc).__name__+': '+str(exc))
        row['wall_s']=time.perf_counter()-start;(raw/'measurement.json').write_text(json.dumps(row,indent=2,allow_nan=False));return row
    rows=[]
    with ThreadPoolExecutor(max_workers=2) as pool:
        for f in as_completed([pool.submit(acquire,j) for j in jobs]):
            row=f.result();rows.append(row);rows.sort(key=lambda x:x['index']);(out/'results.json').write_text(json.dumps(dict(declared=declared,cases=rows),indent=2,allow_nan=False))
            print(json.dumps({k:row.get(k) for k in ['index','scale','challenge','history','acquisition_status','observed_pass','minimum_q_final_hold_V','wall_s','reason']}),flush=True)


if __name__=='__main__':main()
