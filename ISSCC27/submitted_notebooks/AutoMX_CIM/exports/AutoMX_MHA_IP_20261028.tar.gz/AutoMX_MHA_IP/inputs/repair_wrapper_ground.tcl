# Explicit same-layer bridges for the measured _22_04 ground opens.
# Source after read_db. Never alter ITerm logical connectivity or LVS rules.
proc automx_ground_bridges {} {
    set block [ord::get_db_block]
    set tech [ord::get_db_tech]
    set u [$block getDbUnitsPerMicron]
    set ground [$block findNet VGND]
    set layer [$tech findLayer met4]
    if {$ground == "NULL" || $layer == "NULL"} {error "missing VGND/met4"}
    set bridges {
        core_i {636.8 213.52 639.14 214.12} {636.8 213.52 637.2 214.12} {638.74 213.52 639.14 214.12}
        condition_i {1556.4 53.52 1560.74 54.12} {1556.4 53.52 1556.8 54.12} {1560.34 53.52 1560.74 54.12}
    }
    set swires [$ground getSWires]
    if {[llength $swires] != 1} {error "expected one native VGND SWire"}
    foreach {name bridge contact landing} $bridges {
        set instance [$block findInst $name]
        if {$instance == "NULL" || [$instance getOrient] != "R0"} {error "macro placement changed: $name"}
        set terminal [$instance findITerm VGND]
        if {$terminal == "NULL" || [$terminal getNet] != $ground} {error "macro ground net changed: $name"}
        lassign [$instance getOrigin] ox oy
        set contact_db {}; set landing_db {}; set bridge_db {}
        foreach x $contact {lappend contact_db [expr {round($x*$u)}]}
        foreach x $landing {lappend landing_db [expr {round($x*$u)}]}
        foreach x $bridge {lappend bridge_db [expr {round($x*$u)}]}
        set pin_ok 0
        foreach mpin [[$terminal getMTerm] getMPins] {
            foreach box [$mpin getGeometry] {
                if {[$box getTechLayer] != $layer} {continue}
                lassign $contact_db x1 y1 x2 y2
                if {[$box xMin]+$ox <= $x1 && [$box yMin]+$oy <= $y1 &&
                    [$box xMax]+$ox >= $x2 && [$box yMax]+$oy >= $y2} {set pin_ok 1}
            }
        }
        set stripe_ok 0
        foreach swire $swires {
            foreach box [$swire getWires] {
                if {[$box isVia] || [$box getTechLayer] != $layer} {continue}
                lassign $landing_db x1 y1 x2 y2
                if {[$box xMin] <= $x1 && [$box yMin] <= $y1 && [$box xMax] >= $x2 && [$box yMax] >= $y2} {set stripe_ok 1}
                lassign $bridge_db x1 y1 x2 y2
                if {[$box xMin] <= $x1 && [$box yMin] <= $y1 && [$box xMax] >= $x2 && [$box yMax] >= $y2} {
                    error "ground bridge already present: $name"
                }
            }
        }
        if {!$pin_ok || !$stripe_ok} {error "ground bridge lacks actual pin/strap metal: $name"}
    }
    # Validate both targets before making either mutation.
    foreach {name bridge contact landing} $bridges {
        set rectangle {}
        foreach x $bridge {lappend rectangle [expr {round($x*$u)}]}
        odb::dbSBox_create [lindex $swires 0] $layer {*}$rectangle STRIPE
        puts "AUTOMX_GROUND_BRIDGE $name met4 $bridge"
    }
}
