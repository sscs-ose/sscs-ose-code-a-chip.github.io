# The standard-cell M1/M4/M5 grid and core/conditioner macro access retain
# the pinned OpenLane policy. Never disable check_power_grid to pass PDN.
if {$::env(FP_PDN_CHECK_NODES) != 1} {error "FP_PDN_CHECK_NODES must be 1"}
source $::env(SCRIPTS_DIR)/openroad/common/pdn_cfg.tcl
source [file join [file dirname [info script]] repair_wrapper_ground.tcl]

# The ADC has real M4 ring landings to the LEFT of its LEF SIZE boundary.
# Its derived access LEF exposes those two real rectangles and preserves
# all other internal PG metal as OBS. A macro-specific zero PDN halo allows
# the parent M5 straps to reach the external M4 ring; a 10-um PDN halo would
# block those approaches. Placement halos remain enabled independently.
# A non-default instance rule overrides the default macro grid above.
define_pdn_grid -macro -name adc_ring_access -instances {adc_i} \
    -starts_with POWER -grid_over_pg_pins -halo {0 0}
add_pdn_connect -grid adc_ring_access -layers {met4 met5}
puts AUTOMX_ADC_LEFT_RING_M4_PDN_POLICY

# Native LVS (_03) found core_i/condition_i VPWR physically open: their only
# M4 VPWR pins are a 0.6-um bar ending at the core east boundary and a 3-um
# bar inside the conditioner, and the parent M4 straps are cut around both
# macros. Each jumper is one M5 plate with M4M5 vias onto a parent VPWR M4
# strap and onto real macro VPWR pin metal (core: via one M4 pad overlapping
# the bar end by 0.3 um; PSM joins same-layer shapes only through vias, so the
# pad must be a single rectangle). The plate crosses VGND only on M5. Landings
# and spacing are checked against actual DB geometry before creation.
proc automx_overlaps {a b} {
    lassign $a ax1 ay1 ax2 ay2
    lassign $b bx1 by1 bx2 by2
    expr {$ax1 < $bx2 && $bx1 < $ax2 && $ay1 < $by2 && $by1 < $ay2}
}

proc automx_covers {outer inner} {
    lassign $outer ox1 oy1 ox2 oy2
    lassign $inner ix1 iy1 ix2 iy2
    expr {$ox1 <= $ix1 && $oy1 <= $iy1 && $ox2 >= $ix2 && $oy2 >= $iy2}
}

proc automx_dbu {u box {bloat 0}} {
    lassign $box x1 y1 x2 y2
    list [expr {round(($x1-$bloat)*$u)}] [expr {round(($y1-$bloat)*$u)}] [expr {round(($x2+$bloat)*$u)}] [expr {round(($y2+$bloat)*$u)}]
}

# Absolute macro shapes on one layer: {net-or-OBS x1 y1 x2 y2}.
proc automx_macro_shapes {block layer} {
    set shapes {}
    foreach inst [$block getInsts] {
        set master [$inst getMaster]
        if {![$master isBlock]} {continue}
        if {[$inst getOrient] != "R0"} {error "AUTOMX_VPWR_JUMPER [$inst getName] must stay N/R0"}
        lassign [$inst getOrigin] ox oy
        foreach mterm [$master getMTerms] {
            set iterm [$inst findITerm [$mterm getName]]
            set net [$iterm getNet]
            set name [expr {$net == "NULL" ? "UNCONNECTED" : [$net getName]}]
            foreach mpin [$mterm getMPins] {
                foreach box [$mpin getGeometry] {
                    if {[$box getTechLayer] == "NULL" || [[$box getTechLayer] getName] != $layer} {continue}
                    lappend shapes [list $name [expr {[$box xMin]+$ox}] [expr {[$box yMin]+$oy}] [expr {[$box xMax]+$ox}] [expr {[$box yMax]+$oy}]]
                }
            }
        }
        foreach box [$master getObstructions] {
            if {[$box getTechLayer] == "NULL" || [[$box getTechLayer] getName] != $layer} {continue}
            lappend shapes [list OBS [expr {[$box xMin]+$ox}] [expr {[$box yMin]+$oy}] [expr {[$box xMax]+$ox}] [expr {[$box yMax]+$oy}]]
        }
    }
    return $shapes
}

proc automx_special_shapes {block layer} {
    set shapes {}
    foreach net [$block getNets] {
        foreach swire [$net getSWires] {
            foreach box [$swire getWires] {
                if {[$box isVia] || [[$box getTechLayer] getName] != $layer} {continue}
                lappend shapes [list [$net getName] [$box xMin] [$box yMin] [$box xMax] [$box yMax]]
            }
        }
    }
    return $shapes
}

proc automx_macro_vpwr_jumpers {} {
    set block [ord::get_db_block]
    set tech [ord::get_db_tech]
    set u [$block getDbUnitsPerMicron]
    set vpwr [$block findNet VPWR]
    set m4 [$tech findLayer met4]
    set m5 [$tech findLayer met5]
    set via [$tech findVia M4M5_PR]
    if {$vpwr == "NULL" || $m4 == "NULL" || $m5 == "NULL" || $via == "NULL"} {
        error "AUTOMX_VPWR_JUMPER missing VPWR/met4/met5/M4M5_PR"
    }
    # Microns: M4 pin-contact box that must lie on the macro's own VPWR pin,
    # new M4 rectangles, M5 plate, via on parent strap, via on macro side.
    set jumpers {
        core_i {1045.6 103.52 1046.2 104.12}
            {{1045.9 103.02 1048.2 104.62}}
            {1046.6 103.02 1075.9 104.62} {1075.02 103.82} {1047.4 103.82}
        condition_i {1109.6 133.42 1110.4 134.22}
            {}
            {1096.2 129.1 1110.8 134.6} {1097.04 129.9} {1110.0 133.82}
    }
    set m4_macro [automx_macro_shapes $block met4]
    set m5_macro [automx_macro_shapes $block met5]
    set m4_special [automx_special_shapes $block met4]
    set m5_special [automx_special_shapes $block met5]
    set planned {}
    foreach {instname contact m4_rects plate strap pinvia} $jumpers {
        if {[$block findInst $instname] == "NULL"} {error "AUTOMX_VPWR_JUMPER missing $instname"}
        set contact_db [automx_dbu $u $contact]
        set on_pin 0
        foreach shape $m4_macro {
            set box [lrange $shape 1 4]
            if {[lindex $shape 0] == "VPWR" && [automx_covers $box $contact_db]} {set on_pin 1}
            if {[lindex $shape 0] != "VPWR" && [automx_overlaps $box [automx_dbu $u $contact 0.3]]} {
                error "AUTOMX_VPWR_JUMPER $instname: [lindex $shape 0] M4 within 0.3um of pin contact"
            }
        }
        if {!$on_pin} {error "AUTOMX_VPWR_JUMPER $instname: no VPWR M4 pin under $contact"}
        lassign $strap sx sy
        set strap_land [automx_dbu $u [list [expr {$sx-0.59}] [expr {$sy-0.59}] [expr {$sx+0.59}] [expr {$sy+0.59}]]]
        set on_strap 0
        foreach shape $m4_special {
            if {[lindex $shape 0] == "VPWR" && [automx_covers [lrange $shape 1 4] $strap_land]} {set on_strap 1}
        }
        if {!$on_strap} {error "AUTOMX_VPWR_JUMPER $instname: no parent VPWR M4 strap under $strap"}
        lassign $pinvia px py
        set pin_land [automx_dbu $u [list [expr {$px-0.59}] [expr {$py-0.59}] [expr {$px+0.59}] [expr {$py+0.59}]]]
        set m4_new [concat [list $contact] $m4_rects]
        set covered 0
        foreach rect $m4_new {if {[automx_covers [automx_dbu $u $rect] $pin_land]} {set covered 1}}
        foreach shape $m4_macro {
            if {[lindex $shape 0] == "VPWR" && [automx_covers [lrange $shape 1 4] $pin_land]} {set covered 1}
        }
        if {!$covered} {error "AUTOMX_VPWR_JUMPER $instname: macro-side via lacks M4 enclosure"}
        foreach rect $m4_rects {
            foreach shape [concat $m4_macro $m4_special] {
                if {[lindex $shape 0] != "VPWR" && [automx_overlaps [lrange $shape 1 4] [automx_dbu $u $rect 0.3]]} {
                    error "AUTOMX_VPWR_JUMPER $instname: [lindex $shape 0] M4 within 0.3um of $rect"
                }
            }
        }
        foreach shape [concat $m5_macro $m5_special] {
            if {[automx_overlaps [lrange $shape 1 4] [automx_dbu $u $plate 1.6]]} {
                error "AUTOMX_VPWR_JUMPER $instname: [lindex $shape 0] M5 within 1.6um of plate"
            }
        }
        lappend planned $instname $m4_rects $plate $strap $pinvia
    }
    # Append to pdngen's own VPWR wire: a second "+ ROUTED" block is legal
    # DEF, but pinned Magic loses sync on it and drops all later NETS (_22_01
    # XOR 624427 differences).
    set swires [$vpwr getSWires]
    if {[llength $swires] != 1} {error "AUTOMX_VPWR_JUMPER expected one pdngen VPWR SWire, found [llength $swires]"}
    set swire [lindex $swires 0]
    foreach {instname m4_rects plate strap pinvia} $planned {
        foreach rect $m4_rects {
            odb::dbSBox_create $swire $m4 {*}[automx_dbu $u $rect] STRIPE
        }
        odb::dbSBox_create $swire $m5 {*}[automx_dbu $u $plate] STRIPE
        foreach point [list $strap $pinvia] {
            lassign $point x y
            odb::dbSBox_create $swire $via [expr {round($x*$u)}] [expr {round($y*$u)}] STRIPE
        }
        puts "AUTOMX_VPWR_JUMPER $instname plate=$plate strap=$strap pin=$pinvia"
    }
}

# Preserve generated geometry BEFORE OpenLane's check_power_grid. If the
# checker still fails, the export has the exact failing DEF/ODB, not merely
# the pre-PDN tapcell database. These are diagnostics, never a passing view.
if {[llength [info commands automx_wrapper_original_pdngen]] == 0} {
    rename pdngen automx_wrapper_original_pdngen
    proc pdngen {args} {
        set result [uplevel 1 automx_wrapper_original_pdngen {*}$args]
        automx_macro_vpwr_jumpers
        automx_ground_bridges
        set folder [file join $::env(RUN_DIR) tmp wrapper_pdn]
        file mkdir $folder
        write_db [file join $folder generated.odb]
        write_def [file join $folder generated.def]
        puts AUTOMX_WRAPPER_PDN_GEOMETRY_RECORDED
        return $result
    }
}
