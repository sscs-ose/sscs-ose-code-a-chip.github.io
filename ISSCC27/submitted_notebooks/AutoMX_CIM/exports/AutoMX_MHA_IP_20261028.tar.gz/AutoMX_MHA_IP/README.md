# AutoMX MHA RTL IP

Copyright 2026 EDABK Laboratory.

This package contains the synthesizable 2-token, 4-channel, 2-head MHA IP, its CIM/SAR integrated RTL top, both functional testbenches, and five hard-macro LEF/GDS views, including independently routed MHA and readout/calibration. No stored simulation results are used as test inputs.

Run from this extracted folder using Python with NumPy and native Icarus Verilog installed:

```bash
python ip/automx_mha/verify.py --root . --work output
```

See ip/automx_mha/README.md and manifest.json for ports, number formats, softmax approximation and verification scope. Use the included FuseSoC filesets or your ASIC flow to bind the physical macro views from inputs/. The digital blocks also carry routed gate netlists and SPEFs for hierarchical STA. Their Liberty models contain physical port constraints for placement/CTS; actual timing uses the gate netlists and extracted parasitics. SKY130 PDK and physical tools are external flow dependencies. The full laboratory notebook supplies their configuration and cold implementation.
